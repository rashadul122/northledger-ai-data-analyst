#!/usr/bin/env python3
"""
The inference core's statistics, written by hand so the engine runs in a browser.

The browser engine (Pyodide) loads numpy, pandas and sqlite3 only; there is no scipy. So
the few special functions the change test needs are here, each small enough to read:

  * random draws: only ``Generator.random()`` (NEP 19's stable subset, so a seed gives the
    same stream on any numpy release), with normals by the Box-Muller transform;
  * the regularised incomplete beta function (Lentz's continued fraction), and from it the
    Student-t distribution function and the beta quantile (Clopper-Pearson intervals);
  * Benjamini-Hochberg's step-up procedure and its adjusted q-values, and the gate's
    role-structured family rule (family_lines);
  * the change test itself (design §2.1 M1, M2, M4): one estimand, one unit, one model.

The change test
---------------
Estimand: the ratio of the average month in the latest 12 months to the average month in
the 12 before, where a month is the monthly total (volume) or the monthly mean (a measure).
Model, on the log of the monthly values, so delta is a log ratio::

    log y_t = level + seasonal terms + older * 1[t before the prior 12]
              + delta * 1[t in latest 12] + u_t

fitted by restricted maximum likelihood (REML) over a grid, by exact GLS (months with no
value are gaps, handled exactly). The months before the prior window carry their own level
(`older`), so delta compares the latest 12 months with the 12 before them, the headline's
comparison, while the older months still inform the seasonal terms and the momentum (review
of R1, 23 Sep 2026: with up to 24 months before, the printed interval could exclude its own
headline). The seasonal terms are 11 monthly indicators (R1 registers no screen that drops
them).

Two error models are fitted. The TEST STATISTIC's model has AR(1) errors (phi on PHI_GRID).
The MOMENTUM-PLUS-NOISE model has AR(1) plus white noise (ARMA(1,1)): a volume is a count,
with counting noise on top of the business's momentum, and a measure's monthly mean carries
its rows' sampling noise; a pure AR(1) fit sees phi through that white noise and
under-states the dependence (review of R1: the rule then confirmed 1.3-3.0% of no-change
series at the bar, nominal 1%). Its grid is (phi, white-noise share) on GRID.

Test (M2): the one-sided minimum-effect null H0: delta <= log(1 + bar) for a rise (or
delta >= log(1 - bar) for a fall: the same bar both ways in the reader's percentage, see
bar_log; the direction is the HEADLINE's), with the studentised
statistic t = (d - d0) / SE of the AR(1) model. Its null distribution is a parametric
bootstrap: simulate B series from the null model at delta = d0, refit the AR(1) model on
each, re-estimating phi every time, and p = (1 + #{t* >= t}) / (B + 1). The bootstrap's
errors are AR(1) at a momentum chosen by BOOT_RULE (TrendModel.boot_index): by default a
weighted average of (a) the restricted momentum-plus-noise fit's phi and (b) the larger of the
restricted AR(1) fit's phi and the momentum-plus-noise model's phi, so the persistence a pure
AR(1) fit misses under white noise is drawn from. Neither restricted phi goes above the upper
end of the full AR(1) model's profile-likelihood interval for phi (PHI_CAP_LR, and the looser
PHI_CAP_LR_NOISE for (a)): far from the estimate the restricted model, whose shift is fixed at a
wrong value, puts the step into persistence (phi 0.9-0.99 on iid data), and the p-value then
stopped falling as evidence grew (review of R1).

The GLS estimate is equivariant, so t* depends only on the bootstrap's error model (its
grid point), not on the null fit's level, seasonal terms or scale. So one batch of B
bootstrap refits per grid point serves every d0 whose null model lands on it, which is what
makes the interval by test inversion (M4) affordable: with the grid point held fixed the
bound is a quantile of the batch's t*, re-checked against its own grid point until the two
agree.

Sizes: the test runs at B_TEST (1,999) and its 95% interval inverts it at B_CI (1,999). The
caller extends B to 9,999 only while the 99% Monte Carlo interval of p straddles the line
that decides the claim (§1.1), and asks for one-sided selection-adjusted bounds at the tails
its false-discovery family needs (fcr_tails).

Estimand check: the model's estimate and the headline (the plain ratio of the average
months, computed here from the same monthly values) must point the same way whenever either
is at least the bar; otherwise the model cannot separate a change from the series' own drift
and no test is printed beside that headline (review of R1: a 32% fall was printed beside
the p and interval of a +1.8% rise).

Drift screen (M2): the claim is capped when the AR(1) model's profile likelihood cannot
exclude phi >= 0.95 AND its own phi estimate is at least 0.9 (a wandering series; UR_MODEL can
switch the screen to the momentum-plus-noise model's profile), or when a linear trend is
established in the same model with the shift in it (a steadily growing series always shows a
12-versus-12 gap). With 24 months and seasonal terms a trend cannot be told from a step: the
screen says so.

Python 3.9, numpy + stdlib.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

TREND_KIND = "northledger.trend_test/1"
#: The claim key suffix of a like-for-like twin ('total:amount:rent:like_for_like').
LIKE_FOR_LIKE_SUFFIX = ":like_for_like"
TREND_SEED = 20260923

#: phi grid for the AR(1) REML fit: -0.5 to 0.95 in steps of 0.05, plus 0.97 and 0.99 (the
#: drift screen asks whether phi >= 0.95 can be excluded).
PHI_GRID: Tuple[float, ...] = tuple([round(-0.5 + 0.05 * i, 2) for i in range(30)] + [0.97, 0.99])
UNIT_ROOT_PHI = 0.95
#: The unit-root screen fires when phi >= 0.95 is inside the profile-likelihood interval at
#: this chi-square(1) cut-off (2.706 = the one-sided 5% point, i.e. a 90% two-sided interval)
#: AND the screened model's phi estimate is at least UNIT_ROOT_PHI_HAT.
UNIT_ROOT_LR = 2.706
#: The REML profile of phi on 11-23 degrees of freedom is too flat to exclude 0.95 on most
#: momentum series: without this condition the screen fired on 88% of AR(1) 0.8, 24-month
#: series, removed almost no false confirmations and cost power (review of R1, 23 Sep 2026).
UNIT_ROOT_PHI_HAT = 0.9
#: A linear trend is "established" when its two-sided p in the model with the shift is below
#: this. Chosen by the engine's own confirmation level (1%): the screen stops confirmations,
#: so it answers the same question at the same strictness.
TREND_SCREEN_P = 0.01
#: With the best single level shift in the model, a momentum at most this means the shift, not
#: a drift, explains the series (TrendModel.step_screen, review v2).
STEP_PHI_MAX = 0.5
#: Bootstrap sizes (§1.1). The normals are drawn in these nested blocks, so the first b
#: columns are the same whatever B a claim ends at.
B_LADDER: Tuple[int, ...] = (399, 1999, 9999)
#: The test's first size, and the 95% interval's (review of R1: every claim is tested once at
#: B_TEST; only a claim whose Monte Carlo interval straddles the line that decides it is
#: extended to 9,999, by the caller).
B_TEST = 1999
B_CI = 1999
MC_LEVEL = 0.99
#: Two-sided interval tails a caller may ask for by name (kept for recorded payloads).
CI_TAILS: Tuple[float, ...] = (0.025, 0.005, 0.0025, 0.0005, 0.00025, 0.00005)
#: The months the model reads, at most: the latest 12 and up to 24 before them. The design's
#: evidence (§2.1 M2 table) covers 24 and 36 months; older history is left to the forecast.
MODEL_MONTHS_MAX = 36
#: Fewer observed months than this in either window, or fewer residual degrees of freedom,
#: and no test is run.
MIN_MONTHS_PER_WINDOW = 10
MIN_RESIDUAL_DF = 6


# =========================================================================== random draws
def normals(rng: np.random.Generator, shape: Any) -> np.ndarray:
    """Standard normals by Box-Muller on rng.random() only (NEP 19's stable subset)."""
    shape = (int(shape),) if isinstance(shape, (int, np.integer)) else tuple(int(s) for s in shape)
    size = int(np.prod(shape)) if shape else 1
    m = (size + 1) // 2
    u1 = rng.random(m)
    u2 = rng.random(m)
    r = np.sqrt(-2.0 * np.log1p(-u1))
    z = np.concatenate([r * np.cos(2.0 * np.pi * u2), r * np.sin(2.0 * np.pi * u2)])
    return z[:size].reshape(shape)


def generator(*keys: int) -> np.random.Generator:
    """A seeded Generator from integer keys (PCG64 via SeedSequence: stable by NEP 19)."""
    return np.random.Generator(np.random.PCG64(np.random.SeedSequence([int(k) & 0xFFFFFFFF for k in keys])))


# =========================================================================== special functions
def _betacf(a: float, b: float, x: float) -> float:
    """Continued fraction for the incomplete beta function (modified Lentz)."""
    tiny = 1e-300
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c, d = 1.0, 1.0 - qab * x / qap
    if abs(d) < tiny:
        d = tiny
    d = 1.0 / d
    h = d
    for m in range(1, 400):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        d = tiny if abs(d) < tiny else d
        c = 1.0 + aa / c
        c = tiny if abs(c) < tiny else c
        d = 1.0 / d
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        d = tiny if abs(d) < tiny else d
        c = 1.0 + aa / c
        c = tiny if abs(c) < tiny else c
        d = 1.0 / d
        de = d * c
        h *= de
        if abs(de - 1.0) < 1e-15:
            break
    return h


def betainc(a: float, b: float, x: float) -> float:
    """Regularised incomplete beta I_x(a, b), a, b > 0, 0 <= x <= 1."""
    if a <= 0 or b <= 0:
        raise ValueError("betainc needs a, b > 0")
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    lbt = (math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b)
           + a * math.log(x) + b * math.log1p(-x))
    if x < (a + 1.0) / (a + b + 2.0):
        return math.exp(lbt) * _betacf(a, b, x) / a
    return 1.0 - math.exp(lbt) * _betacf(b, a, 1.0 - x) / b


def t_cdf(t: float, df: float) -> float:
    """Student-t distribution function."""
    if df <= 0:
        raise ValueError("df must be positive")
    if math.isinf(t):
        return 1.0 if t > 0 else 0.0
    x = df / (df + t * t)
    tail = 0.5 * betainc(0.5 * df, 0.5, x)
    return 1.0 - tail if t > 0 else tail


def t_two_sided_p(t: float, df: float) -> float:
    return min(1.0, 2.0 * t_cdf(-abs(t), df))


def _bisect(f, lo: float, hi: float, iters: int = 200, tol: float = 1e-14) -> float:
    flo = f(lo)
    for _ in range(iters):
        mid = 0.5 * (lo + hi)
        fm = f(mid)
        if (fm > 0) == (flo > 0):
            lo, flo = mid, fm
        else:
            hi = mid
        if hi - lo < tol:
            break
    return 0.5 * (lo + hi)


def t_ppf(q: float, df: float) -> float:
    """Student-t quantile, by bisection on t_cdf."""
    if not 0.0 < q < 1.0:
        raise ValueError("q must be in (0, 1)")
    if q == 0.5:
        return 0.0
    hi = 1.0
    while t_cdf(hi, df) < max(q, 1.0 - q):
        hi *= 2.0
        if hi > 1e12:
            break
    x = _bisect(lambda t: t_cdf(t, df) - max(q, 1.0 - q), 0.0, hi, tol=1e-13)
    return x if q > 0.5 else -x


def beta_ppf(q: float, a: float, b: float) -> float:
    """Beta(a, b) quantile, by bisection on betainc."""
    if q <= 0.0:
        return 0.0
    if q >= 1.0:
        return 1.0
    return _bisect(lambda x: betainc(a, b, x) - q, 0.0, 1.0, tol=1e-15)


def clopper_pearson(k: int, n: int, level: float = 0.95) -> Tuple[float, float]:
    """Exact binomial interval for k successes in n trials, from beta quantiles."""
    if n <= 0:
        return (0.0, 1.0)
    a = 1.0 - level
    lo = 0.0 if k <= 0 else beta_ppf(a / 2.0, k, n - k + 1)
    hi = 1.0 if k >= n else beta_ppf(1.0 - a / 2.0, k + 1, n - k)
    return (lo, hi)


def mc_interval(count: int, b: int, level: float = MC_LEVEL) -> Tuple[float, float]:
    """
    Monte Carlo interval of a resampled p-value p = (1 + count) / (b + 1): the Clopper-Pearson
    interval of the exceedance probability from `count` of `b` resamples.
    """
    return clopper_pearson(int(count), int(b), level)


# =========================================================================== multiple testing
def benjamini_hochberg(pvalues: Sequence[float], q: float) -> Dict[str, Any]:
    """
    Benjamini-Hochberg step-up at level q. Returns which hypotheses are rejected, the
    adjusted q-values, and the rejection threshold q*k/m (0 when nothing is rejected).
    """
    p = [float(x) for x in pvalues]
    m = len(p)
    if m == 0:
        return {"reject": [], "q_values": [], "threshold": 0.0, "k": 0, "m": 0}
    order = sorted(range(m), key=lambda i: p[i])
    k = 0
    for rank, i in enumerate(order, start=1):
        if p[i] <= q * rank / m:
            k = rank
    thr = q * k / m if k else 0.0
    reject = [p[i] <= thr and k > 0 for i in range(m)]
    qv = [0.0] * m
    running = 1.0
    for rank in range(m, 0, -1):
        i = order[rank - 1]
        running = min(running, p[i] * m / rank)
        qv[i] = min(1.0, running)
    return {"reject": reject, "q_values": qv, "threshold": thr, "k": k, "m": m}


# =========================================================================== the model
#: Share of the monthly noise's variance that is white (counting or measurement noise), on a
#: grid, for the momentum-plus-noise model (AR(1) plus white noise, i.e. ARMA(1,1)). 0 is the
#: pure AR(1) model.
NOISE_GRID: Tuple[float, ...] = (0.0, 0.15, 0.3, 0.5, 0.7)
#: With white noise on top, phi is gridded up to this (0.99: the whole range). Measured: on a
#: clean iid series the momentum-plus-noise fit lands in the near-unit-root-plus-noise corner
#: about 9% of the time (18 of 200 30-month series with an 11% step), which makes the bootstrap
#: more cautious there; cutting the grid at 0.9 removed that and also removed most of the
#: protection under real white noise (the AR(1) plus white-noise and small-count cells rose to
#: 1.6-2.6% at 1,000 series a cell), so the whole range is kept.
NOISE_PHI_MAX = 0.99


def _make_grid(phis: Sequence[float], noises: Sequence[float]) -> Tuple[Tuple[float, float], ...]:
    """(phi, white-noise share) pairs: every phi without white noise; with it, 0 < phi <= 0.9."""
    g = [(float(p), 0.0) for p in phis]
    for lam in noises:
        if lam > 0:
            g.extend((float(p), float(lam)) for p in phis if 0 < p <= NOISE_PHI_MAX + 1e-12)
    return tuple(g)


#: The error models' grid. Its first len(PHI_GRID) points are the pure AR(1) model's.
GRID: Tuple[Tuple[float, float], ...] = _make_grid(PHI_GRID, NOISE_GRID)
_GRID_PHI = np.array([g[0] for g in GRID])
_GRID_NOISE = np.array([g[1] for g in GRID])
_AR1 = np.flatnonzero(_GRID_NOISE == 0.0)

#: The restricted fit (delta fixed at d0) may not place phi above the upper end of the full
#: model's profile-likelihood interval for phi at this chi-square(1) cut-off (3.841, the 5%
#: point: the full model's 95% interval). At the bar, where the restricted model is right, the
#: cap rarely binds; far from the estimate it stops the restricted fit putting the step into
#: persistence. Measured (600 series a cell, iid 24 months): at the 1% point (6.635) a +100%
#: change still had a median p of 0.0025 and a +50% change was confirmed 41% of the time; at
#: 3.841, 0.0005 and 60%, with the no-change rate at the bar 0.5-1.0% in the AR(1) cells.
PHI_CAP_LR = 3.841
#: The same cap for the momentum-plus-noise restricted fit (BOOT_RULE "H" and "mix"), at the 1%
#: point (6.635): that fit is the one that keeps the no-change rate down under white noise, and
#: capping it at the 95% interval gave that protection back (measured: the AR(1) plus white
#: noise cells rose from about 1.6% to 2.1-2.9% at 1,000 series a cell).
PHI_CAP_LR_NOISE = 6.635
#: The bootstrap's momentum rule (TrendModel.boot_index), an operating point chosen by
#: measurement (review of R1, 23 Sep 2026; the candidates' ROC is in the release report). With
#: "mix" at 0.3 the rule confirmed, at the 5% bar with no change beyond it (2,000 series a cell):
#: AR(1) 0.8-0.9 plus white noise 0.75-1.45%, monthly counts of 100-1,000 with AR(1) 0.8 momentum
#: 0.65-1.55%, pure AR(1) 0.30-0.80%; power at a 20% change 19% (24 months) and 40% (36 months).
#: In earlier candidates "H" held every cell under 1.3% at about half that power, and "H2" kept
#: the power and left the white-noise cells at 2.2-2.8%. Move it with the benchmark, not by eye:
#:   "H2"  the larger of the restricted AR(1) fit's phi (capped) and the momentum-plus-noise
#:         model's phi (the persistence seen through white noise);
#:   "H"   the restricted momentum-plus-noise fit's phi (capped): the most conservative;
#:   "mix" their average, weight MIX_W on "H".
BOOT_RULE = "mix"
MIX_W = 0.3
#: Which profile the unit-root screen reads: "2d" the momentum-plus-noise model's (profiled over
#: the white-noise share: a random walk plus noise wanders too), "1d" the AR(1) model's.
UR_MODEL = "1d"
#: A sign disagreement between the model's change and the headline counts when either is at
#: least the bar (log scale).
ESTIMAND_SIGN_RULE = "opposite signs, either at least the bar"


@dataclass
class _Design:
    """Per-grid-point GLS pieces for one design at fixed observation times."""
    M: np.ndarray                 # (G, k, n): the residual basis (n - p rows), then delta's weights
    ld: np.ndarray                # (G,) log|Sigma| + log|X' Sigma^-1 X| (REML)
    v: Optional[np.ndarray]       # (G,) (X' Sigma^-1 X)^-1 [delta, delta]
    n: int
    p: int
    has_delta: bool


def _chol(times: np.ndarray, idx: np.ndarray) -> np.ndarray:
    """Cholesky factors of the error correlation matrix at the grid points idx, (G, n, n)."""
    t = np.asarray(times, dtype=float)
    D = np.abs(t[:, None] - t[None, :])
    phi = _GRID_PHI[idx][:, None, None]
    lam = _GRID_NOISE[idx][:, None, None]
    with np.errstate(all="ignore"):
        R = np.where(D[None] == 0.0, 1.0, np.power(phi, D[None]))
    C = (1.0 - lam) * R + lam * np.eye(len(t))[None]
    return np.linalg.cholesky(C)


def _design(X: np.ndarray, W: np.ndarray, logdet_c: np.ndarray, j_delta: Optional[int]) -> Optional[_Design]:
    """GLS through the whitening W = L^-1 at every grid point (vectorised over the grid)."""
    G, n, _ = W.shape
    p = X.shape[1]
    if n <= p:
        return None
    with np.errstate(all="ignore"):
        Q, R = np.linalg.qr(W @ X, mode="complete")
    Rp = R[:, :p, :]
    dg = np.abs(np.diagonal(Rp, axis1=1, axis2=2))
    if not np.all(np.isfinite(dg)) or np.any(dg.min(axis=1) <= 1e-9 * np.maximum(1.0, dg.max(axis=1))):
        return None                                   # the design is rank-deficient
    Qt = np.swapaxes(Q, 1, 2)
    with np.errstate(all="ignore"):
        N = Qt[:, p:, :] @ W                          # rss = || N y ||^2
    ld = logdet_c + 2.0 * np.sum(np.log(dg), axis=1)
    if j_delta is None:
        return _Design(M=np.ascontiguousarray(N), ld=ld, v=None, n=n, p=p, has_delta=False)
    e = np.zeros((G, p, 1))
    e[:, j_delta, 0] = 1.0
    w = np.linalg.solve(np.swapaxes(Rp, 1, 2), e)[:, :, 0]          # R^-T e_delta
    with np.errstate(all="ignore"):
        a = (w[:, None, :] @ Qt[:, :p, :]) @ W                       # delta_hat = a y
    v = np.sum(w * w, axis=1)
    return _Design(M=np.ascontiguousarray(np.concatenate([N, a], axis=1)), ld=ld, v=v, n=n, p=p,
                   has_delta=True)


def _fit(d: _Design, Y: np.ndarray, sub: Optional[np.ndarray] = None) -> Dict[str, np.ndarray]:
    """REML over the design's grid points (or the positions `sub` among them), per column of Y."""
    Y2 = Y[:, None] if Y.ndim == 1 else Y
    M = d.M if sub is None else d.M[sub]
    ld = d.ld if sub is None else d.ld[sub]
    G, k, n = M.shape
    B = Y2.shape[1]
    Mf = M.reshape(G * k, n)
    dfree = d.n - d.p
    rss = np.empty((G, B))
    dh = np.empty((G, B)) if d.has_delta else None
    step = max(1, int(1_500_000 // (G * k)))
    # numpy 2.0.x with Apple's Accelerate raises spurious floating-point flags inside matmul (a
    # plain product of two random matrices "divides by zero"); the flags are silenced and the
    # results are checked for finiteness instead.
    with np.errstate(all="ignore"):
        for s in range(0, B, step):
            Z = (Mf @ Y2[:, s:s + step]).reshape(G, k, -1)
            R = Z[:, :-1] if dh is not None else Z
            if dh is not None:
                dh[:, s:s + step] = Z[:, -1]
            rss[:, s:s + step] = np.einsum("gkb,gkb->gb", R, R)
        rss = np.maximum(rss, 1e-300)
        ll = -0.5 * (ld[:, None] + dfree * np.log(rss))
    if not (np.all(np.isfinite(ll)) and (dh is None or np.all(np.isfinite(dh)))):
        raise FloatingPointError("the model fit returned a non-finite value")
    kk = np.argmax(ll, axis=0)
    cols = np.arange(B)
    out = {"k": kk if sub is None else np.asarray(sub)[kk], "ll": ll}
    if dh is not None:
        v = d.v if sub is None else d.v[sub]
        out["delta"] = dh[kk, cols]
        out["se"] = np.sqrt(rss[kk, cols] / dfree * v[kk])
    return out


def _nearest(idx: np.ndarray, phi: float) -> int:
    """The grid point among idx whose phi is nearest `phi`."""
    return int(idx[int(np.argmin(np.abs(_GRID_PHI[idx] - phi)))])


class TrendModel:
    """One claim's model, with its bootstrap draws cached by the bootstrap's phi."""

    def __init__(self, y: np.ndarray, times: np.ndarray, latest: np.ndarray, seed: int,
                 seasonal: bool = True, older: Optional[np.ndarray] = None) -> None:
        self.y = np.asarray(y, dtype=float)
        self.times = np.asarray(times, dtype=int)
        self.latest = np.asarray(latest, dtype=bool)
        self.seed = int(seed)
        n = len(self.y)
        cols = [np.ones(n)]
        names = ["level"]
        self.seasonal_terms = 0
        if seasonal:
            moy = self.times % 12
            present = sorted(set(int(m) for m in moy))
            for m in present[1:]:                       # first month present is the reference
                col = (moy == m).astype(float)
                if col.sum() >= 1:
                    cols.append(col)
                    names.append("month_%02d" % (m + 1))
                    self.seasonal_terms += 1
        self.older_term = False
        if older is not None:
            o = np.asarray(older, dtype=bool)
            if o.any() and not o.all():
                cols.append(o.astype(float))
                names.append("older")
                self.older_term = True
        cols.append(self.latest.astype(float))
        names.append("delta")
        self.X = np.column_stack(cols)
        self.names = names
        self.j_delta = len(names) - 1
        self.Xr = self.X[:, :self.j_delta]
        self.full: Optional[_Design] = None
        self.restricted: Optional[_Design] = None
        self._tstar: Dict[int, np.ndarray] = {}         # grid index -> t* (B,)
        self.se = 0.0
        self.sigma = 0.0
        try:
            self.L = _chol(self.times, np.arange(len(GRID)))
        except np.linalg.LinAlgError:
            return
        W = np.linalg.inv(self.L)
        self.logdet_c = 2.0 * np.sum(np.log(np.diagonal(self.L, axis1=1, axis2=2)), axis=1)
        self._W = W
        self.full = _design(self.X, W, self.logdet_c, self.j_delta)
        self.restricted = _design(self.Xr, W, self.logdet_c, None) if self.full is not None else None
        if self.full is None or self.restricted is None:
            return
        # the momentum-plus-noise model: every grid point
        f2 = _fit(self.full, self.y)
        self.profile2 = f2["ll"][:, 0]
        self.k2 = int(f2["k"][0])
        # the test statistic's model: AR(1), the first len(PHI_GRID) grid points
        f1 = _fit(self.full, self.y, sub=_AR1)
        self.k_hat = int(f1["k"][0])
        self.delta = float(f1["delta"][0])
        self.se = float(f1["se"][0])
        # the AR(1) model's residual scale: the marginal SD of the log monthly noise (about the
        # month-to-month CV once the seasonal terms and the shift are allowed for)
        vk = float(self.full.v[self.k_hat]) if self.full.v is not None else 0.0
        self.sigma = self.se / math.sqrt(vk) if vk > 0 else 0.0
        self.profile = f1["ll"][:, 0]                  # over PHI_GRID
        inside = 2.0 * (float(np.max(self.profile)) - self.profile) <= PHI_CAP_LR
        self.phi_cap = float(np.max(_GRID_PHI[_AR1][inside]))
        inside = 2.0 * (float(np.max(self.profile)) - self.profile) <= PHI_CAP_LR_NOISE
        self.phi_cap_noise = float(np.max(_GRID_PHI[_AR1][inside]))

    @property
    def ok(self) -> bool:
        return self.full is not None and self.restricted is not None and self.se > 1e-12

    @property
    def n(self) -> int:
        return len(self.y)

    @property
    def df(self) -> int:
        return self.full.n - self.full.p if self.full is not None else 0

    def phi_hat(self) -> float:
        """The test statistic's AR(1) phi."""
        return float(_GRID_PHI[self.k_hat])

    def phi_hat_2d(self) -> float:
        """phi of the momentum-plus-noise model (the persistence seen through white noise)."""
        return float(_GRID_PHI[self.k2])

    def noise_share_hat(self) -> float:
        return float(_GRID_NOISE[self.k2])

    def boot_index(self, d0: float) -> int:
        """
        The bootstrap's error model for the null delta = d0: AR(1) at a phi on PHI_GRID (its
        grid index). BOOT_RULE "H2": the larger of the restricted AR(1) fit's phi, capped at the
        AR(1) full model's interval, and the momentum-plus-noise model's phi. "H": the
        restricted momentum-plus-noise fit's phi, capped. "mix": their weighted average.
        """
        z = self.y - d0 * self.latest.astype(float)
        f1 = _fit(self.restricted, z, sub=_AR1)
        phi_h2 = max(min(float(_GRID_PHI[int(f1["k"][0])]), self.phi_cap), self.phi_hat_2d())
        if BOOT_RULE == "H2":
            return _nearest(_AR1, phi_h2)
        f2 = _fit(self.restricted, z)
        phi_h = min(float(_GRID_PHI[int(f2["k"][0])]), self.phi_cap_noise)
        if BOOT_RULE == "H":
            return _nearest(_AR1, phi_h)
        return _nearest(_AR1, MIX_W * phi_h + (1.0 - MIX_W) * phi_h2)

    # kept under its R1 names for callers and tests
    restricted_index = boot_index
    restricted_phi_index = boot_index

    def boot_params(self, k: int) -> Tuple[float, float]:
        """(phi, white-noise share) of a bootstrap index."""
        return float(_GRID_PHI[k]), float(_GRID_NOISE[k])

    def _normals(self, b: int) -> np.ndarray:
        blocks = [B_LADDER[0]] + [B_LADDER[i] - B_LADDER[i - 1] for i in range(1, len(B_LADDER))]
        parts, have, i = [], 0, 0
        while have < b:
            size = blocks[i] if i < len(blocks) else b - have
            parts.append(normals(generator(self.seed, 7919, i), (self.n, size)))
            have += size
            i += 1
        return np.concatenate(parts, axis=1)[:, :b]

    def tstar(self, k: int, b: int) -> np.ndarray:
        """Bootstrap t* for the bootstrap index k, B = b (nested, cached)."""
        cur = self._tstar.get(k)
        if cur is not None and len(cur) >= b:
            return cur[:b]
        start = 0 if cur is None else len(cur)
        E = self._normals(b)[:, start:b]
        with np.errstate(all="ignore"):
            U = self.L[k] @ E                           # errors with the bootstrap's correlation
        f = _fit(self.full, U, sub=_AR1)
        t = f["delta"] / f["se"]
        new = t if cur is None else np.concatenate([cur, t])
        self._tstar[k] = new
        return new[:b]

    def exceed(self, d0: float, direction: int, b: int) -> Tuple[int, int]:
        """(#{t* at least as extreme as t_obs in `direction`}, the bootstrap's grid index)."""
        k = self.boot_index(d0)
        t_obs = (self.delta - d0) / self.se
        ts = self.tstar(k, b)
        if direction > 0:
            c = int(np.sum(ts >= t_obs - 1e-12))
        elif direction < 0:
            c = int(np.sum(ts <= t_obs + 1e-12))
        else:
            c = int(np.sum(np.abs(ts) >= abs(t_obs) - 1e-12))
        return c, k

    def pvalue(self, d0: float, direction: int, b: int) -> float:
        c, _ = self.exceed(d0, direction, b)
        return (1.0 + c) / (b + 1.0)

    def _bound_at(self, k: int, tail: float, side: int, b: int) -> float:
        """The bound from one batch of t* (grid point k): exact, a quantile of t*."""
        ts = np.sort(self.tstar(k, b))
        c_min = int(math.floor(tail * (b + 1.0) - 1.0 + 1e-9)) + 1    # p > tail <=> count >= c_min
        c_min = min(max(c_min, 1), b)
        T = ts[b - c_min] if side < 0 else ts[c_min - 1]
        return self.delta - self.se * float(T)

    def bound(self, tail: float, side: int, b: int) -> Optional[float]:
        """
        One-sided confidence bound by test inversion: side -1 gives the lower bound, the d0
        at which the test of H0: delta <= d0 has p equal to `tail`; side +1 the upper bound.
        With the bootstrap's grid point held fixed, p is monotone in d0 and the bound is a
        quantile of that batch's t*; the bound is then re-checked against its own grid point,
        and the search repeats until the two agree (the test at the bound uses the batch the
        bound came from). A cycle takes the outer of its bounds. None when `tail` is below the
        resolution 1/(b+1) of b resamples.
        """
        if tail * (b + 1) < 1.0:
            return None
        k = self.boot_index(self.delta + side * 2.0 * self.se)
        seen: Dict[int, float] = {}
        for _ in range(8):
            d = self._bound_at(k, tail, side, b)
            seen[k] = d
            k2 = self.boot_index(d)
            if k2 == k:
                return d
            if k2 in seen:
                break
            k = k2
        vals = list(seen.values())
        return min(vals) if side < 0 else max(vals)

    def trend_screen(self) -> Dict[str, Any]:
        """
        A linear trend in the same model (with the shift in it): established or not. The
        separate level for the older months is left out here: with it, a trend over the whole
        history is confounded with that level and the screen went blind (measured: steady 1%
        a month growth, 36 months, no step, was confirmed in 81 of 150 series).
        """
        tc = (self.times - self.times.mean()) / 12.0
        keep = [i for i, nm in enumerate(self.names) if nm != "older"]
        X = np.column_stack([self.X[:, keep], tc])
        gf = _design(X, self._W[_AR1], self.logdet_c[_AR1], X.shape[1] - 1)
        if gf is None or gf.n - gf.p < 3:
            return {"assessable": False, "why": "with %d months and seasonal terms a steady trend "
                                                "cannot be told apart from a step" % self.n}
        f = _fit(gf, self.y)
        t = float(f["delta"][0] / f["se"][0])
        p = t_two_sided_p(t, gf.n - gf.p)
        return {"assessable": True, "slope_per_year": float(f["delta"][0]), "t": t, "p": p,
                "df": gf.n - gf.p, "phi": float(_GRID_PHI[int(f["k"][0])]),
                "established": bool(p < TREND_SCREEN_P)}

    def step_screen(self, latest_start: int) -> Dict[str, Any]:
        """
        Is the series one level shift rather than a drift (review v2, 24 Sep 2026: a planted +25%
        price step was graded "this series wanders")? The single step that best fits (least
        squares over every month with 3 or more months each side, monthly terms kept), then the
        AR(1) model with that step: the step explains the series when, with it, the momentum is
        low (phi at most STEP_PHI_MAX), a momentum of 0.95 or more is excluded, and no trend
        remains. Read only when the drift screen has fired; it never makes a claim stronger than
        the test, it only names what the screen saw.
        """
        times = self.times
        keep = [i for i, nm in enumerate(self.names) if nm not in ("older", "delta")]
        base = self.X[:, keep]
        cands = sorted(set(int(x) for x in times))
        best, best_rss = None, math.inf
        for tau in cands:
            step = (times >= tau).astype(float)
            if step.sum() < 3 or (1 - step).sum() < 3:
                continue
            X = np.column_stack([base, step])
            coef, _res, rank, _sv = np.linalg.lstsq(X, self.y, rcond=None)
            if rank < X.shape[1]:
                continue
            r = self.y - X @ coef
            rss = float(r @ r)
            if rss < best_rss - 1e-12:
                best, best_rss = tau, rss
        if best is None:
            return {"assessable": False, "explains": False}
        step = (times >= best).astype(float)
        X = np.column_stack([base, step])
        d = _design(X, self._W[_AR1], self.logdet_c[_AR1], X.shape[1] - 1)
        if d is None or d.n - d.p < 3:
            return {"assessable": False, "explains": False}
        f = _fit(d, self.y)
        prof = f["ll"][:, 0]
        phis = _GRID_PHI[_AR1]
        phi = float(phis[int(np.argmax(prof))])
        lr = 2.0 * (float(np.max(prof)) - float(np.max(prof[phis >= UNIT_ROOT_PHI - 1e-12])))
        size = float(f["delta"][0])
        tc = (times - times.mean()) / 12.0
        X2 = np.column_stack([X, tc])
        d2 = _design(X2, self._W[_AR1], self.logdet_c[_AR1], X2.shape[1] - 1)
        trend_p = 1.0
        if d2 is not None and d2.n - d2.p >= 3:
            f2 = _fit(d2, self.y)
            trend_p = t_two_sided_p(float(f2["delta"][0] / f2["se"][0]), d2.n - d2.p)
        explains = bool(phi <= STEP_PHI_MAX and lr >= UNIT_ROOT_LR and trend_p >= TREND_SCREEN_P
                        and abs(size) >= math.log1p(0.02))
        return {"assessable": True, "month": int(best), "size": math.expm1(size), "phi": phi,
                "unit_root_lr": lr, "trend_p": trend_p, "explains": explains,
                "at_boundary": bool(abs(int(best) - int(latest_start)) <= 1)}

    def composition_steps(self, months: Sequence[int]) -> Dict[str, Any]:
        """
        Does a change in what the file covers explain what the drift screen saw (ship round,
        24 Sep 2026: a building bought in 2025-03 almost doubled a rent total, and the screen
        called it "this series drifts steadily")? The months are KNOWN before the model looks at
        the values (the months a category level starts, or the month after one stops), so nothing
        is searched: one level-shift term per such month (3 or more months each side; a month
        whose shift is the 12-versus-12 term itself is left to that term), added to the claim's
        own model (monthly terms and the latest-12 shift; the older months' separate level left
        out, as in trend_screen), AR(1) errors by REML. Each step's size, t and two-sided p are
        recorded; a step is DETECTED when p < TREND_SCREEN_P and it is at least 2%. The steps
        EXPLAIN the series when at least one is detected and, with them in the model, the drift
        screen itself no longer fires: no trend is established (p >= TREND_SCREEN_P) and the
        wandering screen (cannot exclude phi >= 0.95 with phi-hat >= UNIT_ROOT_PHI_HAT) is quiet.
        Like step_screen it never makes a claim stronger than its test; it only names what the
        screen saw.
        """
        keep = [i for i, nm in enumerate(self.names) if nm != "older"]
        base = self.X[:, keep]
        times = self.times
        steps = []
        for m in sorted(set(int(x) for x in months)):
            col = (times >= m).astype(float)
            if int(col.sum()) < 3 or int((1 - col).sum()) < 3:
                continue
            if np.array_equal(col, self.latest.astype(float)):
                continue                                # the 12-versus-12 shift already is this step
            steps.append((m, col))
        if not steps:
            return {"assessable": False, "explains": False, "steps": []}
        cols = [c for _, c in steps]
        W, ld = self._W[_AR1], self.logdet_c[_AR1]
        phis = _GRID_PHI[_AR1]
        out_steps: List[Dict[str, Any]] = []
        for j, (m, _c) in enumerate(steps):
            X = np.column_stack([base] + [c for i, c in enumerate(cols) if i != j] + [cols[j]])
            d = _design(X, W, ld, X.shape[1] - 1)
            if d is None or d.n - d.p < 3:
                return {"assessable": False, "explains": False, "steps": []}
            f = _fit(d, self.y)
            est, se = float(f["delta"][0]), float(f["se"][0])
            t = est / se if se > 0 else 0.0
            p = t_two_sided_p(t, d.n - d.p) if se > 0 else 1.0
            out_steps.append({"month": int(m), "size": math.expm1(est), "t": t, "p": p,
                              "detected": bool(p < TREND_SCREEN_P and abs(est) >= math.log1p(0.02))})
        X = np.column_stack([base] + cols)
        d = _design(X, W, ld, None)
        if d is None or d.n - d.p < 3:
            return {"assessable": False, "explains": False, "steps": out_steps}
        prof = _fit(d, self.y)["ll"][:, 0]
        phi = float(phis[int(np.argmax(prof))])
        lr = 2.0 * (float(np.max(prof)) - float(np.max(prof[phis >= UNIT_ROOT_PHI - 1e-12])))
        wanders = bool(lr < UNIT_ROOT_LR and phi >= UNIT_ROOT_PHI_HAT - 1e-12)
        tc = (times - times.mean()) / 12.0
        X2 = np.column_stack([X, tc])
        d2 = _design(X2, W, ld, X2.shape[1] - 1)
        trend_p = 1.0
        if d2 is not None and d2.n - d2.p >= 3:
            f2 = _fit(d2, self.y)
            trend_p = t_two_sided_p(float(f2["delta"][0] / f2["se"][0]), d2.n - d2.p)
        detected = [s for s in out_steps if s["detected"]]
        explains = bool(detected and trend_p >= TREND_SCREEN_P and not wanders)
        return {"assessable": True, "steps": out_steps, "phi": phi, "unit_root_lr": lr,
                "wanders": wanders, "trend_p": trend_p, "explains": explains}

    def seasonal_test(self) -> Dict[str, Any]:
        """
        Is there a month-of-year pattern? An F test of the monthly terms at the AR(1) fit's own
        momentum (the error model held fixed). Used to match a claim to benchmark conditions
        with or without seasonality (review v2, 24 Sep 2026); it does not change the model,
        which always carries the monthly terms.
        """
        if not self.seasonal_terms or self.full is None:
            return {"assessable": False, "seasonal": False, "p": None}
        keep = [i for i, nm in enumerate(self.names) if not nm.startswith("month_")]
        k = np.array([self.k_hat])
        red = _design(self.X[:, keep], self._W[k], self.logdet_c[k], None)
        full = _design(self.X, self._W[k], self.logdet_c[k], self.j_delta)
        if red is None or full is None:
            return {"assessable": False, "seasonal": False, "p": None}
        with np.errstate(all="ignore"):
            r_full = full.M[0, :-1] @ self.y
            r_red = red.M[0] @ self.y
        rss_f, rss_r = float(r_full @ r_full), float(r_red @ r_red)
        q, df = int(self.seasonal_terms), int(full.n - full.p)
        if df <= 0 or rss_f <= 0:
            return {"assessable": False, "seasonal": False, "p": None}
        F = max(0.0, (rss_r - rss_f) / q) / (rss_f / df)
        x = q * F / (q * F + df)
        p = 1.0 - betainc(q / 2.0, df / 2.0, x) if x > 0 else 1.0
        return {"assessable": True, "F": F, "df": [q, df], "p": p, "seasonal": bool(p < 0.05)}

    def unit_root_screen(self) -> Dict[str, Any]:
        """
        Can phi >= 0.95 be excluded? Read on the momentum-plus-noise model's profile (UR_MODEL
        "2d", profiled over the white-noise share) or the AR(1) model's ("1d"); the screen fires
        only when it cannot AND that model's own phi estimate is at least UNIT_ROOT_PHI_HAT.
        """
        if UR_MODEL == "2d":
            prof, phis, ph = self.profile2, _GRID_PHI, self.phi_hat_2d()
        else:
            prof, phis, ph = self.profile, _GRID_PHI[_AR1], self.phi_hat()
        top = float(np.max(prof))
        hi = float(np.max(prof[phis >= UNIT_ROOT_PHI - 1e-12]))
        lr = 2.0 * (top - hi)
        inside = bool(lr < UNIT_ROOT_LR)
        return {"lr": lr, "cutoff": UNIT_ROOT_LR, "model": UR_MODEL, "phi_hat": ph,
                "phi_hat_min": UNIT_ROOT_PHI_HAT, "phi_095_inside_interval": inside,
                "cannot_exclude": bool(inside and ph >= UNIT_ROOT_PHI_HAT - 1e-12)}


#: The last few models, keyed by their inputs, so a claim re-run at a larger B or for its
#: selection-adjusted bound reuses the bootstrap batches it already drew (a pure cache: the
#: batches are fixed by the seed).
_MODEL_CACHE: Dict[Any, TrendModel] = {}
_MODEL_CACHE_MAX = 8

_MONTHS = ("January", "February", "March", "April", "May", "June", "July", "August",
           "September", "October", "November", "December")


def clear_cache() -> None:
    """Forget cached models (EvidenceLedger.verify re-runs every test from its payload)."""
    _MODEL_CACHE.clear()


def _model(y: np.ndarray, times: np.ndarray, latest: np.ndarray, older: np.ndarray, seed: int,
           seasonal: bool) -> TrendModel:
    key = (tuple(float(v) for v in y), tuple(int(t) for t in times), tuple(bool(v) for v in latest),
           tuple(bool(v) for v in older), int(seed), bool(seasonal), BOOT_RULE, UR_MODEL, PHI_CAP_LR)
    m = _MODEL_CACHE.get(key)
    if m is None:
        m = TrendModel(y, times, latest, seed, seasonal=seasonal, older=older)
        if len(_MODEL_CACHE) >= _MODEL_CACHE_MAX:
            _MODEL_CACHE.pop(next(iter(_MODEL_CACHE)))
        _MODEL_CACHE[key] = m
    return m


def bar_log(bar: float, direction: int) -> float:
    """
    The minimum-effect null on the model's log scale, the SAME bar both ways in the reader's
    units: a rise of at least `bar` is log(1 + bar), a fall of at least `bar` is log(1 - bar).
    Before 23 Sep 2026 a fall used -log(1 + bar), a fall of 4.76% at a 5% bar, while every
    line of text said 5% (review of R1: 4 of 20 true 4.95% falls were confirmed as at least
    5%). The fall's null is now the stricter of the two, so no text needs a second number.
    """
    b = float(bar)
    if direction < 0:
        if not 0.0 <= b < 1.0:
            raise ValueError("a fall bar must be under 100%%, got %r" % b)
        return math.log1p(-b)
    return math.log1p(b)


def _at_least_bar(v: float, bar: float) -> bool:
    """A log change at least the bar in its own direction (bar_log's convention)."""
    return v >= bar_log(bar, 1) - 1e-12 if v > 0 else (v < 0 and v <= bar_log(bar, -1) + 1e-12)


def _pct_words(fraction: float) -> str:
    return "%+.1f%%" % (100.0 * fraction)


def _label(m: int) -> str:
    return "%04d-%02d" % (int(m) // 12, int(m) % 12 + 1)


def trend_test(values: Sequence[Optional[float]], month_index: Sequence[int], latest_start: int,
               bar: float, seed: int, thresholds: Sequence[float] = (),
               b_ladder: Sequence[int] = (B_TEST, B_LADDER[-1]), candidate_level: float = 0.01,
               seasonal: bool = True, nonpositive: str = "refuse",
               fcr_tails: Sequence[float] = (), ci_b: int = B_CI,
               composition_months: Sequence[int] = ()) -> Dict[str, Any]:
    """
    The change test for one claim (see the module docstring). `values` are the monthly values
    (a total or a mean) at integer month indices. Months with no value (None or NaN) are gaps.
    A month at or below zero is a gap when `nonpositive` is "gap" (a volume's empty month); with
    "refuse" it is a gap when it lies before the two compared windows, and inside them the test
    is refused and the months are named (a ratio of average months needs values above zero).

    The test runs at the first B of `b_ladder` and is extended along it while its 99% Monte
    Carlo interval straddles one of `thresholds` (the caller passes only the lines that decide
    the claim). `fcr_tails` asks for one-sided bounds at those tails in the claim's direction
    (the selection-adjusted bound of a confirmed claim, M4). Returns every number the fact and
    its payload carry.

    `composition_months` are the months a category level starts (or the month after one
    stops) inside the modelled span: when the drift screen fires and level shifts at exactly
    those months explain it (TrendModel.composition_steps), the screen stands down and the
    result says so (screen_kind "composition_step"); the steps are recorded either way.
    """
    out: Dict[str, Any] = {"method": "REML AR(1) with seasonal terms; parametric bootstrap from "
                                     "AR(1) momentum (seen through white noise) re-estimating phi "
                                     "(design M1-M2, review of R1)",
                           "bar": float(bar), "seed": int(seed), "ran": False}
    mi = np.asarray(month_index, dtype=int)
    vals = np.array([float("nan") if v is None else float(v) for v in values], dtype=float)
    finite = np.isfinite(vals)
    nonpos = finite & (vals <= 0)
    ls = int(latest_start)
    latest = mi >= ls
    prior12 = (mi >= ls - 12) & (mi < ls)
    compared = latest | prior12
    out["months_in_model"] = int(len(vals))
    if np.any(nonpos) and nonpositive != "gap":
        inside = nonpos & compared
        if np.any(inside):
            k = int(np.sum(inside))
            out["not_run"] = ("%d monthly value%s at or below zero inside the two compared 12-month "
                              "windows (%s%s), so the change cannot be tested as a ratio of the "
                              "average month" % (k, " is" if k == 1 else "s are",
                                                 ", ".join(_label(m) for m in mi[inside][:4]),
                                                 ", ..." if k > 4 else ""))
            out["nonpositive_months"] = [int(m) for m in mi[inside]]
            return out
        out["nonpositive_gaps"] = int(np.sum(nonpos))
    ok = finite & ~nonpos
    out["months_observed"] = int(np.sum(ok))
    out["months_gap"] = int(np.sum(~ok))
    n_last, n_prior = int(np.sum(ok & latest)), int(np.sum(ok & prior12))
    if n_last < MIN_MONTHS_PER_WINDOW or n_prior < MIN_MONTHS_PER_WINDOW:
        out["not_run"] = ("only %d of the latest 12 months and %d of the 12 before hold a usable "
                          "value; the test needs at least %d in each"
                          % (n_last, n_prior, MIN_MONTHS_PER_WINDOW))
        out["months_usable"] = [n_last, n_prior]
        # calendar months with no value in any year of the span: a collection pattern
        seen = set(int(m) % 12 for m in mi[ok])
        spans = set(int(m) % 12 for m in mi)
        never = sorted(c for c in spans if c not in seen)
        if never and len(spans) == 12 and 12 - len(never) < MIN_MONTHS_PER_WINDOW:
            out["never_observed_months"] = never
            out["not_run"] += ("; the file holds no values for %s in any year"
                               % ", ".join(_MONTHS[c] for c in never))
        return out
    # the headline estimand from the same monthly values: the ratio of the average months
    # (a volume's empty month counts as zero, as in its SQL ratio of totals)
    lv, pv = vals[finite & latest], vals[finite & prior12]
    headline = (float(np.mean(lv)) / float(np.mean(pv)) - 1.0) if len(pv) and np.mean(pv) > 0 else None
    out["headline"] = headline
    # the average month over the two compared windows: for a volume, the rows a month (the
    # counting noise the benchmark conditions are matched on)
    out["mean_month"] = float(np.mean(vals[finite & compared]))
    try:
        return _run(out, vals, mi, ok, latest, mi < ls - 12, bar, seed, thresholds, b_ladder,
                    seasonal, headline, fcr_tails, ci_b, composition_months)
    except (FloatingPointError, np.linalg.LinAlgError) as exc:
        out["not_run"] = "the model could not be fitted to these months (%s)" % exc
        out["ran"] = False
        return out


def _run(out: Dict[str, Any], vals: np.ndarray, mi: np.ndarray, ok: np.ndarray, latest: np.ndarray,
         older: np.ndarray, bar: float, seed: int, thresholds: Sequence[float],
         b_ladder: Sequence[int], seasonal: bool, headline: Optional[float],
         fcr_tails: Sequence[float], ci_b: int,
         composition_months: Sequence[int] = ()) -> Dict[str, Any]:
    y = np.log(vals[ok])
    times = mi[ok]
    model = _model(y, times, latest[ok], older[ok], seed, seasonal)
    if model.full is not None and model.restricted is not None and model.se <= 1e-12:
        out["not_run"] = ("the monthly values do not vary once the seasonal pattern and the shift are "
                          "allowed for, so there is no month-to-month noise to test the change against")
        return out
    if not model.ok or model.df < MIN_RESIDUAL_DF:
        out["not_run"] = ("the monthly series is too short or too irregular for the model "
                          "(%d months, %d residual degrees of freedom)" % (model.n, max(model.df, 0)))
        return out
    d = model.delta
    ur = model.unit_root_screen()
    fit = {"delta_hat": d, "se": model.se, "sigma_hat": model.sigma, "effect_model": math.expm1(d),
           "phi_hat": model.phi_hat(),
           "phi_hat_2d": model.phi_hat_2d(), "noise_share_hat": model.noise_share_hat(),
           "boot_rule": BOOT_RULE, "phi_cap": model.phi_cap, "n": model.n,
           "params": int(model.full.p), "df": model.df, "seasonal_terms": model.seasonal_terms,
           "seasonal_rule": "11 monthly indicators, always fitted in R1 (no screen registered)",
           "older_term": model.older_term, "unit_root": ur}
    try:
        sz = model.seasonal_test()
        fit["seasonal_p"], fit["seasonal"] = sz.get("p"), bool(sz.get("seasonal"))
    except (FloatingPointError, np.linalg.LinAlgError, ValueError, ZeroDivisionError):
        fit["seasonal_p"], fit["seasonal"] = None, False
    # One estimand (design §1.2): the test's direction is the headline's, and a model estimate
    # of the other sign, with either at least the bar, is not printed beside it.
    direction = (1 if d >= 0 else -1) if not headline else (1 if headline > 0 else -1)
    if headline is not None and headline > -1.0:
        h = math.log1p(headline)
        opposite = (d != 0.0 and h != 0.0 and (d > 0) != (h > 0)
                    and (_at_least_bar(d, bar) or _at_least_bar(h, bar)))
        if opposite:
            out.update(fit)
            out["estimand_mismatch"] = True
            out["not_run"] = (
                "the model's estimate of the change (%s, momentum %.2f) and the plain ratio of the "
                "average months (%s) point opposite ways, so the model cannot separate a change "
                "from this series' own drift and no test is printed beside the headline"
                % (_pct_words(math.expm1(d)), model.phi_hat(), _pct_words(headline)))
            return out
    d0 = bar_log(bar, direction)
    ladder = [int(b) for b in b_ladder]
    b = ladder[0]
    while True:
        c, k0 = model.exceed(d0, direction, b)
        lo, hi = mc_interval(c, b)
        straddle = [float(t) for t in thresholds if lo <= t <= hi]
        if not straddle or b >= ladder[-1]:
            break
        b = next(x for x in ladder if x > b)
    p_min = (1.0 + c) / (b + 1.0)
    b0 = B_LADDER[0]
    c0, k00 = model.exceed(0.0, 0, b0)
    p_zero = (1.0 + c0) / (b0 + 1.0)
    lo95 = model.bound(0.025, -1, ci_b)
    hi95 = model.bound(0.025, +1, ci_b)
    # The interval's near end (the side the claim is judged on) may not clear the bar unless
    # the test itself does (design §1.2). Review v2 (24 Sep 2026): with the near end
    # re-estimating momentum at the bound (phi 0.75) while the test drew from the bar's (0.97),
    # small_shop printed an interval from +20.9% beside a test of 'at least 5%' with p = 0.0255.
    # The near end is the more cautious of the self-consistent inversion and the inversion of
    # the test itself (the bar's momentum, the same t* batch and B): an interval clearing the bar
    # therefore implies the test rejects at 2.5%. Measured on the standard benchmark, using the
    # test's inversion alone made the two agree exactly but cut 95% coverage by 1.5 points
    # (92.4% to 90.9% at phi-hat < 0.5), so the cautious end is kept and the rarer other case
    # (the test rejects, the interval still reaches the bar) is flagged, not hidden.
    near_side = -1 if direction > 0 else +1
    near_b = b
    agree = True
    if 0.025 * (near_b + 1) >= 1.0:
        near = model._bound_at(k0, 0.025, near_side, near_b)
        if near_side < 0:
            lo95 = near if lo95 is None else min(lo95, near)
            clears = lo95 is not None and lo95 > d0
        else:
            hi95 = near if hi95 is None else max(hi95, near)
            clears = hi95 is not None and hi95 < d0
        agree = bool(clears) == bool(p_min <= 0.025)
    table = []
    if lo95 is not None and hi95 is not None:
        table.append({"tail": 0.025, "level": 0.95, "lo": math.expm1(lo95), "hi": math.expm1(hi95),
                      "b": ci_b})
    one_sided = []
    side = -1 if direction > 0 else +1
    for tail in fcr_tails:
        tail = float(tail)
        bb = ci_b if tail * (ci_b + 1) >= 1.0 else B_LADDER[-1]
        v = model.bound(tail, side, bb)
        one_sided.append({"tail": tail, "level": 1.0 - tail, "side": "lower" if side < 0 else "upper",
                          "bound": None if v is None else math.expm1(v), "b": bb})
    tr = model.trend_screen()
    screen = ""
    screen_kind = ""
    if ur["cannot_exclude"]:
        screen = ("this series wanders (its month-to-month persistence cannot be told apart from "
                  "a random walk), so a gap between two 12-month windows is expected without any "
                  "change")
        screen_kind = "wanders"
    elif tr.get("established"):
        screen = ("this series drifts steadily (a trend over the whole history is established), "
                  "so a 12-versus-12 gap is expected without any change")
        screen_kind = "drifts"
    step = None
    if screen:
        # a single level shift is not a drift (review v2): at the start of the latest 12 months it
        # IS the change tested, and the screen stands down; anywhere else it is named
        try:
            step = model.step_screen(int(np.min(model.times[model.latest])))
        except (FloatingPointError, np.linalg.LinAlgError, ValueError):
            step = None
        if step and step.get("explains"):
            if step["at_boundary"]:
                screen, screen_kind = "", "step_at_start"
            elif step["month"] <= int(np.min(model.times[model.latest])) - 12:
                # before both compared years: the model's level for the older months holds it,
                # and the 12-versus-12 comparison does not see it
                screen, screen_kind = "", "step_before"
            else:
                screen = ("this series steps once, in %s (by %s), rather than drifting, and that is "
                          "not where the latest 12 months start, so the 12-versus-12 gap straddles "
                          "the step" % (_label(step["month"]), _pct_words(step["size"])))
                screen_kind = "step"
    comp_step = None
    if composition_months:
        # a change in what the file covers, at months known before the values were read (ship
        # round): when shifts there explain what the screen saw, it is not drift
        try:
            comp_step = model.composition_steps(composition_months)
        except (FloatingPointError, np.linalg.LinAlgError, ValueError):
            comp_step = None
        if screen and comp_step and comp_step.get("explains"):
            screen, screen_kind = "", "composition_step"
    out.update(fit)
    out.update({
        "ran": True, "direction": direction,
        "phi_restricted": model.boot_params(k0)[0], "noise_restricted": model.boot_params(k0)[1],
        "phi_restricted_point_null": model.boot_params(k00)[0],
        "t_min_effect": (d - d0) / model.se, "d0": d0,
        "p_min_effect": p_min, "p_nonzero": p_zero, "b": b, "b_point_null": b0,
        "mc_count": c, "mc_interval": [lo, hi], "mc_level": MC_LEVEL,
        "mc_thresholds": [float(t) for t in thresholds], "mc_straddles": straddle,
        "ci_level": 0.95, "ci_low": table[0]["lo"] if table else None,
        "ci_high": table[0]["hi"] if table else None,
        "ci_method": ("inversion of the same bootstrap test (B = %d; the end on the claim's side "
                      "also inverting the test itself, the more cautious of the two, B = %d)"
                      % (ci_b, near_b)), "ci_b": ci_b,
        "ci_near_b": near_b, "ci_near_side": "lower" if near_side < 0 else "upper",
        "ci_test_agree": agree,
        "ci_table": table, "fcr_bounds": one_sided, "trend": tr, "drift_screen": screen,
        "screen_kind": screen_kind, "step": step, "composition_step": comp_step,
    })
    return out


def family_lines(claims: Sequence[Tuple[str, str, float]], q: float, primary_key: str = "",
                 method: str = "bh") -> Dict[str, Dict[str, Any]]:
    """
    The gate's false-discovery rule (gate.apply_trend_families, M3) on (id, key, p) triples,
    for the analysis to know, before gating, which line decides each claim and which tail its
    selection-adjusted bound needs. The PRIMARY claim (the first whose key is `primary_key`,
    or "volume" when none is named) is tested alone at q; the rest form one Benjamini-Hochberg
    (or -Yekutieli, method "by") family at q. For each id: family, m, line (the p a claim must
    meet, or q/m when the family rejects nothing), reject, R (the family's rejections) and
    fcr_tail = R * q' / m (q' = q, or q over the harmonic sum for "by"), None when not rejected.
    """
    keys = {str(k) for _, k, _ in claims}
    pk = primary_key or ("volume" if "volume" in keys else "")
    # The primary claim's like-for-like twin (ship round, 24 Sep 2026) is tested alone at q as
    # well: it exists only when what the file covers changed, and then the primary claim itself
    # is held at WATCH by the composition rule whatever its test says, so the primary question
    # still has exactly one claim that can be confirmed.
    pk_lf = (pk + LIKE_FOR_LIKE_SUFFIX) if pk else ""
    prim: List[Tuple[str, str, float]] = []
    prim_lf: List[Tuple[str, str, float]] = []
    sec: List[Tuple[str, str, float]] = []
    for c in claims:
        if pk and str(c[1]) == pk and not prim:
            prim.append(c)
        elif pk_lf and str(c[1]) == pk_lf and not prim_lf:
            prim_lf.append(c)
        else:
            sec.append(c)
    out: Dict[str, Dict[str, Any]] = {}
    for fam, members in (("primary", prim), ("primary_like_for_like", prim_lf)):
        for cid, _, p in members:
            rej = float(p) <= q
            out[cid] = {"family": fam, "m": 1, "line": float(q), "reject": rej, "R": int(rej),
                        "fcr_tail": float(q) if rej else None}
    if sec:
        m = len(sec)
        qq = q / sum(1.0 / i for i in range(1, m + 1)) if method == "by" else q
        res = benjamini_hochberg([float(c[2]) for c in sec], qq)
        line = res["threshold"] if res["threshold"] > 0 else q / m
        R = int(res["k"])
        for (cid, _, p), rej in zip(sec, res["reject"]):
            out[cid] = {"family": "secondary", "m": m, "line": float(line), "reject": bool(rej),
                        "R": R, "fcr_tail": (R * qq / m) if rej else None}
    return out
