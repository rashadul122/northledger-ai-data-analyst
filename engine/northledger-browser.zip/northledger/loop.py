#!/usr/bin/env python3
"""
The Insight Loop orchestrator.

Runs the stages in order and returns everything a client and an auditor need:

    profile -> clean/quarantine -> facts -> derive -> GATE -> narrate -> ledger

The ordering is the product. In particular the narrator is handed gated facts
and nothing else, so no stage after the gate can reach raw data -- which is what
makes the brief's numbers checkable rather than merely plausible.

Python 3.9 compatible.
"""
from __future__ import annotations

import datetime as _dt
import json
import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from . import clean as _clean
from . import gate as _gate
from . import health as _health
from . import narrate as _narrate
from .facts import EvidenceLedger, Fact, FactSet, GatedFact, derive


@dataclass
class LoopResult:
    table: str
    objective: str
    run_id: str
    health: Any
    clean: Any
    facts: List[Fact]
    gated: List[GatedFact]
    brief: Any                       # one-page version: the top actions
    verification: Dict[str, Any]
    artifacts: Dict[str, str] = field(default_factory=dict)
    full_brief: Any = None           # every action, for the full report

    @property
    def counts(self) -> Dict[str, int]:
        """Verdicts of FINDINGS only; background measurements are counted separately."""
        out = {"RECOMMEND": 0, "WATCH": 0, "INSUFFICIENT": 0}
        for gf in self.gated:
            if getattr(gf.fact, "role", "headline") == "headline":
                out[gf.gate.verdict] += 1
        return out

    @property
    def n_background(self) -> int:
        return sum(1 for gf in self.gated if getattr(gf.fact, "role", "headline") != "headline")

    def summary(self) -> str:
        c = self.counts
        v = self.verification
        return (
            "table=%s  health=%.1f/100  rows %s -> %s clean + %s quarantined\n"
            "facts=%d  findings: RECOMMEND=%d WATCH=%d INSUFFICIENT=%d; background: %d\n"
            "evidence: %d re-run, %d reproduced, %d did not (withheld); unreproduced rate %s"
            % (self.table, self.health.score,
               format(self.clean.total_in, ","), format(self.clean.rows_clean, ","),
               format(self.clean.rows_quarantined, ","),
               len(self.facts), c["RECOMMEND"], c["WATCH"], c["INSUFFICIENT"], self.n_background,
               v.get("checked", 0), v.get("reproduced", 0), v.get("failed", 0),
               "n/a" if v.get("unreproduced_rate") is None else "%.3f" % v["unreproduced_rate"])
        )


def _now_iso() -> str:
    return _dt.datetime.now().replace(microsecond=0).isoformat()



# Which stage-1/stage-2 diagnostics are DEFECTS a client can act on, and which
# are DESCRIPTIVE context. This mapping is a judgement call, not a fact: it
# decides what the brief is allowed to recommend, and the engine's owner should
# own it. The rule applied here: recommend on defects, report context as context.
#
# "goodness" scores -- higher is better, so the defect share is the shortfall
_GOODNESS_SUFFIXES = (
    "completeness_pct", "validity_pct", "consistency_pct",
    "uniqueness_pct", "timeliness_pct", "health.score",
)
# "badness" measures -- the value IS the defect share
_BADNESS_MARKERS = ("null_like", "duplicate", "future_dated", "quarantine", "quarantined",
                    "placeholder_values", "padded_values", "off_convention_casing",
                    "variant_spellings", "off_format_dates", "duplicate_ids",
                    "negative_values")
# descriptive: true, useful in the evidence ledger, never advice on its own
_DESCRIPTIVE_MARKERS = ("rows_in", "rows_clean", "rows_accounted_for", "fixes_applied",
                        "clean.fixed.", "health.rows", ".gaps_follow.", ".not_applicable.")


def _as_state(f: Fact) -> Fact:
    """
    Profiling and cleaning facts describe a CONDITION, not a movement, so the
    gate must not judge them by trend criteria.

    For a state fact, effect_size carries MATERIALITY: the share of the table
    the condition affects. Getting its direction right matters -- reading
    "completeness 89.3%" as 89% material would recommend action on the healthy
    part of the table, and dividing a count of CELLS by a count of ROWS produced
    the meaningless "7.96 times the usual level" in the first run.
    """
    f.fact_kind = "state"
    fid = f.id.lower()

    if f.query_kind == "computed":
        # Composite scores (consistency 64/100, the overall Health Score) summarise the
        # per-column findings; ranked as actions they crowded out the concrete defects.
        f.role = "detail"
        f.effect_size = 0.0
        return f

    if any(m in fid for m in _DESCRIPTIVE_MARKERS):
        f.role = "detail"
        # Context, not a finding. No materiality => never reaches RECOMMEND.
        f.effect_size = 0.0
        f.caveats = list(f.caveats) + ["context for the audit, not a recommended action"]
        return f

    if f.unit == "pct":
        share = float(f.value) / 100.0
        if any(fid.endswith(sfx) or sfx in fid for sfx in _GOODNESS_SUFFIXES):
            # Whole-table dimension scores (completeness 95.8%) summarise the per-column
            # findings; the specific findings are the actions.
            f.role = "detail"
            f.effect_size = 0.0
            return f
        f.effect_size = share
        if share <= 0:
            f.role = "detail"                  # nothing wrong found: reassurance, not a finding
        return f

    if f.unit == "count" and f.rows_scanned > 0 and any(m in fid for m in _BADNESS_MARKERS):
        # Only row-scoped defect counts. Cell counts have no row denominator.
        if "cell" in fid or "cells" in f.claim.lower():
            f.role = "detail"
            f.effect_size = 0.0
            f.caveats = list(f.caveats) + [
                "counted in cells; not expressed as a share of rows"]
        else:
            f.effect_size = min(1.0, float(f.value) / float(f.rows_scanned))
            if f.effect_size <= 0:
                # "0 duplicate rows" is good news about the file. Gated as a defect it read
                # "affects 0% of the table where we want at least 5%".
                f.role = "detail"
        return f

    f.effect_size = f.effect_size or 0.0
    return f


def _add_cleaning_derivations(fs: FactSet, cr: Any) -> None:
    """
    Record the row-conservation arithmetic as a checkable fact.

    The September 2026 audit found the project's only wrong number was a total
    added up inside prose. Totals now go through derive(), which computes them
    from their inputs and lets EvidenceLedger re-add them.
    """
    ids = {f.id for f in fs}
    clean_id = next((i for i in ids if i.endswith("rows_clean")), None)
    quar_id = next((i for i in ids if i.endswith("rows_quarantined")), None)
    if clean_id and quar_id:
        f = derive(
            fs, "clean.rows_accounted_for",
            "Rows accounted for after cleaning (clean + quarantined); nothing was dropped",
            "count", "sum", [clean_id, quar_id],
            caveats=["must equal rows read; a gap means rows were lost"],
        )
        # A reconciliation check, not a finding: it read "held for only 0 periods" when
        # it was gated as a trend. It is reassurance about the file.
        f.role, f.fact_kind, f.measures = "detail", "state", "data_quality"


def run_loop(
    db_path: str,
    table: str,
    objective: str,
    policy: Optional[Any] = None,
    enrichments: Optional[List[Any]] = None,
    out_dir: Optional[str] = None,
    run_id: str = "",
    max_actions: int = 3,
    clean_limit: Optional[int] = None,
    allow_public_data: bool = False,
    display_name: Optional[str] = None,
    as_of: Optional[str] = None,
) -> LoopResult:
    from .engagement import check_ready
    if not out_dir:
        # No silent default: artifacts used to land wherever the process happened to
        # be running. Every output belongs in one engagement folder.
        raise ValueError("out_dir is required; put every output in the engagement's folder")
    check_ready(db_path, allow_public_data=allow_public_data)
    now = _now_iso()
    run_id = run_id or ("%s-%s" % (table, now.replace(":", "").replace("-", "")))
    os.makedirs(out_dir, exist_ok=True)

    # -- stage 1: profile before anything ---------------------------------
    con = _health.connect_read_only(db_path)
    try:
        th = _health.score_table(con, table)

        # -- stage 2: clean + quarantine, zero delta ----------------------
        cr = _clean.clean_table(con, table, limit=clean_limit, health=th,   # profile once
                                as_of=as_of)
        cr.reconcile()          # raises rather than losing a row silently
        _health.reflect_cleaning(th, cr)     # validity as the analysis meets it (review v2)
    finally:
        con.close()

    # -- stage 4: facts ---------------------------------------------------
    fs = FactSet(run_id=run_id, now_iso=now)
    for f in th.to_facts("health"):
        fs.add(_as_state(f))
    for f in cr.to_facts("clean"):
        fs.add(_as_state(f))
    _add_cleaning_derivations(fs, cr)
    if display_name and display_name != table:
        # Sentences name the file the client sent, and a column as "the zone column of
        # deliveries_aug.csv" rather than "deliveries_aug.csv.zone", which reads like a
        # path. Queries keep the real table name, so every figure stays re-runnable.
        cols = sorted((c.name for c in th.columns), key=len, reverse=True)
        for f in fs:
            claim = f.claim
            for col in cols:
                claim = claim.replace("%s.%s" % (table, col), "the %s column of %s" % (col, display_name))
            f.claim = claim.replace(table, display_name)

    # -- stage 7: the gate ------------------------------------------------
    gated = _gate.gate_all(fs.facts, policy)

    # -- verify BEFORE narrating ------------------------------------------
    # so the brief states what was actually re-checked, and a figure that does
    # not reproduce is withheld rather than reported.
    verification = EvidenceLedger(gated).verify(db_path)
    gated = _gate.withhold_unreproduced(gated)

    # -- stage 8: narrate, from gated facts only --------------------------
    # Findings are narrated; background measurements go to "About your file". Both
    # are in the evidence ledger.
    headlines = [g for g in gated if getattr(g.fact, "role", "headline") == "headline"]
    background = [g for g in gated if getattr(g.fact, "role", "headline") != "headline"]
    brief = _narrate.narrate(headlines, objective, enrichments=enrichments,
                             max_actions=max_actions)
    # The one-page summary is capped; the full brief lists every action. (Both are
    # rendered from the same gated facts, so they cannot disagree about a number.)
    n_actions = sum(1 for g in headlines if g.gate.verdict == "RECOMMEND")
    full_brief = _narrate.narrate(headlines, objective, enrichments=enrichments,
                                  max_actions=max(max_actions, n_actions))
    about = ["%s [fact: %s]" % (g.fact.claim.rstrip("."), g.fact.id) for g in background]
    brief.about_file = about
    full_brief.about_file = list(about)

    # -- stage 9: deliver ----------------------------------------------------
    ledger = EvidenceLedger(gated)

    artifacts = {}
    artifacts["evidence_csv"] = ledger.to_csv(os.path.join(out_dir, "evidence-ledger.csv"))
    artifacts["evidence_json"] = ledger.to_json(os.path.join(out_dir, "evidence-ledger.json"))

    bp = os.path.join(out_dir, "brief.md")
    with open(bp, "w", encoding="utf-8") as fh:
        fh.write(full_brief.to_markdown())
    artifacts["brief_md"] = bp

    ep = os.path.join(out_dir, "brief-exec.md")
    with open(ep, "w", encoding="utf-8") as fh:
        fh.write(brief.to_exec_markdown())
    artifacts["brief_exec_md"] = ep

    hp = os.path.join(out_dir, "data-health.json")
    profile = th.to_dict()
    # Counts and shapes only. top_values are raw cell values from the client's data;
    # the analyst already strips them before the model sees a profile, and the
    # saved file must not be a second copy of the data either.
    for c in profile.get("columns", []):
        c.pop("top_values", None)
    with open(hp, "w", encoding="utf-8") as fh:
        json.dump(profile, fh, indent=1, default=str)
    artifacts["health_json"] = hp

    vp = os.path.join(out_dir, "verification.json")
    with open(vp, "w", encoding="utf-8") as fh:
        json.dump(verification, fh, indent=1, default=str)
    artifacts["verification_json"] = vp

    return LoopResult(
        table=table, objective=objective, run_id=run_id, health=th, clean=cr,
        facts=fs.facts, gated=gated, brief=brief, verification=verification,
        artifacts=artifacts, full_brief=full_brief,
    )


# ==========================================================================
# The no-AI business analysis: measure + forecast + story (python -m northledger analyze)
# ==========================================================================
class StageTimer:
    """
    Seconds, rows/s and peak memory per stage, for timings.json. Peak RSS is the process's
    high-water mark when the stage ended (getrusage), so it only ever grows: it reads as
    "the most memory the run had needed by the end of this stage".
    """

    def __init__(self) -> None:
        self.stages: List[Dict[str, Any]] = []

    @staticmethod
    def peak_rss_mb() -> float:
        import resource
        import sys as _sys
        r = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        # bytes on macOS, kilobytes on Linux
        return round(r / (1024.0 * 1024.0) if _sys.platform == "darwin" else r / 1024.0, 1)

    def stage(self, name: str, rows: int = 0):
        timer = self

        class _Ctx:
            def __enter__(self_inner):
                import time
                self_inner.t0 = time.perf_counter()
                return self_inner

            def __exit__(self_inner, *exc):
                import time
                secs = time.perf_counter() - self_inner.t0
                timer.stages.append({
                    "stage": name, "seconds": round(secs, 3), "rows": int(rows),
                    "rows_per_s": round(rows / secs, 1) if rows and secs > 0 else None,
                    "peak_rss_mb": timer.peak_rss_mb(),
                    "ok": exc[0] is None,
                })
                return False
        return _Ctx()


def gate_analysis(facts: List[Fact], policy: Optional[Any] = None) -> List[GatedFact]:
    """
    Gate the analysis's facts. Forecasts go through forecast.gate_forecast (history, backtest,
    champion vs seasonal-naive, band calibration); background measurements get a plain
    "background" result instead of trend wording that does not apply to them; every
    headline measure goes through the ordinary gate unchanged.
    """
    from . import forecast as _fc
    from .facts import GateResult
    out: List[GatedFact] = []
    for f in facts:
        if f.fact_kind == "forecast":
            if f.role == "headline":
                g = _fc.gate_forecast(f, policy)
            else:
                g = GateResult("WATCH", "A detail of the forecast it belongs to (its range, its "
                               "replay record); judged with that forecast, not on its own.",
                               "", {"rule": "forecast_detail", "fact_id": f.id})
        elif f.role != "headline":
            g = GateResult("WATCH", "A background measurement that describes the data or supports "
                           "a finding; it is not advice on its own.", "",
                           {"rule": "background", "fact_id": f.id})
        else:
            g = _gate.gate(f, policy)
        out.append(GatedFact(fact=f, gate=g))
    # False-discovery control across the run's change claims (design M3): the primary claim
    # alone, the secondary measures as one family, so extra columns cannot dilute the headline.
    out = _gate.apply_trend_families(out, policy)
    # every CONFIRMED change quotes the false-confirm rate the benchmark measured in its nearest
    # condition (design §1.5), from a receipt recorded on this code
    out = _gate.attach_measured_rates(out)
    # A forecast's details carry their headline's verdict, so the ledger never shows a
    # WATCH band under a forecast that was withheld.
    head = {g.fact.id.rsplit(".", 1)[0]: g.gate.verdict for g in out
            if g.fact.fact_kind == "forecast" and g.fact.role == "headline" and g.fact.id.endswith(".next")}
    for g in out:
        if g.fact.fact_kind == "forecast" and g.fact.role != "headline":
            key = ".".join(g.fact.id.split(".")[:2])
            if key in head:
                g.gate.verdict = head[key]
    return out


@dataclass
class AnalyzeResult:
    table: str
    objective: str
    run_id: str
    health: Any
    clean: Any
    roles: Any
    measure: Any
    forecasts: Dict[str, Any]
    facts: List[Fact]
    gated: List[GatedFact]
    brief: Any
    full_brief: Any
    story: Any
    verification: Dict[str, Any]
    artifacts: Dict[str, str] = field(default_factory=dict)
    timings: List[Dict[str, Any]] = field(default_factory=list)
    as_of: str = ""

    def summary(self) -> str:
        c = {"RECOMMEND": 0, "WATCH": 0, "INSUFFICIENT": 0}
        for g in self.gated:
            if g.fact.role == "headline":
                c[g.gate.verdict] += 1
        v = self.verification
        lines = [
            "table=%s  health=%.1f/100  rows %s -> %s clean + %s quarantined"
            % (self.table, self.health.score, format(self.clean.total_in, ","),
               format(self.clean.rows_clean, ","), format(self.clean.rows_quarantined, ",")),
            "roles: date=%s measures=%s dimensions=%s grain=%s"
            % (self.roles.date or "-", ",".join(self.roles.measures) or "-",
               ",".join(self.roles.dimensions) or "-", self.roles.grain),
            "facts=%d  findings: RECOMMEND=%d WATCH=%d INSUFFICIENT=%d"
            % (len(self.facts), c["RECOMMEND"], c["WATCH"], c["INSUFFICIENT"]),
        ]
        for slug, fr in sorted(self.forecasts.items()):
            lines.append("forecast %s: champion=%s (baseline won: %s), replay %d months, band held %d of %d"
                         % (slug, fr.champion, "yes" if fr.baseline_won else "no", fr.holdout,
                            fr.coverage["hits"], fr.coverage["n"]))
        lines.append("evidence: %d re-run or refit, %d reproduced, %d did not (withheld)"
                     % (v.get("checked", 0), v.get("reproduced", 0), v.get("failed", 0)))
        return "\n".join(lines)


def _private_columns(db_path: str, table: str) -> List[str]:
    """Columns withheld, pending or coded at intake: never printed as category values."""
    from .engagement import COLUMNS_TABLE, intake_state
    from ._sqlite import connect_ro
    st = intake_state(db_path)
    cols = set(st.withheld.get(table, set()))
    con = connect_ro(db_path)
    try:
        names = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if COLUMNS_TABLE in names:
            # 'keep' is a person's decision that the column is not personal data: respected.
            cols |= {r[0] for r in con.execute("SELECT column_name FROM %s WHERE table_name = ? "
                                                "AND decision != 'keep'" % COLUMNS_TABLE, (table,))}
    finally:
        con.close()
    return sorted(cols)


def run_analyze(
    db_path: str,
    table: str,
    objective: str,
    out_dir: str,
    policy: Optional[Any] = None,
    enrichments: Optional[List[Any]] = None,
    run_id: str = "",
    as_of: Optional[str] = None,
    horizon: int = 12,
    allow_public_data: bool = False,
    display_name: Optional[str] = None,
    max_actions: int = 3,
    max_series: int = 3,
    timer: Optional[StageTimer] = None,
    landing: Optional[Dict[str, Any]] = None,
) -> AnalyzeResult:
    """
    profile -> clean -> measure (SQL facts) -> forecast (model facts) -> gate -> verify
    -> narrate the story. No AI model is called at any point.

    `as_of` (default today) is the one analysis date: the cleaner judges "in the future"
    against it, the window ends by it, and a forecast whose first month is not after it
    is history, not a plan. `landing` (the engagement's landing record) is stamped into
    forecast.json so an export never pairs this forecast with a later landing's rows.
    """
    from . import forecast as _fc
    from . import measure as _ms
    from .engagement import check_ready
    from ._sqlite import connect_ro
    if not out_dir:
        raise ValueError("out_dir is required; put every output in the engagement's folder")
    check_ready(db_path, allow_public_data=allow_public_data)
    timer = timer or StageTimer()
    now = _now_iso()
    run_id = run_id or ("%s-analysis-%s" % (table, now.replace(":", "").replace("-", "")))
    os.makedirs(out_dir, exist_ok=True)
    label = display_name or table
    import datetime as _dtm
    as_of = str(as_of or _dtm.date.today().isoformat())[:10]

    con = _health.connect_read_only(db_path)
    try:
        with timer.stage("profile"):
            th = _health.score_table(con, table)
        timer.stages[-1]["rows"] = th.total_rows
        with timer.stage("clean", rows=th.total_rows):
            cr = _clean.clean_table(con, table, health=th, as_of=as_of)
            cr.reconcile()
            _health.reflect_cleaning(th, cr)     # validity as the analysis meets it (review v2)
    finally:
        con.close()
    # The cleaner's sanity stop applies to the analysis too. Above the policy's rate the
    # cleaner is more likely misreading the file than the file is that broken, and figures
    # from the few rows it kept would be told as the business (QA, 23 Sep 2026: 3 of 2,160
    # rows kept, "average rent_paid 1.875").
    pol = policy if policy is not None else _gate.DEFAULT_POLICY
    max_rate = float(getattr(pol, "max_quarantine_rate", 0.20))
    if cr.total_in and cr.suspect_quarantine_rate > max_rate:
        from .engagement import NotReady
        raise NotReady(
            "cleaning set aside %.1f%% of the %s rows, above the %.0f%% at which the cleaning itself "
            "is suspect; read the audit's quarantine reasons, correct the rule, and re-run before "
            "analysis" % (100.0 * cr.suspect_quarantine_rate, format(cr.total_in, ","),
                          100.0 * max_rate))
    if timer.stages[0]["seconds"]:
        timer.stages[0]["rows_per_s"] = round(th.total_rows / timer.stages[0]["seconds"], 1)

    with timer.stage("measure", rows=cr.rows_clean):
        roles = _ms.infer_roles(cr.clean, th, private=_private_columns(db_path, table))
        dcol = next((c for c in th.columns if c.name == roles.date), None)
        at = _ms.build_analysis_table(db_path, table, cr.clean, roles, cr.quarantined,
                                      date_formats=_clean._strptime_formats(
                                          getattr(dcol, "date_formats", None)))
        fs = FactSet(run_id=run_id, now_iso=now)
        mr = _ms.measure_facts(fs, db_path, at, as_of=as_of, data_health=th.score, label=label,
                               claim_health=_ms.column_claim_health(th),
                               min_effect=float(getattr(pol, "min_effect_recommend", _ms.DEFAULT_BAR)),
                               q=float(getattr(pol, "recommend_q", _ms.DEFAULT_Q)),
                               primary_metric=str(getattr(pol, "primary_metric", "") or ""),
                               fdr_method=str(getattr(pol, "fdr_method", "bh") or "bh"))

    forecasts: Dict[str, Any] = {}
    with timer.stage("forecast", rows=cr.rows_clean):
        con = connect_ro(db_path)
        try:
            for s in mr.series[:max_series]:
                res = _fc.forecast_facts(fs, con, s.sql, s.label, s.unit, slug=s.slug,
                                         source_table=label, data_health=th.score, rows_scanned=s.rows,
                                         fill=s.fill, config={"horizon": int(horizon)},
                                         # a change of mix inside the history is a caveat on a
                                         # 12-versus-12 average, not on a forecast judged by its
                                         # own replay (review v2)
                                         confounders=[c for c in mr.confounders
                                                      if not c.startswith("the mix of ")],
                                         caveats=mr.caveats,
                                         as_of=as_of, step=getattr(s, "step", None))
                if res is not None:
                    forecasts[s.slug] = res
        finally:
            con.close()
        if len(mr.series) > max_series:
            mr.unmeasured.append("Only the first %d monthly series were forecast; %d more were not."
                                 % (max_series, len(mr.series) - max_series))

    with timer.stage("gate_verify"):
        gated = gate_analysis(fs.facts, policy)
        verification = EvidenceLedger(gated).verify(db_path)
        gated = _gate.withhold_unreproduced(gated)

    with timer.stage("narrate"):
        headlines = [g for g in gated if g.fact.role == "headline"]
        background = [g for g in gated if g.fact.role != "headline"]
        story = _narrate.narrate_story(gated, objective, enrichments=enrichments,
                                       not_measured=mr.unmeasured)
        brief = _narrate.narrate(headlines, objective, max_actions=max_actions)
        n_actions = sum(1 for g in headlines if g.gate.verdict == "RECOMMEND")
        full_brief = _narrate.narrate(headlines, objective,
                                      max_actions=max(max_actions, n_actions))
        # the benchmark figures quoted beside a confirmed change describe the engine, not the
        # file: they are cited where they are quoted, not listed under "About your file"
        about = ["%s [fact: %s]" % (g.fact.claim.rstrip("."), g.fact.id) for g in background
                 if (g.gate.signals or {}).get("rule") != "benchmark_rate"]
        for b in (brief, full_brief):
            b.story = story
            b.about_file = list(about)

    artifacts: Dict[str, str] = {}
    with timer.stage("write"):
        ledger = EvidenceLedger(gated)
        artifacts["evidence_csv"] = ledger.to_csv(os.path.join(out_dir, "analysis-ledger.csv"))
        artifacts["evidence_json"] = ledger.to_json(os.path.join(out_dir, "analysis-ledger.json"))
        for key, name, text in (("brief_md", "analysis-brief.md", full_brief.to_markdown()),
                                ("brief_exec_md", "analysis-brief-exec.md", brief.to_exec_markdown()),
                                ("story_md", "analysis-story.md", story.to_markdown())):
            p = os.path.join(out_dir, name)
            with open(p, "w", encoding="utf-8") as fh:
                fh.write(text)
            artifacts[key] = p
        verdict = {g.fact.id: g.gate.verdict for g in gated}
        fdoc = {}
        for slug_, fr in forecasts.items():
            d = fr.to_dict()
            d["label"] = next((s.label for s in mr.series if s.slug == slug_), slug_)
            d["unit"] = next((s.unit for s in mr.series if s.slug == slug_), "")
            d["verdict"] = verdict.get("forecast.%s.next" % slug_, "")
            d["fact_ids"] = sorted(g.fact.id for g in gated if g.fact.id.startswith("forecast.%s." % slug_))
            fdoc[slug_] = d
        p = os.path.join(out_dir, "forecast.json")
        with open(p, "w", encoding="utf-8") as fh:
            json.dump({"run_id": run_id, "table": table, "label": label, "as_of": as_of,
                       "landing": dict(landing) if landing else None, "forecasts": fdoc}, fh,
                      indent=1, default=float)
        artifacts["forecast_json"] = p
        p = os.path.join(out_dir, "measure.json")
        with open(p, "w", encoding="utf-8") as fh:
            json.dump(mr.to_dict(), fh, indent=1, default=str)
        artifacts["measure_json"] = p
        p = os.path.join(out_dir, "analysis-verification.json")
        with open(p, "w", encoding="utf-8") as fh:
            json.dump(verification, fh, indent=1, default=str)
        artifacts["verification_json"] = p

    return AnalyzeResult(
        table=table, objective=objective, run_id=run_id, health=th, clean=cr, roles=roles,
        measure=mr, forecasts=forecasts, facts=fs.facts, gated=gated, brief=brief,
        full_brief=full_brief, story=story, verification=verification, artifacts=artifacts,
        timings=list(timer.stages), as_of=as_of,
    )


# ==========================================================================
# E13: the timings receipt
# ==========================================================================
def engine_snapshot() -> Dict[str, Any]:
    """
    A content hash of the engine's source. The repository is not under version control
    here, so there is no commit id; this names exactly which code produced a timing.
    """
    import hashlib
    here = os.path.dirname(os.path.abspath(__file__))
    h = hashlib.sha256()
    files = sorted(f for f in os.listdir(here) if f.endswith(".py"))
    for f in files:
        h.update(f.encode("utf-8") + b"\0")
        with open(os.path.join(here, f), "rb") as fh:
            h.update(fh.read())
        h.update(b"\0")
    return {"kind": "sha256 of northledger/*.py (no git commit available)",
            "id": h.hexdigest(), "files": len(files), "environment": environment()}


#: The numpy release this engine's receipts are recorded with (design §1.1 M13: "numpy is
#: pinned per release"). Generator streams may change in a numpy feature release, so a
#: receipt names the release it was recorded on; the stable draws (random() only) keep the
#: engine's own resampling identical across releases in practice, and this says which.
NUMPY_PINNED = "2.0"


def environment() -> Dict[str, Any]:
    """
    The runtime a number was produced in (M13): the same engine hash on another numpy or in
    Pyodide can give other floating-point results, so every snapshot receipt names it.
    """
    import platform
    import sqlite3
    import sys as _sys
    env: Dict[str, Any] = {"python": platform.python_version(),
                           "python_implementation": platform.python_implementation(),
                           "sqlite": sqlite3.sqlite_version, "platform": platform.platform(),
                           "machine": platform.machine(), "numpy_pinned": NUMPY_PINNED}
    try:
        import numpy
        env["numpy"] = numpy.__version__
    except ImportError:
        env["numpy"] = None
    try:
        import pandas
        env["pandas"] = pandas.__version__
    except ImportError:
        env["pandas"] = None
    pyo = _sys.modules.get("pyodide")
    env["pyodide"] = getattr(pyo, "__version__", "yes") if pyo is not None else None
    return env


def machine_info() -> Dict[str, Any]:
    import platform
    info: Dict[str, Any] = {
        "platform": platform.platform(), "machine": platform.machine(),
        "processor": platform.processor(), "python": platform.python_version(),
        "cpu_count": os.cpu_count(),
    }
    try:
        info["memory_gb"] = round(os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 1024.0 ** 3, 1)
    except (ValueError, OSError, AttributeError):
        info["memory_gb"] = None
    try:
        import numpy, pandas
        info["numpy"], info["pandas"] = numpy.__version__, pandas.__version__
    except ImportError:
        pass
    return info


def run_bench(file_path: str, out_path: str, decisions: Optional[List[str]] = None,
              public_data: bool = False, objective: str = "What is happening to volume?",
              keep: Optional[str] = None) -> Dict[str, Any]:
    """
    Land -> decide -> audit -> analyze -> export on one file, in a throwaway engagement,
    timing every stage. Writes the receipt to out_path and returns it. Nothing is sent
    anywhere and no AI model is called.
    """
    import hashlib
    import shutil
    import tempfile
    import time
    from . import engagement as E
    from . import pbip_lint, powerbi, report

    sha = hashlib.sha256()
    with open(file_path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            sha.update(chunk)
    root = keep or tempfile.mkdtemp(prefix="nl_bench_")
    eng_dir = os.path.join(root, "bench-engagement")
    if os.path.isdir(eng_dir):
        shutil.rmtree(eng_dir)
    timer = StageTimer()
    doc: Dict[str, Any] = {
        "what": "NorthLedger timings receipt: one recorded run, not an average",
        "machine": machine_info(),
        "date": _now_iso(),
        "input": {"file": os.path.basename(file_path), "bytes": os.path.getsize(file_path),
                  "sha256": sha.hexdigest()},
        "engine": engine_snapshot(),
        "ai_model_called": False,
        "stages": [], "ok": False, "error": "",
    }
    t_all = time.perf_counter()
    rows = 0
    try:
        eng = E.open_engagement(eng_dir, create=True)
        with timer.stage("land"):
            res = E.land(eng, file_path, allow_public_data=public_data)
        rows = int(res.n_rows)
        timer.stages[-1]["rows"] = rows
        timer.stages[-1]["rows_per_s"] = round(rows / max(timer.stages[-1]["seconds"], 1e-9), 1)
        with timer.stage("decide"):
            for d in decisions or []:
                col, _, choice = d.partition("=")
                E.decide(eng, col.strip(), choice.strip())
        with timer.stage("audit", rows=rows):
            E.run_audit(eng, objective)
        inner = StageTimer()
        with timer.stage("analyze", rows=rows):
            meta = eng.meta()
            table = meta["landings"][-1]["table"]
            r = run_analyze(eng.db_path, table, objective, out_dir=os.path.join(eng.run_dir, "analysis"),
                            display_name=meta["landings"][-1]["file"], timer=inner,
                            landing=E.landing_stamp(meta, table))
            report.deliverables(r.brief, r.gated, eng.deliverables_dir, stem="business-analysis",
                                title="Business Analysis", full_brief=r.full_brief)
        for st in inner.stages:
            st = dict(st)
            st["stage"] = "analyze." + st["stage"]
            st["part_of"] = "analyze"          # already inside the analyze total; do not add up
            timer.stages.append(st)
        with timer.stage("export", rows=rows):
            pr = powerbi.export_engagement(eng, name="NorthLedger Bench")
            problems = pbip_lint.lint(pr["project_dir"])
        doc["export_lint_problems"] = len(problems)
        doc["analysis"] = {"facts": len(r.facts), "reproduced": r.verification.get("reproduced"),
                           "checked": r.verification.get("checked"),
                           "forecasts": {k: {"champion": v.champion, "baseline_won": v.baseline_won,
                                             "holdout_months": v.holdout}
                                         for k, v in r.forecasts.items()}}
        doc["ok"] = not problems
    except Exception as exc:  # noqa: BLE001 - the receipt records the failure instead of hiding it
        doc["error"] = "%s: %s" % (type(exc).__name__, str(exc)[:300])
    finally:
        doc["stages"] = timer.stages
        doc["rows"] = rows
        doc["total_seconds"] = round(time.perf_counter() - t_all, 3)
        doc["end_to_end_rows_per_s"] = round(rows / doc["total_seconds"], 1) if rows else None
        doc["peak_rss_mb"] = StageTimer.peak_rss_mb()
        if not keep:
            shutil.rmtree(root, ignore_errors=True)
        os.makedirs(os.path.dirname(os.path.abspath(out_path)) or ".", exist_ok=True)
        with open(out_path, "w", encoding="utf-8") as fh:
            json.dump(doc, fh, indent=1, default=str)
    return doc
