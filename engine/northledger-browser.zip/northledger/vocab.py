#!/usr/bin/env python3
"""
The one definition of "this value means missing".

Before this module existed, three parts of the engine disagreed: the profiler
counted 6 tokens as missing, the cleaner repaired 14, and the evaluation
harness planted 9. On the same table the Data Health Score treated '#N/A' as a
real value and then the cleaning report repaired it -- two documents for one
client disagreeing about the same cells.

The base is pandas' default `na_values`, an established external convention,
rather than a list tuned to pass this project's own benchmark. To it are added
common spreadsheet and database export artefacts.

Deliberately NOT included: 'unknown' and 'unspecified'. In real source systems
they are often genuine category values -- the NYPD collision data records
UNKNOWN as a vehicle type and uses 'Unspecified' as its official code for "no
contributing factor recorded" (16,316 rows). Treating them as missing would
corrupt real categories. The cost is stated, not hidden: the benchmark plants
'unknown' as a placeholder, and those plants are counted as missed.
"""
from __future__ import annotations

# pandas.io.parsers default na_values (the empty string is handled separately
# by every caller, as blank-after-trimming).
_PANDAS_DEFAULT = (
    "#N/A", "#N/A N/A", "#NA", "-1.#IND", "-1.#QNAN", "-NaN", "-nan",
    "1.#IND", "1.#QNAN", "<NA>", "N/A", "NA", "NULL", "NaN", "None",
    "n/a", "nan", "null",
)

# Spreadsheet and database export artefacts seen in the wild.
_EXPORT_ARTEFACTS = ("-", "--", "?", "nil", "(null)", "#NULL!", "n.a.", "\\N")

# Case-insensitive, compared after trimming. Upper-cased for SQL comparisons.
NULL_TOKENS_UPPER = tuple(sorted({t.strip().upper() for t in _PANDAS_DEFAULT + _EXPORT_ARTEFACTS
                                  if t.strip()}))
NULL_TOKENS_LOWER = tuple(sorted({t.lower() for t in NULL_TOKENS_UPPER}))

# Tokens that look like placeholders but are kept as values, and why.
NOT_NULL_ON_PURPOSE = ("unknown", "unspecified")


def is_null_like(value) -> bool:
    """Python-side test, identical in meaning to the SQL used by the profiler."""
    if value is None:
        return True
    try:
        import math
        if isinstance(value, float) and math.isnan(value):
            return True
    except Exception:  # noqa: BLE001
        pass
    s = str(value).strip()
    return s == "" or s.upper() in NULL_TOKENS_UPPER


# ---------------------------------------------------------------- day/month order
# One rule for "is 05/03/2025 the 5th of March or the 3rd of May?", used by the
# profiler (in SQL) and the cleaner (in pandas) so the two can never read the
# same column two ways. The evidence is the column's own values: a first part
# above 12 can only be a day, a second part above 12 can only be a day.
#   dmy      some values prove day-first, none prove month-first
#   mdy      the reverse
#   mixed    both kinds of proof: the column holds two conventions, and a value
#            that could be either cannot be read without guessing
#   unknown  no proof either way: one disclosed default for the whole column
def day_month_order(n_first_over_12: int, n_second_over_12: int) -> str:
    if n_first_over_12 and n_second_over_12:
        return "mixed"
    if n_first_over_12:
        return "dmy"
    if n_second_over_12:
        return "mdy"
    return "unknown"


# ---------------------------------------------------------------- yes/no spellings
# One list of the spellings a yes/no column is exported with. Keys are compared
# after trimming and lower-casing. "1"/"0" are included because Excel and SQL
# exports write booleans that way; the cleaner only maps them inside a column
# that is already mostly yes/no values (see clean.BOOLEAN_DOMINANCE), so a
# numeric column of counts is never read as booleans.
BOOLEAN_SYNONYMS = {
    "true": True, "false": False,
    "t": True, "f": False,
    "yes": True, "no": False,
    "y": True, "n": False,
    "1": True, "0": False,
}
# The pairs a column can be written in; the column keeps the pair it mostly uses.
BOOLEAN_PAIRS = (("true", "false"), ("yes", "no"), ("y", "n"), ("t", "f"), ("1", "0"))


def boolean_value(value):
    """True / False for a recognised yes/no spelling, else None."""
    if isinstance(value, bool):
        return value
    if value is None:
        return None
    try:
        if isinstance(value, (int, float)) and value in (0, 1):
            return bool(value)
    except Exception:  # noqa: BLE001
        return None
    return BOOLEAN_SYNONYMS.get(str(value).strip().lower())


# ---------------------------------------------------------------- cleaning facts
# Every fact the cleaner emits carries this line in its query, so the gate can
# recognise a cleaning figure without importing pandas.
CLEAN_QUERY_MARKER = "from northledger.clean import clean_table"
# Said on a cleaning fact whose data_health is the share of rows that survived
# cleaning, because no stage-1 score was supplied. Row retention is NOT a quality
# score, and nothing may describe it as one.
RETENTION_CAVEAT = "data_health here is row retention, not a stage-1 table score"


# ---------------------------------------------------------------- verdict names (§2.4)
# Internal verdict codes stay RECOMMEND / WATCH / INSUFFICIENT (the ledger, the gate, the
# tests). A visitor reads an evidence grade: the engine finds associations in observational
# 12-versus-12 comparisons, not causes, so "recommend" oversold it (design §2.4).
VISITOR_VERDICT = {"RECOMMEND": "CONFIRMED", "WATCH": "WATCH", "INSUFFICIENT": "NOT ENOUGH DATA"}


def visitor_verdict(code: str) -> str:
    """The grade a visitor reads for an internal verdict code."""
    return VISITOR_VERDICT.get(str(code), str(code))


# ---------------------------------------------------------------- the wording guard (M12)
# Never in engine text: a p-value, q-value or verdict presented as confidence or as the
# probability a claim is true (ASA statement, principles 2 and 3), and never causal wording
# for a change the engine only associates with a period. The C8 posterior sentence, if it
# ships, has its own fixed template and its own test.
import re as _re

BANNED_CONFIDENCE = (
    _re.compile(r"\d+(?:\.\d+)?\s*%\s*(?:confident|sure|certain)\b", _re.I),
    _re.compile(r"\b(?:confident|sure|certain)\s+(?:at|to)\s+\d", _re.I),
    _re.compile(r"\bprobability\s+(?:that\s+)?(?:the\s+)?(?:claim|change|finding|result|it)\b[^.]*\bis\s+true\b",
                _re.I),
    _re.compile(r"\bchance\s+(?:that\s+)?(?:the\s+)?(?:claim|change|finding|result|it)\b[^.]*\bis\s+(?:true|real)\b",
                _re.I),
    _re.compile(r"\bwould still turn up by chance\b", _re.I),
)
# causal verbs and phrases a change claim must not use about its own movement
CAUSAL_WORDS = (
    _re.compile(r"\b(?:caused|causes|causing)\b", _re.I),
    _re.compile(r"\bbecause of\b", _re.I),
    _re.compile(r"\bdue to\b", _re.I),
    _re.compile(r"\b(?:drove|drives|driven by)\b", _re.I),
    _re.compile(r"\bled to\b", _re.I),
    _re.compile(r"\bresult(?:ed|s)? in\b", _re.I),
)


def wording_problems(text: str, causal: bool = True) -> list:
    """The banned confidence or causal phrases in `text` (empty when it is clean)."""
    out = []
    for rx in BANNED_CONFIDENCE + (CAUSAL_WORDS if causal else ()):
        m = rx.search(str(text or ""))
        if m:
            out.append(m.group(0))
    return out


def plural_of(name: str) -> str:
    """A column's name as a plural noun for the reader ('property' -> 'properties', 'store' ->
    'stores', 'branch' -> 'branches'): 'the 3 properties present in every modelled month', not
    'the 3 property values' (fixer round, 24 Sep 2026)."""
    w = " ".join(str(name or "").replace("_", " ").split()).strip()
    if not w:
        return "values"
    low = w.lower()
    if low.endswith(("s", "x", "z", "ch", "sh")):
        return w + "es" if not low.endswith("s") else w
    if low.endswith("y") and len(low) > 1 and low[-2] not in "aeiou":
        return w[:-1] + "ies"
    return w + "s"
