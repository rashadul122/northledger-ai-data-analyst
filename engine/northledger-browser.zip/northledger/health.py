#!/usr/bin/env python3
"""
Stage 1 of the NorthLedger Insight Loop: profile before anything.

Nothing downstream is allowed to look at a table until this module has scored
it. The output -- a `TableHealth` -- is both an internal gating signal (every
`Fact` carries the `data_health` of the table it came from) and the artefact the
client pays for: the Data Health Audit.

Design rules this module obeys
------------------------------
* Aggregate SQL only. No table is ever pulled into memory. Every measurement is
  a COUNT/SUM over a generated expression, so a 40M-row table costs scans, not RAM.
* Never mutate. Only SELECT and PRAGMA are issued. `connect_read_only` is
  provided so a caller can prove it at the connection level.
* Identifiers are quoted defensively and the table name is resolved against
  `sqlite_master` with a bound parameter before it is ever interpolated.
* Every number that CAN be expressed as one re-runnable SQL statement is
  captured by *executing that statement* and keeping both the SQL and its
  result. `to_facts()` therefore emits Facts that reproduce by construction --
  `EvidenceLedger.verify` re-runs them and gets the same number back.

HOW THE SCORE IS MADE (a client will ask; this is the answer)
-------------------------------------------------------------
Five dimensions, each scored 0-100 and rounded to 1 decimal. The overall score
is the mean of the dimensions that APPLY, rounded to 1 decimal. A dimension that
cannot apply is `None` and is excluded from the mean -- it is never scored 0,
because "this table has no date column" is not the same statement as "this
table's dates are terrible".

completeness
    Share of cells that are not null-like, across the whole table.
    Null-like = SQL NULL, empty string, whitespace-only, or -- case
    insensitively, after trimming -- one of 'NULL', 'N/A', 'NA', 'none', '-',
    '?'. This project has genuinely seen the string 'NULL' rank as the #1
    borough in a city dataset, which is why the literals are in the definition
    and not in a footnote.
        completeness = 100 * (1 - null_like_cells / (n_rows * n_cols))

validity
    Per column: every non-null-like value is classified as a date (in one of
    five recognised formats), a number, or text. The column's inferred type is
    the largest class, and its validity starts as that class's share -- a column
    that is 60% numbers and 40% prose scores 0.60, because half of it will break
    whatever is done to the other half. Two further penalties apply:
      * a date column is multiplied by (values in its dominant format / all its
        date values), so mixed formats -- '2026-01-05' next to '01/05/2026' --
        count against it;
      * a numeric column is multiplied by (1 - 0.5 * share stored with SQLite
        storage class 'text') and by (1 - share carrying formatting such as
        '1,200' or '$85.00'), because numbers-stored-as-text do not sort, sum,
        or compare.
    The dimension is the mean over columns that have at least one non-null-like
    value. Columns that are genuinely text are NOT penalised for being text.

uniqueness
    Two penalties, applied multiplicatively:
      * fully duplicated rows: (1 - duplicated_rows / n_rows);
      * the worst id-like column: (1 - (1 - distinct_values / non_null_values)).
    A column is id-like when its name ends in id / _id / key / _key / uuid / pk
    AND more than 90% of its non-null values are already distinct. The
    distinctness requirement is what makes the name heuristic safe: it means a
    boolean column called `valid` or a category called `monkey` can never be
    mistaken for a key, and a column named `customer_id` that is only 40%
    distinct is read as a foreign key -- which is supposed to repeat -- rather
    than as a broken primary key.

consistency
    Per text column, two penalties applied multiplicatively:
      * casing/padding collapse: (1 - (distinct_raw - distinct_normalised) /
        distinct_raw), where normalised = lowercased and trimmed. 'Brooklyn',
        'BROOKLYN' and ' brooklyn ' are three raw values and one real value, so
        that column loses two thirds of this factor;
      * untrimmed padding: (1 - padded_values / non_null_values).
    The dimension is the mean over text columns. A table with no text columns
    scores 100 here -- it has nothing to be inconsistent about. The one
    exception is a table in which EVERY cell is null-like: there consistency
    and uniqueness are `None` rather than a vacuous 100, because a table with
    no content must not average its way to a passing score.

timeliness
    Only when a date-like column exists; otherwise `None` and excluded.
    The date column with the most parseable date values is chosen, its values
    are normalised to ISO in SQL, and:
      * staleness: 1.0 while the newest row is within 30 days, then decaying
        linearly to 0.0 at 730 days;
      * future rows: (1 - rows_dated_after_today / dated_rows).
        timeliness = 100 * staleness * (1 - future_share)
    Day/month order for slash dates is assumed US (MM/DD/YYYY) and for dashed
    four-digit-last dates European (DD-MM-YYYY); when either is present the
    column carries an explicit issue saying so.

Python 3.9 compatible. Depends on the standard library only.
"""
from __future__ import annotations

import datetime as _dt
import re
import sqlite3
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

from northledger.facts import Fact
from ._sqlite import connect_ro  # noqa: E402

__all__ = [
    "ColumnHealth",
    "TableHealth",
    "score_table",
    "connect_read_only",
    "NULL_LIKE_LITERALS",
    "DIMENSIONS",
]

# --------------------------------------------------------------------------
# tuning constants -- every one of them shows up in the docstring above
# --------------------------------------------------------------------------
# One definition of "missing", shared with clean.py; see northledger/vocab.py.
from .vocab import NULL_TOKENS_UPPER as NULL_LIKE_LITERALS  # noqa: E402
from .vocab import day_month_order  # noqa: E402

# AS MATERIALIZED arrived in SQLite 3.35; older builds get the same query, unforced.
_MATERIALIZED = "MATERIALIZED " if sqlite3.sqlite_version_info >= (3, 35, 0) else ""
DIMENSIONS = ("completeness", "validity", "uniqueness", "consistency", "timeliness")

_FRESH_DAYS = 30          # newest row this recent => no staleness penalty
_DEAD_DAYS = 730          # newest row this old => staleness factor 0.0
_NUM_AS_TEXT_PENALTY = 0.5
_ID_DISTINCT_THRESHOLD = 0.90
_ID_NAME_SUFFIXES = ("id", "_id", "key", "_key", "uuid", "_uuid", "pk", "_pk")
_TOP_VALUES = 5
_TOP_VALUE_CARDINALITY_CAP = 50000
_MAX_FINDINGS = 14

# (label, GLOB pattern) -- order matters, first match wins, code = index + 1
_DATE_FORMATS = (
    ("YYYY-MM-DD", "[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]"),
    # ISO-8601 with a 'T' separator must be matched BEFORE the loose
    # "YYYY-MM-DD HH:MM" pattern below, whose trailing ?* swallows it. Calling a
    # 2026-05-31T00:00:00.000 value "YYYY-MM-DD HH:MM" made stage 2 hand pandas
    # the format "%Y-%m-%d %H:%M", which cannot parse it -- so 5,088 perfectly
    # good timestamps were quarantined as "matches no known date format".
    ("YYYY-MM-DDTHH:MM:SS", "[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]T*"),
    ("YYYY-MM-DD HH:MM", "[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]?*"),
    ("MM/DD/YYYY", "[0-9][0-9]/[0-9][0-9]/[0-9][0-9][0-9][0-9]"),
    # US 12-hour timestamps: NYC 311, Excel and SQL Server exports.
    ("MM/DD/YYYY hh:mm:ss AM",
     "[0-9][0-9]/[0-9][0-9]/[0-9][0-9][0-9][0-9] [0-9][0-9]:[0-9][0-9]:[0-9][0-9] [AaPp][Mm]"),
    ("DD-MM-YYYY", "[0-9][0-9]-[0-9][0-9]-[0-9][0-9][0-9][0-9]"),
    ("YYYY/MM/DD", "[0-9][0-9][0-9][0-9]/[0-9][0-9]/[0-9][0-9]"),
    # Excel's default display format for a date column. Extremely common in
    # real exports and previously invisible to the profiler.
    ("DD-Mon-YYYY", "[0-9][0-9]-[A-Za-z][A-Za-z][A-Za-z]-[0-9][0-9][0-9][0-9]"),
    ("DD-Mon-YY", "[0-9][0-9]-[A-Za-z][A-Za-z][A-Za-z]-[0-9][0-9]"),
    # 'Feb 03 2025': month-name dates with no comma, common in report exports.
    ("Mon DD YYYY", "[A-Za-z][A-Za-z][A-Za-z] [0-9][0-9] [0-9][0-9][0-9][0-9]"),
    # Month-level dates, one row per month in a KPI file (review v2, 24 Sep 2026: '2024-11'
    # and 'Dec-2024' were text, so a monthly metrics file had no date column). The letters
    # are limited to those month abbreviations use, so a code like 'SKU-2024' is not a date.
    ("YYYY-MM", "[12][0-9][0-9][0-9]-[01][0-9]"),
    ("YYYY/MM", "[12][0-9][0-9][0-9]/[01][0-9]"),
    ("Mon-YYYY", "[JFMASONDjfmasond][aeupcoAEUPCO][nbrylgptvcNBRYLGPTVC]-[12][0-9][0-9][0-9]"),
    ("Mon YYYY", "[JFMASONDjfmasond][aeupcoAEUPCO][nbrylgptvcNBRYLGPTVC] [12][0-9][0-9][0-9]"),
)

# The two numeric shapes whose day/month order cannot be told from the shape
# alone, with the order each label assumes when the column's values prove
# nothing. When they DO prove something (a first part above 12 can only be a
# day), the column is relabelled and read that way -- see vocab.day_month_order,
# which the cleaner applies to the same values, so the two stages agree.
_DAY_MONTH_SHAPES = {"MM/DD/YYYY": "mdy", "MM/DD/YYYY hh:mm:ss AM": "mdy", "DD-MM-YYYY": "dmy"}
_ORDER_LABEL = {("MM/DD/YYYY", "dmy"): "DD/MM/YYYY", ("DD-MM-YYYY", "mdy"): "MM-DD-YYYY",
                ("MM/DD/YYYY hh:mm:ss AM", "dmy"): "DD/MM/YYYY hh:mm:ss AM"}
_LABEL_GLOB = dict(_DATE_FORMATS)
_LABEL_GLOB.update((new, _LABEL_GLOB[old]) for (old, _o), new in _ORDER_LABEL.items())

_CODE_CLEAN_NUM = len(_DATE_FORMATS) + 1   # 6
_CODE_DIRTY_NUM = len(_DATE_FORMATS) + 2   # 7
_CODE_TEXT = len(_DATE_FORMATS) + 3        # 8

_WS_CHARS = "char(32)||char(9)||char(10)||char(13)"
_FMT_CHARS = "0123456789,.$% "


# --------------------------------------------------------------------------
# SQL construction helpers
# --------------------------------------------------------------------------
def _qi(name: str) -> str:
    """Quote an SQLite identifier. The only safe way to interpolate a name."""
    return '"' + str(name).replace('"', '""') + '"'


def _trim(expr: str) -> str:
    return "TRIM(CAST(%s AS TEXT), %s)" % (expr, _WS_CHARS)


def _strip_chars(expr: str, chars: str) -> str:
    out = expr
    for ch in chars:
        out = "REPLACE(%s, '%s', '')" % (out, ch)
    return out


def _null_like_on(t_expr: str) -> str:
    """Null-like test written against an ALREADY trimmed text expression."""
    lits = ", ".join("'%s'" % s.replace("'", "''") for s in NULL_LIKE_LITERALS)
    return "(%s IS NULL OR %s = '' OR UPPER(%s) IN (%s))" % (t_expr, t_expr, t_expr, lits)


def _null_like_col(col: str) -> str:
    """Null-like test for a raw column, usable anywhere in a query."""
    return _null_like_on(_trim(_qi(col)))


def _display_expr(col: str) -> str:
    """
    A value expression that is always safe to hand back to Python.

    Identical to the trimmed text of the column, except that a BLOB is
    described rather than returned -- returning raw bytes through sqlite3's
    text factory is how a binary column takes the whole scan down.
    """
    q = _qi(col)
    return (
        "CASE WHEN typeof({q}) = 'blob' THEN '<blob:' || length({q}) || ' bytes>' "
        "ELSE {t} END"
    ).format(q=q, t=_trim(q))


def _class_case() -> str:
    """
    Classify one value. Expects aliases `nl`, `t` and `body` to be in scope.

    0 null-like | 1..5 a recognised date format | 6 clean number |
    7 number wearing formatting ('1,200', '$85.00') | 8 text.
    """
    digits_gone = _strip_chars("body", "0123456789")
    fmt_gone = _strip_chars("body", _FMT_CHARS)
    has_digit = "LENGTH(body) > LENGTH(%s)" % digits_gone

    parts = ["CASE WHEN nl = 1 THEN 0"]
    for i, (_label, glob) in enumerate(_DATE_FORMATS, start=1):
        parts.append("WHEN t GLOB '%s' THEN %d" % (glob, i))
    parts.append("WHEN %s AND %s IN ('', '.') THEN %d" % (has_digit, digits_gone, _CODE_CLEAN_NUM))
    parts.append("WHEN %s AND %s = '' THEN %d" % (has_digit, fmt_gone, _CODE_DIRTY_NUM))
    # a magnitude suffix after the digits ('$31.0k', '1.2M'): a number the cleaner reads
    parts.append("WHEN %s AND %s IN ('k', 'K', 'M') AND substr(body, -1) IN ('k', 'K', 'M') "
                 "AND substr(body, -2, 1) GLOB '[0-9.]' THEN %d" % (has_digit, fmt_gone, _CODE_DIRTY_NUM))
    parts.append("ELSE %d END" % _CODE_TEXT)
    return " ".join(parts)


# The SQL that turns each recognised date label into YYYY-MM-DD, keyed by LABEL.
# It used to be chosen by list position; inserting one format shifted every later
# one onto its neighbour's transform, and 12 March (MM/DD/YYYY) was read as
# 3 December -- 446 invented future-dated rows in a delivered audit (22 Sep 2026).
_MONTH = ("(CASE UPPER(substr({t},4,3)) WHEN 'JAN' THEN '01' WHEN 'FEB' THEN '02' "
          "WHEN 'MAR' THEN '03' WHEN 'APR' THEN '04' WHEN 'MAY' THEN '05' WHEN 'JUN' THEN '06' "
          "WHEN 'JUL' THEN '07' WHEN 'AUG' THEN '08' WHEN 'SEP' THEN '09' WHEN 'OCT' THEN '10' "
          "WHEN 'NOV' THEN '11' WHEN 'DEC' THEN '12' END)")
_DATE_TO_ISO = {
    "YYYY-MM-DD": "{t}",
    "YYYY-MM-DDTHH:MM:SS": "substr({t},1,10)",
    "YYYY-MM-DD HH:MM": "substr({t},1,10)",
    "MM/DD/YYYY": "substr({t},7,4)||'-'||substr({t},1,2)||'-'||substr({t},4,2)",
    "MM/DD/YYYY hh:mm:ss AM": "substr({t},7,4)||'-'||substr({t},1,2)||'-'||substr({t},4,2)",
    "DD-MM-YYYY": "substr({t},7,4)||'-'||substr({t},4,2)||'-'||substr({t},1,2)",
    "YYYY/MM/DD": "REPLACE({t},'/','-')",
    "DD-Mon-YYYY": "substr({t},8,4)||'-'||" + _MONTH + "||'-'||substr({t},1,2)",
    "Mon DD YYYY": "substr({t},8,4)||'-'||" + _MONTH.replace("substr({t},4,3)", "substr({t},1,3)")
                   + "||'-'||substr({t},5,2)",
    # Two-digit years pivot like Python's %y (00-68 -> 20xx, 69-99 -> 19xx), so the
    # profiler and the cleaner, which parses with strptime, agree on the century.
    "YYYY-MM": "{t}||'-01'",
    "YYYY/MM": "REPLACE({t},'/','-')||'-01'",
    "Mon-YYYY": "substr({t},5,4)||'-'||" + _MONTH.replace("substr({t},4,3)", "substr({t},1,3)") + "||'-01'",
    "Mon YYYY": "substr({t},5,4)||'-'||" + _MONTH.replace("substr({t},4,3)", "substr({t},1,3)") + "||'-01'",
    "DD-Mon-YY": ("(CASE WHEN CAST(substr({t},8,2) AS INTEGER) < 69 THEN '20' ELSE '19' END)"
                  "||substr({t},8,2)||'-'||" + _MONTH + "||'-'||substr({t},1,2)"),
}


_DMY_ISO = "substr({t},7,4)||'-'||substr({t},4,2)||'-'||substr({t},1,2)"
_MDY_ISO = "substr({t},7,4)||'-'||substr({t},1,2)||'-'||substr({t},4,2)"


def _to_iso(label: str, order: str) -> str:
    """The ISO transform for one label, honouring the column's day/month order."""
    if label not in _DAY_MONTH_SHAPES:
        return _DATE_TO_ISO[label]
    if order == "mixed":
        # read only what the value itself proves; a value that could be either is NULL
        return ("(CASE WHEN CAST(substr({t},1,2) AS INTEGER) > 12 THEN %s "
                "WHEN CAST(substr({t},4,2) AS INTEGER) > 12 THEN %s "
                "WHEN substr({t},1,2) = substr({t},4,2) THEN %s ELSE NULL END)"
                % (_DMY_ISO, _MDY_ISO, _MDY_ISO))
    use = order if order in ("dmy", "mdy") else _DAY_MONTH_SHAPES[label]
    return _DMY_ISO if use == "dmy" else _MDY_ISO


def _iso_case(t_expr: str = "t", order: str = "") -> str:
    """Normalise every recognised date format to 'YYYY-MM-DD', else NULL."""
    missing = [label for label, _ in _DATE_FORMATS if label not in _DATE_TO_ISO]
    if missing:
        raise RuntimeError("date label(s) with no ISO transform: %s" % ", ".join(missing))
    whens = " ".join(
        "WHEN {t} GLOB '%s' THEN %s" % (pattern.replace("'", "''"), _to_iso(label, order))
        for label, pattern in _DATE_FORMATS          # same order as matching: first wins
    )
    return ("CASE " + whens + " ELSE NULL END").format(t=t_expr)


def _classified(src: str, col: str) -> str:
    """One row per source row: raw text, trimmed text, storage type, null flag, class code."""
    q = _qi(col)
    l1 = "SELECT CAST({q} AS TEXT) AS raw, {t} AS t, typeof({q}) AS ty FROM {src}".format(
        q=q, t=_trim(q), src=src
    )
    l2 = (
        "SELECT raw, t, ty, CASE WHEN {nl} THEN 1 ELSE 0 END AS nl, "
        "CASE WHEN substr(t,1,1) IN ('-','+') THEN substr(t,2) ELSE t END AS body "
        "FROM ({l1})"
    ).format(nl=_null_like_on("t"), l1=l1)
    return "SELECT raw, t, ty, nl, {code} AS code FROM ({l2})".format(code=_class_case(), l2=l2)


def _profile_sql(src: str, col: str) -> str:
    aggs = [
        "COUNT(*)",
        "COALESCE(SUM(nl), 0)",
        "COUNT(DISTINCT CASE WHEN nl = 0 THEN raw END)",
        "COUNT(DISTINCT CASE WHEN nl = 0 THEN LOWER(t) END)",
        "COALESCE(SUM(CASE WHEN nl = 0 AND raw <> t THEN 1 ELSE 0 END), 0)",
        "COALESCE(SUM(CASE WHEN nl = 0 AND ty = 'text' THEN 1 ELSE 0 END), 0)",
        "COALESCE(SUM(CASE WHEN code IN (%d, %d) AND ty = 'text' THEN 1 ELSE 0 END), 0)"
        % (_CODE_CLEAN_NUM, _CODE_DIRTY_NUM),
    ]
    for code in range(1, _CODE_TEXT + 1):
        aggs.append("COALESCE(SUM(CASE WHEN code = %d THEN 1 ELSE 0 END), 0)" % code)
    # day/month evidence over the two ambiguous numeric shapes (see _DAY_MONTH_SHAPES)
    dm_codes = ", ".join(str(i) for i, (label, _g) in enumerate(_DATE_FORMATS, start=1)
                         if label in _DAY_MONTH_SHAPES)
    a, b = "CAST(substr(t,1,2) AS INTEGER)", "CAST(substr(t,4,2) AS INTEGER)"
    for cond in ("%s > 12 AND %s <= 12" % (a, b), "%s > 12 AND %s <= 12" % (b, a),
                 "%s <= 12 AND %s <= 12 AND %s <> %s" % (a, b, a, b)):
        aggs.append("COALESCE(SUM(CASE WHEN code IN (%s) AND %s THEN 1 ELSE 0 END), 0)"
                    % (dm_codes, cond))
    # Every aggregate above reads code/nl/t. As a plain subquery SQLite flattens the
    # classifier into each reference and re-runs its GLOBs and REPLACE chains ~10
    # times a row; materialised, it runs once. Identical results, 10-17x faster on
    # NYC 311 (police_precinct at 20k rows: 3.28s -> 0.20s).
    # The CTE takes a reserved name: a client table called "c" made it circular.
    return "WITH _northledger_cls AS %s(%s) SELECT %s FROM _northledger_cls" % (
        _MATERIALIZED, _classified(src, col), ", ".join(aggs))


def _null_pct_sql(src: str, col: str) -> str:
    return (
        "SELECT ROUND(100.0 * COALESCE(SUM(CASE WHEN {nl} THEN 1 ELSE 0 END), 0) "
        "/ COUNT(*), 1) FROM {src}"
    ).format(nl=_null_like_col(col), src=src)


def _null_cells_expr(cols: Sequence[str]) -> str:
    return " + ".join(
        "COALESCE(SUM(CASE WHEN %s THEN 1 ELSE 0 END), 0)" % _null_like_col(c) for c in cols
    )


def _scalar(con: sqlite3.Connection, sql: str) -> Any:
    row = con.execute(sql).fetchone()
    return None if row is None else row[0]


# --------------------------------------------------------------------------
# dataclasses
# --------------------------------------------------------------------------
@dataclass
class ColumnHealth:
    """Per-column profile. `issues` are client-readable, one sentence each."""

    name: str
    dtype_guess: str = "unknown"          # date | numeric | text | empty
    n_null_like: int = 0
    pct_null_like: float = 0.0
    n_distinct: int = 0                   # distinct RAW values, null-like excluded
    top_values: List[Tuple[Any, int]] = field(default_factory=list)
    issues: List[str] = field(default_factory=list)

    # -- detail the dimensions are computed from (not part of the headline) --
    declared_type: str = ""
    n_rows: int = 0
    n_non_null: int = 0
    n_distinct_normalised: int = 0
    n_padded: int = 0
    n_stored_text: int = 0
    n_numeric_as_text: int = 0
    class_counts: Dict[str, int] = field(default_factory=dict)
    date_formats: Dict[str, int] = field(default_factory=dict)
    day_month_order: str = ""             # dmy | mdy | mixed | unknown, "" when not applicable
    validity: Optional[float] = None      # 0-1, None when the column is all null-like
    consistency: Optional[float] = None   # 0-1, None for non-text columns
    is_id_like: bool = False

    @property
    def distinct_ratio(self) -> float:
        return (self.n_distinct / self.n_non_null) if self.n_non_null else 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "dtype_guess": self.dtype_guess,
            "declared_type": self.declared_type,
            "n_rows": self.n_rows,
            "n_null_like": self.n_null_like,
            "pct_null_like": self.pct_null_like,
            "n_distinct": self.n_distinct,
            "n_distinct_normalised": self.n_distinct_normalised,
            "n_padded": self.n_padded,
            "n_stored_text": self.n_stored_text,
            "n_numeric_as_text": self.n_numeric_as_text,
            "class_counts": dict(self.class_counts),
            "date_formats": dict(self.date_formats),
            "day_month_order": self.day_month_order,
            "validity": self.validity,
            "consistency": self.consistency,
            "is_id_like": self.is_id_like,
            "top_values": [[v, n] for (v, n) in self.top_values],
            "issues": list(self.issues),
        }


@dataclass
class TableHealth:
    """
    The Data Health Audit for one table.

    `dimensions` always carries all five keys of `DIMENSIONS`; a value of None
    means the dimension does not apply and was EXCLUDED from `score`. The cases:
    timeliness is None when the table holds no date-like column (or none of its
    values parse); validity is None when no column has a single non-null-like
    value; uniqueness and consistency are None only in that same
    nothing-to-measure case, where a 100 would be vacuous rather than earned.
    All five are None when the table holds no rows at all, and `score` is then
    0.0 by convention, which the findings say out loud.
    """

    table: str
    n_rows: int = 0
    n_cols: int = 0
    score: float = 0.0
    dimensions: Dict[str, Optional[float]] = field(default_factory=dict)
    columns: List[ColumnHealth] = field(default_factory=list)
    findings: List[str] = field(default_factory=list)

    # provenance
    scanned_at: str = ""
    total_rows: int = 0        # rows in the table; differs from n_rows when sampled
    sampled: bool = False
    date_column: str = ""
    # (sql, value) pairs captured by ACTUALLY RUNNING the sql during the scan,
    # which is what makes to_facts() reproducible rather than merely plausible.
    sql_evidence: List[Dict[str, Any]] = field(default_factory=list)
    # validity capped by what the cleaner could read (reflect_cleaning, review v2), or None
    validity_cap: Optional[Dict[str, Any]] = None

    # -- export ------------------------------------------------------------
    def to_dict(self) -> Dict[str, Any]:
        return {
            "table": self.table,
            "n_rows": self.n_rows,
            "total_rows": self.total_rows,
            "sampled": self.sampled,
            "n_cols": self.n_cols,
            "score": self.score,
            "dimensions": dict(self.dimensions),
            "date_column": self.date_column,
            "scanned_at": self.scanned_at,
            "columns": [c.to_dict() for c in self.columns],
            "findings": list(self.findings),
            "sql_evidence": [dict(e) for e in self.sql_evidence],
        }

    def to_facts(self, prefix: str = "health") -> List[Fact]:
        """
        Turn the audit into typed Facts for the Insight Loop.

        Facts whose number is one SQL aggregate are emitted with
        query_kind='sql' and the exact statement that produced them, so
        `EvidenceLedger.verify` re-runs them and reproduces the value. The four
        composite dimensions and the overall score are emitted with
        query_kind='computed' and carry their formula in `query`; they are
        arithmetic over the sql-backed facts, not new measurements, and
        pretending otherwise would be the kind of unverifiable number this
        whole contract exists to prevent.
        """
        pfx = (prefix or "health").rstrip(".")
        facts: List[Fact] = []
        caveats = self._global_caveats()

        for ev in self.sql_evidence:
            facts.append(
                Fact(
                    id="%s.%s" % (pfx, ev["key"]),
                    claim=ev["claim"],
                    value=float(ev["value"]),
                    unit=ev["unit"],
                    query=ev["sql"],
                    source_table=self.table,
                    query_kind="sql",
                    rows_scanned=self.n_rows,
                    data_health=self.score,
                    caveats=list(caveats) + list(ev.get("caveats", [])),
                    tolerance=ev.get("tolerance", ""),
                )
            )

        derived = [
            ("validity_pct", "validity",
             "mean over columns of (dominant-class share x date-format and "
             "numbers-as-text penalties); see northledger.health docstring"
             + ((", capped at 100 x (1 - rows the cleaner set aside for unreadable values / rows "
                 "in) = %.1f" % self.validity_cap["cap"])
                if getattr(self, "validity_cap", None) and
                self.validity_cap["cap"] <= float(self.dimensions.get("validity") or 0) + 1e-9 else "")),
            ("uniqueness_pct", "uniqueness",
             "100 * (1 - duplicate_rows/%s.rows) * (1 - worst id-like column "
             "duplicate share)" % pfx),
            ("consistency_pct", "consistency",
             "mean over text columns of (1 - case/padding collapse share) * "
             "(1 - padded share)"),
            ("timeliness_pct", "timeliness",
             "100 * staleness_factor(newest row) * (1 - %s.future_dated_rows/dated_rows)" % pfx),
        ]
        for key, dim, formula in derived:
            val = self.dimensions.get(dim)
            if val is None:
                continue
            facts.append(
                Fact(
                    id="%s.%s" % (pfx, key),
                    claim="%s scores %.1f/100 on %s" % (self.table, val, dim),
                    value=float(val),
                    unit="pct",
                    query="derived: " + formula,
                    source_table=self.table,
                    query_kind="computed",
                    rows_scanned=self.n_rows,
                    data_health=self.score,
                    caveats=list(caveats),
                )
            )

        skipped = [d for d in DIMENSIONS if self.dimensions.get(d) is None]
        score_caveats = list(caveats)
        if skipped:
            score_caveats.append(
                "dimension(s) not applicable and excluded from the mean: %s" % ", ".join(skipped)
            )
        facts.append(
            Fact(
                id="%s.score" % pfx,
                claim="Data Health Score for %s is %.1f/100" % (self.table, self.score),
                value=float(self.score),
                unit="pct",
                query="derived: mean of applicable dimensions %s, rounded to 1 decimal"
                      % ", ".join("%s=%s" % (d, self.dimensions.get(d)) for d in DIMENSIONS),
                source_table=self.table,
                query_kind="computed",
                rows_scanned=self.n_rows,
                data_health=self.score,
                caveats=score_caveats,
            )
        )
        for f in facts:
            f.measures = "data_quality"
        return facts

    def _global_caveats(self) -> List[str]:
        out: List[str] = []
        if self.sampled:
            out.append(
                "measured on a sample of %d of %d rows" % (self.n_rows, self.total_rows)
            )
        return out


# --------------------------------------------------------------------------
# connection helper
# --------------------------------------------------------------------------
def connect_read_only(db_path: str) -> sqlite3.Connection:
    """Open `db_path` read-only. Stage 1 never needs write access to anything."""
    return connect_ro(db_path)


# --------------------------------------------------------------------------
# the scan
# --------------------------------------------------------------------------
def _resolve_table(con: sqlite3.Connection, table: str) -> str:
    row = con.execute(
        "SELECT name FROM sqlite_master WHERE type IN ('table','view') AND name = ?",
        (table,),
    ).fetchone()
    if row is None:
        raise ValueError("no such table or view: %r" % (table,))
    return row[0]


def _slug(text: str) -> str:
    out = re.sub(r"[^0-9A-Za-z]+", "_", str(text)).strip("_").lower()
    return out or "x"


def _slug_map(cols: Sequence[str]) -> Dict[str, str]:
    """
    A slug per column that is unique WITHIN the table.

    `_slug` is lossy -- 'a b', 'a-b' and 'a/b' all reduce to 'a_b' -- and the
    slug ends up inside a Fact id. Two facts sharing an id is not a cosmetic
    problem: `FactSet.add` refuses the second one, so a table with two such
    columns would abort the run. Disambiguate deterministically (PRAGMA column
    order is stable, so ids are stable across re-runs).
    """
    taken = set()
    out: Dict[str, str] = {}
    for name in cols:
        base = _slug(name)
        slug = base
        n = 2
        while slug in taken:
            slug = "%s_%d" % (base, n)
            n += 1
        taken.add(slug)
        out[name] = slug
    return out


def _staleness_factor(age_days: int) -> float:
    if age_days <= _FRESH_DAYS:
        return 1.0
    if age_days >= _DEAD_DAYS:
        return 0.0
    return 1.0 - (age_days - _FRESH_DAYS) / float(_DEAD_DAYS - _FRESH_DAYS)


def _pct(x: float) -> float:
    return round(max(0.0, min(1.0, x)) * 100.0, 1)


def score_table(
    con: sqlite3.Connection,
    table: str,
    sample_limit: int = 0,
) -> TableHealth:
    """
    Profile `table` and return its Data Health Audit.

    `sample_limit > 0` profiles only the first N rows (ordered by rowid where
    the table has one, so the sample is stable across re-runs and the emitted
    SQL really does reproduce). Every resulting Fact then carries an explicit
    "measured on a sample" caveat -- a sampled number must never read as a
    census.

    Issues only SELECT and PRAGMA statements; the database is not modified.
    """
    table = _resolve_table(con, table)
    qt = _qi(table)
    now = _dt.datetime.now()
    as_of = now.date().isoformat()

    info = con.execute("PRAGMA table_info(%s)" % qt).fetchall()
    cols = [str(r[1]) for r in info]
    declared = dict((str(r[1]), str(r[2] or "")) for r in info)
    n_cols = len(cols)

    th = TableHealth(
        table=table,
        n_cols=n_cols,
        dimensions=dict((d, None) for d in DIMENSIONS),
        scanned_at=now.isoformat(timespec="seconds"),
    )
    if n_cols == 0:
        th.findings.append("%s exposes no columns; nothing to profile." % table)
        return th

    total_rows = int(_scalar(con, "SELECT COUNT(*) FROM %s" % qt) or 0)
    th.total_rows = total_rows

    src = qt
    if sample_limit and sample_limit > 0:
        try:
            con.execute("SELECT rowid FROM %s LIMIT 1" % qt).fetchone()
            order = " ORDER BY rowid"
        except sqlite3.Error:
            order = ""
        src = "(SELECT * FROM %s%s LIMIT %d)" % (qt, order, int(sample_limit))
        th.sampled = True

    n_rows = int(_scalar(con, "SELECT COUNT(*) FROM %s" % src) or 0)
    th.n_rows = n_rows
    if th.sampled:
        th.findings.append(
            "Profiled a sample of %d of %d rows; every number below is a sample estimate."
            % (n_rows, total_rows)
        )

    if n_rows == 0:
        th.columns = [ColumnHealth(name=c, dtype_guess="empty", declared_type=declared[c])
                      for c in cols]
        th.score = 0.0
        th.findings.append(
            "%s holds 0 rows. No dimension can be measured, so the score is 0 by "
            "convention rather than by measurement." % table
        )
        th.sql_evidence.append({
            "key": "rows", "unit": "count", "value": 0.0,
            "sql": "SELECT COUNT(*) FROM %s" % src,
            "claim": "%s holds 0 rows" % table,
        })
        return th

    # -- per column profile -------------------------------------------------
    columns: List[ColumnHealth] = []
    for name in cols:
        columns.append(_profile_column(con, src, name, declared[name], n_rows))
    th.columns = columns

    # -- evidence: rows, null-like cells, completeness -----------------------
    sql_rows = "SELECT COUNT(*) FROM %s" % src
    th.sql_evidence.append({
        "key": "rows", "unit": "count", "value": float(n_rows), "sql": sql_rows,
        "claim": "%s holds %d rows across %d columns" % (table, n_rows, n_cols),
    })

    sql_nulls = "SELECT %s FROM %s" % (_null_cells_expr(cols), src)
    n_null_cells = int(_scalar(con, sql_nulls) or 0)
    th.sql_evidence.append({
        "key": "null_like_cells", "unit": "count", "value": float(n_null_cells),
        "sql": sql_nulls,
        # The full vocabulary (22 tokens) is in northledger/vocab.py; reciting it in a
        # client sentence read as noise.
        "claim": "%s of %s cells in %s are missing (empty, or a placeholder such as N/A or #N/A)"
                 % (format(n_null_cells, ","), format(n_rows * n_cols, ","), table),
    })

    sql_completeness = (
        "SELECT ROUND(100.0 * (1.0 - CAST(%s AS REAL) / (COUNT(*) * %d)), 1) FROM %s"
        % (_null_cells_expr(cols), n_cols, src)
    )
    completeness = float(_scalar(con, sql_completeness))
    th.sql_evidence.append({
        "key": "completeness_pct", "unit": "pct", "value": completeness,
        "sql": sql_completeness,
        "claim": "%s scores %.1f/100 on completeness" % (table, completeness),
    })
    th.dimensions["completeness"] = completeness

    # -- uniqueness ---------------------------------------------------------
    distinct_cols = ", ".join(_qi(c) for c in cols)
    sql_dups = (
        "SELECT (SELECT COUNT(*) FROM %s) - (SELECT COUNT(*) FROM "
        "(SELECT DISTINCT %s FROM %s))" % (src, distinct_cols, src)
    )
    dup_rows = int(_scalar(con, sql_dups) or 0)
    th.sql_evidence.append({
        "key": "duplicate_rows", "unit": "count", "value": float(dup_rows), "sql": sql_dups,
        "tolerance": "zero",
        "claim": "%d of %d rows in %s are exact duplicates of another row"
                 % (dup_rows, n_rows, table),
    })
    dup_share = dup_rows / float(n_rows)

    worst_id_share = 0.0
    worst_id_col = ""
    for ch in columns:
        if not ch.is_id_like:
            continue
        shortfall = 1.0 - ch.distinct_ratio
        if shortfall > worst_id_share:
            worst_id_share = shortfall
            worst_id_col = ch.name
    th.dimensions["uniqueness"] = _pct((1.0 - dup_share) * (1.0 - worst_id_share))

    # -- validity / consistency --------------------------------------------
    vals = [c.validity for c in columns if c.validity is not None]
    th.dimensions["validity"] = _pct(sum(vals) / len(vals)) if vals else None
    cons = [c.consistency for c in columns if c.consistency is not None]
    th.dimensions["consistency"] = _pct(sum(cons) / len(cons)) if cons else 100.0

    # A table whose every cell is null-like has nothing for uniqueness or
    # consistency to measure, and they both come back vacuously perfect: rows
    # of nothing do not repeat, and values that do not exist are not
    # inconsistently cased. Averaged in, those two 100s would hand a table with
    # zero information a passing score (0 + 100 + 100 over three dimensions =
    # 66.7). The rule this module applies to timeliness applies here too, in
    # the other direction: what cannot be measured is excluded, not scored.
    if all(c.n_non_null == 0 for c in columns):
        th.dimensions["uniqueness"] = None
        th.dimensions["consistency"] = None
        th.findings.append(
            "Every cell in %s is null-like, so validity, uniqueness and consistency "
            "have nothing to measure; they are excluded and the score is completeness "
            "alone." % table
        )

    # -- timeliness ---------------------------------------------------------
    _timeliness(con, src, th, as_of)

    # -- per-column null evidence for the worst offenders --------------------
    slugs = _slug_map(cols)
    dirty = sorted(
        [c for c in columns if c.n_null_like > 0], key=lambda c: -c.pct_null_like
    )[:3]
    for ch in dirty:
        explained = _gaps_follow(con, src, table, ch, columns, slugs) or \
            _blank_for_one_level(con, src, table, ch, columns, slugs)
        if explained:
            th.sql_evidence.extend(explained)
            continue
        sql = _null_pct_sql(src, ch.name)
        val = float(_scalar(con, sql))
        th.sql_evidence.append({
            "key": "col.%s.null_like_pct" % slugs[ch.name], "unit": "pct", "value": val,
            "sql": sql,
            "claim": "%.1f%% of %s.%s is null-like" % (val, table, ch.name),
        })

    # -- per-column defect evidence ------------------------------------------
    _defect_evidence(con, src, table, columns, slugs, th, sql_dups=sql_dups)

    # -- score --------------------------------------------------------------
    applicable = [th.dimensions[d] for d in DIMENSIONS if th.dimensions[d] is not None]
    th.score = round(sum(applicable) / len(applicable), 1) if applicable else 0.0

    _findings(th, dup_rows, dup_share, worst_id_col, worst_id_share, n_null_cells)
    return th


#: Reasons for setting a row aside that are not about reading its values (duplicates are
#: uniqueness; a superseded row is by design).
_NOT_VALIDITY_REASONS = (": exact duplicate row", ": superseded by a later row")


def reflect_cleaning(th: "TableHealth", cr: Any) -> None:
    """
    Validity as the analysis meets it (review v2, 24 Sep 2026): a table scored 83 to 94 out of
    100 while the cleaner set aside 43% to 100% of its rows as unreadable. Validity is capped at
    the share of rows the cleaner could read (100 x (1 - rows set aside for their dates, numbers,
    ranges or required values / rows in)), and the mean is recomputed. Duplicates stay in
    uniqueness. Updates `th` in place and the cleaning result's source health with it.
    """
    total = int(getattr(cr, "total_in", 0) or 0)
    if not total or th.dimensions.get("validity") is None:
        return
    rejected = sum(int(n) for k, n in (getattr(cr, "quarantine_reasons", None) or {}).items()
                   if not any(m in str(k) for m in _NOT_VALIDITY_REASONS))
    cap = round(100.0 * (1.0 - rejected / float(total)), 1)
    th.validity_cap = {"cap": cap, "rows_set_aside": rejected, "rows_in": total}
    if cap >= float(th.dimensions["validity"]):
        return
    th.dimensions["validity"] = cap
    applicable = [th.dimensions[d] for d in DIMENSIONS if th.dimensions[d] is not None]
    th.score = round(sum(applicable) / len(applicable), 1) if applicable else 0.0
    th.findings.append(
        "Validity is scored on what the cleaner could read: %s of %s rows were set aside for "
        "values it could not use (dates, numbers, ranges or required values), so validity is "
        "capped at %.1f and the score is %.1f." % (format(rejected, ","), format(total, ","), cap,
                                                   th.score))
    if hasattr(cr, "source_health"):
        cr.source_health = th.score


def _profile_column(
    con: sqlite3.Connection,
    src: str,
    name: str,
    declared_type: str,
    n_rows: int,
) -> ColumnHealth:
    row = con.execute(_profile_sql(src, name)).fetchone()
    (
        seen, n_null, n_distinct_raw, n_distinct_norm, n_padded, n_stored_text, n_num_as_text,
    ) = [int(x or 0) for x in row[:7]]
    codes = [int(x or 0) for x in row[7:7 + _CODE_TEXT]]
    dm_day_first, dm_month_first, dm_either = [int(x or 0) for x in row[7 + _CODE_TEXT:]]

    if seen != n_rows:
        # Every dimension is a ratio over this count. If one column's scan
        # disagrees with the table's scan the audit is internally inconsistent,
        # and an inconsistent audit is worse than no audit -- say so loudly
        # rather than publishing a score built on two different denominators.
        raise RuntimeError(
            "column %r scanned %d rows but the table scan saw %d; the source is "
            "not stable enough to profile" % (name, seen, n_rows)
        )

    ch = ColumnHealth(name=name, declared_type=declared_type, n_rows=seen)
    ch.n_null_like = n_null
    ch.n_non_null = seen - n_null
    ch.pct_null_like = round(100.0 * n_null / seen, 1) if seen else 0.0
    ch.n_distinct = n_distinct_raw
    ch.n_distinct_normalised = n_distinct_norm
    ch.n_padded = n_padded
    ch.n_stored_text = n_stored_text
    ch.n_numeric_as_text = n_num_as_text

    date_counts = dict(
        (label, codes[i]) for i, (label, _g) in enumerate(_DATE_FORMATS) if codes[i] > 0
    )
    if any(label in date_counts for label in _DAY_MONTH_SHAPES):
        ch.day_month_order = day_month_order(dm_day_first, dm_month_first)
        for shape in _DAY_MONTH_SHAPES:
            relabel = _ORDER_LABEL.get((shape, ch.day_month_order))
            if relabel and shape in date_counts:
                date_counts[relabel] = date_counts.pop(shape)
    n_date = sum(codes[: len(_DATE_FORMATS)])
    n_clean = codes[_CODE_CLEAN_NUM - 1]
    n_dirty = codes[_CODE_DIRTY_NUM - 1]
    n_num = n_clean + n_dirty
    n_text = codes[_CODE_TEXT - 1]
    ch.date_formats = date_counts
    ch.class_counts = {"date": n_date, "numeric": n_num, "text": n_text}

    nn = ch.n_non_null
    if nn == 0:
        ch.dtype_guess = "empty"
        ch.issues.append("every value is null-like; the column carries no information.")
        ch.top_values, _bad = _top_values(con, src, name)
        _note_undecodable(ch, _bad)
        return ch

    if n_date >= n_num and n_date >= n_text and n_date > 0:
        ch.dtype_guess = "date"
    elif n_num >= n_text and n_num > 0:
        ch.dtype_guess = "numeric"
    else:
        ch.dtype_guess = "text"

    majority = float(max(n_date, n_num, n_text))
    validity = majority / nn
    if validity < 1.0:
        ch.issues.append(
            "mixed content: %s date-like, %s numeric and %s text values."
            % (_n(n_date), _n(n_num), _n(n_text))
        )

    if ch.dtype_guess == "date":
        dominant = max(date_counts.values())
        if len(date_counts) > 1:
            validity *= dominant / float(n_date)
            ch.issues.append(
                "%d date formats in one column (%s); anything that sorts or "
                "filters on this will be wrong." % (
                    len(date_counts),
                    ", ".join("%s x%s" % (k, _n(v)) for k, v in sorted(date_counts.items())),
                )
            )
        order = ch.day_month_order
        if order == "dmy":
            ch.issues.append(
                "day/month order read from the values: day-first, because %s date(s) "
                "have a first part above 12." % _n(dm_day_first))
        elif order == "mdy":
            ch.issues.append(
                "day/month order read from the values: month-first, because %s date(s) "
                "have a second part above 12." % _n(dm_month_first))
        elif order == "mixed":
            ch.issues.append(
                "this column holds both day-first and month-first dates (%s can only be "
                "day-first, %s only month-first); %s value(s) that could be either are "
                "not read, rather than guessed." % (_n(dm_day_first), _n(dm_month_first), _n(dm_either)))
        elif order == "unknown":
            shapes = sorted(l for l in date_counts if l in _DAY_MONTH_SHAPES)
            ch.issues.append(
                "day/month order cannot be told from the values (no part is above 12); "
                "read as %s. Confirm with whoever exported the file." % " and ".join(shapes))
    elif ch.dtype_guess == "numeric":
        if n_num_as_text:
            validity *= 1.0 - _NUM_AS_TEXT_PENALTY * (n_num_as_text / float(n_num))
            ch.issues.append(
                "%s of %s numbers are stored as text; they will sort '10' before '9'."
                % (_n(n_num_as_text), _n(n_num))
            )
        if n_dirty:
            validity *= 1.0 - (n_dirty / float(n_num))
            ch.issues.append(
                "%s values carry formatting (thousands separators, currency or "
                "percent signs) and will not cast to a number." % _n(n_dirty)
            )

    ch.validity = max(0.0, min(1.0, validity))

    if ch.dtype_guess == "text":
        collapse = 0.0
        if n_distinct_raw > 0:
            collapse = (n_distinct_raw - n_distinct_norm) / float(n_distinct_raw)
        padding = n_padded / float(nn)
        ch.consistency = max(0.0, (1.0 - collapse) * (1.0 - padding))
        if collapse > 0:
            ch.issues.append(
                "%s distinct values collapse to %s once trimmed and lowercased; "
                "casing/padding is splitting the same real value."
                % (_n(n_distinct_raw), _n(n_distinct_norm))
            )
        if n_padded:
            ch.issues.append("%s values carry leading or trailing whitespace." % _n(n_padded))

    if ch.pct_null_like > 0:
        ch.issues.append(
            "%.1f%% null-like (%s of %s values)." % (ch.pct_null_like, _n(n_null), _n(seen))
        )

    lower = name.lower()
    if any(lower.endswith(s) for s in _ID_NAME_SUFFIXES):
        if ch.distinct_ratio > _ID_DISTINCT_THRESHOLD:
            ch.is_id_like = True
            if ch.distinct_ratio < 1.0:
                ch.issues.append(
                    "looks like a key but only %s of %s values are distinct."
                    % (_n(n_distinct_raw), _n(nn))
                )

    dt = declared_type.upper()
    if dt and ch.dtype_guess == "text" and ("INT" in dt or "REAL" in dt or "NUM" in dt):
        ch.issues.append(
            "declared %s but its values read as text." % declared_type
        )

    ch.top_values, n_bad = _top_values(con, src, name, n_distinct_raw)
    _note_undecodable(ch, n_bad)
    return ch


def _n(x: Any) -> str:
    """A count as a person reads it: 182,063, not 182063."""
    return format(int(x), ",")


def _note_undecodable(ch: ColumnHealth, n_bad: int) -> None:
    if n_bad:
        ch.issues.append(
            "%s of the most frequent values are not valid UTF-8 text; they are "
            "shown with replacement characters and will not survive a text "
            "export intact." % _n(n_bad)
        )


def _top_values(
    con: sqlite3.Connection,
    src: str,
    name: str,
    n_distinct: int = 0,
) -> Tuple[List[Tuple[Any, int]], int]:
    """
    Most frequent values, null-like ones INCLUDED on purpose.

    Returns (values, n_undecodable). Stage 1 profiles tables nobody has vetted,
    so it must survive bytes that are not text: a BLOB column (hashes, images,
    serialised payloads) is ordinary, and sqlite3's default text factory raises
    `OperationalError: Could not decode to UTF-8` the moment such a value is
    returned to Python. Blobs are therefore described in SQL rather than
    returned, and any remaining undecodable text is decoded with replacement
    AND counted, so the column carries a visible issue instead of the scan
    dying or -- worse -- quietly dropping the values.
    """
    if n_distinct > _TOP_VALUE_CARDINALITY_CAP:
        return [], 0
    # GROUP BY / ORDER BY are written against the EXPRESSION, never an output
    # alias: in SQLite a real column of the table wins over an alias of the
    # same name, so profiling a column called `v` or `n` would silently group
    # on the raw, untrimmed value and report counts that do not match the
    # rest of the profile. Wrong counts that never raise are the worst kind.
    expr = _display_expr(name)
    sql = (
        "SELECT %s AS v, COUNT(*) AS n FROM %s GROUP BY %s "
        "ORDER BY COUNT(*) DESC, %s LIMIT %d"
        % (expr, src, expr, expr, _TOP_VALUES)
    )
    bad = []

    def _lossy(raw: bytes) -> str:
        try:
            return raw.decode("utf-8")
        except UnicodeDecodeError:
            bad.append(1)
            return raw.decode("utf-8", "replace")

    previous = con.text_factory
    con.text_factory = _lossy
    try:
        rows = con.execute(sql).fetchall()
    finally:
        con.text_factory = previous
    return [(r[0], int(r[1])) for r in rows], len(bad)


def _timeliness(
    con: sqlite3.Connection,
    src: str,
    th: TableHealth,
    as_of: str,
) -> None:
    candidates = [
        c for c in th.columns
        if c.dtype_guess == "date" and sum(c.date_formats.values()) > 0
    ]
    if not candidates:
        th.dimensions["timeliness"] = None
        th.findings.append(
            "No date-like column found, so timeliness could not be measured. It is "
            "excluded from the score rather than counted as zero."
        )
        return

    col = max(candidates, key=lambda c: sum(c.date_formats.values()))
    th.date_column = col.name
    inner = "SELECT date(%s) AS d FROM (SELECT %s AS t FROM %s)" % (
        _iso_case("t", col.day_month_order), _trim(_qi(col.name)), src
    )
    row = con.execute(
        "SELECT MAX(d), COALESCE(SUM(CASE WHEN d > '%s' THEN 1 ELSE 0 END), 0), COUNT(d) "
        "FROM (%s)" % (as_of, inner)
    ).fetchone()
    max_iso, n_future, n_dated = row[0], int(row[1] or 0), int(row[2] or 0)

    if not n_dated or not max_iso:
        th.dimensions["timeliness"] = None
        th.findings.append(
            "Column %s looks date-shaped but holds no value SQLite accepts as a "
            "date; timeliness excluded from the score." % col.name
        )
        return

    sql_future = (
        "SELECT COALESCE(SUM(CASE WHEN d > '%s' THEN 1 ELSE 0 END), 0) FROM (%s)"
        % (as_of, inner)
    )
    th.sql_evidence.append({
        "key": "future_dated_rows", "unit": "count", "value": float(n_future),
        "sql": sql_future,
        "claim": "%d rows in %s are dated after %s in column %s"
                 % (n_future, th.table, as_of, col.name),
        "caveats": ["as of %s" % as_of],
    })

    y, m, d = (int(p) for p in max_iso.split("-"))
    age = (_dt.date.fromisoformat(as_of) - _dt.date(y, m, d)).days
    stale = _staleness_factor(max(0, age))
    future_share = n_future / float(n_dated)
    th.dimensions["timeliness"] = _pct(stale * (1.0 - future_share))

    if age > _FRESH_DAYS:
        th.findings.append(
            "Newest row in %s is %s, %d days old as of %s." % (col.name, max_iso, age, as_of)
        )
    if n_future:
        th.findings.append(
            "%d of %d dated rows are in the future (latest %s, today is %s) -- a date "
            "column with future rows is usually a parsing or timezone fault."
            % (n_future, n_dated, max_iso, as_of)
        )


def _findings(
    th: TableHealth,
    dup_rows: int,
    dup_share: float,
    worst_id_col: str,
    worst_id_share: float,
    n_null_cells: int,
) -> None:
    head: List[str] = []
    if n_null_cells:
        head.append(
            "%d of %d cells are null-like, so completeness is %.1f/100."
            % (n_null_cells, th.n_rows * th.n_cols, th.dimensions["completeness"])
        )
    if dup_rows:
        head.append(
            "%d rows (%.1f%%) are exact duplicates of another row."
            % (dup_rows, dup_share * 100.0)
        )
    if worst_id_col:
        head.append(
            "Column %s reads as a key but repeats: %.1f%% of its values are not unique."
            % (worst_id_col, worst_id_share * 100.0)
        )
    th.findings = head + th.findings

    for ch in th.columns:
        for issue in ch.issues:
            if len(th.findings) >= _MAX_FINDINGS:
                return
            th.findings.append("%s: %s" % (ch.name, issue))



# --------------------------------------------------------------------------
# Per-column defects, as re-runnable counts
# --------------------------------------------------------------------------
# The profiler already measured padding, casing inconsistency and mixed date
# formats to build its consistency and validity scores, but never said so as a
# fact -- so no client and no evaluator could see or check them. On the first
# evaluation run the LLM analyst missed exactly these three kinds of defect.
# Each count below is emitted with the precise query that produces it.
_CONVENTION_SHARE = 0.70

# Gaps that follow another column (NYC 311, 22 Sep 2026): "8.6% of closed_date is
# null-like" was the audit's first "Do now", yet 12,937 of the 12,938 empty close dates
# were on requests still In Progress, Open or Pending and no Closed request lacked one.
# When a column's gaps are (almost) absent under the dominant value of a low-cardinality
# column and common everywhere else, the gaps are reported as context, and only the gaps
# UNDER that value -- status Closed but no close date -- as a defect.
_GAP_DOMINANT_SHARE = 0.50   # the explaining value covers at least half the rows
_GAP_INSIDE_MAX = 0.01       # at most 1% of those rows have the gap
_GAP_OUTSIDE_SHARE = 0.80    # at least 80% of all gaps are elsewhere
_GAP_LIFT = 20.0             # and gaps are at least 20x as common elsewhere
_GAP_MAX_LEVELS = 30


def _gaps_follow(con, src, table, ch, columns, slugs):
    if ch.pct_null_like < 1.0:
        return None
    x = _trim(_qi(ch.name))
    xnull = _null_like_on(x)
    best = None
    for y in columns:
        if (y.name == ch.name or y.is_id_like or not 2 <= y.n_distinct_normalised <= _GAP_MAX_LEVELS
                or y.pct_null_like >= 50.0):
            continue
        yt = _trim(_qi(y.name))
        ynull = _null_like_on(yt)
        rows = con.execute(
            "SELECT CASE WHEN %s THEN NULL ELSE %s END AS v, COUNT(*), "
            "COALESCE(SUM(CASE WHEN %s THEN 1 ELSE 0 END), 0) FROM %s GROUP BY 1"
            % (ynull, yt, xnull, src)).fetchall()
        total = sum(int(r[1]) for r in rows)
        gaps = sum(int(r[2]) for r in rows)
        for v, n_v, inside in rows:
            n_v, inside = int(n_v), int(inside)
            if v is None or not total or not gaps or n_v < _GAP_DOMINANT_SHARE * total or n_v == total:
                continue
            outside = gaps - inside
            inside_rate = inside / float(n_v)
            outside_rate = outside / float(total - n_v)
            if (inside_rate <= _GAP_INSIDE_MAX and outside >= _GAP_OUTSIDE_SHARE * gaps
                    and outside_rate >= _GAP_LIFT * inside_rate):
                # Rank by how well "y is not v" PREDICTS a gap (F1 of recall and precision),
                # not by column order: on NYC 311 agency 'NYPD' also had no gaps, but only 20%
                # of non-NYPD rows lacked a close date against 88% of non-Closed rows.
                recall = outside / float(gaps)
                f1 = 2 * recall * outside_rate / (recall + outside_rate)
                cand = (f1, -inside_rate, y, str(v), n_v, inside, outside, gaps, yt, ynull)
                if best is None or cand[:2] > best[:2]:
                    best = cand
    if best is None:
        return None
    _share, _r, y, v, n_v, inside, outside, gaps, yt, ynull = best
    lit = "'%s'" % v.replace("'", "''")
    key = "col.%s" % slugs[ch.name]
    ys = slugs[y.name]
    under = ("and none of the %s rows where %s is %s lacks one" % (format(n_v, ","), y.name, lit)
             if inside == 0 else
             "while only %s of the %s rows where %s is %s lack one"
             % (format(inside, ","), format(n_v, ","), y.name, lit))
    out = [{
        "key": "%s.gaps_follow.%s" % (key, ys), "unit": "count", "value": float(outside),
        "sql": "SELECT COUNT(*) FROM %s WHERE %s AND (%s OR %s <> %s)" % (src, xnull, ynull, yt, lit),
        "claim": "%s empty values in %s.%s are on rows whose %s is not %s, %s. The gaps follow %s, "
                 "so they come from how those records work (the value may not exist yet, or may never "
                 "be collected there) rather than from random loss. Confirm with whoever owns the data"
                 % (("All %s" % format(gaps, ",")) if outside == gaps else
                    "%s of the %s" % (format(outside, ","), format(gaps, ",")),
                    table, ch.name, y.name, lit, under, y.name),
    }]
    if inside:
        out.append({
            "key": "%s.null_like_where.%s" % (key, ys), "unit": "count", "value": float(inside),
            "sql": "SELECT COUNT(*) FROM %s WHERE %s AND NOT %s AND %s = %s" % (src, xnull, ynull, yt, lit),
            "claim": "%s rows in %s have %s %s but no %s. Everywhere else %s is %s, %s is present, so "
                     "these are the gaps to fix" % (format(inside, ","), table, y.name, lit, ch.name,
                                                    y.name, lit, ch.name),
        })
    return out   # a column "has a casing convention" at 70%+ of cased values


#: A column blank on (nearly) every row of one category level and filled elsewhere does not
#: apply to that level (review v2, 24 Sep 2026: Vendor and Notes blank on exactly the 1,514 Rent
#: rows were graded CONFIRMED data problems and "Act on" advice).
_NA_INSIDE_MIN = 0.95      # at least 95% of the level's rows are blank
_NA_OUTSIDE_MAX = 0.05     # at most 5% of the other rows are
_NA_COVER_MIN = 0.90       # and the level holds at least 90% of all the blanks
_NA_LEVEL_MIN = 0.05       # a level of at least 5% of the rows


def _blank_for_one_level(con, src, table, ch, columns, slugs):
    """The category level whose rows the column does not apply to, as evidence; or None."""
    if ch.pct_null_like < 1.0:
        return None
    x = _trim(_qi(ch.name))
    xnull = _null_like_on(x)
    best = None
    for y in columns:
        if (y.name == ch.name or y.is_id_like or not 2 <= y.n_distinct_normalised <= _GAP_MAX_LEVELS
                or y.pct_null_like >= 50.0):
            continue
        # levels compared case- and space-blind: 'RENT', 'Rent ' and 'rent' are one level
        yt = "LOWER(%s)" % _trim(_qi(y.name))
        ynull = _null_like_on(_trim(_qi(y.name)))
        rows = con.execute(
            "SELECT CASE WHEN %s THEN NULL ELSE %s END AS v, COUNT(*), "
            "COALESCE(SUM(CASE WHEN %s THEN 1 ELSE 0 END), 0) FROM %s GROUP BY 1"
            % (ynull, yt, xnull, src)).fetchall()
        total = sum(int(r[1]) for r in rows)
        gaps = sum(int(r[2]) for r in rows)
        if not total or not gaps:
            continue
        for v, n_v, inside in rows:
            n_v, inside = int(n_v), int(inside)
            if v is None or n_v < _NA_LEVEL_MIN * total or n_v == total:
                continue
            outside = gaps - inside
            if (inside >= _NA_INSIDE_MIN * n_v and outside <= _NA_OUTSIDE_MAX * (total - n_v)
                    and inside >= _NA_COVER_MIN * gaps):
                cand = (inside / float(gaps), -outside, y, str(v), n_v, inside, outside, gaps, yt, ynull)
                if best is None or cand[:2] > best[:2]:
                    best = cand
    if best is None:
        return None
    _c, _o, y, v, n_v, inside, outside, gaps, yt, ynull = best
    lit = "'%s'" % v.replace("'", "''")
    key = "col.%s" % slugs[ch.name]
    ys = slugs[y.name]
    shown = v if len(v) <= 40 else v[:40]
    out = [{
        "key": "%s.not_applicable.%s" % (key, ys), "unit": "count", "value": float(inside),
        "sql": "SELECT COUNT(*) FROM %s WHERE %s AND NOT %s AND %s = %s" % (src, xnull, ynull, yt, lit),
        "claim": "%s of the %s empty values in %s.%s are on rows where %s is '%s' (%s of those %s rows), "
                 "and the other rows have one: %s does not apply to %s rows, so these are not missing "
                 "data" % (format(inside, ","), format(gaps, ","), table, ch.name, y.name, shown,
                           format(inside, ","), format(n_v, ","), ch.name, shown),
    }]
    if outside:
        out.append({
            "key": "%s.null_like_elsewhere.%s" % (key, ys), "unit": "count", "value": float(outside),
            "sql": "SELECT COUNT(*) FROM %s WHERE %s AND (%s OR %s <> %s)" % (src, xnull, ynull, yt, lit),
            "claim": "%s rows in %s whose %s is not '%s' have no %s, where the rest do: these are the "
                     "gaps to fix" % (format(outside, ","), table, y.name, shown, ch.name),
        })
    return out


def _defect_evidence(con, src, table, columns, slugs, th, sql_dups=None) -> None:
    fmt_glob = _LABEL_GLOB
    for ch in columns:
        col, slug = ch.name, slugs[ch.name]
        qc = _qi(col)
        x = _trim(qc)
        nl = _null_like_on(x)
        is_text = "typeof(%s) = 'text'" % qc

        def emit(key, value, sql, claim, tolerance=""):
            th.sql_evidence.append({"key": "col.%s.%s" % (slug, key), "unit": "count",
                                    "value": float(value), "sql": sql, "claim": claim,
                                    "tolerance": tolerance})

        # (f) one ID on two DIFFERENT records. Exact duplicate rows also repeat their ID,
        # and they are already reported, so they are subtracted: this counts only
        # conflicting records -- possible double counting or double billing.
        if ch.is_id_like and sql_dups:
            extra = ("SELECT COALESCE(SUM(n - 1), 0) FROM (SELECT COUNT(*) AS n FROM %s "
                     "WHERE NOT %s GROUP BY %s HAVING COUNT(*) > 1)" % (src, nl, x))
            sql = "SELECT (%s) - (%s)" % (extra, sql_dups)
            n = int(_scalar(con, sql) or 0)
            if n > 0:
                emit("duplicate_ids", n, sql,
                     "%s rows in %s reuse a %s that a different row already has; one ID on two "
                     "different records can mean double counting or double billing"
                     % (format(n, ","), table, col), tolerance="zero")

        # (g) rare negatives in a column that is otherwise non-negative
        if ch.dtype_guess == "numeric" and not ch.is_id_like and ch.n_non_null:
            sql = ("SELECT COUNT(*) FROM %s WHERE NOT %s AND CAST(%s AS REAL) < 0"
                   % (src, nl, x))
            n = int(_scalar(con, sql) or 0)
            # Flag when the column is PREDOMINANTLY non-negative (<= 25% negative). The
            # first cut stopped at 5% and missed 281 negative fees (15.6%) in a courier
            # log; genuinely signed columns (longitudes, profit and loss) stay unflagged.
            if 0 < n <= 0.25 * ch.n_non_null:
                emit("negative_values", n, sql,
                     "%s values in %s.%s are negative while nearly all the others are not. "
                     "Check whether %s can be negative (a refund or a credit, say) or whether "
                     "these are entry errors" % (format(n, ","), table, col, col))

        # (a) placeholders: present, not NULL, but meaning "missing"
        sql = "SELECT COUNT(*) FROM %s WHERE %s IS NOT NULL AND %s" % (src, qc, nl)
        n = int(_scalar(con, sql) or 0)
        if n and n == ch.n_null_like:
            # Every missing value in this column is a placeholder, so the column's
            # null-share fact and this one describe the same rows. Keep the specific one.
            key = "col.%s.null_like_pct" % slug
            th.sql_evidence[:] = [e for e in th.sql_evidence if e.get("key") != key]
        if n:
            emit("placeholder_values", n, sql,
                 "%s values in %s.%s are placeholders for a missing value (such as 'N/A', "
                 "'#N/A' or a blank) rather than true NULLs, so counts and joins treat them "
                 "as real" % (format(n, ","), table, col))

        # (b) padding, on real values only (a whitespace-only cell is a placeholder)
        sql = ("SELECT COUNT(*) FROM %s WHERE %s AND NOT %s AND CAST(%s AS TEXT) <> %s"
               % (src, is_text, nl, qc, x))
        n = int(_scalar(con, sql) or 0)
        if n:
            emit("padded_values", n, sql,
                 "%s values in %s.%s carry leading or trailing whitespace, so values that "
                 "look equal do not match" % (format(n, ","), table, col))

        # (c)/(d) casing: a broken convention, or -- in a mixed column -- variant spellings
        cased = "UPPER(%s) <> LOWER(%s)" % (x, x)
        row = con.execute(
            "SELECT COALESCE(SUM(CASE WHEN %s THEN 1 ELSE 0 END),0), "
            "COALESCE(SUM(CASE WHEN %s AND %s = UPPER(%s) THEN 1 ELSE 0 END),0), "
            "COALESCE(SUM(CASE WHEN %s AND %s = LOWER(%s) THEN 1 ELSE 0 END),0) "
            "FROM %s WHERE %s AND NOT %s" % (cased, cased, x, x, cased, x, x, src, is_text, nl)
        ).fetchone()
        n_cased, n_upper, n_lower = int(row[0]), int(row[1]), int(row[2])
        if n_cased:
            conv = None
            if n_upper >= _CONVENTION_SHARE * n_cased:
                conv, rule, word = "upper", "%s <> UPPER(%s)" % (x, x), "UPPER-case"
            elif n_lower >= _CONVENTION_SHARE * n_cased:
                conv, rule, word = "lower", "%s <> LOWER(%s)" % (x, x), "lower-case"
            if conv:
                sql = ("SELECT COUNT(*) FROM %s WHERE %s AND NOT %s AND %s AND %s"
                       % (src, is_text, nl, cased, rule))
                n = int(_scalar(con, sql) or 0)
                if n:
                    emit("off_convention_casing", n, sql,
                         "%s values in %s.%s break the column's %s convention, so one value "
                         "can be stored several ways" % (format(n, ","), table, col, word))
            elif ch.n_distinct_normalised is None or ch.n_distinct_normalised < ch.n_distinct:
                # Spellings are compared AFTER trimming, so padding is never mistaken
                # for a second spelling; that is (b)'s job.
                sql = (
                    "WITH g AS (SELECT v, LOWER(v) AS k, COUNT(*) AS n FROM "
                    "(SELECT %s AS v FROM %s WHERE %s AND NOT %s) GROUP BY v), "
                    "top AS (SELECT k, MAX(n) AS m FROM g GROUP BY k HAVING COUNT(*) > 1) "
                    "SELECT COALESCE((SELECT SUM(g.n) FROM g JOIN top ON g.k = top.k), 0) "
                    "- COALESCE((SELECT SUM(m) FROM top), 0)" % (x, src, is_text, nl)
                )
                n = int(_scalar(con, sql) or 0)
                if n:
                    emit("variant_spellings", n, sql,
                         "%s values in %s.%s are letter-case variants of a more common "
                         "spelling, so one category is counted as several" % (format(n, ","), table, col))

        # (e) dates outside the column's dominant format
        if ch.dtype_guess == "date" and ch.date_formats:
            label = max(ch.date_formats, key=lambda k: ch.date_formats[k])
            pattern = fmt_glob.get(label)
            if pattern:
                sql = ("SELECT COUNT(*) FROM %s WHERE NOT %s AND %s NOT GLOB '%s'"
                       % (src, nl, x, pattern.replace("'", "''")))
                n = int(_scalar(con, sql) or 0)
                if n:
                    total = sum(ch.date_formats.values()) or 1
                    share = 100.0 * ch.date_formats[label] / total
                    # "Dominant" overstated a plurality: legacy_export's most common
                    # format covers 30% of its dates. Say how common it actually is.
                    emit("off_format_dates", n, sql,
                         "%s values in %s.%s are not in the column's most common date format "
                         "(%s, used by %.0f%% of its dates across %d formats), so a tool that assumes "
                         "one date format will misread or drop them" % (format(n, ","), table, col, label, share,
                                                   len(ch.date_formats)))
