#!/usr/bin/env python3
"""
Stage 8 of the NorthLedger Insight Loop: the narrator.

The structural guarantee of this module is a type boundary. `narrate` accepts
`GatedFact` objects and nothing else. A raw `Fact` -- a measurement that has not
been through the confidence gate -- cannot be narrated; it raises
`UngatedFactError`. That is the whole trust claim made mechanical: prose in this
system can only ever be assembled from evidence that has already been judged.

Two further rules hold the honesty line:

  * Only RECOMMEND facts may become actions. WATCH facts are phrased as things
    to monitor, never as instructions. INSUFFICIENT facts become explicit
    statements of what the data cannot support, each paired with what would
    settle it.
  * `cannot_answer` is never silently dropped. A brief in which everything was
    gated INSUFFICIENT says so at the top rather than rendering an empty,
    confident-looking document.

No LLM is called here. This is deterministic templating over gated facts, and
that determinism is precisely why the output can be trusted: the same fact set
always produces the same brief, and every number in it carries its unit and a
fact id that resolves to a stored, re-runnable query.

Python 3.9 compatible.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from .facts import Fact, GateResult, GatedFact
from .vocab import RETENTION_CAVEAT as _RETENTION_CAVEAT
from .vocab import visitor_verdict
from .vocab import plural_of as _plural

__all__ = [
    "Brief",
    "Story",
    "narrate",
    "narrate_story",
    "STORY_HEADINGS",
    "UngatedFactError",
    "SECTION_HEADINGS",
    "NOTHING_CLEARED_LINE",
    "NO_ACTION_LINE",
    "NO_FACTS_LINE",
    "ALL_CLEAR_LINE",
    "QUARANTINE_ONLY_LINE",
]

# --------------------------------------------------------------------------
# Fixed language. Kept as module constants so the brief cannot drift between
# runs and so tests can assert on the exact wording.
# --------------------------------------------------------------------------
NO_ACTION_LINE = (
    "No finding in this run cleared the confidence gate, so this brief "
    "recommends no action."
)
# The same line for an analysis whose findings are graded changes (§2.4): a change is graded
# CONFIRMED, a forecast is cleared for planning; "cleared the confidence gate" is the audit's word.
NO_ACTION_LINE_GRADED = (
    "Nothing in this run was graded CONFIRMED or cleared for planning, so this brief "
    "recommends no action."
)
NO_CHANGE_LINE = (
    "No measured change cleared the confidence gate in this run."
)
NO_WATCH_LINE = "Nothing from this run was placed on the watch list."
# Shown when no finding was ruled unanswerable. It used to read "Every fact in this
# brief cleared the confidence gate", printed beneath 22 WATCH items (22 Sep 2026).
ALL_CLEAR_LINE = (
    "No finding was ruled unanswerable by the data. Findings that are real but not "
    "yet ready to act on are listed as things to watch, not as advice."
)
NO_FACTS_LINE = (
    "This run produced no gated facts at all. There is nothing to report, "
    "nothing to act on, and no evidence base behind this brief."
)
QUARANTINE_ONLY_LINE = (
    "This run produced no measured facts. Everything gated into it came from an "
    "external source and is quarantined as outside context, so this brief has no "
    "evidence base of its own and recommends no action."
)
EXTERNAL_PREFACE = (
    "External context. Not produced by this analysis, not verified against the "
    "data, and not used in any recommendation above."
)
NO_EXTERNAL_LINE = "No external context was attached to this brief."
EXTERNAL_QUARANTINE_NOTE = (
    "Outside-context items are not part of this evidence base: they come from "
    "named external sources, carry their own dates, and were not verified "
    "against the client's data here."
)
NO_EVIDENCE_LINE = (
    "No measured facts were gated into this brief, so there is nothing to trace."
)
NOTHING_CLEARED_LINE = (
    "Nothing in this run cleared the confidence gate. This brief recommends no "
    "action and reports only what the data cannot support."
)
EXEC_EVIDENCE_LINE = (
    "Every figure above carries its unit and a fact id. The full evidence trail -- "
    "the query or formula behind each figure, and whether it was re-run -- is in the "
    "full brief and the evidence ledger."
)

SECTION_HEADINGS = (
    "What changed",
    "What it means",
    "What to do",
    "What we are watching",
    "What we cannot answer",
    "Outside context",
    "Evidence",
)

# Units that read badly under the generic "<number> <unit>" rule.
_UNIT_TEMPLATES = {
    "pct": "{n}%",
    "percent": "{n}%",
    "%": "{n}%",
    "ratio": "{n}x",
    "count": "{n} (count)",
    "cad": "CAD {n}",
    "usd": "USD {n}",
    "eur": "EUR {n}",
}


class UngatedFactError(TypeError):
    """
    Raised when something that is not a `GatedFact` reaches the narrator.

    A `TypeError` on purpose: narrating an ungated Fact is a type error in the
    product's model of the world, not a runtime mishap to be recovered from.
    """


# --------------------------------------------------------------------------
# formatting helpers
# --------------------------------------------------------------------------
def _fmt_number(value: Any) -> str:
    try:
        f = float(value)
    except (TypeError, ValueError):
        return str(value)
    if f != f:  # NaN
        return "not a finite number"
    if f in (float("inf"), float("-inf")):
        return "not a finite number"
    if abs(f - round(f)) < 1e-9 and abs(f) < 1e15:
        return "{:,}".format(int(round(f)))
    out = "{:,.2f}".format(f)
    if "." in out:
        out = out.rstrip("0").rstrip(".")
    return out


def _fmt_measure(value: Any, unit: str) -> str:
    """Every number the brief states goes through here, so none loses its unit."""
    n = _fmt_number(value)
    u = (unit or "").strip()
    if not u:
        return "%s (unit not recorded)" % (n,)
    key = u.lower()
    if key in _UNIT_TEMPLATES:
        return _UNIT_TEMPLATES[key].format(n=n)
    if key == "days" and n == "1":
        return "1 day"
    return "%s %s" % (n, u)


_DIGITS = "0123456789"


def _claim_states_measure(claim: str, measure: str) -> bool:
    """
    True only when `measure` appears in `claim` as a number in its own right.

    A bare substring test is not enough: "12.5%" sits inside "112.5%", and
    "CAD 84" sits inside "CAD 840". Suppressing the restatement on such a match
    would delete the fact's own value from the brief and leave the reader with a
    different number entirely -- the exact failure this module exists to stop.
    """
    if not measure or not claim:
        return False
    start = 0
    while True:
        i = claim.find(measure, start)
        if i < 0:
            return False
        j = i + len(measure)
        before = claim[i - 1] if i > 0 else ""
        after = claim[j] if j < len(claim) else ""
        nxt = claim[j + 1] if j + 1 < len(claim) else ""
        # Explicit emptiness checks throughout: "" is a substring of every
        # string, so `before in _DIGITS` is True at position 0 and would reject
        # every legitimate match.
        ok = True
        if before and (before in _DIGITS or before in ".,"):
            ok = False           # our digits are the tail of a longer number
        if ok and after and after in _DIGITS:
            ok = False           # our digits are the head of a longer number
        if ok and after and after in ".," and nxt and nxt in _DIGITS:
            ok = False           # a decimal or thousands separator follows
        if ok:
            return True
        start = i + 1


def _measure_clause(f: Fact, template: str) -> str:
    """
    Restate the measured value unless the claim already carries it verbatim.

    Keeps the unit guarantee without printing "41.8 days. Measured at 41.8 days."
    """
    measure = _fmt_measure(f.value, f.unit)
    if _claim_states_measure(f.claim, measure):
        return ""
    return template % (measure,)


def _sentence(text: str) -> str:
    t = " ".join(str(text or "").split())
    if not t:
        return ""
    if t[-1] in ".!?":
        return t
    return t + "."


def _join(parts: Sequence[str]) -> str:
    return " ".join(p for p in (x.strip() for x in parts if x) if p)


def _ref(fact_id: str) -> str:
    return "[fact: %s]" % (fact_id,)


def _forecast_holdout(f: Fact) -> int:
    import json as _json
    try:
        p = _json.loads(f.query)
        return int((p.get("summary") or {}).get("holdout") or 0)
    except (TypeError, ValueError, AttributeError):
        return 0


def _is_forecast(f: Fact) -> bool:
    return str(getattr(f, "fact_kind", "")) == "forecast"


def _value_clause(f: Fact, template: str) -> str:
    """'Measured at', 'Basis', 'Currently' for a measurement; 'Forecast:' for a forecast.

    A forecast is a prediction, not a measured or persistent value; "Measured at 89.02 rows.
    Support: held across 59 periods" misread it as both (QA, 23 Sep 2026)."""
    if _is_forecast(f):
        return "Forecast: %s." % (_fmt_measure(f.value, f.unit),)
    return _measure_clause(f, template)


def _support_clause(f: Fact) -> str:
    """Only states the support signals that actually exist -- no zero filler."""
    bits: List[str] = []
    if _is_forecast(f):
        if f.periods_observed > 0:
            bits.append("learned from %s month%s of history"
                        % (_fmt_number(f.periods_observed), "" if f.periods_observed == 1 else "s"))
        hold = _forecast_holdout(f)
        if hold:
            bits.append("checked over %s replayed month%s" % (_fmt_number(hold), "" if hold == 1 else "s"))
        if f.rows_scanned > 0:
            bits.append("%s rows scanned" % (_fmt_number(f.rows_scanned),))
        return ("Support: " + ", ".join(bits) + ".") if bits else ""
    if f.periods_observed > 0:
        bits.append(
            "held across %s period%s"
            % (_fmt_number(f.periods_observed), "" if f.periods_observed == 1 else "s")
        )
    if f.rows_scanned > 0:
        bits.append("%s rows scanned" % (_fmt_number(f.rows_scanned),))
    if f.effect_size and not (getattr(f, "test", None) or {}).get("no_ratio"):
        # a change with no ratio (monthly averages at or below zero) has no relative size to state
        bits.append("effect size %s" % (_fmt_number(f.effect_size),))
    if not bits:
        return ""
    return "Support: " + ", ".join(bits) + "."


def _qualifier_clause(f: Fact) -> str:
    bits: List[str] = []
    if f.confounders:
        bits.append("Not controlled for: " + ", ".join(f.confounders) + ".")
    if f.caveats:
        bits.append("Caveats: " + "; ".join(f.caveats) + ".")
    return _join(bits)


def _external_context_line(gf: GatedFact) -> str:
    """
    Render an external-sourced fact as outside context, whatever its verdict.

    `facts.QUERY_KINDS` admits "external", so a Fact can be minted from data
    that was never measured against the client's tables. Such a fact must never
    become a finding or an action: the evidence ledger cannot re-run it against
    the source, so the trust claim behind a recommendation does not hold for it.
    It is quarantined here, marked external, with whatever provenance it has.
    """
    f = gf.fact
    source = f.source_table.strip()
    if "::" in source:  # strip a namespacing prefix, e.g. "external::FRED"
        source = source.split("::", 1)[1].strip()
    date = f.computed_at.strip()
    provenance = "(external - source: %s, dated %s)" % (
        source or "source not recorded",
        date or "date not recorded",
    )
    return _join(
        [
            _sentence(f.claim),
            _measure_clause(f, "Reported at %s."),
            provenance,
            "Not measured against your data and not used in any recommendation.",
            _ref(f.id),
        ]
    )


def _materiality_key(gf: GatedFact):
    """
    Most material first: effect magnitude, then rows scanned, then id.

    Magnitude, not signed value: a large fall is exactly as material as a large
    rise, and ranking a -0.95 effect below a +0.10 one would push the biggest
    movement in the data off the end of a capped action list.
    """
    f = gf.fact
    # Zero-tolerance defects first, whatever their share: 18 reused delivery IDs (1% of
    # a file -- possible double billing) ranked 11th of 11 and never reached the page.
    severity = 0 if str(getattr(f, "tolerance", "")) == "zero" else 1
    return (severity,) + _plain_materiality(gf)


def _plain_materiality(gf: GatedFact):
    f = gf.fact
    try:
        effect = abs(float(f.effect_size or 0.0))
    except (TypeError, ValueError):
        effect = 0.0
    if effect != effect:  # NaN sorts last rather than unpredictably
        effect = float("-inf")
    return (-effect, -int(f.rows_scanned or 0), str(f.id))


# --------------------------------------------------------------------------
# enrichments
# --------------------------------------------------------------------------
def _enrichment_line(index: int, item: Any) -> str:
    if isinstance(item, (Fact, GatedFact)):
        raise TypeError(
            "enrichment %d is a %s. Measured facts belong in the evidence base, "
            "not in outside context." % (index, type(item).__name__)
        )
    if not isinstance(item, Mapping):
        raise TypeError(
            "enrichment %d must be a mapping with 'text', 'source' and 'date'; "
            "got %s" % (index, type(item).__name__)
        )
    text = ""
    for key in ("text", "claim", "statement"):
        if str(item.get(key, "") or "").strip():
            text = str(item[key]).strip()
            break
    source = str(item.get("source", "") or "").strip()
    date = str(item.get("date", "") or "").strip()
    if not text:
        raise ValueError("enrichment %d carries no text" % (index,))
    if not source or not date:
        raise ValueError(
            "enrichment %d needs both a source and a date; external context "
            "without provenance is rumour, and this brief will not carry it."
            % (index,)
        )
    return _join([_sentence(text), "(external - source: %s, dated %s)" % (source, date)])


# --------------------------------------------------------------------------
# the brief
# --------------------------------------------------------------------------
@dataclass
class Brief:
    """The client-facing decision story. Assembled only from gated facts."""

    objective: str
    what_changed: List[str] = field(default_factory=list)
    what_it_means: List[str] = field(default_factory=list)
    what_to_do: List[str] = field(default_factory=list)
    watching: List[str] = field(default_factory=list)
    cannot_answer: List[str] = field(default_factory=list)
    outside_context: List[str] = field(default_factory=list)
    evidence_note: str = ""
    # Background measurements -- row counts, repairs made, composite scores. True and
    # useful, but not findings: they used to sit in the watch list phrased as near-miss
    # defects ("1,800 values were repaired ... affects 0% of the table").
    about_file: List[str] = field(default_factory=list)

    # -- counts the prose is not allowed to contradict ----------------------
    # An empty action list means one of two very different things: nothing
    # cleared the gate, or something did and the cap hid it. The renderer must
    # be able to tell them apart, so the count travels with the brief.
    cleared_count: int = 0       # measured facts the gate returned RECOMMEND for
    withheld_count: int = 0      # of those, how many the action cap kept off the page
    quarantined_count: int = 0   # external-sourced facts moved to outside context
    has_evidence_trail: bool = False
    # True when the brief's findings include graded change claims (§2.4): its count lines then
    # say "graded CONFIRMED or cleared for planning", not the audit's "cleared the gate".
    graded: bool = False
    # The business story (What happened / Why / What's next / What to do), set by the
    # no-AI analysis. None on a data-health audit, which renders exactly as before.
    story: Any = None

    # -- rendering ---------------------------------------------------------
    @staticmethod
    def _bullets(items: Sequence[str], empty_line: str) -> List[str]:
        if not items:
            return ["_%s_" % (empty_line,)]
        return ["- " + item for item in items]

    def _empty_action_line(self) -> str:
        """
        What to print when `what_to_do` is empty.

        It must never claim that nothing cleared the gate when something did and
        only the action cap kept it off the page. That is a silent omission, and
        it is the failure mode this whole module exists to prevent.
        """
        if (self.cleared_count or 0) <= 0:
            return NO_ACTION_LINE_GRADED if self.graded else NO_ACTION_LINE
        return (
            "%d %s, but this brief was "
            "capped at zero actions, so none is listed here. The full fact set "
            "and the evidence ledger carry them."
            % (self.cleared_count, self._cleared_words(self.cleared_count))
        )

    def _cleared_words(self, n: int) -> str:
        """'recommendations cleared the confidence gate', or for graded findings (§2.4)
        'findings were graded CONFIRMED or cleared for planning'."""
        if self.graded:
            return ("finding was graded CONFIRMED or cleared for planning" if n == 1 else
                    "findings were graded CONFIRMED or cleared for planning")
        return "recommendation%s cleared the confidence gate" % ("" if n == 1 else "s")

    def _withheld_action_line(self) -> str:
        """Disclosure for cleared recommendations that the cap kept off the page."""
        shown = len(self.what_to_do)
        if (self.withheld_count or 0) <= 0 or not shown:
            return ""
        further = ("further finding%s graded CONFIRMED or cleared for planning"
                   % ("" if self.withheld_count == 1 else "s")) if self.graded else (
            "further recommendation%s that cleared the confidence gate"
            % ("" if self.withheld_count == 1 else "s"))
        return (
            "Plus %d %s; "
            "the %d most material %s shown above, and the full brief carries all %d."
            % (
                self.withheld_count,
                further,
                shown,
                "is" if shown == 1 else "are",
                self.cleared_count,
            )
        )

    def to_markdown(self) -> str:
        """The full brief: finding, meaning, action, and the limits of all three."""
        out: List[str] = ["# Decision brief", ""]
        out.append("**Objective:** %s" % (_sentence(self.objective),))
        out.append("")
        if self.story is not None:
            out.extend(self.story.markdown_sections())
            out.append("## The evidence, finding by finding")
            out.append("_Every figure above comes from one of the facts below; each is gated and "
                       "re-run._")
            out.append("")

        sections = (
            ("What changed", self.what_changed, NO_CHANGE_LINE),
            ("What it means", self.what_it_means, NO_CHANGE_LINE),
            ("What to do", self.what_to_do, self._empty_action_line()),
            ("What we are watching", self.watching, NO_WATCH_LINE),
            ("What we cannot answer", self.cannot_answer, ALL_CLEAR_LINE),
        )
        for heading, items, empty_line in sections:
            out.append("## %s" % (heading,))
            out.extend(self._bullets(items, empty_line))
            if heading == "What to do":
                withheld = self._withheld_action_line()
                if withheld:
                    out.append("- " + withheld)
            out.append("")

        if self.about_file:
            out.append("## About your file")
            out.append("_Background measurements from the audit. They describe the file; they are "
                       "not problems to act on._")
            out.append("")
            out.extend("- " + line for line in self.about_file)
            out.append("")

        out.append("## Outside context")
        if self.outside_context:
            out.append("_%s_" % (EXTERNAL_PREFACE,))
            out.append("")
            out.extend(self._bullets(self.outside_context, NO_EXTERNAL_LINE))
        else:
            out.append("_%s_" % (NO_EXTERNAL_LINE,))
        out.append("")

        out.append("## Evidence")
        out.append(self.evidence_note or NO_EVIDENCE_LINE)
        out.append("")
        return "\n".join(out).rstrip() + "\n"

    def to_exec_markdown(self) -> str:
        """
        One page, no method: decisions, watch list, and what stayed unanswered.

        "No method" means no queries, no source tables and no data-health trail;
        the support behind each action stays, because an executive asked to act
        is entitled to see what the action rests on.
        """
        out: List[str] = ["# %s" % (_sentence(self.objective),), ""]
        if self.story is not None and self.story.bottom_line:
            out.append("**Bottom line:** %s" % (self.story.bottom_line,))
            out.append("")
            out.append("_%s_" % (self._bottom_line(),))
            out.append("")
            out.extend(self.story.markdown_sections(exec_page=True))
        else:
            out.append("**Bottom line:** %s" % (self._bottom_line(),))
            out.append("")

        out.append("## Do now")
        out.extend(self._bullets(self.what_to_do, self._empty_action_line()))
        withheld = self._withheld_action_line()
        if withheld:
            out.append("- " + withheld)
        out.append("")

        out.append("## Watch")
        shown = list(self.watching[:5])
        out.extend(self._bullets(shown, NO_WATCH_LINE))
        if len(self.watching) > len(shown):
            out.append(
                "- Plus %d further signal%s on the watch list, not listed on this page."
                % (
                    len(self.watching) - len(shown),
                    "" if len(self.watching) - len(shown) == 1 else "s",
                )
            )
        out.append("")

        # Never dropped, however long it runs. An exec page that hides its own
        # blind spots is the failure mode this product exists to prevent.
        out.append("## What we cannot answer")
        out.extend(self._bullets(self.cannot_answer, ALL_CLEAR_LINE))
        out.append("")

        # The pointer follows the trail itself, not the length of the note:
        # a note that says only "nothing to trace" plus a quarantine disclosure
        # is not an evidence trail, and must not be advertised as one.
        pointer = EXEC_EVIDENCE_LINE if self.has_evidence_trail else NO_EVIDENCE_LINE
        out.append("_%s_" % (pointer,))
        out.append("")
        return "\n".join(out).rstrip() + "\n"

    def _bottom_line(self) -> str:
        cleared = self.cleared_count or len(self.what_to_do)
        if cleared:
            base = "%d %s%s." % (
                cleared,
                self._cleared_words(cleared),
                ""
                if cleared == len(self.what_to_do)
                else ", %d listed on this page" % (len(self.what_to_do),),
            )
        elif self.watching:
            base = NO_ACTION_LINE_GRADED if self.graded else NO_ACTION_LINE
        else:
            # Nothing to do and nothing to watch: the reader must meet that
            # first, not infer it from an empty page.
            base = NOTHING_CLEARED_LINE
        tail = "%d signal%s on watch, %d question%s the data cannot answer." % (
            len(self.watching),
            "" if len(self.watching) == 1 else "s",
            len(self.cannot_answer),
            "" if len(self.cannot_answer) == 1 else "s",
        )
        return _join([base, tail])


# --------------------------------------------------------------------------
# the narrator
# --------------------------------------------------------------------------
def _rate_clause(gf: GatedFact) -> str:
    """
    A CONFIRMED change's measured false-confirm rate (design §1.5), as the gate worded it with
    its cited facts, so the exec page's action carries it too; "" for anything else.
    """
    if gf.gate.verdict != "RECOMMEND" or getattr(gf.fact, "min_effect", None) is None:
        return ""
    r = gf.gate.reason
    for mark in ("Measured, not promised:", "No measured false-confirm rate is quoted"):
        i = r.find(mark)
        if i >= 0:
            return r[i:].strip()
    return ""


def _settle_line(settle: str) -> str:
    """'What would settle it: ...', without doubling a settle text that already says so."""
    text = _sentence(settle)
    if text.lower().startswith("what would settle it"):
        return text
    return "What would settle it: %s" % (text,)


def _require_gated(gated: Optional[Iterable[Any]]) -> List[GatedFact]:
    items: List[GatedFact] = []
    if gated is None:
        return items
    if isinstance(gated, (Fact, GatedFact, Mapping, str, bytes)):
        raise UngatedFactError(
            "narrate() takes a sequence of GatedFact, got a bare %s"
            % (type(gated).__name__,)
        )
    for i, item in enumerate(gated):
        if isinstance(item, Fact):
            raise UngatedFactError(
                "element %d (fact %r) is an ungated Fact. The narrator reads "
                "gated facts only: run it through the confidence gate first."
                % (i, getattr(item, "id", "?"))
            )
        if not isinstance(item, GatedFact):
            raise UngatedFactError(
                "element %d is a %s; narrate() accepts GatedFact only."
                % (i, type(item).__name__)
            )
        if not isinstance(item.fact, Fact) or not isinstance(item.gate, GateResult):
            raise UngatedFactError(
                "element %d is not a well-formed GatedFact (fact=%s, gate=%s)."
                % (i, type(item.fact).__name__, type(item.gate).__name__)
            )
        items.append(item)
    return items


def _evidence_note(
    ordered: Sequence[GatedFact],
    has_external: bool,
    external_ids: Optional[Sequence[str]] = None,
) -> str:
    ids = list(external_ids or [])
    if not ordered:
        base = NO_EVIDENCE_LINE
        if ids:
            base += " " + EXTERNAL_QUARANTINE_NOTE + " Quarantined as outside " \
                    "context: " + ", ".join(ids) + "."
        elif has_external:
            base += " " + EXTERNAL_QUARANTINE_NOTE
        return base
    # Only sql and derived facts are re-run. Computed and python facts carry a
    # formula, not a query the ledger can execute, and the note must say which is which.
    RERUNNABLE = ("sql", "derived", "model")
    entries: List[str] = []
    n_rerunnable = n_reproduced = n_failed = 0
    for gf in ordered:
        f = gf.fact
        if f.query_kind in RERUNNABLE:
            n_rerunnable += 1
            v = getattr(f, "verified", None)
            if v is True:
                n_reproduced += 1
                check = "refit: reproduced" if f.query_kind == "model" else "re-run: reproduced"
            elif v is False:
                n_failed += 1
                check = "re-run: DID NOT reproduce"
            else:
                check = "re-runnable, not yet re-run"
        else:
            check = "not re-run (%s)" % (
                "computed from other measures" if f.query_kind == "computed"
                else "%s evidence" % f.query_kind)
        bits = [
            # the visitor's grade, never the internal code (review of R1: "[INSUFFICIENT]")
            "%s [%s] %s" % (f.id, visitor_verdict(gf.gate.verdict), _fmt_measure(f.value, f.unit)),
            check,
        ]
        if f.source_table.strip():
            bits.append("over %s" % (f.source_table.strip(),))
        if f.rows_scanned > 0:
            bits.append("%s rows scanned" % (_fmt_number(f.rows_scanned),))
        if _RETENTION_CAVEAT in (f.caveats or []):
            # a cleaning fact with no stage-1 score carries row retention in data_health;
            # it is not a health score and must not read as one (QA, 23 Sep 2026)
            bits.append("rows kept %s%%" % (_fmt_number(f.data_health),))
        else:
            bits.append("data health %s of 100" % (_fmt_number(f.data_health),))
        if f.p_value is not None:
            bits.append("p %s" % (_fmt_number(f.p_value),))
        entries.append(", ".join(bits))

    total = len(ordered)
    head = ("%d of %d figures in this brief have a query that can be re-run against the "
            "source" % (n_rerunnable, total))
    if n_reproduced or n_failed:
        head += "; of those, %d reproduced when re-run" % n_reproduced
        if n_failed:
            head += " and %d did not, and are withheld" % n_failed
    if total - n_rerunnable:
        head += ". The other %d are computed from other measures and are not re-run " \
                "independently" % (total - n_rerunnable)
    note = (
        "Every number in this brief carries its unit and a fact id. " + head
        + ". Evidence by id: " + "; ".join(entries) + "."
    )
    if has_external or ids:
        note += " " + EXTERNAL_QUARANTINE_NOTE
    if ids:
        note += " Quarantined as outside context: " + ", ".join(ids) + "."
    return note


def narrate(
    gated: Optional[Iterable[Any]],
    objective: str,
    enrichments: Optional[Iterable[Any]] = None,
    max_actions: int = 3,
) -> Brief:
    """
    Turn gated facts into a decision brief.

    Args:
        gated: GatedFact objects only. A raw Fact raises UngatedFactError.
        objective: the client question this brief answers.
        enrichments: optional external context, each a mapping carrying
            'text' (or 'claim'/'statement'), 'source' and 'date'. Rendered in
            `outside_context` and nowhere else.
        max_actions: cap on `what_to_do`. The most material RECOMMEND facts win.

    Returns:
        A Brief. Deterministic: identical input always yields identical output.
    """
    if not isinstance(objective, str) or not objective.strip():
        raise ValueError("a brief needs an objective: the question it answers")
    if not isinstance(max_actions, int) or isinstance(max_actions, bool):
        raise ValueError("max_actions must be an int, got %r" % (max_actions,))
    if max_actions < 0:
        raise ValueError("max_actions must be zero or more, got %d" % (max_actions,))

    items = _require_gated(gated)

    # Quarantine first: an externally sourced fact is outside context no matter
    # what verdict the gate gave it, so it can never reach an action.
    external_facts = [gf for gf in items if gf.fact.query_kind == "external"]
    measured = [gf for gf in items if gf.fact.query_kind != "external"]
    graded = any(_is_change(gf.fact) for gf in measured)

    recommend = sorted(
        [gf for gf in measured if gf.gate.verdict == "RECOMMEND"], key=_materiality_key
    )
    watch = sorted(
        [gf for gf in measured if gf.gate.verdict == "WATCH"], key=_materiality_key
    )
    insufficient = sorted(
        [gf for gf in measured if gf.gate.verdict == "INSUFFICIENT"], key=_materiality_key
    )

    external: List[str] = [
        _external_context_line(gf) for gf in sorted(external_facts, key=_materiality_key)
    ]
    ext_list = list(enrichments) if enrichments is not None else []
    for i, item in enumerate(ext_list):
        external.append(_enrichment_line(i, item))

    # -- what changed ------------------------------------------------------
    what_changed: List[str] = []
    for gf in recommend + watch:
        f = gf.fact
        line = _join(
            [
                _sentence(f.claim),
                _value_clause(f, "Measured at %s."),
                _support_clause(f),
                "Directional only, not yet actionable."
                if gf.gate.verdict == "WATCH"
                else "",
                _ref(f.id),
            ]
        )
        what_changed.append(line)

    # -- what it means -----------------------------------------------------
    what_it_means: List[str] = []
    for gf in recommend + watch:
        f = gf.fact
        if _is_change(f):
            # a change claim reads as its evidence grade (§2.4)
            verdict_phrase = (
                "Graded CONFIRMED: an association with the period, not a finding about its cause."
                if gf.gate.verdict == "RECOMMEND"
                else "Graded WATCH: treated as a signal, not a finding."
            )
        else:
            verdict_phrase = (
                "Cleared the confidence gate."
                if gf.gate.verdict == "RECOMMEND"
                else "Did not clear the confidence gate; treated as a signal, not a finding."
            )
        what_it_means.append(
            _join(
                [
                    _sentence(f.claim),
                    verdict_phrase,
                    _sentence(gf.gate.reason) if gf.gate.reason.strip() else "",
                    _qualifier_clause(f),
                    _ref(f.id),
                ]
            )
        )

    # ASA principle 4: say how many change claims were tested, so a confirmation is read
    # against the number of chances it had (design M3).
    tested = [gf for gf in measured if (gf.gate.signals or {}).get("family")]
    if tested:
        fams: Dict[str, int] = {}
        for gf in tested:
            fams[gf.gate.signals["family"]] = int(gf.gate.signals.get("family_size", 0))
        parts = []
        if fams.get("primary"):
            parts.append("1 primary claim tested alone")
        if fams.get("secondary"):
            parts.append("%d secondary claim%s tested as one false-discovery family"
                         % (fams["secondary"], "" if fams["secondary"] == 1 else "s"))
        what_it_means.append(
            "Change claims tested in this run: %d (%s). The primary claim is judged alone; the "
            "secondary claims' verdicts allow for how many were tested together. A p-value "
            "describes one comparison; the false-discovery figure allows for the whole family."
            % (len(tested), "; ".join(parts)))

    # A brief with nothing behind it must announce that before anything else --
    # and say which kind of nothing. A run whose only gated facts were external
    # did NOT produce "no gated facts at all"; it produced facts that were
    # quarantined, and claiming otherwise is a false statement about the run.
    empty_headline = QUARANTINE_ONLY_LINE if external_facts else NO_FACTS_LINE
    if not measured:
        what_it_means.insert(0, empty_headline)
    elif not recommend and not watch:
        what_it_means.insert(
            0,
            "Every one of the %d findings in this run was gated INSUFFICIENT. "
            "This brief therefore recommends nothing; it states what the data "
            "cannot support and what would settle each question."
            % (len(insufficient),),
        )
    elif not recommend:
        what_it_means.insert(0, NO_ACTION_LINE_GRADED if graded else NO_ACTION_LINE)

    # -- what to do (RECOMMEND only, capped, most material first) ----------
    actions: List[str] = []
    for gf in recommend[:max_actions]:
        f = gf.fact
        actions.append(
            _join(
                [
                    ("Plan with: %s" if f.fact_kind == "forecast" else
                     "Take into account (graded CONFIRMED, an association, not a cause): %s"
                     if getattr(f, "min_effect", None) is not None else "Act on: %s")
                    % (_sentence(f.claim),),
                    _value_clause(f, "Basis: %s."),
                    _support_clause(f),
                    _rate_clause(gf),
                    _qualifier_clause(f),
                    _ref(f.id),
                ]
            )
        )
    withheld = max(0, len(recommend) - len(actions))
    if withheld and actions:
        what_it_means.append(
            "%d further recommendation%s cleared the gate but %s not listed here; "
            "the %d most material %s shown under what to do."
            % (
                withheld,
                "" if withheld == 1 else "s",
                "is" if withheld == 1 else "are",
                len(actions),
                "is" if len(actions) == 1 else "are",
            )
        )
    elif withheld:
        # max_actions=0: the gate still cleared these, and the brief says so
        # rather than rendering an empty action list that reads as "nothing
        # cleared".
        what_it_means.append(
            "%d recommendation%s cleared the gate, but this brief was capped at "
            "zero actions, so none is listed under what to do."
            % (withheld, "" if withheld == 1 else "s")
        )

    # -- watching (WATCH only, phrased as monitoring) ----------------------
    watching: List[str] = []
    for gf in watch:
        f = gf.fact
        settle = gf.gate.needed_to_upgrade.strip()
        watching.append(
            _join(
                [
                    "Monitor: %s" % (_sentence(f.claim),),
                    _value_clause(f, "Currently %s."),
                    "Not yet actionable. Gate: %s"
                    % (
                        _sentence(gf.gate.reason)
                        if gf.gate.reason.strip()
                        else "the gate withheld it."
                    ),
                    # "What would settle it", as in the cannot-answer list: some answers are that
                    # nothing in this release can (review of R1: "Re-check when this is true:
                    # No change test is available ...")
                    _settle_line(settle) if settle else "Re-check on the next run.",
                    _ref(f.id),
                ]
            )
        )

    # -- cannot answer (INSUFFICIENT only, never silently omitted) ---------
    cannot_answer: List[str] = []
    for gf in insufficient:
        f = gf.fact
        settle = gf.gate.needed_to_upgrade.strip()
        cannot_answer.append(
            _join(
                [
                    "The data cannot support this claim: %s" % (_sentence(f.claim),),
                    "Why: %s"
                    % (
                        _sentence(gf.gate.reason)
                        if gf.gate.reason.strip()
                        else "the evidence behind it did not meet the gate."
                    ),
                    _settle_line(settle)
                    if settle
                    else "What would settle it: the gate recorded no upgrade path, "
                    "so treat this as open until better data exists.",
                    _ref(f.id),
                ]
            )
        )
    if measured and not cannot_answer:
        # Deliberately NOT appended. The renderer already supplies ALL_CLEAR_LINE
        # for an empty list, and pushing it in here made len(cannot_answer) == 1,
        # so the bottom line announced "1 question the data cannot answer"
        # directly above the sentence saying nothing was unanswerable.
        pass
    if not measured:
        cannot_answer.append(empty_headline)

    ordered_all = recommend + watch + insufficient
    return Brief(
        objective=objective.strip(),
        what_changed=what_changed,
        what_it_means=what_it_means,
        what_to_do=actions,
        watching=watching,
        cannot_answer=cannot_answer,
        outside_context=external,
        evidence_note=_evidence_note(
            ordered_all,
            bool(external),
            [gf.fact.id for gf in external_facts],
        ),
        cleared_count=len(recommend),
        withheld_count=withheld,
        quarantined_count=len(external_facts),
        has_evidence_trail=bool(ordered_all),
        graded=graded,
    )


# --------------------------------------------------------------------------
# the business story: What happened / Why / What's next / What to do
# --------------------------------------------------------------------------
STORY_HEADINGS = ("What happened", "Why", "What's next", "What to do")
EXTERNAL_LABEL = "[external context]"
NO_WHY_LINE = (
    "Nothing in this data explains the changes above, and no outside context was attached. "
    "That is not the same as having no cause: the file records what happened, not why."
)
NO_FORECAST_LINE = "No series in this file was forecast."
NO_STORY_ACTION_LINE = (
    "Nothing in this analysis was graded CONFIRMED or cleared for planning, so it recommends "
    "no action. The changes above are things to watch, not to act on."
)
NOTHING_HAPPENED_LINE = "No business measure could be computed from this file."


def _decimals(v: float) -> int:
    """The decimals story_number gives a measure value of this size."""
    a = abs(float(v))
    return 0 if a >= 1000 else 1 if a >= 10 else 3


def story_number(value: Any, unit: str = "", signed: bool = False,
                 decimals: Optional[int] = None) -> str:
    """
    How the story prints a fact's value. Rounding is presentation only: the unrounded
    value is the fact's, in the ledger. Tests re-derive every printed number with this.
    `decimals` fixes a measure value's decimals (story_pair: two values printed side by side
    share one precision; review v2: "25.3 in the year before to 8.029").
    """
    try:
        v = float(value)
    except (TypeError, ValueError):
        return str(value)
    if v != v or v in (float("inf"), float("-inf")):
        return "not a finite number"
    u = (unit or "").lower()
    sign = "+" if signed and v > 0 else ""
    if decimals is not None and u not in ("pct", "percent", "%", "count", "rows", "months",
                                          "probability", "ratio"):
        d = max(0, min(3, int(decimals)))
        return "%s%s" % (sign, ("{:,.%df}" % d).format(v))
    if u in ("pct", "percent", "%"):
        return "%s%.1f%%" % (sign, v)
    if u in ("count", "rows", "months") or (abs(v - round(v)) < 1e-9 and abs(v) >= 1):
        return "%s%s" % (sign, "{:,}".format(int(round(v))))
    if u == "probability":
        return ("%.4f" % v) if v < 0.001 else ("%.3f" % v)
    if u == "ratio":
        return "%s%.2f" % (sign, v)
    if abs(v) >= 1000:
        return "%s%s" % (sign, "{:,.0f}".format(v))
    if abs(v) >= 10:
        return "%s%.1f" % (sign, v)
    return "%s%.3f" % (sign, v)


def story_pair(a: Any, b: Any, unit: str = "") -> Tuple[str, str]:
    """Two values of one measure printed side by side, at one precision (the finer of the two,
    at most 2 decimals once either value is 10 or more)."""
    try:
        fa, fb = float(a), float(b)
    except (TypeError, ValueError):
        return story_number(a, unit), story_number(b, unit)
    u = (unit or "").lower()
    if u in ("pct", "percent", "%", "count", "rows", "months", "probability", "ratio") or \
            (abs(fa - round(fa)) < 1e-9 and abs(fb - round(fb)) < 1e-9 and min(abs(fa), abs(fb)) >= 1):
        return story_number(a, unit), story_number(b, unit)
    d = max(_decimals(fa), _decimals(fb))
    if max(abs(fa), abs(fb)) >= 10:
        d = min(d, 2)
    return story_number(a, unit, decimals=d), story_number(b, unit, decimals=d)


def _unit_word(unit: str) -> str:
    u = (unit or "").strip()
    return "" if u.lower() in ("pct", "count", "ratio", "probability", "") else " " + u


@dataclass
class Story:
    """The business story. Every number is a formatted fact value; every line cites its facts."""

    objective: str
    what_happened: List[str] = field(default_factory=list)
    why: List[str] = field(default_factory=list)
    whats_next: List[str] = field(default_factory=list)
    what_to_do: List[str] = field(default_factory=list)
    not_measured: List[str] = field(default_factory=list)
    bottom_line: str = ""
    cited: List[str] = field(default_factory=list)

    def markdown_sections(self, exec_page: bool = False) -> List[str]:
        out: List[str] = []
        for heading, items, empty in (
            ("What happened", self.what_happened, NOTHING_HAPPENED_LINE),
            ("Why", self.why, NO_WHY_LINE),
            ("What's next", self.whats_next, NO_FORECAST_LINE),
            ("What to do", self.what_to_do, NO_STORY_ACTION_LINE),
        ):
            if exec_page and heading == "What to do":
                continue            # the exec page's "Do now" carries the actions
            out.append("## %s" % heading)
            out.extend(["- " + i for i in items] if items else ["_%s_" % empty])
            out.append("")
        if self.not_measured and not exec_page:
            out.append("### Not measured")
            out.extend("- " + i for i in self.not_measured)
            out.append("")
        return out

    def to_markdown(self) -> str:
        out = ["# %s" % _sentence(self.objective), ""]
        if self.bottom_line:
            out += ["**Bottom line:** %s" % self.bottom_line, ""]
        out += self.markdown_sections()
        return "\n".join(out).rstrip() + "\n"

    def lines(self) -> List[str]:
        return list(self.what_happened) + list(self.why) + list(self.whats_next) + \
            list(self.what_to_do) + ([self.bottom_line] if self.bottom_line else [])


def _measured_rate(g: GatedFact, F: Any, N: Any) -> str:
    """
    The §1.5 sentence beside a CONFIRMED change: the false-confirm rate the benchmark measured
    in the condition nearest this series, with its interval, every number a cited fact
    (gate.attach_measured_rates made them); or why none is quoted, with no number.
    """
    from .gate import _rate_sentence
    sig = g.gate.signals or {}
    ids = sig.get("benchmark_fact_ids") or []
    if not ids or any(F(i) is None for i in ids):
        return ("No measured false-confirm rate is quoted for it: no benchmark receipt recorded on "
                "this engine's code covers it.")
    vals = {i.rsplit(".", 1)[-1]: N(i) for i in ids}
    return _rate_sentence(vals, bool(sig.get("benchmark_at_bar")))


def _refs(*ids: str) -> str:
    return "[fact: %s]" % ", ".join(i for i in ids if i)


def _is_change(f: Fact) -> bool:
    """A 12-versus-12 change claim: tested (min_effect set) or with no ratio (its monthly averages
    at or below zero); both read as an evidence grade (§2.4)."""
    return (getattr(f, "min_effect", None) is not None
            or bool((getattr(f, "test", None) or {}).get("no_ratio")))


def _verdict_words(v: str) -> str:
    """How a FORECAST's verdict reads (a forecast is a guide, not a confirmed change)."""
    return {"RECOMMEND": "cleared the confidence gate",
            "WATCH": "did not clear the confidence gate: watch it, do not act on it yet",
            "INSUFFICIENT": "is not supported by the data"}.get(v, v)


def _grade_words(v: str) -> str:
    """How a CHANGE claim's evidence grade reads (§2.4): CONFIRMED / WATCH / NOT ENOUGH DATA."""
    g = visitor_verdict(v)
    return {"RECOMMEND": "is graded %s: the change is at least the materiality bar, as an "
                         "association with the period, not a finding about its cause" % g,
            "WATCH": "is graded %s: watch it, do not act on it yet" % g,
            "INSUFFICIENT": "is graded %s: the data cannot support it" % g}.get(v, g)


def _gated_words(g: GatedFact) -> str:
    """The verdict with its reason, in words and without numbers of its own.

    "p = 0.0001. This did not clear the confidence gate" read as a contradiction: the
    reason (a change under the materiality bar) was only in the Watch list (QA, 23 Sep 2026).
    Since R1 a change claim reads as its evidence grade (§2.4), and a WATCH names the check
    that held it back.
    """
    v = g.gate.verdict
    change = _is_change(g.fact)
    words = _grade_words if change else _verdict_words
    rule0 = (g.gate.signals or {}).get("rule", "")
    if change and v == "INSUFFICIENT" and rule0 == "data_health_floor":
        return ("is graded %s: the data it reads are too incomplete or invalid to support it"
                % visitor_verdict(v))
    if v != "WATCH":
        return words(v)
    sig = g.gate.signals or {}
    rule = sig.get("rule", "")
    why: List[str] = []
    if rule == "below_recommend_bar":
        if sig.get("clears_effect") is False:
            why.append("the change is smaller than the size we require before recommending action")
        if sig.get("clears_rows") is False:
            why.append("it rests on fewer rows than we require behind %s"
                       % ("a confirmed change" if change else "advice"))
        if sig.get("clears_periods") is False:
            why.append("it has not held for enough months to call it a pattern")
        p = sig.get("p_value")
        max_p = (sig.get("policy") or {}).get("max_p_value")
        if not change and why and p is not None and max_p is not None and float(p) <= float(max_p):
            why[0] = "the gap is statistically clear, but " + why[0]
        if change and why:
            why[0] = "the change clears the bar, but " + why[0]
    elif rule == "p_value":
        why.append("a gap this size could still be ordinary variation")
    elif rule == "min_effect_p":
        why.append("the change is not yet shown to be at least the materiality bar"
                   if sig.get("changed") else
                   "no change of at least the materiality bar is shown")
    elif rule == "fdr":
        why.append("it does not hold once the other change claims tested in this run are "
                   "allowed for")
    elif rule == "too_close_to_call":
        why.append("it is too close to the line to call")
    elif rule == "benchmark_condition":
        # no figure here: the story prints only cited facts (the gate's reason names the line)
        why.append("its monthly volume is in a range where the benchmark could not certify the "
                   "engine's false-confirm rate, so by rule it is not confirmed")
    elif rule == "drift_screen":
        why.append("the series drifts or wanders, so a gap between the two years is expected "
                   "without any change")
    elif rule == "composition":
        if sig.get("composition_explains"):
            # ship round (24 Sep 2026): the shift at the months the coverage changed, not drift
            why.append("it steps up or down at the months %s start or stop (what the file covers "
                       "changed), and those steps, not a drift or the business like for like, "
                       "explain it" % _plural(sig.get("composition") or "category values"))
        else:
            why.append("part of it comes from what the file covers (%s that start or stop inside the "
                       "compared months), not from the business like for like"
                       % _plural(sig.get("composition") or "category values"))
    elif rule == "extreme_rows":
        why.append("a few extreme rows drive it")
    elif rule == "step_elsewhere":
        why.append("the series stepped once, but not at the start of the latest 12 months, so the "
                   "12-versus-12 gap straddles that step")
    elif rule == "short_history":
        why.append("the history is shorter than we require before confirming a change")
    elif rule == "tested_below_bar":
        why.append("it was tested against a smaller bar than this report requires")
    elif rule == "confounder":
        why.append("something else moved at the same time and was not separated out")
    elif rule == "untested_trend":
        why.append("it has no percentage change (its monthly averages are at or below zero), so "
                   "no change test could be run" if sig.get("no_ratio") else
                   "no statistical test could be run on the change")
    if not why:
        return words(v)
    if change:
        return ("is graded %s because %s: watch it, do not act on it yet"
                % (visitor_verdict(v), " and ".join(why)))
    return ("did not clear the confidence gate because %s: watch it, do not act on it yet"
            % " and ".join(why))


# a monthly total's change claim, never its like-for-like twin (fixer round, 24 Sep 2026: an unsplit
# total's twin 'measure.units.total.like_for_like.change' read as a group and was told twice)
_re_total = __import__("re").compile(r"^measure\.[^.]+\.total(\.(?!like_for_like\.)[^.]+)?\.change$")


def narrate_story(
    gated: Optional[Iterable[Any]],
    objective: str,
    enrichments: Optional[Iterable[Any]] = None,
    not_measured: Optional[Sequence[str]] = None,
) -> Story:
    """
    Tell the business story from gated measure and forecast facts. Deterministic, and
    every number printed is story_number() of a fact that the same line cites.
    """
    if not isinstance(objective, str) or not objective.strip():
        raise ValueError("a story needs an objective: the question it answers")
    items = _require_gated(gated)
    by_id: Dict[str, GatedFact] = {g.fact.id: g for g in items}
    st = Story(objective=objective.strip(), not_measured=list(not_measured or []))

    def F(fid: str) -> Optional[Fact]:
        # A figure whose own query or refit did not reproduce is never printed.
        g = by_id.get(fid)
        if g is None or getattr(g.fact, "verified", None) is False:
            return None
        return g.fact

    def have(*ids: str) -> bool:
        return all(F(i) is not None for i in ids)

    withheld = sorted(g.fact.id for g in items if getattr(g.fact, "verified", None) is False)
    if withheld:
        st.not_measured.append("Withheld because they did not reproduce when re-run or refit: %s."
                               % ", ".join(withheld))

    def N(fid: str, signed: bool = False) -> str:
        f = F(fid)
        st.cited.append(fid)
        return story_number(f.value, f.unit, signed=signed)

    def verdict(fid: str) -> str:
        return by_id[fid].gate.verdict

    def p_clause(pid: str, what: str = "") -> str:
        if F(pid) is None:
            return "No chance test was run."
        q = F(pid).query or ""
        if '"northledger.trend_test/1"' in q:
            # the p-value keeps its condition (M12); the interval comes from the same test
            base = pid[: -len(".p")]
            iv = ""
            if have(base + ".ci_low", base + ".ci_high"):
                iv = ("The same test's interval for the change runs from %s to %s. "
                      % (N(base + ".ci_low", signed=True), N(base + ".ci_high", signed=True)))
                # where the benchmark measured such intervals short of their label, say so
                # (23 Sep 2026 review); the gate owns the rule
                from .gate import interval_caution
                head = by_id.get(base)
                # one estimand (design §1.2): an interval that does not contain its own headline
                # is said to be the model's, never passed off as this figure's range (review of
                # R1, 23 Sep 2026)
                if head is not None and str(head.fact.unit) == "pct" and not (
                        F(base + ".ci_low").value - 1e-9 <= float(head.fact.value)
                        <= F(base + ".ci_high").value + 1e-9):
                    iv = ("The model's interval for the change runs from %s to %s, which does not "
                          "contain this plain ratio of the average months: the model weighs the "
                          "months differently, so read it as the model's range, not this figure's. "
                          % (N(base + ".ci_low", signed=True), N(base + ".ci_high", signed=True)))
                why = interval_caution(head.fact, with_level=False) if head is not None else ""
                if why:
                    iv += "It was %s. " % why
            return ("%sIf the change were smaller than the materiality bar, a result at least this "
                    "strong would appear with probability p = %s (a one-sided test on the monthly "
                    "%s, the month as the unit)." % (iv, N(pid), what or "values"))
        test = ("Welch's t-test" if '"method": "welch"' in q else "A permutation test")
        return ("%s puts the chance of a gap this large arising from ordinary "
                "variation at p = %s." % (test, N(pid)))

    def cites(ids: Sequence[str]) -> List[str]:
        base = ids[0]
        extra = [base + ".ci_low", base + ".ci_high"]
        return [i for i in list(ids) + extra if F(i) is not None]

    def P(a: str, b: str) -> Tuple[str, str]:
        """Two facts of one measure, printed at one precision (review v2)."""
        fa, fb = F(a), F(b)
        st.cited.extend([a, b])
        return story_pair(fa.value, fb.value, fa.unit)

    def extremes_note(base: str, head: str) -> Tuple[str, List[str]]:
        """'N rows of X are extreme (the largest is V against a median of M); without them the
        change is C.' when the measure has extreme rows (review v2)."""
        m = head.split(".")[1]
        ex, big, med, wo = ("measure.%s.extreme_rows" % m, "measure.%s.extreme_rows.largest" % m,
                            "measure.%s.median24" % m, base + "_without_extremes")
        if not have(ex, big, med, wo):
            return "", []
        rule = (by_id[head].gate.signals or {}).get("rule", "") if head in by_id else ""
        lead = ("It is driven by them: " if rule == "extreme_rows" else "")
        return (" %s of %s are extreme (the largest is %s against a median of %s). %swithout them the "
                "change is %s." % (("%s rows" % N(ex)) if F(ex).value != 1 else "1 row", F(med).unit, N(big),
                                   N(med), lead, N(wo, signed=True))).replace(". without", ". Without"), \
            [ex, big, med, wo]

    bottom: List[Tuple[int, str]] = []
    bottom_ids: List[str] = []
    primary_ids = [g.fact.id for g in items if (getattr(g.fact, "test", None) or {}).get("primary_candidate")]

    # ---- what happened ----------------------------------------------------
    # the money first (review v2): the monthly totals of additive measures, the primary one first
    total_ids = sorted((fid for fid in by_id if _re_total.match(fid)),
                       key=lambda fid: (fid not in primary_ids, fid))
    # what was screened before any money was added up (fixer round, 24 Sep 2026)
    if have("measure.currency.count"):
        cur_ids = sorted(fid for fid in by_id if fid.startswith("measure.currency.rows.") and F(fid) is not None)
        parts = ["%s in %s rows" % (F(i).claim.split("Rows in ", 1)[-1].split(" over ", 1)[0], N(i))
                 for i in cur_ids]
        st.what_happened.append(
            "The amounts are in %s currencies (%s), so they are never added across currencies: each "
            "currency's monthly total is compared on its own. %s"
            % (N("measure.currency.count"), "; ".join(parts), _refs("measure.currency.count", *cur_ids)))
    if have("measure.status_excluded.rows"):
        sc = F("measure.status_excluded.rows").claim
        who = sc.split("Rows whose ", 1)[-1].split(", over the 24", 1)[0]
        st.what_happened.append(
            "%s rows whose %s are not money received, so they are left out of every money total (the row "
            "counts keep them). %s" % (N("measure.status_excluded.rows"), who,
                                      _refs("measure.status_excluded.rows")))
    for fid in total_ids:
        base = fid[: -len(".change")]
        ids = [fid, base + ".prior12", base + ".last12", fid + ".p"]
        if not have(*ids[:3]):
            continue
        what = F(fid).claim.split("monthly total of ", 1)[-1].split(", latest 12", 1)[0]
        a, b = P(ids[1], ids[2])
        line = ("The monthly total of %s moved from %s in the year before to %s in the latest year, "
                "a change of %s. %s This %s."
                % (what, a, b, N(fid, signed=True), p_clause(ids[3], "totals"), _gated_words(by_id[fid])))
        note, nids = extremes_note(fid, fid)
        st.what_happened.append("%s%s %s" % (line, note, _refs(*(cites(ids) + nids))))
        # a turn inside the window, said beside the 12-versus-12 figure (measure._peak_fact)
        pk = [base + ".from_peak", base + ".peak3", base + ".latest3"]
        peak_words = ""
        if have(*pk):
            pmo = F(pk[0]).claim.split("(the 3 months to ", 1)[-1].split(")", 1)[0]
            a3, b3 = P(pk[1], pk[2])
            st.what_happened.append(
                "It peaked in the 3 months to %s (an average of %s a month) and has fallen since: the latest "
                "3 months average %s, %s from the peak. The 12-against-12 comparison above averages across "
                "that turn. This is a description found by looking at the series, not a tested change. %s"
                % (pmo, a3, b3, N(pk[0], signed=True), _refs(*pk)))
            peak_words = ", %s since its peak in the 3 months to %s" % (N(pk[0], signed=True), pmo)
        if verdict(fid) != "INSUFFICIENT":
            extra = peak_words
            if peak_words:
                bottom_ids.append(pk[0])
            if (by_id[fid].gate.signals or {}).get("rule") == "extreme_rows" and nids:
                extra += " (driven by extreme rows; %s without them)" % N(nids[-1], signed=True)
                bottom_ids.append(nids[-1])
            bottom.append((0 if fid in primary_ids else 2, "total %s %s%s, graded %s"
                           % (what, N(fid, signed=True), extra, visitor_verdict(verdict(fid)))))
            bottom_ids.append(fid)
        # its like-for-like twin, a tested claim of its own (ship round, 24 Sep 2026)
        lf = base + ".like_for_like.change"
        lids = [lf, base + ".like_for_like.prior12", base + ".like_for_like.last12", lf + ".p",
                "measure.composition.stable"]
        if have(*lids[:3]) and have("measure.composition.stable"):
            col = ((by_id[lf].fact.test or {}).get("subset") or {}).get("column") or "category"
            a, b = P(lids[1], lids[2])
            line = ("Like for like, on the %s %s present in every modelled month, the monthly "
                    "total of %s moved from %s in the year before to %s in the latest year, a change "
                    "of %s. %s This %s."
                    % (N(lids[4]), _plural(col), what, a, b, N(lf, signed=True), p_clause(lids[3], "totals"),
                       _gated_words(by_id[lf])))
            st.what_happened.append("%s %s" % (line, _refs(*cites(lids))))
            if verdict(lf) != "INSUFFICIENT":
                bottom.append((0 if fid in primary_ids else 2, "like for like %s, graded %s"
                               % (N(lf, signed=True), visitor_verdict(verdict(lf)))))
                bottom_ids.append(lf)
    if have("measure.volume.change_pct", "measure.volume.last12", "measure.volume.prior12"):
        ids = ["measure.volume.change_pct", "measure.volume.last12", "measure.volume.prior12",
               "measure.volume.change_pct.p"]
        line = ("Row volume changed by %s in the latest year (%s rows) against the year before "
                "(%s rows). %s This %s."
                % (N(ids[0], signed=True), N(ids[1]), N(ids[2]), p_clause(ids[3], "totals"),
                   _gated_words(by_id[ids[0]])))
        st.what_happened.append("%s %s" % (line, _refs(*cites(ids))))
        if verdict(ids[0]) != "INSUFFICIENT":
            bottom.append((1, "volume %s on the year before, graded %s"
                           % (N(ids[0], signed=True), visitor_verdict(verdict(ids[0])))))
            bottom_ids.append(ids[0])
    lf = "measure.volume.like_for_like.change_pct"
    if have(lf, "measure.volume.like_for_like.last12", "measure.volume.like_for_like.prior12",
            "measure.composition.stable"):
        ids = [lf, "measure.volume.like_for_like.last12", "measure.volume.like_for_like.prior12", lf + ".p",
               "measure.composition.stable"]
        col = (by_id[lf].fact.test or {}).get("composition", {}).get("column") \
            or F(lf).claim.split(" values present", 1)[0].rsplit(" ", 1)[-1]
        line = ("Like for like, on the %s %s present in every modelled month, row volume changed "
                "by %s (%s rows against %s). %s This %s."
                % (N(ids[4]), _plural(col), N(lf, signed=True), N(ids[1]), N(ids[2]), p_clause(ids[3], "totals"),
                   _gated_words(by_id[lf])))
        st.what_happened.append("%s %s" % (line, _refs(*cites(ids))))
        if verdict(lf) != "INSUFFICIENT":
            bottom.append((1, "rows like for like %s, graded %s" % (N(lf, signed=True),
                                                                   visitor_verdict(verdict(lf)))))
            bottom_ids.append(lf)
    import re as _re
    measure_ids = sorted({fid.split(".")[1] for fid in by_id
                          if fid.startswith("measure.") and fid.endswith(".mean")})
    for m in measure_ids:
        base = "measure.%s" % m
        mean = F(base + ".mean")
        if mean is None:
            continue
        col = mean.unit
        if have(base + ".kinds.median_level", base + ".kinds.median_rest"):
            ids = [base + ".kinds.median_level", base + ".kinds.median_rest"]
            m = _re.search(r" where (.+) is '(.*)', over", F(ids[0]).claim)
            who = ("rows where %s is '%s'" % (m.group(1), m.group(2))) if m else "one group of rows"
            a, b = P(ids[0], ids[1])
            st.what_happened.append(
                "%s holds two kinds of value: %s (median %s) and the other rows (median %s), so an "
                "average across them means nothing and is not compared; the monthly total of each "
                "kind is compared instead. %s" % (col[:1].upper() + col[1:], who, a, b, _refs(*ids)))
            continue
        if have(base + ".change", base + ".last12_mean", base + ".prior12_mean"):
            ids = [base + ".change", base + ".prior12_mean", base + ".last12_mean", base + ".change.p"]
            # every measure change is a change in the average month (a mean of monthly means),
            # a percentage or, with no ratio, a difference in its own units
            month = " (the average month)"
            a, b = P(ids[1], ids[2])
            line = ("Average %s%s moved from %s in the year before to %s in the latest year, a change of "
                    "%s. %s This %s."
                    % (col, month, a, b, N(ids[0], signed=True),
                       p_clause(ids[3], "averages"), _gated_words(by_id[ids[0]])))
            note, nids = extremes_note(ids[0], ids[0])
            st.what_happened.append("%s%s %s" % (line, note, _refs(*(cites(ids) + nids))))
            if verdict(ids[0]) != "INSUFFICIENT":
                # the bottom line carries each change's grade and leaves out the ones the data
                # cannot support (review of R1: 13 NOT ENOUGH DATA changes listed as findings)
                extra = ""
                if (by_id[ids[0]].gate.signals or {}).get("rule") == "extreme_rows" and nids:
                    extra = " (driven by extreme rows; %s without them)" % N(nids[-1], signed=True)
                    bottom_ids.append(nids[-1])
                bottom.append((3, "average %s %s%s, graded %s" % (col, N(ids[0], signed=True), extra,
                                                                  visitor_verdict(verdict(ids[0])))))
                bottom_ids.append(ids[0])
        else:
            ids = [base + ".mean", base + ".median"]
            st.what_happened.append("Average %s over the period was %s (median %s). %s"
                                    % (col, N(ids[0]), N(ids[1]) if F(ids[1]) else "not measured",
                                       _refs(*[i for i in ids if F(i) is not None])))
    dims = sorted({fid.split(".")[1] for fid in by_id
                   if fid.startswith("measure.") and fid.endswith(".share.1")})
    for d in dims:
        fid = "measure.%s.share.1" % d
        if F(fid) is None:
            continue
        m = _re.search(r"where (.+) is '(.*)' \(rank", F(fid).claim)
        if not m:
            continue
        st.what_happened.append("The most common %s value is '%s', with %s of rows. %s"
                                % (m.group(1), m.group(2), N(fid), _refs(fid)))
    if F("measure.rows_after_end") is not None:
        f = F("measure.rows_after_end")
        why = "; ".join(f.caveats) if f.caveats else ""
        st.what_happened.append("Left out of every figure above: %s rows dated after the analysis "
                                "window%s. %s" % (N("measure.rows_after_end"),
                                                  (" (%s)" % why) if why else "",
                                                  _refs("measure.rows_after_end")))

    # ---- why -----------------------------------------------------------------
    if have("measure.composition", "measure.composition.stable"):
        # review v2 (24 Sep 2026): a change in what the file covers is the first explanation, and
        # "nothing in this data explains the changes" is never printed beside it
        comp = next(((getattr(g.fact, "test", None) or {}).get("composition") for g in items
                     if (getattr(g.fact, "test", None) or {}).get("composition")), None) or {}
        col = comp.get("column") or "a category"
        words = comp.get("words") or F("measure.composition").claim.split("): ", 1)[-1]
        ids = ["measure.composition", "measure.composition.stable"]
        parts = []
        if have("measure.volume.like_for_like.change_pct"):
            parts.append("rows changed by %s" % N("measure.volume.like_for_like.change_pct", signed=True))
            ids.append("measure.volume.like_for_like.change_pct")
        for fid in sorted(i for i in by_id if i.endswith(".like_for_like.change") and i.startswith("measure.")):
            if F(fid) is None:
                continue
            what = F(fid).claim.split("monthly total of ", 1)[-1].split(" like for like", 1)[0]
            parts.append("the total of %s by %s" % (what, N(fid, signed=True)))
            ids.append(fid)
        lfl = (" Like for like, on the %s %s present in every modelled month, %s."
               % (N("measure.composition.stable"), _plural(col), "; ".join(parts))) if parts else ""
        # the level shifts the change tests found at those months, largest claim first (ship
        # round, 24 Sep 2026: "must read as a step at 2025-03, not drift")
        steps_txt = []
        for fid in sorted((i for i in by_id if _re_total.match(i) or i == "measure.volume.change_pct"),
                          key=lambda i: (i not in primary_ids, i)):
            cs = (by_id[fid].fact.test or {}).get("composition_steps") or {}
            named = [x for x in cs.get("named") or [] if F(x.get("fact", "")) is not None]
            if not named:
                continue
            what = ("row volume" if fid == "measure.volume.change_pct" else "the monthly total of %s"
                    % F(fid).claim.split("monthly total of ", 1)[-1].split(", latest 12", 1)[0])
            bits = []
            for x in named[:3]:
                who = "; ".join("'%s' %s" % (lv, verb) for lv, verb in x.get("levels") or [])
                bits.append("%sby %s in %s%s" % ("" if bits else ("up " if float(x["size"]) > 0 else "down "),
                                                 N(x["fact"], signed=True), x["month"],
                                                 (", when %s" % who) if who else ""))
                ids.append(x["fact"])
            steps_txt.append("%s%s steps %s%s" % (what[:1].upper(), what[1:], "; ".join(bits),
                                                  (": with those steps allowed for, no drift remains"
                                                   if cs.get("explains") else
                                                   ", and it still drifts with them allowed for")))
        stx = (" " + ". ".join(steps_txt) + ".") if steps_txt else ""
        st.why.append("Part of the change is in what the file covers, not in the business: in %s, %s.%s%s "
                      "%s" % (col, words, stx, lfl, _refs(*ids)))
    seen: List[str] = []
    for g in items:
        if not (g.fact.id.startswith("measure.") or g.fact.id.startswith("forecast.")):
            continue
        for c in g.fact.confounders or []:
            if c not in seen:
                seen.append(c)
    for c in seen:
        if c.startswith("the mix of ") and have("measure.composition"):
            continue                                   # said above, with its like-for-like figures
        if "set aside by cleaning differs" in c and F("measure.set_aside_share.lowest_month") \
                and F("measure.set_aside_share.highest_month"):
            ids = ["measure.set_aside_share.lowest_month", "measure.set_aside_share.highest_month"]
            st.why.append("Not separated out: the share of rows set aside by cleaning ranged from %s "
                          "to %s a month, so part of any change may come from cleaning rather than "
                          "the business. %s" % (N(ids[0]), N(ids[1]), _refs(*ids)))
        elif "month cannot be read" in c and F("measure.set_aside_undated"):
            st.why.append("Not separated out: %s rows set aside by cleaning have no readable month, "
                          "so they could belong to either period. %s"
                          % (N("measure.set_aside_undated"), _refs("measure.set_aside_undated")))
        else:
            st.why.append("Not separated out: %s." % c.rstrip("."))
    for i, item in enumerate(list(enrichments) if enrichments is not None else []):
        st.why.append("%s %s" % (EXTERNAL_LABEL, _enrichment_line(i, item)))

    # ---- what's next ---------------------------------------------------------
    from . import forecast as _fc
    prim_series = {(getattr(by_id[i].fact, "test", None) or {}).get("series_slug") for i in primary_ids}
    heads = sorted((fid for fid in by_id if fid.startswith("forecast.")
                    and (fid.endswith(".next") or fid.endswith(".history_months"))),
                   key=lambda fid: (fid.split(".")[1] not in prim_series, fid.split(".")[1] != "monthly_rows", fid))
    for fid in heads:
        g = by_id[fid]
        sl = fid.split(".")[1]
        pre = "forecast.%s." % sl

        def unrep(*ids: str) -> bool:
            # present in the ledger but its re-run or refit did not reproduce. A figure that
            # is simply absent (an undefined range or MASE, never emitted) is not "withheld".
            return any(i in by_id and F(i) is None for i in ids)

        if F(fid) is None or (fid.endswith(".next") and (unrep(
                pre + "next.lo80", pre + "next.hi80", pre + "backtest.months", pre + "backtest.mape",
                pre + "history.months") or not have(pre + "backtest.months", pre + "history.months"))):
            st.whats_next.append("The forecast of %s is withheld: its figures did not reproduce when "
                                 "refit. %s" % (sl.replace("_", " "), _refs(fid)))
            continue
        if fid.endswith(".history_months"):
            st.whats_next.append("No forecast of %s: %s months of history is too short to replay "
                                 "and check one. %s"
                                 % (g.fact.claim.split(" to forecast ", 1)[-1], N(fid), _refs(fid)))
            continue
        p = _fc.payload_of(g.fact) or {}
        champ = str(p.get("model", ""))
        if g.gate.verdict == "INSUFFICIENT":
            # A forecast that could not be checked properly is not offered, not even as a guide,
            # and the reason given is the gate's own (it used to be "too few replayed months"
            # whatever the rule was: QA, 23 Sep 2026).
            what = g.fact.claim.split("Forecast of ", 1)[-1].split(" for ")[0]
            rule = (g.gate.signals or {}).get("rule", "")
            if rule == "stale":
                s0 = p.get("summary", {})
                st.whats_next.append(
                    "No forecast of %s is offered: the data stops at %s, before the analysis date "
                    "(%s), so a forecast of %s would be history, not a plan. %s"
                    % (what, s0.get("end", "?"), str(s0.get("as_of", "?"))[:7],
                       s0.get("first_forecast_month", "?"), _refs(fid)))
            elif rule == "data_health_floor":
                st.whats_next.append(
                    "A forecast of %s was fitted but is not offered: the file's data-health score is "
                    "under the floor we require before forecasting, and a forecast of a broken series "
                    "is a forecast of the breakage. %s" % (what, _refs(fid)))
            elif rule == "min_history":
                st.whats_next.append(
                    "A forecast of %s was fitted but is not offered: %s months of history is too "
                    "short to show whether a seasonal pattern repeats. %s"
                    % (what, N(pre + "history.months"), _refs(fid, pre + "history.months")))
            else:
                st.whats_next.append(
                    "A forecast of %s was fitted but is not offered: it could only be checked "
                    "against %s replayed months of %s months of history, too few to trust. %s"
                    % (what, N(pre + "backtest.months"), N(pre + "history.months"),
                       _refs(fid, pre + "backtest.months", pre + "history.months")))
            continue
        label = g.fact.claim.split("Forecast of ", 1)[-1]
        uw = _unit_word(g.fact.unit)
        has_band = have(pre + "next.lo80", pre + "next.hi80")
        if has_band:
            line = ("%s: %s%s (80%% range %s to %s)."
                    % (label, N(fid), uw, N(pre + "next.lo80"), N(pre + "next.hi80")))
            ids = [fid, pre + "next.lo80", pre + "next.hi80"]
        else:
            line = ("%s: %s%s, with no 80%% range: too few replayed errors at that horizon to "
                    "draw one." % (label, N(fid), uw))
            ids = [fid]
        if have(pre + "end", pre + "end.lo80", pre + "end.hi80"):
            endlabel = F(pre + "end").claim.rsplit(" for ", 1)[-1]
            line += " By %s: %s (80%% range %s to %s)." % (
                endlabel, N(pre + "end"), N(pre + "end.lo80"), N(pre + "end.hi80"))
            ids += [pre + "end", pre + "end.lo80", pre + "end.hi80"]
        st.whats_next.append("%s %s" % (line, _refs(*ids)))
        # after a step the change test found (ship round, 24 Sep 2026): what the forecast did
        # about it, in plain words (forecast_facts records the choice in the config)
        cfg_ = p.get("config") or {}
        step_m = str(cfg_.get("fit_from") or cfg_.get("step_month") or "")
        if step_m:
            who = ""
            for cg in items:
                tt = getattr(cg.fact, "test", None) or {}
                if tt.get("series_slug") == sl or (sl == "monthly_rows" and cg.fact.id == "measure.volume.change_pct"):
                    for x in ((tt.get("composition_steps") or {}).get("named") or []):
                        if x.get("month") == step_m and x.get("levels"):
                            who = " (%s)" % "; ".join("'%s' %s" % (lv, verb) for lv, verb in x["levels"])
            if cfg_.get("fit_from"):
                st.whats_next.append(
                    "The series stepped in %s%s, so this forecast was fitted and replayed only on the "
                    "months from then on: the months before would teach it a level the series has "
                    "left. %s" % (step_m, who, _refs(fid)))
            else:
                ratio = float(cfg_.get("useful_range_ratio") or _fc.USEFUL_RANGE_RATIO)
                times = "twice" if abs(ratio - 2.0) < 1e-9 else "%g times" % ratio
                shown_to = (" (here up to %s)" % F(pre + "end").claim.rsplit(" for ", 1)[-1]
                            if have(pre + "end") else " (here the month ahead only)")
                st.whats_next.append(
                    "The series stepped in %s%s, and the months since are too few to fit and replay "
                    "a forecast on alone, so the model learned across the step. The replayed forecasts "
                    "made before a step and scored after it measure the step, not the method, so they "
                    "are left out of its range, and it was judged against repeating last year's month "
                    "scaled by the step. Months ahead are shown only while the range's high end is at "
                    "most %s its low end%s. %s" % (step_m, who, times, shown_to, _refs(fid)))
        ids = [pre + "backtest.months"]
        method = ("Method: %s, chosen because it had the lowest error when we replayed the last %s "
                  "months, forecasting each from what was known at the time"
                  % (_fc.PLAIN_NAME.get(champ, champ), N(ids[0])))
        if not have(pre + "backtest.mape"):
            # every replayed month was zero, so a miss "as a share of the actual" is undefined
            method += ". Its miss cannot be stated as a share of the actual value: the replayed months were zero."
        else:
            method += (". Over that replay it missed by %s on average across every horizon"
                       % N(pre + "backtest.mape"))
            ids.append(pre + "backtest.mape")
            if have(pre + "backtest.mape_h1", pre + "backtest.mape_end"):
                method += (": by %s one month ahead and by %s at the furthest month ahead."
                           % (N(pre + "backtest.mape_h1"), N(pre + "backtest.mape_end")))
                ids += [pre + "backtest.mape_h1", pre + "backtest.mape_end"]
            elif have(pre + "backtest.mape_h1"):
                method += ", by %s one month ahead." % N(pre + "backtest.mape_h1")
                ids.append(pre + "backtest.mape_h1")
            else:
                method += "."
        if champ in _fc.BASELINES:
            method += (" Plainly: the simplest rule (%s) beat every more elaborate method we tried."
                       % _fc.PLAIN_NAME[champ])
        else:
            others = []
            for b in _fc.BASELINES:
                bid = pre + "model.%s.mape" % b
                if F(bid) is not None:
                    others.append("%s missed by %s" % (_fc.PLAIN_NAME[b], N(bid)))
                    ids.append(bid)
            if others:
                method += " For comparison, %s." % "; ".join(others)
        st.whats_next.append("%s %s" % (method, _refs(*ids)))
        ids = [pre + "coverage.hits", pre + "coverage.n"]
        if have(*ids):
            st.whats_next.append("Its month-ahead 80%% range held in %s of %s replayed months, each "
                                 "range built only from errors known at the time. This forecast %s. %s"
                                 % (N(ids[0]), N(ids[1]), _verdict_words(g.gate.verdict), _refs(fid, *ids)))
        if has_band and not (F(pre + "next.lo80").value <= g.fact.value <= F(pre + "next.hi80").value):
            st.whats_next.append("The range does not contain the point forecast: in the replay this "
                                 "method's misses leaned one way, and the range follows its actual "
                                 "misses rather than being centred on the point. %s"
                                 % _refs(fid, pre + "next.lo80", pre + "next.hi80"))
        bottom.append((4 if sl in prim_series else 5, "%s forecast at %s%s for %s"
                       % (label.rsplit(" for ", 1)[0], N(fid), uw, label.rsplit(" for ", 1)[-1])))
        bottom_ids.append(fid)

    # ---- what to do ------------------------------------------------------------
    # A forecast of the ledger's own line count is data-pipeline monitoring, not a planning number,
    # when the file has a money total to plan with (fixer round, 24 Sep 2026: "plan with ... monthly
    # rows ... 104 rows"); it stays under what comes next.
    money_fc = any(fid.startswith("forecast.total_") and fid.endswith(".next") for fid in by_id)
    for g in sorted([g for g in items if g.gate.verdict == "RECOMMEND" and F(g.fact.id) is not None
                     and getattr(g.fact, "role", "headline") == "headline"
                     and g.fact.query_kind != "external"], key=_materiality_key):
        if g.fact.fact_kind == "forecast":
            pre = g.fact.id.rsplit(".", 1)[0] + "."
            if money_fc and g.fact.id == "forecast.monthly_rows.next":
                continue
            if have(pre + "next.lo80", pre + "next.hi80"):
                # (a forecast with no range is never planned with: it cannot be RECOMMENDED,
                # since the gate scores the range on the replay)
                st.what_to_do.append(
                    "Plan with the forecast, range and all: %s is %s%s, with an 80%% range of %s to "
                    "%s; plan for either end, not only the middle. %s"
                    % (g.fact.claim.split("Forecast of ", 1)[-1], N(g.fact.id), _unit_word(g.fact.unit),
                       N(pre + "next.lo80"), N(pre + "next.hi80"),
                       _refs(g.fact.id, pre + "next.lo80", pre + "next.hi80")))
            continue
        if getattr(g.fact, "min_effect", None) is not None:
            # a confirmed change is an association with the period (§2.4): the engine shows it,
            # the decision it supports is the owner's
            head = ("Take into account, graded %s: %s (%s%s). It is associated with the period, "
                    "not shown to have a cause; what to do about it is your decision."
                    % (visitor_verdict(g.gate.verdict), g.fact.claim.rstrip("."),
                       N(g.fact.id, signed=True), _unit_word(g.fact.unit)))
            st.what_to_do.append("%s %s %s" % (head, _measured_rate(g, F, N), _refs(
                g.fact.id, *[i for i in (g.gate.signals or {}).get("benchmark_fact_ids") or []
                             if F(i) is not None])))
            continue
        st.what_to_do.append("Act on: %s (%s%s). %s" % (g.fact.claim.rstrip("."), N(g.fact.id),
                                                         _unit_word(g.fact.unit), _refs(g.fact.id)))

    # one forecast in the bottom line: the money series' when there is one, else the row count
    fc_items = sorted((b for b in bottom if b[0] >= 4), key=lambda x: x[0])
    bottom = [b for b in bottom if b[0] < 4] + fc_items[:1]
    if not bottom and have("measure.months") and not have("measure.volume.change_pct") \
            and any(fid.endswith(".mean") and fid.startswith("measure.") for fid in by_id):
        # a file too short to compare two years still has a bottom line (review v2: a 22-month
        # KPI file read "No business measure could be computed" above its own averages)
        span = F("measure.months").claim.rsplit(", ", 1)[-1]
        st.bottom_line = ("%s months of history (%s): too short to compare the latest 12 months with the "
                          "12 before, so no change is tested; the averages over the period are below. %s"
                          % (N("measure.months"), span, _refs("measure.months")))
    if bottom:
        text = "; ".join(t for _, t in sorted(bottom, key=lambda x: x[0]))
        st.bottom_line = "%s %s" % (_sentence(text[0].upper() + text[1:]), _refs(*bottom_ids))
    return st
