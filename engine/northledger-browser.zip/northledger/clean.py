#!/usr/bin/env python3
"""
Stage 2 of the NorthLedger Insight Loop: cleaning, with a conservation law.

The invariant a client's accountant will probe for, and the one this module
exists to make un-fudgeable:

    rows_in == rows_clean + rows_quarantined      (always, asserted in code)

Nothing is ever silently dropped. A row either survives into `clean` or it is
placed in `quarantined` carrying a human-readable reason for why it left. A
repaired VALUE is a fix, not a drop -- fixes and quarantines are counted on
separate ledgers so "we cleaned 4,000 rows" can never quietly mean "we deleted
400 of them".

Cleaning behaviours mirror real Excel-export abuse: null-like strings, stray
whitespace and casing, dates in three formats in one column, numbers stored as
text, copy-paste duplicate rows, and impossible values.

Python 3.9 compatible. Depends only on stdlib + pandas + numpy.
"""
from __future__ import annotations

import datetime as _dt
import math
import re
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from .facts import Fact

__all__ = [
    "Rule",
    "RULE_KINDS",
    "SEVERITIES",
    "DEFAULT_NULL_TOKENS",
    "DEFAULT_DATE_FORMATS",
    "QUARANTINE_COL",
    "ReconciliationError",
    "CleanResult",
    "clean_frame",
    "clean_table",
    "standard_rules",
]

QUARANTINE_COL = "_quarantine_reason"

RULE_KINDS = (
    "null_like",    # 'NULL', 'N/A', '', whitespace -> NaN                (fix)
    "trim",         # strip + collapse internal whitespace                (fix)
    "case",         # casing normalisation: upper | lower | title         (fix)
    "numeric",      # numbers-stored-as-text -> float; unparseable out    (fix + quarantine)
    "date",         # mixed date formats -> datetime; unparseable out     (fix + quarantine)
    "dedupe",       # exact duplicate rows -> quarantine, never oblivion  (quarantine)
    "range",        # min/max impossibility (e.g. negative quantity)      (quarantine)
    "not_future",   # a date that has not happened yet (e.g. birth date)  (quarantine)
    "not_null",     # a required value is missing                         (quarantine)
    "allowed",      # value outside a known code list                     (quarantine)
    "boolean",      # yes/no spellings -> the column's own pair; only in a
                    # column that is mostly yes/no values                 (fix + quarantine)
    "series_end",   # rows dated after the series stops (a phantom tail)  (quarantine + fact)
    "latest_per_key",  # keep the latest row per key by an order column;
                    # superseded rows leave BY DESIGN, with a reason      (quarantine + fact)
    "date_plausible",  # a placeholder date (1900-01-01) or one far before the rest of
                    # the column, on the main event date                  (quarantine)
)

SEVERITIES = ("quarantine", "fix", "flag")

# Rules whose whole job is repair. Their severity is always "fix".
_FIX_ONLY_KINDS = ("null_like", "trim", "case")

# One definition of "missing", shared with health.py; see northledger/vocab.py.
from .vocab import NULL_TOKENS_LOWER as _SHARED_NULL_TOKENS  # noqa: E402
from .vocab import day_month_order  # noqa: E402
from .vocab import BOOLEAN_PAIRS, boolean_value  # noqa: E402
from .vocab import CLEAN_QUERY_MARKER, RETENTION_CAVEAT  # noqa: E402
DEFAULT_NULL_TOKENS = ("",) + tuple(_SHARED_NULL_TOKENS)

# Explicit formats, tried in order. ISO first so an unambiguous value is never
# claimed by a guessier pattern; day-first before month-first because the
# Canadian exports this was built against are day-first.
# A text column is only retyped as numeric when this share of its non-null
# values already parse as numbers. Below it, the odd numeric-looking cell is
# data entry noise, not the column's type.
NUMERIC_DOMINANCE = 0.90

# The same bar for dates (a column gets a date rule when this share of its
# non-null values are dates, or when stage 1 typed it as a date) and for yes/no
# columns (spellings are mapped only when this share are yes/no spellings).
# 23 Sep 2026: ONE date-like review body out of 48,384 gave the free-text column a
# date rule, and 99.92% of the file was quarantined.
DATE_DOMINANCE = NUMERIC_DOMINANCE
BOOLEAN_DOMINANCE = NUMERIC_DOMINANCE

# Epoch numbers inside a date column are converted only when the column's other
# values are mostly real dates (this share of its non-null values), only at 10
# digits (seconds) or 13 digits (milliseconds), and only inside these years.
EPOCH_MIN_DATE_SHARE = 0.50
EPOCH_YEARS = (1990, 2100)

# Series-end ("phantom tail") detector: the first month from which `run` months
# in a row -- and every month after it -- hold under `ratio` of the median month
# of the `min_prior` months before it.
SERIES_END_DEFAULTS = {"min_prior": 12, "run": 3, "ratio": 0.10}

DEFAULT_DATE_FORMATS = (
    "%Y-%m-%d",
    "%Y-%m-%dT%H:%M:%S.%f",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M",
    "%Y-%m-%d %H:%M:%S",
    "%d-%b-%Y",
    "%d-%b-%y",
    "%Y/%m/%d",
    "%d/%m/%Y",
    "%m/%d/%Y",
    "%d/%m/%Y %I:%M:%S %p",
    "%m/%d/%Y %I:%M:%S %p",
    "%d/%m/%Y %H:%M:%S",
    "%m/%d/%Y %H:%M:%S",
    "%d-%m-%Y",
    "%d.%m.%Y",
    "%b %d, %Y",
    "%d %b %Y",
    "%B %d, %Y",
    "%b %d %Y",
    "%B %d %Y",
    "%d %B %Y",
    "%d/%m/%y",
    "%Y%m%d",
    # Month-level dates (one row per month in a KPI or summary file): read as the first of
    # the month. Review v2 (24 Sep 2026): a SaaS metrics file written '2024-11' and
    # 'Dec-2024' had no date column at all, so nothing over time could be said.
    "%Y-%m",
    "%Y/%m",
    "%b-%Y",
    "%B-%Y",
    "%b %Y",
    "%B %Y",
    "%m/%Y",
)

# ISO-8601 with a time zone ('Z' or an offset): read as the same instant in UTC. Review v2
# (24 Sep 2026): '2023-05-02T01:26:00Z' matched no format and 87% of a support-ticket
# export was set aside.
_ZONED_ISO_RE = re.compile(
    r"^\s*\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?\s*(?:Z|z|UTC|[+-]\d{2}:?\d{2})\s*$")

# Formats whose first two numbers are day and month in some order. Which order a
# column uses is decided ONCE per column from its own values (vocab.day_month_order),
# never value by value: trying %m/%d/%Y and then %d/%m/%Y on whatever was left read
# one courier column two ways and silently swapped 151 of 389 dates (22 Sep 2026).
_DAY_FIRST_FORMATS = ("%d/%m/%Y", "%d-%m-%Y", "%d.%m.%Y", "%d/%m/%y", "%d-%m-%y", "%d.%m.%y",
                      "%d/%m/%Y %I:%M:%S %p", "%d/%m/%Y %H:%M:%S")
_MONTH_FIRST_FORMATS = ("%m/%d/%Y", "%m-%d-%Y", "%m.%d.%Y", "%m/%d/%y", "%m-%d-%y", "%m.%d.%y",
                        "%m/%d/%Y %I:%M:%S %p", "%m/%d/%Y %H:%M:%S")
_ORDER_TWIN = dict(zip(_DAY_FIRST_FORMATS, _MONTH_FIRST_FORMATS))
_ORDER_TWIN.update(zip(_MONTH_FIRST_FORMATS, _DAY_FIRST_FORMATS))
_DAY_MONTH_RE = r"^\s*(\d{1,2})([/.\-])(\d{1,2})\2(\d{2}|\d{4})(?:[ T].*)?\s*$"   # time may follow

_WS_RE = re.compile(r"\s+")
_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_$]*$")
# 1,200 / 1,200.50 -- a comma used as a thousands separator, and nothing else.
# Anything else with a comma in it ('1,5') is ambiguous between a European
# decimal mark and a malformed group, so it is rejected rather than guessed at.
_THOUSANDS_RE = re.compile(r"^[+-]?\d{1,3}(?:,\d{3})+(?:\.\d+)?$")
_CODE_NAME_RE = re.compile(r"(^|_)(id|code|sku|status|type|category|class|province|state|currency)s?$", re.I)
_NON_NEGATIVE_RE = re.compile(r"(^|_)(qty|quantity|quantities|count|units|amount|price|total|hours|days|age)s?$", re.I)
# 'balance' is deliberately NOT here (26 Sep 2026): a balance is two-sided by nature. A trade
# balance is negative for every deficit partner (Canada-China, latest quarter about -5.1bn),
# a bank balance can be overdrawn, a current-account balance is negative in deficit years.
# Quarantining those rows as "outside the possible range" collapsed whole analyses of real
# statistical tables. The name still tells the AI planner the column is a level; the engine
# just never hard-quarantines on the name alone.
_PAST_ONLY_RE = re.compile(r"(birth|dob|born|hired|hire_date)", re.I)
# Star ratings are never negative; the -1 'not rated' sentinel is a defect, not a score.
# ('score' is deliberately absent: net promoter and z-scores go below zero.)
_RATING_RE = re.compile(r"(^|_)(rating|ratings|stars?)$", re.I)
# Dates that are ALLOWED to be ahead of today: nothing is "in the future" about a due
# date. Matched on the name with every non-alphanumeric run turned into '_'.
_FORWARD_LOOKING_RE = re.compile(
    r"(^|_)(due|expir\w*|expiry|expires|next|scheduled|schedule|planned|plan|target|deadline|"
    r"forecast\w*|projected|estimated|eta|renewal|renews|maturity|matures|end|ends|until|"
    r"valid_to|valid_until|follow_up|followup|appointment|reinspection|effective_to|"
    # a signed lease that starts next month, a move-in booked ahead, a unit available from
    # a later date: normal in a rent roll, never a typo (QA, 23 Sep 2026)
    # ('start' alone is left out: a trip log's start_time is its event date.)
    r"lease_start|tenancy_start|contract_start|term_start|commence\w*|move_in|movein|"
    r"effective|effective_from|available|"
    r"availability|occupancy|booking|booked|closing|possession)(_|$)", re.I)
_CURRENCY_CHARS = "$£€¥₹"


# ---------------------------------------------------------------------------
# small helpers
# ---------------------------------------------------------------------------
def _is_na(value: Any) -> bool:
    """pd.isna that never returns an array and never raises."""
    try:
        res = pd.isna(value)
    except Exception:  # noqa: BLE001 - unhashable / exotic cell
        return False
    if isinstance(res, (bool, np.bool_)):
        return bool(res)
    return False


def _is_number(value: Any) -> bool:
    return isinstance(value, (int, float, np.integer, np.floating)) and not isinstance(value, bool)


def _is_datetime_like(value: Any) -> bool:
    return isinstance(value, (pd.Timestamp, _dt.datetime, _dt.date)) and not isinstance(value, bool)


def _changed_mask(old: pd.Series, new: pd.Series) -> pd.Series:
    """
    Element-wise "did this cell actually change", with NaN -> NaN counted as
    unchanged. Done cell by cell because the columns we repair hold mixed types
    and a vectorised `!=` across str/float/Timestamp is not reliable.
    """
    old_na = old.isna().to_numpy()
    new_na = new.isna().to_numpy()
    ov = old.to_numpy(dtype=object)
    nv = new.to_numpy(dtype=object)
    out = np.zeros(len(old), dtype=bool)
    for i in range(len(old)):
        if old_na[i] and new_na[i]:
            out[i] = False
        elif old_na[i] != new_na[i]:
            out[i] = True
        else:
            try:
                out[i] = bool(ov[i] != nv[i])
            except Exception:  # noqa: BLE001 - incomparable pair means it changed
                out[i] = True
    return pd.Series(out, index=old.index)


def _slug(text: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "_", str(text).strip().lower()).strip("_")
    return slug or "unnamed"


def _fmt_num(value: Any) -> str:
    v = float(value)
    return format(int(v), ",") if v.is_integer() else "%.1f" % v


def _short(value: Any, limit: int = 40) -> str:
    text = "<missing>" if _is_na(value) else str(value)
    text = text.replace("\n", "\\n")
    return text if len(text) <= limit else text[: limit - 1] + "…"


# ---------------------------------------------------------------------------
# Rule
# ---------------------------------------------------------------------------
@dataclass
class Rule:
    """One cleaning instruction. `column` may be "*" (all text columns) or ""
    (whole-row rules such as dedupe)."""

    name: str
    column: str
    kind: str
    params: Dict[str, Any] = field(default_factory=dict)
    severity: str = "quarantine"

    def __post_init__(self) -> None:
        if not str(self.name).strip():
            raise ValueError("a Rule needs a name; it is how its count is reported")
        if self.kind not in RULE_KINDS:
            raise ValueError("kind must be one of %s, got %r" % (RULE_KINDS, self.kind))
        if self.severity not in SEVERITIES:
            raise ValueError("severity must be one of %s, got %r" % (SEVERITIES, self.severity))
        if self.kind in _FIX_ONLY_KINDS and self.severity != "fix":
            raise ValueError(
                "rule %r is kind %r, which only ever repairs values; severity must "
                "be 'fix', got %r" % (self.name, self.kind, self.severity)
            )
        if self.kind not in ("dedupe",) and not str(self.column).strip():
            raise ValueError("rule %r (kind %s) needs a column" % (self.name, self.kind))
        if self.params is None:
            self.params = {}

    # the stable, rule-level phrase that quarantine counts are keyed by
    def reason_key(self) -> str:
        return "%s: %s" % (self.name, _RULE_BLURBS.get(self.kind, self.kind))


_RULE_BLURBS = {
    "numeric": "value is not a number",
    "date": "value matches no known date format",
    "dedupe": "exact duplicate row",
    "range": "value outside the possible range",
    "not_future": "date is in the future",
    "not_null": "required value is missing",
    "allowed": "value is not in the allowed list",
    "boolean": "value is not a yes/no value",
    "series_end": "dated after the series ends",
    "latest_per_key": "superseded by a later row for the same key",
    "date_plausible": "date is a placeholder or implausibly early",
}


class ReconciliationError(Exception):
    """Raised when rows_in != rows_clean + rows_quarantined, or when the
    quarantine ledger does not account for every quarantined row."""


# ---------------------------------------------------------------------------
# CleanResult
# ---------------------------------------------------------------------------
@dataclass(eq=False)
class CleanResult:
    """The outcome of a cleaning pass, and its conservation proof."""

    total_in: int
    rows_clean: int
    rows_quarantined: int
    fixes_applied: Dict[str, int] = field(default_factory=dict)
    quarantine_reasons: Dict[str, int] = field(default_factory=dict)
    clean: pd.DataFrame = field(default_factory=pd.DataFrame, repr=False)
    quarantined: pd.DataFrame = field(default_factory=pd.DataFrame, repr=False)
    # --- extras, all defaulted so the documented signature still holds -------
    flags: Dict[str, int] = field(default_factory=dict)
    source: str = ""
    rule_source: str = ""      # "health" | "frame-fallback" | "" (caller-supplied)
    # Why stage-1 rules were not used, when they were not. A downgrade to the
    # timid fallback changes what gets rejected, so it is never silent: the
    # reason travels in the summary AND as a caveat on every derived fact.
    rule_source_error: str = ""
    # Things a rule found that are not a count of fixes or rejections: where a
    # series ends, how many rows a latest-per-key step collapsed. Each becomes a fact.
    events: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    # The stage-1 score of the source table, when cleaning was derived from one. The
    # facts carry it as data_health; row retention is only a labelled stand-in.
    source_health: Optional[float] = None

    # -- the invariant ------------------------------------------------------
    def reconcile(self) -> bool:
        """Prove nothing was dropped. Raises ReconciliationError on any delta."""
        delta = self.total_in - (self.rows_clean + self.rows_quarantined)
        if delta != 0:
            raise ReconciliationError(
                "row conservation broken for %r: rows_in=%d but clean=%d + quarantined=%d "
                "(delta=%d). %d row(s) vanished without a reason."
                % (self.source or "<frame>", self.total_in, self.rows_clean,
                   self.rows_quarantined, delta, abs(delta))
            )
        if len(self.clean) != self.rows_clean:
            raise ReconciliationError(
                "clean frame holds %d rows but rows_clean says %d"
                % (len(self.clean), self.rows_clean)
            )
        if len(self.quarantined) != self.rows_quarantined:
            raise ReconciliationError(
                "quarantine frame holds %d rows but rows_quarantined says %d"
                % (len(self.quarantined), self.rows_quarantined)
            )
        counted = int(sum(self.quarantine_reasons.values()))
        if counted != self.rows_quarantined:
            raise ReconciliationError(
                "quarantine reasons account for %d row(s) but %d were quarantined; "
                "every quarantined row must be explained"
                % (counted, self.rows_quarantined)
            )
        if self.rows_quarantined:
            if QUARANTINE_COL not in self.quarantined.columns:
                raise ReconciliationError(
                    "quarantined rows carry no %r column" % (QUARANTINE_COL,)
                )
            blank = [
                str(idx)
                for idx, val in self.quarantined[QUARANTINE_COL].items()
                if _is_na(val) or not str(val).strip()
            ]
            if blank:
                raise ReconciliationError(
                    "%d quarantined row(s) carry no reason (index: %s)"
                    % (len(blank), ", ".join(blank[:5]))
                )
        return True

    # -- derived numbers ----------------------------------------------------
    @property
    def quarantine_rate(self) -> float:
        return (self.rows_quarantined / self.total_in) if self.total_in else 0.0

    @property
    def total_fixes(self) -> int:
        return int(sum(self.fixes_applied.values()))

    @property
    def collapsed_rows(self) -> int:
        """Rows set aside BY DESIGN (superseded by a later row for the same key)."""
        return int(sum(int(e.get("rows", 0)) for e in self.events.values()
                       if e.get("kind") == "latest_per_key" and e.get("action") == "quarantined"))

    @property
    def suspect_quarantine_rate(self) -> float:
        """The quarantine rate without the by-design collapse: the share the rules rejected."""
        if not self.total_in:
            return 0.0
        return (self.rows_quarantined - self.collapsed_rows) / float(self.total_in)

    def summary(self) -> str:
        via = " [rules: %s]" % self.rule_source if self.rule_source else ""
        if self.rule_source_error:
            via += " [%s]" % self.rule_source_error
        return (
            "%s: %d in -> %d clean + %d quarantined; %d value fix(es)%s"
            % (self.source or "frame", self.total_in, self.rows_clean,
               self.rows_quarantined, self.total_fixes, via)
        )

    # -- facts --------------------------------------------------------------
    def to_facts(self, prefix: str = "clean", data_health: Optional[float] = None) -> List[Fact]:
        """
        Describe the cleaning outcome as typed Facts.

        `data_health` is the stage-1 score of the source table. When the caller
        does not supply one, the share of rows that survived cleaning is used as
        a stand-in, and the fact says so in its caveats.
        """
        self.reconcile()
        prefix = _slug(prefix)
        retention = 100.0 * (self.rows_clean / self.total_in) if self.total_in else 100.0
        if data_health is None and self.source_health is not None:
            data_health = self.source_health
        health_given = data_health is not None
        health = float(data_health) if health_given else max(0.0, min(100.0, retention))
        health_caveat = [] if health_given else [RETENTION_CAVEAT]
        if self.rule_source_error:
            health_caveat = health_caveat + [
                "cleaning ran on reduced rules: %s" % self.rule_source_error
            ]
        table = self.source or ""
        base_q = (
            CLEAN_QUERY_MARKER + ", standard_rules\n"
            "res = clean_table(con, %r)  # rules=standard_rules(health)\n" % (table or "<table>",)
        )

        used_ids = set()

        def unique_id(suffix: str) -> str:
            """
            Fact ids must be unique -- FactSet.add refuses a duplicate, so a
            collision here would abort the whole run downstream. Two rule names
            that differ only in punctuation ('qty num' and 'qty-num', both
            ordinary Excel headers) slug to the same string, so the collision is
            broken here, deterministically.
            """
            base = "%s.%s" % (prefix, suffix)
            if base not in used_ids:
                used_ids.add(base)
                return base
            n = 2
            while "%s__%d" % (base, n) in used_ids:
                n += 1
            out = "%s__%d" % (base, n)
            used_ids.add(out)
            return out

        def mk(suffix, claim, value, unit, expr, caveats=None, effect=0.0):
            return Fact(
                id=unique_id(suffix),
                claim=claim,
                value=float(value),
                unit=unit,
                query=base_q + expr,
                source_table=table,
                query_kind="python",
                rows_scanned=int(self.total_in),
                effect_size=float(effect),
                periods_observed=1,
                data_health=health,
                caveats=list(caveats or []) + health_caveat,
            )

        label = table or "the input frame"
        by_design = {e.get("reason_key"): e for e in self.events.values()
                     if e.get("kind") == "latest_per_key"}
        rate_caveats = []
        if self.collapsed_rows:
            rate_caveats.append(
                "includes %s row(s) collapsed by design to the latest row per key; the share "
                "the cleaning rules rejected is %.2f%%"
                % (format(self.collapsed_rows, ","), 100.0 * self.suspect_quarantine_rate))
        facts: List[Fact] = [
            mk("rows_in", "%d rows entered cleaning from %s" % (self.total_in, label),
               self.total_in, "count", "res.total_in"),
            mk("rows_clean", "%d of %d rows from %s survived cleaning"
               % (self.rows_clean, self.total_in, label),
               self.rows_clean, "count", "res.rows_clean"),
            mk("rows_quarantined",
               "%d of %d rows from %s were quarantined, not dropped"
               % (self.rows_quarantined, self.total_in, label),
               self.rows_quarantined, "count", "res.rows_quarantined",
               caveats=["quarantined rows are retained in full and re-reviewable"]),
            mk("quarantine_rate",
               "%.2f%% of rows from %s were quarantined during cleaning"
               % (100.0 * self.quarantine_rate, label),
               round(100.0 * self.quarantine_rate, 4), "pct", "100.0 * res.quarantine_rate",
               caveats=rate_caveats, effect=self.quarantine_rate),
            mk("fixes_applied",
               "%d value(s) in %s were repaired in place without dropping a row"
               % (self.total_fixes, label),
               self.total_fixes, "count", "res.total_fixes",
               caveats=["a repaired value is a fix, not a quarantine"]),
        ]
        for reason, count in sorted(self.quarantine_reasons.items()):
            design = by_design.get(reason)
            f = mk(
                "quarantined.%s" % _slug(reason),
                "%s row(s) from %s were quarantined because %s" % (format(count, ","), label, reason),
                count, "count", "res.quarantine_reasons[%r]" % (reason,),
                caveats=(["superseded rows are the earlier history of a key, set aside by "
                          "design; they are not a defect in the file"] if design else None),
            )
            if design:
                f.role = "detail"
            facts.append(f)
        for rule_name, count in sorted(self.fixes_applied.items()):
            facts.append(mk(
                "fixed.%s" % _slug(rule_name),
                "%s value(s) in %s were repaired by rule %r" % (format(count, ","), label, rule_name),
                count, "count", "res.fixes_applied[%r]" % (rule_name,),
            ))
        for flag_name, count in sorted(self.flags.items()):
            facts.append(mk(
                "flagged.%s" % _slug(flag_name),
                "%s value(s) in %s were flagged by %r but left in place"
                % (format(count, ","), label, flag_name),
                count, "count", "res.flags[%r]" % (flag_name,),
            ))
        for key, ev in sorted(self.events.items()):
            if ev.get("kind") == "nulled_cells" and ev.get("rows"):
                ex = ", ".join(repr(x) for x in ev.get("examples") or [])
                f = mk(
                    "nulled.%s" % _slug(ev["column"]),
                    "%s value(s) in the %s column of %s could not be read as numbers%s and were "
                    "left empty; their rows were kept"
                    % (format(int(ev["rows"]), ","), ev["column"], label,
                       (" (for example %s)" % ex) if ex else ""),
                    ev["rows"], "count", "res.events[%r]['rows']" % (key,),
                    effect=(float(ev["rows"]) / self.total_in) if self.total_in else 0.0,
                )
                f.fact_kind = "state"
                facts.append(f)
                continue
            if ev.get("kind") == "series_end" and ev.get("rows"):
                verb = "set aside" if ev.get("action") == "quarantined" else "flagged"
                f = mk(
                    "series_end.%s" % _slug(ev["column"]),
                    "%s row(s) of %s are dated after the %s series ends: from %s, every month "
                    "holds under %d%% of the median month of the %d months before it (%s rows), "
                    "so these %s month(s) look like date typos or a partial extract rather than "
                    "activity; they were %s, not deleted, and belong back in if the business "
                    "really fell that far"
                    % (format(int(ev["rows"]), ","), label, ev["column"], ev["cliff_month"],
                       int(round(100 * ev["ratio"])), int(ev["min_prior"]),
                       _fmt_num(ev["prior_median"]), format(int(ev["months"]), ","), verb),
                    ev["rows"], "count", "res.events[%r]['rows']" % (key,),
                    effect=(float(ev["rows"]) / self.total_in) if self.total_in else 0.0,
                )
                f.fact_kind = "state"
                facts.append(f)
        if by_design:
            n_keys = sum(int(e.get("keys_with_history", 0)) for e in by_design.values())
            keys = "; ".join("%s by %s" % ("+".join(e["key"]), e["order"]) for e in by_design.values())
            f = mk(
                "collapsed_rows",
                "%s earlier row(s) from %s were collapsed to the latest row per key (%s); "
                "%s key(s) had more than one row"
                % (format(self.collapsed_rows, ","), label, keys, format(n_keys, ",")),
                self.collapsed_rows, "count",
                "sum(e['rows'] for e in res.events.values() if e['kind'] == 'latest_per_key')",
                caveats=["the superseded rows stay in quarantine with their reason, re-reviewable"],
            )
            f.fact_kind, f.role = "state", "detail"
            facts.append(f)
        for _f in facts:
            _f.measures = "data_quality"
        return facts


# ---------------------------------------------------------------------------
# the cleaning pass
# ---------------------------------------------------------------------------
class _Pass:
    """Mutable state for one run of clean_frame. Rows are tracked positionally."""

    def __init__(self, df: pd.DataFrame) -> None:
        self.n = int(len(df))
        self.original = df.reset_index(drop=True)
        self.work = self.original.copy()
        self.active = np.ones(self.n, dtype=bool)
        self.reasons = np.array([""] * self.n, dtype=object)
        self.fixes: Dict[str, int] = {}
        self.flags: Dict[str, int] = {}
        self.qcounts: Dict[str, int] = {}
        self.events: Dict[str, Dict[str, Any]] = {}

    @property
    def act(self) -> pd.Series:
        return pd.Series(self.active, index=self.work.index)

    def note_fix(self, rule: Rule, count: int) -> None:
        if count:
            self.fixes[rule.name] = self.fixes.get(rule.name, 0) + int(count)

    def note_fix_key(self, key: str, count: int) -> None:
        """A fix counted under a named sub-rule ('<rule>.epoch'), so each repair says what it was."""
        if count:
            self.fixes[key] = self.fixes.get(key, 0) + int(count)

    def note_flag(self, key: str, count: int) -> None:
        if count:
            self.flags[key] = self.flags.get(key, 0) + int(count)

    def quarantine(self, rule: Rule, mask: pd.Series, messages: Dict[int, str]) -> None:
        """Remove rows from the active set, each carrying its own reason."""
        arr = mask.to_numpy(dtype=bool) & self.active
        hits = np.flatnonzero(arr)
        if not len(hits):
            return
        key = rule.reason_key()
        for pos in hits:
            self.reasons[pos] = messages.get(int(pos)) or key
        self.active[arr] = False
        self.qcounts[key] = self.qcounts.get(key, 0) + int(len(hits))


def _resolve_columns(rule: Rule, df: pd.DataFrame) -> List[str]:
    if rule.column == "*":
        return [c for c in df.columns if _looks_textual(df[c])]
    if rule.column not in df.columns:
        raise KeyError(
            "rule %r targets column %r which is not in the frame (columns: %s)"
            % (rule.name, rule.column, list(df.columns))
        )
    return [rule.column]


def _looks_textual(series: pd.Series) -> bool:
    return series.dtype == object or pd.api.types.is_string_dtype(series)


def _apply_fix(state: _Pass, rule: Rule, col: str, new: pd.Series) -> None:
    old = state.work[col]
    changed = _changed_mask(old, new) & state.act
    if bool(changed.any()):
        if isinstance(old.dtype, pd.CategoricalDtype):
            # a repair ('acme' -> 'ACME') is a category the column has never
            # seen; widen to object rather than refuse to clean the table
            state.work[col] = old.astype(object)
        state.work.loc[changed, col] = new[changed].astype(object)
        state.note_fix(rule, int(changed.sum()))


# -- individual rule kinds ---------------------------------------------------
def _rule_null_like(state: _Pass, rule: Rule) -> None:
    tokens = set(str(t).strip().lower() for t in rule.params.get("tokens", DEFAULT_NULL_TOKENS))

    def norm(value: Any) -> Any:
        if isinstance(value, str) and value.strip().lower() in tokens:
            return np.nan
        return value

    for col in _resolve_columns(rule, state.work):
        _apply_fix(state, rule, col, state.work[col].map(norm))


def _rule_trim(state: _Pass, rule: Rule) -> None:
    collapse = bool(rule.params.get("collapse", True))

    def norm(value: Any) -> Any:
        if not isinstance(value, str):
            return value
        out = value.strip()
        if collapse:
            out = _WS_RE.sub(" ", out)
        return out

    for col in _resolve_columns(rule, state.work):
        _apply_fix(state, rule, col, state.work[col].map(norm))


#: A grouping column's letter-case and spacing variants are mapped to their most common spelling
#: ("dominant" case mode) only when the column has at most this many distinct spellings once case
#: and spacing are ignored (a category, a store, a building; not free text or names).
DOMINANT_MAX_LEVELS = 50


def _case_key(value: Any) -> Any:
    return " ".join(value.split()).lower() if isinstance(value, str) else None


def _rule_case(state: _Pass, rule: Rule) -> None:
    mode = str(rule.params.get("mode", "upper")).lower()
    if mode not in ("upper", "lower", "title", "dominant"):
        raise ValueError("case rule %r: mode must be upper|lower|title|dominant, got %r" % (rule.name, mode))
    if mode == "dominant":
        # 'parkdale walk-up' and 'PARKDALE WALK-UP' become 'Parkdale Walk-Up', the spelling most
        # rows use (fixer round, 24 Sep 2026: the audit CONFIRMED 173 case variants in property,
        # the cleaner left them, and the cleaned CSV and the charts kept 15 spellings of 5
        # buildings while the analysis merged them). A yes/no column is left to the boolean rule.
        for col in _resolve_columns(rule, state.work):
            ser = state.work[col]
            raw = ser.to_numpy(dtype=object)
            spell: Dict[Any, Dict[str, int]] = {}
            n_str = n_bool = 0
            for i, v in enumerate(raw):
                if not isinstance(v, str) or not v.strip() or not state.active[i]:
                    continue
                n_str += 1
                if boolean_value(v) is not None:
                    n_bool += 1
                k = _case_key(v)
                spell.setdefault(k, {})
                spell[k][v] = spell[k].get(v, 0) + 1
            if not spell or len(spell) > DOMINANT_MAX_LEVELS or n_bool >= BOOLEAN_DOMINANCE * n_str:
                continue
            canon = {k: max(sorted(d), key=lambda sp: d[sp]) for k, d in spell.items() if len(d) > 1}
            if not canon:
                continue
            new = pd.Series([canon.get(_case_key(v), v) if isinstance(v, str) else v for v in raw],
                            index=ser.index, dtype=object)
            _apply_fix(state, rule, col, new)
        return

    def norm(value: Any) -> Any:
        if not isinstance(value, str):
            return value
        if mode == "upper":
            return value.upper()
        if mode == "lower":
            return value.lower()
        return value.title()

    for col in _resolve_columns(rule, state.work):
        _apply_fix(state, rule, col, state.work[col].map(norm))


_NUMERIC_PROBLEMS = {
    "not_a_number": "%s is not a number",
    "ambiguous_comma": (
        "%s is ambiguous: the comma is neither a thousands separator nor an "
        "unambiguous decimal mark, so no value can be read without guessing"
    ),
    "ambiguous_comma_group": (
        "%s is ambiguous: this column writes decimals with a comma, but this comma "
        "could also be a thousands separator, so no value can be read without guessing"
    ),
    "ambiguous_dot": (
        "%s is ambiguous: this column writes decimals with a comma, so this dot may be "
        "a thousands separator; no value can be read without guessing"
    ),
}

# Shapes, after currency, spaces and sign are stripped.
# A comma that can ONLY be a decimal mark: not followed by exactly three digits
# ('12,50', '1,5', '1234,567'), or after dot-grouped thousands ('1.234,56').
_COMMA_DECIMAL_RE = re.compile(r"^-?(?:\d+,\d{1,2}|\d+,\d{4,}|\d{4,},\d+|\d{1,3}(?:\.\d{3})+,\d+)$")
# A dot that can ONLY be a decimal mark ('12.50', '1,234.50'). '1.234' is left out of
# both counts: it is a European thousands group as readily as a decimal.
_DOT_DECIMAL_RE = re.compile(r"^-?(?:\d+\.\d{1,2}|\d+\.\d{4,}|\d{4,}\.\d+|\d{1,3}(?:,\d{3})+\.\d+)$")
_COMMA_MARK_RE = re.compile(r"^-?\d+,\d+$")
_COMMA_GROUP_RE = re.compile(r"^-?\d{1,3}(?:,\d{3})+$")
_EURO_GROUPED_RE = re.compile(r"^-?\d{1,3}(?:\.\d{3})+,\d+$")
_DOT_GROUP_RE = re.compile(r"^-?\d{1,3}(?:\.\d{3})+$")
# A column switches to the comma convention only on this much evidence.
COMMA_DECIMAL_MIN_VALUES = 3


def _numeric_body(text: str, allow_parens: bool) -> Tuple[str, bool]:
    """Strip currency, spaces, sign and parentheses: (digits-and-marks, negative)."""
    negative = False
    text = text.strip()
    if allow_parens and text.startswith("(") and text.endswith(")"):
        negative = True
        text = text[1:-1].strip()
    for ch in _CURRENCY_CHARS:
        text = text.replace(ch, "")
    text = text.replace("\xa0", "").replace("\u202f", "").replace(" ", "")
    text = text.replace("CAD", "").replace("USD", "")
    if text.endswith("-"):           # trailing-minus exports
        negative = True
        text = text[:-1]
    if text.startswith("+"):
        text = text[1:]
    return text, negative


def _decimal_convention(values: Sequence[Any], allow_parens: bool = True) -> str:
    """
    ',' when the column writes decimals with a comma, else '.'.

    Decided once per column from its own values, like day/month order: a comma
    column is one where values that can ONLY be comma decimals ('12,50', '1,5')
    are at least NUMERIC_DOMINANCE of the values carrying any decimal mark, outnumber
    the comma thousands groups ('1,850', which a dot column writes), and
    there are at least COMMA_DECIMAL_MIN_VALUES of them. A few '12,50' in a
    column of '12.50' prove nothing, and stay rejected as ambiguous.
    """
    n_comma = n_dot = n_group = 0
    for v in values:
        if not isinstance(v, str) or "," not in v and "." not in v:
            continue
        body, _neg = _numeric_body(v, allow_parens)
        if _COMMA_DECIMAL_RE.match(body):
            n_comma += 1
        elif _DOT_DECIMAL_RE.match(body):
            n_dot += 1
        elif _COMMA_GROUP_RE.match(body):
            # '1,850', '12,345,678': most often dot-convention thousands groups (a comma
            # column would write '1.850'), though '2,999' could be a 3-decimal comma value.
            # Before QA (23 Sep 2026) they counted on neither side, so three stray '1,5'
            # values flipped a rent column of 2,000 '1,850'-style values to commas and
            # quarantined 99.9% of it. Now the comma-only values must outnumber them.
            n_group += 1
    if n_comma >= COMMA_DECIMAL_MIN_VALUES and \
            n_comma >= NUMERIC_DOMINANCE * (n_comma + n_dot) and n_comma > n_group:
        return ","
    return "."


def _coerce_numeric_value(value: Any, allow_parens: bool) -> Tuple[Any, str]:
    """(number_or_nan, problem_code) under the dot-decimal convention."""
    number, problem, _how = _coerce_numeric_detail(value, allow_parens, ".")
    return number, problem


# Magnitude suffixes ('$31.0k', '1.2M', '$4bn'). A lowercase 'm' is read as millions only
# beside a currency sign: '5m' alone may be minutes or metres. Review v2 (24 Sep 2026): an
# MRR column written '$31.0k' on every third row lost those months.
_MAGNITUDE_RE = re.compile(r"^(.*[0-9.])\s*(k|K|M|m|B|bn|BN|Bn)$")
_MAGNITUDE = {"k": 1e3, "K": 1e3, "M": 1e6, "m": 1e6, "B": 1e9, "bn": 1e9, "BN": 1e9, "Bn": 1e9}
# A unit written after the number in a column whose NAME states that unit ('3.5h' in
# resolution_hours): the number is what the cell says, in the column's own unit.
_UNIT_WORDS = {
    "hours": ("h", "hr", "hrs", "hour", "hours"), "hour": ("h", "hr", "hrs", "hour", "hours"),
    "hrs": ("h", "hr", "hrs", "hour", "hours"),
    "days": ("d", "day", "days"), "day": ("d", "day", "days"),
    "minutes": ("min", "mins", "minute", "minutes"), "mins": ("min", "mins", "minute", "minutes"),
    "kg": ("kg",), "km": ("km",),
}


def column_units(name: str) -> Tuple[str, ...]:
    """The unit suffixes a column's name licenses ('resolution_hours' -> h, hr, hrs...)."""
    toks = re.split(r"[^a-z0-9]+", str(name).lower())
    out: List[str] = []
    for t in toks:
        for u in _UNIT_WORDS.get(t, ()):
            if u not in out:
                out.append(u)
    return tuple(out)


def _coerce_numeric_detail(value: Any, allow_parens: bool, decimal: str = ".",
                           units: Sequence[str] = ()) -> Tuple[Any, str, str]:
    """
    Return (number_or_nan, problem_code, how).

    problem_code is "" when the value parsed, and also when it was missing to
    begin with -- a missing value is not a parse failure. Otherwise it is a key
    of _NUMERIC_PROBLEMS, so a quarantined row can say WHICH failure this was
    instead of flattening every rejection into "not a number".
    `how` names a repair that is counted under its own name: "comma_decimal" (read under
    the column's comma convention), "percent" ('15%' is 0.15), "magnitude" ('$31.0k' is
    31,000) or "unit_suffix" ('3.5h' in an hours column is 3.5).
    """
    if _is_na(value):
        return np.nan, "", ""
    if _is_number(value):
        return float(value), "", ""
    if isinstance(value, bool):
        return np.nan, "not_a_number", ""
    if not isinstance(value, str):
        return np.nan, "not_a_number", ""
    if not value.strip():
        return np.nan, "", ""
    text, negative = _numeric_body(value, allow_parens)
    how = ""
    scale = 1.0
    if text.endswith("%") and len(text) > 1:
        text, scale, how = text[:-1], 0.01, "percent"
    else:
        low = text.lower()
        unit = next((u for u in sorted(units, key=len, reverse=True)
                     if low.endswith(u) and len(low) > len(u) and (low[-len(u) - 1].isdigit()
                                                                   or low[-len(u) - 1] == ".")), "")
        if unit:
            text, how = text[:-len(unit)], "unit_suffix"
        else:
            mg = _MAGNITUDE_RE.match(text)
            if mg and (mg.group(2) != "m" or any(ch in value for ch in _CURRENCY_CHARS)):
                text, scale, how = mg.group(1), _MAGNITUDE[mg.group(2)], "magnitude"
    if decimal == ",":
        if "," in text:
            if _COMMA_MARK_RE.match(text) and not _COMMA_GROUP_RE.match(text):
                text, how = text.replace(",", "."), "comma_decimal"
            elif _EURO_GROUPED_RE.match(text):
                text, how = text.replace(".", "").replace(",", "."), "comma_decimal"
            elif _COMMA_GROUP_RE.match(text):
                return np.nan, "ambiguous_comma_group", ""
            else:
                return np.nan, "ambiguous_comma", ""
        elif _DOT_GROUP_RE.match(text):
            return np.nan, "ambiguous_dot", ""
    elif "," in text:
        # Never silently turn '1,5' into 15.0 -- nor into 1.5. Either reading
        # may be the right one, and a trust engine does not pick one behind the
        # client's back. Only an unambiguous thousands grouping is repaired
        # (unless the whole column proves a comma convention: _decimal_convention).
        if _THOUSANDS_RE.match(text):
            text = text.replace(",", "")
        else:
            return np.nan, "ambiguous_comma", ""
    if not text:
        return np.nan, "not_a_number", ""
    try:
        number = float(text)
    except (TypeError, ValueError):
        return np.nan, "not_a_number", ""
    if not math.isfinite(number):
        return np.nan, "not_a_number", ""
    number = number * scale
    if scale != 1.0:
        number = float(round(number, 12))
    return (-number if negative else number), "", how


def _rule_numeric(state: _Pass, rule: Rule) -> None:
    allow_parens = bool(rule.params.get("allow_parens_negative", True))
    decimal_param = str(rule.params.get("decimal", "auto"))
    if decimal_param not in ("auto", ".", ","):
        raise ValueError("numeric rule %r: decimal must be auto|.|, got %r" % (rule.name, decimal_param))
    for col in _resolve_columns(rule, state.work):
        old = state.work[col]
        raw = old.to_numpy(dtype=object)
        decimal = decimal_param
        if decimal == "auto":
            decimal = _decimal_convention(raw[state.active], allow_parens)
        units = tuple(rule.params.get("units", column_units(col)))
        triples = [_coerce_numeric_detail(v, allow_parens, decimal, units) for v in raw]
        parsed = pd.Series([p[0] for p in triples], index=old.index, dtype="float64")
        problems = [p[1] for p in triples]
        hows = pd.Series([p[2] for p in triples], index=old.index)
        was_number = pd.Series([_is_number(v) for v in raw], index=old.index)
        repaired = old.notna() & parsed.notna() & (~was_number) & state.act
        failed = old.notna() & parsed.isna() & state.act
        state.work[col] = parsed
        state.note_fix(rule, int((repaired & (hows == "")).sum()))
        for how in ("comma_decimal", "percent", "magnitude", "unit_suffix"):
            state.note_fix_key("%s.%s" % (rule.name, how), int((repaired & (hows == how)).sum()))
        if bool(failed.any()):
            if rule.severity == "flag":
                state.note_flag("%s.unparseable" % rule.name, int(failed.sum()))
            elif rule.severity == "fix":
                # Review v2 (24 Sep 2026): one unreadable measure cell ('3.5h', 'abc') used to
                # set aside its whole row, and with it the row's date and every other measure.
                # A measure that is not the row's key only loses the one cell: it is emptied,
                # counted, and the values are kept as examples for the reader.
                bad = old[failed]
                seen: List[str] = []
                for v in bad.to_numpy(dtype=object):
                    t = _short(v)
                    if t not in seen:
                        seen.append(t)
                    if len(seen) >= 3:
                        break
                state.events["%s.nulled" % rule.name] = {
                    "kind": "nulled_cells", "column": col, "rows": int(failed.sum()),
                    "examples": seen, "rule": rule.name}
            else:
                msgs = {}
                for pos in np.flatnonzero(failed.to_numpy(dtype=bool)):
                    pos = int(pos)
                    template = _NUMERIC_PROBLEMS.get(
                        problems[pos] or "not_a_number", _NUMERIC_PROBLEMS["not_a_number"]
                    )
                    msgs[pos] = "column %r: %s" % (
                        col, template % (repr(_short(old.iloc[pos])),)
                    )
                state.quarantine(rule, failed, msgs)


def _to_naive_timestamp(value: Any) -> pd.Timestamp:
    """
    A real datetime as a tz-naive, nanosecond-representable pd.Timestamp.

    Raises when the value cannot be represented. Timezone-aware values are
    converted to UTC and then made naive, rather than being written straight
    into a datetime64[ns] column -- pandas only deprecation-warns about that
    today and will raise tomorrow, and the old code turned that warning into a
    silent "this is not a date".
    """
    ts = pd.Timestamp(value)
    if ts.tz is not None:
        ts = ts.tz_convert("UTC").tz_localize(None)
    if ts is pd.NaT:
        raise ValueError("not a timestamp")
    # force nanosecond resolution now, so an out-of-range year fails HERE
    # (one value, named in its own reason) instead of when the whole column
    # is built.
    if not (pd.Timestamp.min <= ts <= pd.Timestamp.max):
        raise ValueError("outside the representable range")
    return pd.Timestamp(ts.to_datetime64())


def _coerce_dates_detail(
    series: pd.Series, formats: Sequence[str]
) -> Tuple[pd.Series, List[int], List[int]]:
    """
    Parse `series` to datetime64[ns], and report which values were genuinely
    datetimes that could not be represented.

    The second element holds POSITIONS (0-based, into the series) of values
    that are real datetimes but out of pandas' representable range. They are
    still rejected -- they cannot be stored -- but they must not be told they
    "match no known date format", because they do: they are dates.

    The third element holds POSITIONS of values that could be day-first or
    month-first in a column that holds both conventions; they are not read.
    """
    unrepresentable: List[int] = []
    if pd.api.types.is_datetime64_any_dtype(series):
        out = pd.to_datetime(series, errors="coerce")
        if getattr(out.dtype, "tz", None) is not None:
            out = out.dt.tz_convert("UTC").dt.tz_localize(None)
        return out, unrepresentable, []

    values = series.to_numpy(dtype=object)
    # built as a plain list first: assigning a tz-aware or out-of-range value
    # into an already-typed datetime64[ns] Series is what used to warn (and,
    # under -W error, silently mis-reject a perfectly good date).
    slots: List[Any] = [pd.NaT] * len(values)
    for i, value in enumerate(values):
        if not _is_datetime_like(value):
            continue
        try:
            slots[i] = _to_naive_timestamp(value)
        except Exception:  # noqa: BLE001 - recorded, not swallowed
            unrepresentable.append(i)
    parsed = pd.Series(slots, index=series.index, dtype="datetime64[ns]")

    # pass 1b: ISO timestamps carrying a zone, to the same instant in UTC
    for i, value in enumerate(values):
        if isinstance(value, str) and _ZONED_ISO_RE.match(value) and pd.isna(parsed.iat[i]):
            try:
                text = value.strip()
                if text.endswith("UTC"):
                    text = text[:-3].strip() + "Z"
                parsed.iat[i] = _to_naive_timestamp(text)
            except Exception:  # noqa: BLE001 - left for the formats below, then reported
                pass

    formats, held_back = _formats_for_day_month_order(series[parsed.isna() & series.notna()], formats)
    ambiguous = [int(i) for i in np.flatnonzero(series.index.isin(held_back))]

    # pass 2: each explicit format in turn, on whatever is still unparsed
    for fmt in formats:
        todo = parsed.isna() & series.notna() & ~series.index.isin(held_back)
        if not bool(todo.any()):
            break
        text = series[todo].astype(str).str.strip()
        attempt = pd.to_datetime(text, format=fmt, errors="coerce")
        got = attempt.notna()
        if bool(got.any()):
            parsed.loc[attempt.index[got]] = attempt[got]
    if unrepresentable:
        still_bad = parsed.isna().to_numpy()
        unrepresentable = [i for i in unrepresentable if still_bad[i]]
    return parsed, unrepresentable, ambiguous


def _formats_for_day_month_order(
    text_values: pd.Series, formats: Sequence[str]
) -> Tuple[List[str], pd.Index]:
    """
    Decide the column's day/month order from its own values and return the formats
    to try, plus the index labels of values that must NOT be read (a mixed column's
    values that could be either). One order per column, never one per value.
    """
    fmts = list(formats)
    text = text_values.astype(str)
    parts = text.str.extract(_DAY_MONTH_RE)
    a = pd.to_numeric(parts[0], errors="coerce")
    b = pd.to_numeric(parts[2], errors="coerce")
    order = day_month_order(int(((a > 12) & (b <= 12)).sum()), int(((b > 12) & (a <= 12)).sum()))
    if order == "mixed":
        either = ((a <= 12) & (b <= 12) & (a != b)).fillna(False)
        return fmts, text_values.index[either.to_numpy(dtype=bool)]
    if order == "unknown":
        # No proof either way, so every such value parses under the first format
        # listed for its separator -- the same per-shape default the profiler
        # discloses ("read as MM/DD/YYYY"). Nothing can be swapped; leave the list.
        return fmts, pd.Index([])
    drop = _MONTH_FIRST_FORMATS if order == "dmy" else _DAY_FIRST_FORMATS
    out: List[str] = []
    for f in fmts:
        g = _ORDER_TWIN[f] if f in drop else f      # a wrong-order format becomes its twin, in place
        if g not in out:
            out.append(g)
    return out, pd.Index([])


def _coerce_dates(series: pd.Series, formats: Sequence[str]) -> pd.Series:
    return _coerce_dates_detail(series, formats)[0]


_EPOCH_RE = re.compile(r"^\d{10}(?:\d{3})?$")


def _epoch_timestamp(value: Any, years: Tuple[int, int]) -> Optional[pd.Timestamp]:
    """
    A Unix epoch written as a plain number: 10 digits = seconds, 13 = milliseconds.
    Anything else (11 digits, a sign, a decimal) is not unambiguous and returns None,
    as does a value landing outside `years`.
    """
    if isinstance(value, (bool, np.bool_)):
        return None
    if isinstance(value, (int, np.integer)):
        text = str(int(value))
    elif isinstance(value, (float, np.floating)):
        if not np.isfinite(value) or not float(value).is_integer():
            return None
        text = str(int(value))
    elif isinstance(value, str):
        text = value.strip()
    else:
        return None
    if not _EPOCH_RE.match(text):
        return None
    ts = pd.Timestamp(int(text), unit="s" if len(text) == 10 else "ms")
    if not (years[0] <= ts.year < years[1]):
        return None
    return ts


def _rule_date(state: _Pass, rule: Rule) -> None:
    formats = tuple(rule.params.get("formats", DEFAULT_DATE_FORMATS))
    epoch_on = bool(rule.params.get("epoch", True))
    years = tuple(rule.params.get("epoch_years", EPOCH_YEARS))
    min_share = float(rule.params.get("epoch_min_date_share", EPOCH_MIN_DATE_SHARE))
    for col in _resolve_columns(rule, state.work):
        old = state.work[col]
        parsed, unrepresentable, ambiguous = _coerce_dates_detail(old, formats)
        was_dt = pd.Series(
            [_is_datetime_like(v) for v in old.to_numpy(dtype=object)], index=old.index
        )
        # Epoch numbers: converted only in a column whose other values are mostly real
        # dates. 23 Sep 2026: 5,867 epoch-ms review dates (12.1% of the file) were
        # quarantined as "matches no known date format" and every monthly count sat a
        # median 14.5% low.
        epoch = pd.Series(False, index=old.index)
        n_non_null = int(old.notna().sum())
        if epoch_on and n_non_null and not pd.api.types.is_datetime64_any_dtype(old):
            share = float((old.notna() & parsed.notna()).sum()) / n_non_null
            if share >= min_share:
                todo = np.flatnonzero((old.notna() & parsed.isna()).to_numpy(dtype=bool))
                raw = old.to_numpy(dtype=object)
                hits = {}
                for pos in todo:
                    ts = _epoch_timestamp(raw[pos], years)
                    if ts is not None:
                        hits[int(pos)] = ts
                if hits:
                    idx = old.index[list(hits)]
                    parsed.loc[idx] = pd.Series(list(hits.values()), index=idx, dtype="datetime64[ns]")
                    epoch.loc[idx] = True
        repaired = old.notna() & parsed.notna() & (~was_dt) & state.act
        failed = old.notna() & parsed.isna() & state.act
        zoned = pd.Series([isinstance(v, str) and bool(_ZONED_ISO_RE.match(v))
                           for v in old.to_numpy(dtype=object)], index=old.index)
        state.work[col] = parsed
        state.note_fix(rule, int((repaired & ~epoch & ~zoned).sum()))
        state.note_fix_key("%s.epoch" % rule.name, int((repaired & epoch).sum()))
        # a time zone ('Z', '+05:30') was read and the instant stated in UTC: its own count,
        # because a month boundary can move (23:30 at -05:00 on the 31st is the 1st in UTC)
        state.note_fix_key("%s.utc" % rule.name, int((repaired & zoned).sum()))
        if bool(failed.any()):
            if rule.severity in ("flag", "fix"):
                state.note_flag("%s.unparseable" % rule.name, int(failed.sum()))
            else:
                shown = ", ".join(formats[:4]) + ("..." if len(formats) > 4 else "")
                out_of_range = set(unrepresentable)
                either_way = set(ambiguous)
                msgs = {}
                for pos in np.flatnonzero(failed.to_numpy(dtype=bool)):
                    pos = int(pos)
                    if pos in either_way:
                        msgs[pos] = (
                            "column %r: %s could be day/month or month/day, and this column "
                            "holds both day-first and month-first dates, so it is not read by "
                            "guessing" % (col, repr(_short(old.iloc[pos])))
                        )
                    elif pos in out_of_range:
                        msgs[pos] = (
                            "column %r: %s is a date, but outside the range that can "
                            "be stored (%s to %s)"
                            % (col, repr(_short(old.iloc[pos])),
                               pd.Timestamp.min.date().isoformat(),
                               pd.Timestamp.max.date().isoformat())
                        )
                    else:
                        msgs[pos] = (
                            "column %r: %s matches no known date format (tried %s)"
                            % (col, repr(_short(old.iloc[pos])), shown)
                        )
                state.quarantine(rule, failed, msgs)


def _row_key(values: Iterable[Any]) -> Tuple[Any, ...]:
    out: List[Any] = []
    for v in values:
        if _is_na(v):
            out.append("\x00<NA>")
        else:
            try:
                hash(v)
                out.append(v)
            except TypeError:
                out.append(repr(v))
    return tuple(out)


def _rule_dedupe(state: _Pass, rule: Rule) -> None:
    subset = rule.params.get("subset")
    cols = list(subset) if subset else list(state.work.columns)
    missing = [c for c in cols if c not in state.work.columns]
    if missing:
        raise KeyError("dedupe rule %r: unknown column(s) %s" % (rule.name, missing))
    act = state.act
    sub = state.work.loc[act, cols]
    if sub.empty:
        return
    keys = [_row_key(row) for row in sub.to_numpy(dtype=object)]
    first_pos: Dict[Tuple[Any, ...], int] = {}
    dupes: List[int] = []
    positions = list(sub.index)
    for key, pos in zip(keys, positions):
        if key in first_pos:
            dupes.append(int(pos))
        else:
            first_pos[key] = int(pos)
    if not dupes:
        return
    mask = pd.Series(False, index=state.work.index)
    mask.loc[dupes] = True
    msgs = {}
    for key, pos in zip(keys, positions):
        if int(pos) in set(dupes):
            keeper = first_pos[key]
            msgs[int(pos)] = (
                "exact duplicate of the row kept at input position %d%s"
                % (keeper, "" if subset is None else " (matched on %s)" % ", ".join(cols))
            )
    if rule.severity == "flag":
        state.note_flag("%s.duplicates" % rule.name, len(dupes))
        return
    state.quarantine(rule, mask, msgs)


def _rule_range(state: _Pass, rule: Rule) -> None:
    low = rule.params.get("min")
    high = rule.params.get("max")
    if low is None and high is None:
        raise ValueError("range rule %r needs a 'min' and/or a 'max'" % (rule.name,))
    for col in _resolve_columns(rule, state.work):
        values = pd.to_numeric(state.work[col], errors="coerce")
        bad = pd.Series(False, index=values.index)
        if low is not None:
            bad = bad | (values < float(low))
        if high is not None:
            bad = bad | (values > float(high))
        bad = bad.fillna(False) & state.act        # a missing value is not out of range
        if not bool(bad.any()):
            continue
        if rule.severity == "flag":
            state.note_flag(rule.name, int(bad.sum()))
            continue
        bounds = "[%s, %s]" % ("-inf" if low is None else low, "+inf" if high is None else high)
        msgs = {
            int(pos): "column %r: value %s is outside the possible range %s"
                      % (col, _short(state.original[col].iloc[pos]), bounds)
            for pos in np.flatnonzero(bad.to_numpy(dtype=bool))
        }
        state.quarantine(rule, bad, msgs)


def _rule_not_future(state: _Pass, rule: Rule) -> None:
    as_of = rule.params.get("as_of")
    # normalised the same way the values are, so a tz-aware as_of cannot turn
    # the comparison into a TypeError halfway through a client's table
    cutoff = (
        _to_naive_timestamp(as_of) if as_of is not None
        else pd.Timestamp.today().normalize()
    )
    formats = tuple(rule.params.get("formats", DEFAULT_DATE_FORMATS))
    for col in _resolve_columns(rule, state.work):
        values = _coerce_dates(state.work[col], formats)
        # Compared by DAY: a row stamped 15:15 on the as-of day happened on that day, not
        # after it. (The cutoff is midnight, so `values > cutoff` quarantined every row an
        # export pulled today holds for today: QA, 23 Sep 2026.)
        bad = (values.dt.normalize() > cutoff.normalize()).fillna(False) & state.act
        if not bool(bad.any()):
            continue
        if rule.severity in ("flag", "fix"):
            state.note_flag(rule.name, int(bad.sum()))
            continue
        msgs = {
            int(pos): "column %r: %s is in the future (as of %s)"
                      % (col, values.iloc[pos].date().isoformat(), cutoff.date().isoformat())
            for pos in np.flatnonzero(bad.to_numpy(dtype=bool))
        }
        state.quarantine(rule, bad, msgs)


def _rule_not_null(state: _Pass, rule: Rule) -> None:
    for col in _resolve_columns(rule, state.work):
        bad = state.work[col].isna() & state.act
        if not bool(bad.any()):
            continue
        if rule.severity == "flag":
            state.note_flag(rule.name, int(bad.sum()))
            continue
        msgs = {
            int(pos): "column %r: a required value is missing" % (col,)
            for pos in np.flatnonzero(bad.to_numpy(dtype=bool))
        }
        state.quarantine(rule, bad, msgs)


def _rule_allowed(state: _Pass, rule: Rule) -> None:
    raw = rule.params.get("values")
    if not raw:
        raise ValueError("allowed rule %r needs a non-empty 'values' list" % (rule.name,))
    fold = bool(rule.params.get("case_insensitive", True))
    allowed = set(str(v).lower() if fold else str(v) for v in raw)
    for col in _resolve_columns(rule, state.work):
        series = state.work[col]
        def ok(value: Any) -> bool:
            if _is_na(value):
                return True                      # missing is not "not allowed"
            text = str(value)
            return (text.lower() if fold else text) in allowed
        bad = pd.Series(
            [not ok(v) for v in series.to_numpy(dtype=object)], index=series.index
        ) & state.act
        if not bool(bad.any()):
            continue
        if rule.severity == "flag":
            state.note_flag(rule.name, int(bad.sum()))
            continue
        shown = ", ".join(sorted(str(v) for v in raw)[:6])
        msgs = {
            int(pos): "column %r: %s is not one of {%s}"
                      % (col, repr(_short(series.iloc[pos])), shown)
            for pos in np.flatnonzero(bad.to_numpy(dtype=bool))
        }
        state.quarantine(rule, bad, msgs)


_PAIR_DEFAULT_SPELLING = {"true": "True", "false": "False", "yes": "Yes", "no": "No",
                          "y": "Y", "n": "N", "t": "T", "f": "F", "1": "1", "0": "0"}


def _rule_boolean(state: _Pass, rule: Rule) -> None:
    """
    Yes/no spellings -> the pair the column mostly uses, in its most common casing.

    Acts only on a column where at least `dominance` (default BOOLEAN_DOMINANCE) of
    the non-null values are yes/no spellings; anywhere else it changes nothing, so
    a free-text column holding the odd "yes" is never rewritten. Inside such a
    column a value that is not a yes/no spelling is quarantined (or flagged).
    23 Sep 2026: 'Y'/'N' in a True/False column were not recognised at all.
    """
    dominance = float(rule.params.get("dominance", BOOLEAN_DOMINANCE))
    for col in _resolve_columns(rule, state.work):
        old = state.work[col]
        raw = old.to_numpy(dtype=object)
        present = np.array([not _is_na(v) and not (isinstance(v, str) and not v.strip())
                            for v in raw], dtype=bool)
        mapped = [boolean_value(v) if present[i] else None for i, v in enumerate(raw)]
        n_present = int((present & state.active).sum())
        n_mapped = sum(1 for i, m in enumerate(mapped) if m is not None and present[i] and state.active[i])
        if not n_present or n_mapped < dominance * n_present:
            continue
        # which pair does the column use, and in which casing?
        spelled: Dict[str, Dict[str, int]] = {}
        for i, v in enumerate(raw):
            if isinstance(v, str) and mapped[i] is not None:
                key = v.strip().lower()
                spelled.setdefault(key, {})
                spelled[key][v.strip()] = spelled[key].get(v.strip(), 0) + 1
        def pair_count(pair):
            return sum(sum(spelled.get(k, {}).values()) for k in pair)
        pair = max(BOOLEAN_PAIRS, key=pair_count)      # ties: the listed order
        canon = {}
        for k, truth in ((pair[0], True), (pair[1], False)):
            seen = spelled.get(k, {})
            canon[truth] = max(sorted(seen), key=lambda sp: seen[sp]) if seen else _PAIR_DEFAULT_SPELLING[k]
        new = pd.Series(
            [canon[mapped[i]] if (isinstance(v, str) and mapped[i] is not None) else v
             for i, v in enumerate(raw)],
            index=old.index, dtype=object)
        _apply_fix(state, rule, col, new)
        failed = pd.Series(present & np.array([m is None for m in mapped], dtype=bool),
                           index=old.index) & state.act
        if not bool(failed.any()):
            continue
        if rule.severity in ("flag", "fix"):
            state.note_flag("%s.not_yes_no" % rule.name, int(failed.sum()))
            continue
        msgs = {
            int(pos): "column %r: %s is not a yes/no value in a column that is otherwise "
                      "%s/%s" % (col, repr(_short(raw[pos])), canon[True], canon[False])
            for pos in np.flatnonzero(failed.to_numpy(dtype=bool))
        }
        state.quarantine(rule, failed, msgs)


# Placeholder dates that systems write for "no date" (review v2, 24 Sep 2026: 8 tickets at
# 1900-01-01 started the analysis window in 1900 and the forecast was fitted over 1,519 months).
SENTINEL_DATES = ("1900-01-01", "1899-12-30", "1899-12-31", "1901-01-01", "1970-01-01",
                  "1753-01-01", "2000-01-01")
# A date this far before the column's first quartile (the larger of 5 inter-quartile ranges
# and 10 years) is a typo or placeholder when such dates are rare (under this share).
PLAUSIBLE_IQR_SPAN = 5.0
PLAUSIBLE_MIN_YEARS = 10.0
PLAUSIBLE_MAX_SHARE = 0.02


def _rule_date_plausible(state: _Pass, rule: Rule) -> None:
    """
    Set aside placeholder dates on the main event date: an exact sentinel (1900-01-01 and the
    like, at midnight) that sits far outside the rest of the column, and any date far before
    it (before Q1 minus the larger of 5 IQRs and 10 years), when such dates are rare. A long
    history whose early rows are many is history, not a typo, and is kept.
    """
    formats = tuple(rule.params.get("formats", DEFAULT_DATE_FORMATS))
    max_share = float(rule.params.get("max_share", PLAUSIBLE_MAX_SHARE))
    for col in _resolve_columns(rule, state.work):
        values = _coerce_dates(state.work[col], formats)
        use = values.notna() & state.act
        n = int(use.sum())
        if n < 20:
            continue
        v = values[use]
        ns = v.astype("int64").to_numpy(dtype=np.int64)
        q1, q3 = np.percentile(ns, [25, 75])
        day = 86400e9
        span = max(PLAUSIBLE_IQR_SPAN * (q3 - q1), PLAUSIBLE_MIN_YEARS * 365.25 * day)
        # A series older than pandas' own date range (1677..2262) used to crash here: a 150-year
        # history puts Q1 minus its span below the nanosecond epoch floor. Clamp to the range
        # instead: the rule still quarantines placeholder dates, it just never explodes on a
        # long history. pd.Timestamp(int(...)) reads the int as nanoseconds.
        floor = pd.Timestamp(max(int(q1 - span), int(pd.Timestamp.min.value) + 1))
        sentinel = values.dt.normalize().isin([pd.Timestamp(x) for x in SENTINEL_DATES]) & \
            (values == values.dt.normalize()) & (values < floor)
        early = (values < floor) & use
        bad = (sentinel | early).fillna(False) & use
        k = int(bad.sum())
        if not k or k > max_share * n:
            continue
        lo, hi = pd.Timestamp(int(q1)).date().isoformat(), pd.Timestamp(int(q3)).date().isoformat()
        msgs = {}
        for pos in np.flatnonzero(bad.to_numpy(dtype=bool)):
            pos = int(pos)
            d = values.iloc[pos]
            what = ("a placeholder date" if bool(sentinel.iloc[pos]) else "far earlier than the rest")
            msgs[pos] = ("column %r: %s is %s (half of this column's dates fall from %s to %s), so it "
                         "is treated as a missing date, not as when this happened"
                         % (col, d.date().isoformat(), what, lo, hi))
        if rule.severity in ("flag", "fix"):
            state.note_flag(rule.name, k)
            continue
        state.quarantine(rule, bad, msgs)


def _rule_series_end(state: _Pass, rule: Rule) -> None:
    """
    Set aside rows dated after a series stops.

    The cliff is the first month from which `run` consecutive months -- and every
    month after them -- hold under `ratio` of the median month of the `min_prior`
    months before it. The rows from that month on are typo dates or a partial
    extract, not activity: 23 Sep 2026, 129 review dates pushed forward by a typo
    made a 37-month phantom tail and a forecast of 2 reviews a month. They are
    quarantined with a reason, and the cut is reported as a fact -- never deleted.
    A dip that recovers is not an end, and nothing is judged without a year of history.
    """
    p = dict(SERIES_END_DEFAULTS)
    p.update({k: rule.params[k] for k in SERIES_END_DEFAULTS if k in rule.params})
    min_prior, run, ratio = int(p["min_prior"]), int(p["run"]), float(p["ratio"])
    if min_prior < 1 or run < 1 or not (0.0 < ratio < 1.0):
        raise ValueError("series_end rule %r: min_prior and run must be >= 1 and ratio in (0, 1)"
                         % (rule.name,))
    formats = tuple(rule.params.get("formats", DEFAULT_DATE_FORMATS))
    for col in _resolve_columns(rule, state.work):
        values = _coerce_dates(state.work[col], formats)
        use = values.notna() & state.act
        if not bool(use.any()):
            continue
        months = values[use].dt.to_period("M")
        span = pd.period_range(months.min(), months.max(), freq="M")
        counts = months.value_counts().reindex(span, fill_value=0).to_numpy(dtype=float)
        cliff = None
        median = 0.0
        for i in range(min_prior, len(counts) - run + 1):
            median = float(np.median(counts[i - min_prior:i]))
            if median <= 0:
                continue
            limit = ratio * median
            if bool((counts[i:i + run] < limit).all()) and bool((counts[i:] < limit).all()):
                cliff = i
                break
        if cliff is None:
            continue
        cliff_month = span[cliff]
        month_of = values.dt.to_period("M")
        bad = (use & (month_of >= cliff_month)).fillna(False)
        n_rows = int(bad.sum())
        n_months = len(span) - cliff
        state.events["series_end:%s" % col] = {
            "kind": "series_end", "rule": rule.name, "column": col,
            "cliff_month": str(cliff_month), "last_month": str(span[-1]),
            "rows": n_rows, "months": n_months, "prior_median": median,
            "ratio": ratio, "min_prior": min_prior, "run": run,
            "action": "quarantined" if rule.severity == "quarantine" else "flagged",
        }
        if rule.severity in ("flag", "fix"):
            state.note_flag("%s.after_series_end" % rule.name, n_rows)
            continue
        msgs = {
            int(pos): "column %r: dated %s, after the series ends: from %s every month holds "
                      "under %d%% of the median month of the %d before it (%s rows)"
                      % (col, str(month_of.iloc[pos]), str(cliff_month), int(round(100 * ratio)),
                         min_prior, _fmt_num(median))
            for pos in np.flatnonzero(bad.to_numpy(dtype=bool))
        }
        state.quarantine(rule, bad, msgs)


def _order_values(series: pd.Series) -> pd.Series:
    """An order column as something comparable: datetimes, else numbers, else parsed dates."""
    if pd.api.types.is_datetime64_any_dtype(series) or pd.api.types.is_numeric_dtype(series):
        return series
    nums = pd.to_numeric(series, errors="coerce")
    n = int(series.notna().sum())
    if n and int(nums.notna().sum()) >= NUMERIC_DOMINANCE * n:
        return nums
    return _coerce_dates(series, DEFAULT_DATE_FORMATS)


def _rule_latest_per_key(state: _Pass, rule: Rule) -> None:
    """
    Keep the latest row per key, by an order column (a panel: one building, many
    inspections). Earlier rows are quarantined BY DESIGN with a reason naming the
    row that superseded them, and the collapse is reported as a fact. A row whose
    order value is missing or unreadable cannot be placed in time: it is kept and
    flagged, never guessed. Rows tied on the latest order value keep the first in
    file order; the others are quarantined with a reason that says it was a tie.
    """
    key = rule.params.get("key") or rule.column
    keys = [key] if isinstance(key, str) else list(key)
    order = rule.params.get("order")
    if not order:
        raise ValueError("latest_per_key rule %r needs an 'order' column" % (rule.name,))
    missing = [c for c in keys + [order] if c not in state.work.columns]
    if missing:
        raise KeyError("latest_per_key rule %r: unknown column(s) %s" % (rule.name, missing))
    ordv = _order_values(state.work[order])
    frame = pd.DataFrame({"_pos": np.arange(state.n), "_ord": ordv.to_numpy()})
    for i, k in enumerate(keys):
        frame["_k%d" % i] = state.work[k].to_numpy(dtype=object)
    kcols = ["_k%d" % i for i in range(len(keys))]
    has_key = frame[kcols].notna().all(axis=1).to_numpy() & state.active
    unordered = has_key & frame["_ord"].isna().to_numpy()
    cand = frame[has_key & ~unordered]
    event = {"kind": "latest_per_key", "rule": rule.name, "key": keys, "order": order,
             "reason_key": rule.reason_key(), "rows": 0, "keys_with_history": 0,
             "ties": 0, "unordered": int(unordered.sum()),
             "action": "quarantined" if rule.severity == "quarantine" else "flagged"}
    state.events["latest_per_key:%s" % rule.name] = event
    if int(unordered.sum()):
        state.note_flag("%s.unordered" % rule.name, int(unordered.sum()))
    if cand.empty:
        return
    ranked = cand.sort_values(["_ord", "_pos"], ascending=[False, True], kind="mergesort")
    superseded = ranked.duplicated(subset=kcols, keep="first")
    keeper = ranked[~superseded].set_index(kcols)
    losers = ranked[superseded]
    if losers.empty:
        return
    top = dict(zip(map(_row_key, keeper.index.to_frame(index=False).to_numpy(dtype=object)),
                   zip(keeper["_ord"].tolist(), keeper["_pos"].tolist())))
    msgs: Dict[int, str] = {}
    ties = 0
    lk = losers[kcols].to_numpy(dtype=object)
    for kv, o, pos in zip(lk, losers["_ord"].tolist(), losers["_pos"].tolist()):
        best_ord, kp = top[_row_key(kv)]
        tied = bool(o == best_ord)
        ties += int(tied)
        shown = ", ".join("%s=%s" % (c, _short(v)) for c, v in zip(keys, kv))
        msgs[int(pos)] = (
            "superseded: %s has a later row by %r, kept at input position %d%s"
            % (shown, order, int(kp), " (a tie on that value; the first in file order was kept)"
               if tied else ""))
    mask = pd.Series(False, index=state.work.index)
    mask.iloc[list(msgs)] = True
    event.update(rows=len(msgs), ties=ties,
                 keys_with_history=int(losers[kcols].drop_duplicates().shape[0]))
    if rule.severity in ("flag", "fix"):
        state.note_flag("%s.superseded" % rule.name, len(msgs))
        return
    state.quarantine(rule, mask, msgs)


_DISPATCH = {
    "null_like": _rule_null_like,
    "trim": _rule_trim,
    "case": _rule_case,
    "numeric": _rule_numeric,
    "date": _rule_date,
    "dedupe": _rule_dedupe,
    "range": _rule_range,
    "not_future": _rule_not_future,
    "not_null": _rule_not_null,
    "allowed": _rule_allowed,
    "boolean": _rule_boolean,
    "series_end": _rule_series_end,
    "date_plausible": _rule_date_plausible,
    "latest_per_key": _rule_latest_per_key,
}


def clean_frame(df: pd.DataFrame, rules: Optional[Sequence[Rule]] = None) -> CleanResult:
    """
    Apply `rules` in order and return a reconciled CleanResult.

    Rules run in the order given: repairs first, then rejections, so that (for
    example) whitespace normalisation can expose duplicates that were hiding
    behind a trailing space. A row leaves the active set the moment a rule
    rejects it, so every quarantined row carries exactly one reason -- the rule
    that caught it first.

    The returned CleanResult has already been reconciled; a broken invariant
    raises ReconciliationError here rather than shipping a wrong number.
    """
    if not isinstance(df, pd.DataFrame):
        raise TypeError("clean_frame expects a pandas DataFrame, got %r" % (type(df).__name__,))
    if QUARANTINE_COL in df.columns:
        raise ValueError(
            "input already has a %r column; cleaning would overwrite the reason "
            "an earlier pass recorded" % (QUARANTINE_COL,)
        )
    rules = list(rules or [])
    seen = set()
    for rule in rules:
        if not isinstance(rule, Rule):
            raise TypeError("rules must be Rule instances, got %r" % (type(rule).__name__,))
        if rule.name in seen:
            raise ValueError("duplicate rule name %r; counts would be merged" % (rule.name,))
        seen.add(rule.name)

    state = _Pass(df)
    for rule in rules:
        _DISPATCH[rule.kind](state, rule)

    active = state.active
    clean = state.work.loc[active].copy()
    quarantined = state.original.loc[~active].copy()
    if len(quarantined):
        quarantined[QUARANTINE_COL] = state.reasons[~active]
    else:
        quarantined = quarantined.assign(**{QUARANTINE_COL: pd.Series(dtype=object)})

    # restore the caller's original index labels on both halves
    orig_index = df.index
    clean.index = orig_index[np.flatnonzero(active)]
    quarantined.index = orig_index[np.flatnonzero(~active)]

    result = CleanResult(
        total_in=int(len(df)),
        rows_clean=int(len(clean)),
        rows_quarantined=int(len(quarantined)),
        fixes_applied=dict(state.fixes),
        quarantine_reasons=dict(state.qcounts),
        clean=clean,
        quarantined=quarantined,
        flags=dict(state.flags),
        source=getattr(df, "attrs", {}).get("source", "") if hasattr(df, "attrs") else "",
        events=dict(state.events),
    )
    result.reconcile()          # loud, here, before anyone reads a number
    return result


# ---------------------------------------------------------------------------
# rule derivation
# ---------------------------------------------------------------------------
def _get(obj: Any, names: Sequence[str], default: Any = None) -> Any:
    for name in names:
        if isinstance(obj, dict):
            if name in obj and obj[name] is not None:
                return obj[name]
        else:
            value = getattr(obj, name, None)
            if value is not None:
                return value
    return default


def _family(type_text: str, name: str) -> str:
    text = str(type_text or "").lower()
    if any(tok in text for tok in ("date", "time", "timestamp")):
        return "date"
    if any(tok in text for tok in ("int", "float", "numeric", "number", "decimal", "double", "currency", "money", "real")):
        return "numeric"
    if "bool" in text:
        return "bool"
    if any(tok in text for tok in ("categor", "code", "enum")):
        return "categorical"
    if text in ("object", "str", "string", "text", ""):
        return "text"
    return "text"


# Stage 1 reports the date layouts it actually observed, using these tokens.
# Honouring them keeps one assumption in the pipeline (health's, which is
# documented and client-visible) instead of two that can silently disagree on a
# value like "05/02/2026".
_HEALTH_DATE_TOKENS = {
    "YYYY-MM-DD": "%Y-%m-%d",
    "YYYY-MM-DD HH:MM": "%Y-%m-%d %H:%M",
    "YYYY-MM-DD HH:MM:SS": "%Y-%m-%d %H:%M:%S",
    "YYYY-MM-DDTHH:MM:SS": "%Y-%m-%dT%H:%M:%S.%f",
    "DD-Mon-YYYY": "%d-%b-%Y",
    "DD-Mon-YY": "%d-%b-%y",
    "Mon DD YYYY": "%b %d %Y",
    "MM/DD/YYYY": "%m/%d/%Y",
    "DD/MM/YYYY": "%d/%m/%Y",
    "MM/DD/YYYY hh:mm:ss AM": "%m/%d/%Y %I:%M:%S %p",
    "DD/MM/YYYY hh:mm:ss AM": "%d/%m/%Y %I:%M:%S %p",
    "DD-MM-YYYY": "%d-%m-%Y",
    "MM-DD-YYYY": "%m-%d-%Y",
    "YYYY/MM/DD": "%Y/%m/%d",
    "DD.MM.YYYY": "%d.%m.%Y",
    "YYYYMMDD": "%Y%m%d",
    "YYYY-MM": "%Y-%m",
    "YYYY/MM": "%Y/%m",
    "Mon-YYYY": "%b-%Y",
    "Mon YYYY": "%b %Y",
}


def _strptime_formats(observed: Any) -> List[str]:
    """Map stage-1 format tokens to strptime formats, most-seen first."""
    if not observed:
        return []
    if isinstance(observed, dict):
        tokens = [t for t, _ in sorted(observed.items(), key=lambda kv: -int(kv[1] or 0))]
    else:
        tokens = list(observed)
    out: List[str] = []
    for token in tokens:
        fmt = _HEALTH_DATE_TOKENS.get(str(token))
        if fmt and fmt not in out:
            out.append(fmt)
    return out


def _name_tokens(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(name).lower()).strip("_")


def standard_rules(
    health: Any,
    as_of: Any = None,
    latest_per_key: Optional[Dict[str, Any]] = None,
) -> List[Rule]:
    """
    Derive a sensible rule set from a stage-1 TableHealth.

    `as_of` is the date "the future" is measured from (default: today).
    `latest_per_key`, e.g. {"key": "RSN", "order": "EVALUATION COMPLETED ON"}, adds a
    step that keeps only the latest row per key (see _rule_latest_per_key); it runs
    after exact de-duplication.

    What each column gets:
      * numeric: when stage 1 typed it numeric, or >= NUMERIC_DOMINANCE of it is numbers.
      * date: when stage 1 typed it a date, or >= DATE_DOMINANCE of it is dates --
        dominance, never presence (one date-like review body is not a date column).
      * yes/no: a low-cardinality text column gets a boolean rule, which acts only if
        >= BOOLEAN_DOMINANCE of the column is yes/no spellings.
      * not_future: every date column except forward-looking ones (due, expiry, next,
        scheduled...), whose dates may legitimately be ahead of today.
      * series_end: the main event-date column (most date values; not a birth date,
        not forward-looking) is checked for a phantom tail after the series ends.
      * range min 0: quantities, amounts, prices... and star ratings (the -1 sentinel).

    `health` is read duck-typed -- the health module is imported lazily and only
    for a clearer error message -- so clean.py and health.py stay independently
    testable and neither blocks the other.

    Expected shape (attributes or dict keys, several spellings accepted):
        health.table / .name          the table's name
        health.columns                a sequence of per-column entries, each with
                                      .name/.column, a type hint
                                      (.inferred_type/.semantic_type/.dtype) and
                                      optional .is_key/.required flags.
    """
    if health is None:
        try:                                    # lazy: only for the message
            from .health import TableHealth     # noqa: F401
            hint = "pass the TableHealth produced by health.profile_table()"
        except Exception:                       # noqa: BLE001 - health.py may not exist yet
            hint = "pass a TableHealth-shaped object with .columns"
        raise ValueError("standard_rules() needs a TableHealth; %s" % hint)

    columns = _get(health, ("columns", "column_health", "cols"), []) or []
    if isinstance(columns, dict):
        entries = [
            (str(key), value if not isinstance(value, str) else {"inferred_type": value})
            for key, value in columns.items()
        ]
    else:
        entries = [(str(_get(c, ("name", "column", "col"), "")), c) for c in columns]
    entries = [(name, c) for name, c in entries if name]

    rules: List[Rule] = [
        Rule("null_like", "*", "null_like", {"tokens": list(DEFAULT_NULL_TOKENS)}, "fix"),
        Rule("trim_text", "*", "trim", {"collapse": True}, "fix"),
    ]
    case_rules: List[Rule] = []
    coerce_rules: List[Rule] = []
    reject_rules: List[Rule] = []
    future_params: Dict[str, Any] = {} if as_of is None else {"as_of": as_of}
    event_dates: List[Tuple[int, str]] = []     # (date values seen, column) for series_end
    future_rules: List[Tuple[Rule, bool]] = []  # (not_future rule, past-only column)

    for name, entry in entries:
        declared = _get(
            entry,
            ("dtype_guess", "inferred_type", "semantic_type", "suggested_type", "type", "kind"),
            "",
        )
        stored = str(_get(entry, ("declared_type", "dtype", "pandas_dtype", "stored_dtype"), "") or "")
        family = _family(declared or stored, name)
        stored_is_text = (not stored) or _family(stored, name) in ("text", "categorical")
        # measured signals from stage 1, when it supplies them
        numeric_as_text = int(_get(entry, ("n_numeric_as_text",), 0) or 0)
        seen_formats = _get(entry, ("date_formats",), None) or {}
        id_like = bool(_get(entry, ("is_id_like", "is_key", "primary_key"), False))

        # DOMINANCE, not presence. `On Street` held exactly ONE numeric-looking
        # value out of 13,893 street names; under `> 0` that single value turned
        # the column numeric and quarantined all 13,892 real streets. A column is
        # numeric when it is *mostly* numeric, never because one cell looks it.
        n_non_null = int(_get(entry, ("n_non_null",), 0) or 0)
        numeric_share = (float(numeric_as_text) / n_non_null) if n_non_null else 0.0
        wants_numeric = stored_is_text and (
            family == "numeric" or numeric_share >= NUMERIC_DOMINANCE
        )
        # Dates get the same DOMINANCE rule. Under the old presence test
        # (`bool(seen_formats)`) one date-like review body out of 48,384 gave the
        # free-text column a date rule and 41,840 real reviews were quarantined.
        class_counts = _get(entry, ("class_counts",), None) or {}
        if isinstance(class_counts, dict) and "date" in class_counts:
            n_dates = int(class_counts.get("date") or 0)
        else:
            n_dates = int(sum(int(v or 0) for v in dict(seen_formats).values())) \
                if isinstance(seen_formats, dict) else 0
        date_share = (float(n_dates) / n_non_null) if n_non_null else 0.0
        wants_date = stored_is_text and (family == "date" or date_share >= DATE_DOMINANCE)
        n_distinct_norm = int(_get(entry, ("n_distinct_normalised",), 0) or 0)

        if wants_numeric:
            # A key's unreadable value sets its row aside; any other numeric column only loses
            # the cell (review v2, 24 Sep 2026: one '3.5h' took a ticket's date and CSAT out of
            # every figure).
            keyish = id_like or bool(_get(entry, ("is_key", "primary_key", "required", "is_required"), False))
            coerce_rules.append(Rule("%s_numeric" % name, name, "numeric", {},
                                     "quarantine" if keyish else "fix"))
        elif wants_date:
            observed = _strptime_formats(seen_formats)
            formats = observed + [f for f in DEFAULT_DATE_FORMATS if f not in observed]
            coerce_rules.append(
                Rule("%s_date" % name, name, "date",
                     {"formats": formats,
                      "formats_source": "health.date_formats" if observed else "default"},
                     "quarantine")
            )
        elif family in ("text", "categorical"):
            code_like = bool(_CODE_NAME_RE.search(name)) or id_like
            if code_like or family == "categorical":
                case_rules.append(
                    Rule("%s_case" % name, name, "case",
                         {"mode": "upper" if code_like else "title"}, "fix")
                )
            elif (not id_like and 0 < n_distinct_norm <= DOMINANT_MAX_LEVELS
                  and n_distinct_norm < int(_get(entry, ("n_distinct",), 0) or 0)):
                # a grouping column whose spellings differ only in case or spacing (the audit's
                # letter-case finding): each takes its most common spelling (see _rule_case)
                case_rules.append(Rule("%s_case" % name, name, "case", {"mode": "dominant"}, "fix"))
            if 0 < n_distinct_norm <= 10 and not id_like:
                # acts only if the column turns out to be mostly yes/no spellings. An odd
                # 'Unknown' or 'Pending' in a side yes/no column is flagged and the row kept:
                # quarantining it took the row's rent out of every figure (QA, 23 Sep 2026).
                # Only a required column quarantines.
                required = bool(_get(entry, ("is_key", "primary_key", "required", "is_required"), False))
                coerce_rules.append(Rule("%s_boolean" % name, name, "boolean", {},
                                         "quarantine" if required else "flag"))

        if _get(entry, ("is_key", "primary_key", "required", "is_required"), False):
            reject_rules.append(Rule("%s_required" % name, name, "not_null", {}, "quarantine"))
        if family == "numeric" and (_NON_NEGATIVE_RE.search(name) or _RATING_RE.search(_name_tokens(name))):
            reject_rules.append(Rule("%s_range" % name, name, "range", {"min": 0}, "quarantine"))
        is_date_col = (family == "date" or wants_date) and not wants_numeric
        forward = bool(_FORWARD_LOOKING_RE.search(_name_tokens(name)))
        past_only = bool(_PAST_ONLY_RE.search(name))
        if is_date_col and (past_only or not forward):
            # Every event date, not only birth and hire dates: a review, an inspection
            # or an order dated after today is a typo. Due/expiry/next dates are exempt.
            # Severity is settled below: quarantine on the main event date (and birth or
            # hire dates), a flag on any other date column, so one side column cannot
            # take a row's figures out of every analysis.
            future_rule = Rule("%s_not_future" % name, name, "not_future",
                               dict(future_params), "quarantine")
            future_rules.append((future_rule, past_only))
            reject_rules.append(future_rule)
        if is_date_col and not forward and not past_only:
            event_dates.append((n_dates, name))

    # repairs, then rejections, then dedupe last so normalised values are
    # compared -- ' ACME ' and 'ACME' are the same duplicate.
    rules.extend(case_rules)
    rules.extend(coerce_rules)
    rules.extend(reject_rules)
    main = None
    if event_dates:
        # the main event date: most date values; the first listed on a tie
        best = max(n for n, _c in event_dates)
        main = next(c for n, c in event_dates if n == best)
        rules.append(Rule("%s_plausible" % main, main, "date_plausible", {}, "quarantine"))
        rules.append(Rule("%s_series_end" % main, main, "series_end", {}, "quarantine"))
    for fr, past_only_col in future_rules:
        if not past_only_col and fr.column != main:
            fr.severity = "flag"
    rules.append(Rule("exact_duplicates", "", "dedupe", {"keep": "first"}, "quarantine"))
    if latest_per_key:
        key = latest_per_key.get("key")
        order = latest_per_key.get("order")
        if not key or not order:
            raise ValueError("latest_per_key needs a 'key' and an 'order', got %r" % (latest_per_key,))
        keys = [key] if isinstance(key, str) else list(key)
        rules.append(Rule("latest_per_%s" % _slug("_".join(keys)), keys[0], "latest_per_key",
                          {"key": key, "order": order}, "quarantine"))
    return rules


def _rules_from_frame(df: pd.DataFrame) -> List[Rule]:
    """
    Fallback rule set derived from the frame itself, used by clean_table when no
    rules are given and no TableHealth is available. Deliberately timid: it
    normalises and de-duplicates, and never invents a rejection rule.
    """
    rules = [
        Rule("null_like", "*", "null_like", {"tokens": list(DEFAULT_NULL_TOKENS)}, "fix"),
        Rule("trim_text", "*", "trim", {"collapse": True}, "fix"),
        Rule("exact_duplicates", "", "dedupe", {"keep": "first"}, "quarantine"),
    ]
    return rules


# ---------------------------------------------------------------------------
# sqlite entry point
# ---------------------------------------------------------------------------
def _quote_ident(name: str) -> str:
    if not _IDENT_RE.match(str(name)):
        raise ValueError(
            "refusing to build SQL for table name %r; expected a plain identifier" % (name,)
        )
    return '"%s"' % str(name).replace('"', '""')


def clean_table(
    con: Any,
    table: str,
    rules: Optional[Sequence[Rule]] = None,
    limit: Optional[int] = None,
    health: Any = None,
    as_of: Any = None,
    latest_per_key: Optional[Dict[str, Any]] = None,
) -> CleanResult:
    """
    Read `table` from an open sqlite3 connection and clean it.

    When `rules` is None the rule set is derived from a stage-1 TableHealth: the one
    passed as `health` (the loop already holds it -- re-profiling cost 40% of a NYC 311
    audit), else a fresh profile if health.py is importable; otherwise a timid
    frame-derived fallback is used, and that choice is visible in the result's
    rule names.
    """
    sql = "SELECT * FROM %s" % _quote_ident(table)
    if limit is not None:
        if not isinstance(limit, int) or isinstance(limit, bool) or limit < 0:
            raise ValueError("limit must be a non-negative int, got %r" % (limit,))
        sql += " LIMIT %d" % limit
    df = pd.read_sql_query(sql, con)

    rule_source = ""
    rule_source_error = ""
    source_health: Optional[float] = None
    if rules is None and health is not None:
        rules = standard_rules(health, as_of=as_of, latest_per_key=latest_per_key)
        rule_source = "health"
        source_health = _health_score(health)
    if rules is None:
        _health = None
        try:                                     # lazy import: stage 1 is optional here
            from . import health as _health      # noqa: WPS433
        except Exception as exc:                 # noqa: BLE001 - stage 1 may not exist yet
            rule_source_error = "stage-1 health module is not importable: %s" % (exc,)
        if _health is not None:
            fn_names = ("score_table", "profile_table", "table_health", "profile")
            fn = None
            for fn_name in fn_names:
                candidate = getattr(_health, fn_name, None)
                if callable(candidate):
                    fn = candidate
                    break
            if fn is None:
                rule_source_error = (
                    "stage-1 health module exposes none of %s" % (fn_names,)
                )
            else:
                try:
                    profile = fn(con, table)
                    if profile is None:
                        rule_source_error = (
                            "stage-1 %s() returned nothing for %r" % (fn.__name__, table)
                        )
                    else:
                        rules = standard_rules(profile, as_of=as_of, latest_per_key=latest_per_key)
                        rule_source = "health"
                        source_health = _health_score(profile)
                except Exception as exc:         # noqa: BLE001 - reported, not swallowed
                    rules = None
                    rule_source_error = (
                        "stage-1 rule derivation failed for %r (%s: %s)"
                        % (table, type(exc).__name__, exc)
                    )
        if rules is None:
            # Deliberately timid, and SAID so: a caller must be able to tell a
            # health-derived pass from one that only trimmed and de-duplicated,
            # and must be told WHY the stronger rules were unavailable. A silent
            # downgrade would let a non-numeric quantity through while the run
            # still looked healthy.
            rules = _rules_from_frame(df)
            rule_source = "frame-fallback"

    if health is not None and source_health is None:
        source_health = _health_score(health)
    result = clean_frame(df, rules)
    result.source = str(table)
    result.rule_source = rule_source
    result.rule_source_error = rule_source_error
    result.source_health = source_health
    return result


def _health_score(health: Any) -> Optional[float]:
    """The stage-1 table score, when the profile carries a usable one."""
    score = _get(health, ("score",), None)
    try:
        value = float(score)
    except (TypeError, ValueError):
        return None
    return value if 0.0 <= value <= 100.0 else None
