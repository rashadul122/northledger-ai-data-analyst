"""Open a SQLite file read-only, whatever characters its path holds.

`sqlite3.connect("file:%s?mode=ro" % path, uri=True)` breaks on a path containing '#', '?'
or '%': the URI is cut short, mode=ro is dropped, and an empty database can be created
elsewhere (found by review, 2026-09-23). The path is percent-encoded instead.
"""
from __future__ import annotations

import os
import sqlite3
from urllib.parse import quote


def ro_uri(path: str) -> str:
    return "file:%s?mode=ro" % quote(os.path.abspath(path))


def connect_ro(path: str) -> sqlite3.Connection:
    return sqlite3.connect(ro_uri(path), uri=True)
