#!/usr/bin/env python3
"""
Prediction under the evidence rules: a monthly forecast that has to earn its place.

What this module does, in the order a sceptical client would ask about it:

1. It fits five small models, numpy only (the engine bans scipy, statsmodels and
   sklearn): naive (repeat last month), seasonal-naive (repeat the same month last
   year), drift (straight line through the first and last month), a damped-trend
   Holt model on logs, and a log-linear trend with month-of-year effects.
2. It REPLAYS the past. A rolling-origin backtest stands at each of the last
   months of history (24 when the history allows, never fewer than 12), fits every
   model on what was known then, and forecasts 1..h months ahead. The model with
   the lowest backtest error is the champion -- including when that is a naive
   baseline, which the result says in plain words.
3. The 80% band is not a sqrt(h) guess from an in-sample sigma. It is a split-conformal
   rank band on the champion's OWN backtest errors at that horizon (design §2.1 M6):
   with n errors sorted, the low edge is the floor((n + 1) * 0.1)-th smallest and the
   high edge the ceil((n + 1) * 0.9)-th. If the errors were exchangeable, a range built
   this way covers at least 80% on average (at most 1 - 0.2 + 2/(n + 1)); with fewer
   than 9 errors no 80% range can be supported, and none is drawn. (It used to be
   np.quantile(errors, [0.1, 0.9]), which covers about 64% with 8 errors and 74% with
   24 even when the errors are ideal.) Because the guarantee is an average over
   calibration sets, each range also carries the spread of its OWN coverage given the n
   errors behind it: Beta(u - l, n + 1 - (u - l)), 10th and 90th percentiles. When the
   band is scored against the held-out months, each band is built only from errors that
   were already observable at that origin: no peeking. Errors from consecutive origins are not
   exchangeable when the series has momentum (they move together, so they carry the
   information of fewer errors): when their lag-1 autocorrelation is significant the band is
   widened by :func:`dependence_widening`, and each range states by how much. (Without it, 80%
   ranges on AR(1) 0.8-0.9 series covered as little as 67-75% at their weakest horizon;
   23 Sep 2026 review.)
4. The forecast becomes Facts with query_kind "model". Each carries the series SQL,
   the model, the configuration and the seed; `EvidenceLedger.verify` calls
   :func:`recompute`, which re-reads the series, refits everything and must land on
   the same number.
5. :func:`gate_forecast` decides RECOMMEND / WATCH / INSUFFICIENT from rules a
   client can read: enough history, a long enough backtest, a champion that beats
   seasonal-naive on MASE and a procedure SHOWN to beat it one month ahead (design M7: a
   one-sided Diebold-Mariano test with the Harvey-Leybourne-Newbold correction on the
   nested-selection errors, so picking the best of five candidates is inside the test), a replay record that does not REJECT 80% coverage (exact
   binomial test at 5%: the replay can reveal a badly calibrated range, never certify a
   good one; Christoffersen's independence and conditional-coverage tests are reported
   beside it as diagnostics), and a range that is sharper than seasonal-naive's range
   built the same way (interval score, MSIS). Design §2.1 M8.
6. Error measures (design S7): MASE is the headline error and skill is stated against
   seasonal-naive; MAPE is secondary and is withheld when any replayed actual is zero or
   near zero (under `mape_min_share` of the typical replayed month), where a percentage
   miss is undefined or explodes; sMAPE is never used. The champion is chosen on MAE, so
   its point forecast is a median-type forecast, and the 80% range is a statement about
   each month on its own, not about the whole 12-month path.

Python 3.9 compatible. numpy + stdlib only (pandas only in the CSV command).
"""
from __future__ import annotations

import json
import math
import sqlite3
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

from .facts import Fact, FactSet, GateResult

PAYLOAD_KIND = "northledger.forecast/1"
SEASON = 12
MODEL_NAMES = ("naive", "seasonal_naive", "drift", "holt_damped_log", "loglinear_season")
BASELINES = ("naive", "seasonal_naive")

#: How each model is described to a client.
PLAIN_NAME = {
    "naive": "repeat last month's value",
    "seasonal_naive": "repeat the same month from last year",
    "drift": "extend the straight line from the first month to the last",
    "holt_damped_log": "a damped trend fitted on the log scale (Holt)",
    "loglinear_season": "a log-linear trend with month-of-year effects",
}

#: Defaults. Every one is written into the fact's payload, so a re-run uses the same.
DEFAULT_CONFIG: Dict[str, Any] = {
    "horizon": 12,            # months ahead
    "max_holdout": 24,        # scored backtest origins when the history allows
    "min_holdout": 12,        # never fewer (the gate enforces it too)
    "min_train": 24,          # months a model is given before its first backtest forecast
    # errors needed at a horizon before a band is drawn from them. The conformal ranks need
    # at least 2/(1 - band) - 1: 9 for 80% (19 for 90%, 39 for 95%); a lower value here is
    # raised to that, never used (design §2.1 M6).
    "min_band_errors": 9,
    "max_history": 120,       # months of history used (the most recent ones)
    "loglinear_window": 60,   # months the log-linear model is fitted on
    "band": 0.80,
    "band_method": "conformal_rank",
    # Which errors the range is built from (design §2.1 M6 red tests, S4). Measured on the
    # benchmark's forecast cells, 200 series each (23 Sep 2026, scratchpad r1/b3):
    #   "champion": the final champion's own errors. It was chosen on those same errors, so
    #       they are optimistic: AR(1) phi 0.7 pooled coverage 73% (48 months), 77% (72, 120).
    #   "nested": the errors of the whole procedure -- at each backtest origin the model with
    #       the lowest MAE on the errors known THEN, seasonal-naive before any are known. Free
    #       of that optimism (AR(1) 78-80%), but after a level shift its earlier picks carry
    #       the old level while the champion has adapted: a -25% shift 12 months before the
    #       origin fell from 78% to 41% coverage.
    #   "envelope" (default): the champion's point with a range that must hold under BOTH
    #       calibrations -- the lower of the two low edges and the higher of the two high
    #       edges, each band drawn around the champion's point. It contains both, so it can
    #       never cover less than either: AR(1) 81-82%, the k = 12 shift 78%, at a range about
    #       10-15% wider than the champion's alone.
    # (Also measured and rejected: judging only whole observed forecast paths, with
    # seasonal-naive until one exists; it doubled the range on trending seasonal series.)
    "band_errors": "envelope",
    # Dependent calibration errors (23 Sep 2026 review): errors from consecutive backtest
    # origins move together when the series has momentum, so n of them carry the information of
    # fewer independent ones and their rank band is too narrow -- the conformal guarantee needs
    # exchangeable errors (Barber et al. 2023). Measured on the benchmark's AR(1) 0.8/0.9 cells
    # (48-120 months, around a level and around a seasonal mean; 1,000 series each, master seed
    # 777001), the weakest horizon's coverage was 66.7-80.2% with "none" (8 of 12 cells failed
    # the 80% - 2 MCSE gate) and 78.8-86.0% with "ar1_widen" (none failed); on the stable seasonal
    # cells the two agree to 0.4 points. The price is width: about +8% at one month ahead and
    # +34-37% at twelve on AR(1) 0.8-0.9 (2,000 series per cell, scratchpad r1/fc-longh).
    # "ar1_widen" (default) widens a band when its errors' lag-1 autocorrelation is significant;
    # see dependence_widening. "none" is the plain rank band.
    "band_dependence": "ar1_widen",
    # MAPE is withheld when a replayed actual is below this share of the mean absolute
    # replayed actual (or zero): a percentage of a near-zero month explodes (fpp3 §5.8).
    "mape_min_share": 0.10,
    # The baseline test (design M7, see _baseline_test) starts at the first backtest origin
    # where the procedure had at least this many replayed errors to choose a model from.
    "baseline_test_min_known": 12,
    "seed": 0,                # no model draws random numbers; recorded for the contract
    # A series that has never gone below zero (a count, a sum of rents) is never forecast
    # below zero, and neither is its range: "auto" decides from the history itself.
    "nonnegative": "auto",
    # After a detected step (ship round, 24 Sep 2026; see forecast_facts): "fit_from" (a month
    # label) fits and replays on the months from the step on; "step_month" (a month label) keeps
    # the fit across the step and shows months ahead only while the 80% range is still useful:
    # its high end at most `useful_range_ratio` times its low end.
    "fit_from": None,
    "step_month": None,
    "useful_range_ratio": 2.0,
}

#: The display rule after a step the forecast could not fit around (see DEFAULT_CONFIG
#: "useful_range_ratio"): a month ahead is shown while its 80% range's high end is at most this
#: many times its low end. A range wider than a doubling says only "somewhere between X and more
#: than twice X", which is no plan; the month-ahead forecast is always shown (the gate grades it).
USEFUL_RANGE_RATIO = 2.0

# Holt grid: small, fixed and ordered, so the chosen parameters are reproducible.
_ALPHAS = (0.1, 0.2, 0.3, 0.5, 0.7, 0.9)
_BETAS = (0.01, 0.05, 0.1, 0.2)
_PHIS = (0.8, 0.9, 0.95, 0.98)


class ForecastError(ValueError):
    """The series cannot support a forecast (too short, gaps, not a number)."""


# --------------------------------------------------------------------------- months
def month_index(label: str) -> int:
    """'2023-08' -> a running month number; inverse of :func:`month_label`."""
    s = str(label).strip()[:7]
    y, m = s.split("-")
    y, m = int(y), int(m)
    if not (1 <= m <= 12):
        raise ForecastError("not a month: %r" % (label,))
    return y * 12 + (m - 1)


def month_label(idx: int) -> str:
    return "%04d-%02d" % (idx // 12, idx % 12 + 1)


# --------------------------------------------------------------------------- transforms
def _transform_kind(y: np.ndarray) -> str:
    if np.all(y > 0):
        return "log"
    if np.all(y >= 0):
        return "log1p"
    return "none"


def _fwd(z: np.ndarray, kind: str) -> np.ndarray:
    if kind == "log":
        return np.log(z)
    if kind == "log1p":
        return np.log1p(z)
    return z.astype(float)


def _inv(z: np.ndarray, kind: str) -> np.ndarray:
    if kind == "log":
        return np.exp(z)
    if kind == "log1p":
        return np.expm1(z)
    return z


# --------------------------------------------------------------------------- models
def _naive(y: np.ndarray, h: int, m0: int, cfg: Dict[str, Any]) -> Tuple[np.ndarray, Dict[str, Any]]:
    return np.full(h, float(y[-1])), {}


def _seasonal_naive(y, h, m0, cfg):
    if len(y) < SEASON:
        raise ForecastError("seasonal-naive needs a full year of history")
    n = len(y)
    out = np.array([float(y[n - SEASON + (i % SEASON)]) for i in range(h)])
    # After a named step in the series (fixer round, 24 Sep 2026: a building bought in 2025-03),
    # "the same month last year" is scaled by each step between that month and the target, so
    # the rule is judged on the level the series is at, not the one it left (see _step_scale).
    if cfg.get("step_pos"):
        out = out * np.array([_step_scale(cfg["step_pos"], n - SEASON + (i % SEASON), n + i)
                              for i in range(h)])
    return out, {}


def _step_scale(step_pos: Sequence[Sequence[float]], ref: int, target: int) -> float:
    """The product of (1 + size) of the steps at positions p with ref < p <= target."""
    f = 1.0
    for p, ratio in step_pos:
        if ref < int(p) <= target:
            f *= float(ratio)
    return f


def _drift(y, h, m0, cfg):
    n = len(y)
    if n < 2:
        raise ForecastError("drift needs two months")
    slope = (float(y[-1]) - float(y[0])) / (n - 1)
    return float(y[-1]) + slope * np.arange(1, h + 1, dtype=float), {"slope": slope}


def _holt_damped_log(y, h, m0, cfg):
    """Damped-trend Holt, every grid point at once (vectorised over the grid)."""
    if len(y) < 3:
        raise ForecastError("Holt needs three months")
    kind = _transform_kind(y)
    z = _fwd(np.asarray(y, dtype=float), kind)
    grid = np.array([(a, b, p) for a in _ALPHAS for b in _BETAS for p in _PHIS], dtype=float)
    a, b, p = grid[:, 0], grid[:, 1], grid[:, 2]
    lvl = np.full(len(grid), z[0])
    trd = np.full(len(grid), z[1] - z[0])
    sse = np.zeros(len(grid))
    for x in z[1:]:
        f = lvl + p * trd
        sse += (x - f) ** 2
        new_lvl = a * x + (1 - a) * f
        trd = b * (new_lvl - lvl) + (1 - b) * p * trd
        lvl = new_lvl
    k = int(np.argmin(sse))          # first minimum: ties resolve by grid order
    phi = p[k]
    steps = np.cumsum(phi ** np.arange(1, h + 1))
    pred = _inv(lvl[k] + steps * trd[k], kind)
    return pred, {"alpha": float(a[k]), "beta": float(b[k]), "phi": float(phi), "transform": kind}


def _loglinear_season(y, h, m0, cfg):
    w = int(cfg.get("loglinear_window", 60))
    n = len(y)
    if n < 2 * SEASON:
        raise ForecastError("the seasonal regression needs two full years")
    start = max(0, n - w)
    kind = _transform_kind(y)
    z = _fwd(np.asarray(y[start:], dtype=float), kind)
    t = np.arange(start, n, dtype=float)

    def design(tt):
        cal = (m0 + tt.astype(int)) % SEASON
        cols = [np.ones(len(tt)), tt] + [(cal == c).astype(float) for c in range(1, SEASON)]
        return np.column_stack(cols)

    coef = np.linalg.lstsq(design(t), z, rcond=None)[0]
    pred = _inv(design(np.arange(n, n + h, dtype=float)) @ coef, kind)
    return pred, {"transform": kind, "window": int(len(z))}


_MODELS = {
    "naive": _naive,
    "seasonal_naive": _seasonal_naive,
    "drift": _drift,
    "holt_damped_log": _holt_damped_log,
    "loglinear_season": _loglinear_season,
}


def fit_predict(name: str, y: Sequence[float], h: int, m0: int = 0,
                cfg: Optional[Dict[str, Any]] = None) -> Tuple[np.ndarray, Dict[str, Any]]:
    """Fit model `name` on `y` (month-of-year of y[0] is m0) and forecast h steps."""
    if name not in _MODELS:
        raise ValueError("unknown model %r; expected one of %s" % (name, MODEL_NAMES))
    return _MODELS[name](np.asarray(y, dtype=float), int(h), int(m0), dict(cfg or DEFAULT_CONFIG))


# --------------------------------------------------------------------------- statistics
def wilson(k: int, n: int, z: float = 1.959964) -> Tuple[float, float]:
    """95% Wilson score interval for k successes in n trials."""
    if n <= 0:
        return (float("nan"), float("nan"))
    p = k / float(n)
    den = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / den
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return (max(0.0, centre - half), min(1.0, centre + half))


# Hand-written distribution functions: the engine runs in Pyodide, which has no scipy. Each
# is checked in tests/test_forecast_bands.py against an independent exact identity (the
# binomial-sum form of the incomplete beta for integer shapes, closed forms at a or b = 1,
# chi-square with 1 and 2 degrees of freedom against erfc and exp).
def _betacf(a: float, b: float, x: float) -> float:
    """Continued fraction of the incomplete beta (modified Lentz; Numerical Recipes §6.4)."""
    tiny, eps = 1e-300, 3e-16
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c, d = 1.0, 1.0 - qab * x / qap
    d = 1.0 / (d if abs(d) > tiny else tiny)
    h = d
    for m in range(1, 400):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        d = 1.0 / (d if abs(d) > tiny else tiny)
        c = 1.0 + aa / c
        c = c if abs(c) > tiny else tiny
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        d = 1.0 / (d if abs(d) > tiny else tiny)
        c = 1.0 + aa / c
        c = c if abs(c) > tiny else tiny
        de = d * c
        h *= de
        if abs(de - 1.0) < eps:
            break
    return h


def beta_cdf(x: float, a: float, b: float) -> float:
    """Regularised incomplete beta I_x(a, b): the CDF of Beta(a, b) at x."""
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    lbt = (math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b)
           + a * math.log(x) + b * math.log1p(-x))
    bt = math.exp(lbt)
    if x < (a + 1.0) / (a + b + 2.0):
        return bt * _betacf(a, b, x) / a
    return 1.0 - bt * _betacf(b, a, 1.0 - x) / b


def beta_ppf(q: float, a: float, b: float) -> float:
    """Quantile of Beta(a, b) by bisection on beta_cdf (monotone; 1e-12 in x)."""
    if q <= 0.0:
        return 0.0
    if q >= 1.0:
        return 1.0
    lo, hi = 0.0, 1.0
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if beta_cdf(mid, a, b) < q:
            lo = mid
        else:
            hi = mid
        if hi - lo < 1e-12:
            break
    return 0.5 * (lo + hi)


def binom_pmf(k: int, n: int, p: float) -> float:
    if k < 0 or k > n:
        return 0.0
    if p <= 0.0:
        return 1.0 if k == 0 else 0.0
    if p >= 1.0:
        return 1.0 if k == n else 0.0
    return math.exp(math.lgamma(n + 1) - math.lgamma(k + 1) - math.lgamma(n - k + 1)
                    + k * math.log(p) + (n - k) * math.log1p(-p))


def binom_test_two_sided(k: int, n: int, p: float) -> float:
    """Exact two-sided binomial p-value, R's binom.test rule: the total probability of the
    outcomes no more likely than the one observed (relative tolerance 1e-7)."""
    if n <= 0:
        return float("nan")
    lim = binom_pmf(k, n, p) * (1.0 + 1e-7)
    probs = [binom_pmf(i, n, p) for i in range(n + 1)]
    return float(min(1.0, sum(q for q in probs if q <= lim)))


def chi2_sf(x: float, df: int) -> float:
    """Upper tail of chi-square with 1 or 2 degrees of freedom (all Christoffersen needs)."""
    if not math.isfinite(x):
        return float("nan")
    if x <= 0.0:
        return 1.0
    if df == 1:
        return math.erfc(math.sqrt(x / 2.0))
    if df == 2:
        return math.exp(-x / 2.0)
    raise ValueError("chi2_sf supports 1 or 2 degrees of freedom")


def t_cdf(x: float, df: float) -> float:
    """CDF of Student's t with `df` degrees of freedom, through the incomplete beta:
    P(T <= x) = I_{df/(df+x^2)}(df/2, 1/2) / 2 for x <= 0 (and 1 minus that for x > 0).
    Checked in tests/test_forecast_baseline.py against the closed forms at df = 1 and 2 and a
    numerical integral of the density."""
    if not math.isfinite(x):
        return 0.0 if x < 0 else (1.0 if x > 0 else float("nan"))
    if df <= 0:
        return float("nan")
    tail = 0.5 * beta_cdf(df / (df + x * x), df / 2.0, 0.5)
    return tail if x <= 0 else 1.0 - tail


def dm_test(e1: Sequence[float], e2: Sequence[float], h: int = 1, power: int = 1) -> Dict[str, Any]:
    """
    Diebold-Mariano test with the Harvey-Leybourne-Newbold small-sample correction, one-sided:
    H1 "method 1 is more accurate than method 2". Written to match R's forecast::dm.test(e1, e2,
    alternative = "less", h, power): d = |e1|^power - |e2|^power, the long-run variance from the
    autocovariances of d up to lag h - 1 (divided by n, as R's acf does), the statistic mean(d) /
    sqrt(var / n) times sqrt((n + 1 - 2h + h(h - 1)/n) / n), referred to t with n - 1 degrees of
    freedom (Harvey, Leybourne & Newbold 1997). p is None when d has no variance (the two methods
    made the same misses): there is then no evidence either way.
    """
    a = np.asarray(e1, dtype=float)
    b = np.asarray(e2, dtype=float)
    if a.shape != b.shape:
        raise ValueError("dm_test needs paired errors")
    ok = np.isfinite(a) & np.isfinite(b)
    d = np.abs(a[ok]) ** int(power) - np.abs(b[ok]) ** int(power)
    n = int(len(d))
    h = int(h)
    out: Dict[str, Any] = {"n": n, "h": h, "power": int(power), "mean_d": float("nan"),
                           "statistic": float("nan"), "df": n - 1, "p": None}
    if n < 2 or h < 1 or h >= n:
        return out
    dbar = float(np.mean(d))
    c = d - dbar
    var = float(np.dot(c, c)) / n
    for k in range(1, h):
        var += 2.0 * float(np.dot(c[k:], c[:-k])) / n
    out["mean_d"] = dbar
    if not var > 0:
        return out
    stat = dbar / math.sqrt(var / n)
    corr = math.sqrt(max(0.0, (n + 1 - 2 * h + (h / float(n)) * (h - 1)) / n))
    stat *= corr
    out.update({"statistic": stat, "p": t_cdf(stat, n - 1)})
    return out


def _xlogy(n: float, p: float) -> float:
    """n * log(p) with 0 * log(0) = 0."""
    return 0.0 if n == 0 else n * math.log(p)


def christoffersen(hits: Sequence[bool], level: float) -> Dict[str, Any]:
    """
    Christoffersen (1998) tests on a time-ordered sequence of in-range indicators:
      unconditional coverage  LR_uc ~ chi2(1): the hit rate equals `level`;
      independence            LR_ind ~ chi2(1): a miss does not make the next miss likelier
                              (first-order Markov alternative);
      conditional coverage    LR_cc = LR_uc + LR_ind ~ chi2(2).
    Diagnostics only: with 12-24 checks they have little power and the chi-square reference
    is rough. A p-value is None when its statistic is undefined (no misses, or no
    transition out of a miss).
    """
    I = [bool(h) for h in hits]
    n = len(I)
    out: Dict[str, Any] = {"n": n, "lr_uc": None, "uc_p": None, "lr_ind": None, "ind_p": None,
                           "lr_cc": None, "cc_p": None}
    if n < 2:
        return out
    n1 = sum(I)
    n0 = n - n1
    pi = n1 / float(n)
    lr_uc = -2.0 * (_xlogy(n1, level) + _xlogy(n0, 1.0 - level) - _xlogy(n1, pi) - _xlogy(n0, 1.0 - pi))
    lr_uc = max(lr_uc, 0.0)
    out["lr_uc"], out["uc_p"] = lr_uc, chi2_sf(lr_uc, 1)
    # transitions, with True meaning a MISS (the event whose clustering matters)
    m = [not v for v in I]
    t00 = t01 = t10 = t11 = 0
    for a, b in zip(m[:-1], m[1:]):
        if not a and not b:
            t00 += 1
        elif not a and b:
            t01 += 1
        elif a and not b:
            t10 += 1
        else:
            t11 += 1
    if (t01 + t11) == 0 or (t10 + t11) == 0 or (t00 + t01) == 0:
        return out                       # no misses, or no transition out of a miss
    p01 = t01 / float(t00 + t01)
    p11 = t11 / float(t10 + t11)
    p2 = (t01 + t11) / float(t00 + t01 + t10 + t11)
    l0 = _xlogy(t00 + t10, 1.0 - p2) + _xlogy(t01 + t11, p2)
    l1 = _xlogy(t00, 1.0 - p01) + _xlogy(t01, p01) + _xlogy(t10, 1.0 - p11) + _xlogy(t11, p11)
    lr_ind = max(0.0, -2.0 * (l0 - l1))
    out["lr_ind"], out["ind_p"] = lr_ind, chi2_sf(lr_ind, 1)
    out["lr_cc"] = lr_uc + lr_ind
    out["cc_p"] = chi2_sf(lr_uc + lr_ind, 2)
    return out


# --------------------------------------------------------------------------- conformal band
def _alpha(level: float) -> float:
    return round(1.0 - float(level), 12)


def conformal_ranks(n: int, level: float) -> Optional[Tuple[int, int]]:
    """
    1-based ranks (l, u) of the sorted errors that bound an equal-tailed conformal band:
    l = floor((n + 1) * alpha / 2), u = ceil((n + 1) * (1 - alpha / 2)). None when either
    falls outside 1..n: the level cannot be supported from n errors. (A 1e-9 guard keeps
    float noise, e.g. (1 - 0.8) / 2 = 0.09999999999999998, from moving a rank.)
    """
    n = int(n)
    a = _alpha(level)
    l = int(math.floor((n + 1) * a / 2.0 + 1e-9))
    u = int(math.ceil((n + 1) * (1.0 - a / 2.0) - 1e-9))
    if n < 1 or l < 1 or u > n or u <= l:
        return None
    return l, u


def conformal_min_errors(level: float) -> int:
    """The fewest errors from which a band at `level` can be drawn (9 for 80%)."""
    n = 1
    while conformal_ranks(n, level) is None:
        n += 1
        if n > 100000:
            raise ValueError("level %r cannot be supported" % (level,))
    return n


def band_spread(n: int, level: float) -> Dict[str, Any]:
    """
    What a rank band from n errors promises, and how far THIS band's own coverage may sit
    from it. If the n + 1 errors are exchangeable, the band's coverage given its n errors is
    U_(u) - U_(l) ~ Beta(u - l, n + 1 - (u - l)) (Angelopoulos & Bates, section on the
    calibration-set size); its mean (u - l)/(n + 1) is the average-case coverage, at least
    `level`, and 1 - 2/(n + 1) is the most any band from n errors can reach.
    """
    n = int(n)
    r = conformal_ranks(n, level)
    top = (1.0 - 2.0 / (n + 1)) if n >= 1 else float("nan")
    if r is None:
        return {"n_errors": n, "ranks": None, "expected": float("nan"), "max_level": top,
                "p10": float("nan"), "p90": float("nan"), "p_below_level_minus_10": float("nan")}
    l, u = r
    a = float(u - l)
    b = float(n + 1) - a
    return {"n_errors": n, "ranks": [l, u], "expected": a / (n + 1), "max_level": top,
            "p10": beta_ppf(0.10, a, b), "p90": beta_ppf(0.90, a, b),
            "p_below_level_minus_10": beta_cdf(float(level) - 0.10, a, b)}


#: One-sided 5% normal quantile: lag-1 autocorrelation above z/sqrt(n) rejects white noise.
_DEP_Z = 1.6448536269514722
_DEP_MAX_R = 0.95          # a corrected autocorrelation is capped here
_DEP_MIN_NEFF = 2.0        # and the effective count floored here (the widening then tops out ~1.7x)


def dependence_widening(errs: Sequence[float], lag: Optional[int] = None) -> Dict[str, Any]:
    """
    How much a rank band from these time-ordered errors must widen because they move together.
    `lag` is how many steps after the last of them the error being covered falls (h for an
    h-month-ahead range: the last calibration error's target is the last observed month); None
    treats that error as unrelated to them.

    The conformal rank band assumes the n errors and the next one are exchangeable. Errors from
    consecutive backtest origins are not when the series has momentum: they cluster, so their
    spread understates the spread of an error further away, as if there were fewer of them.
    Measured on run_forecast (23 Sep 2026 review, scratchpad r1/fc-longh): on AR(1) 0.8-0.9
    series of 48-120 months the plain rank band's weakest horizon covered 72-78% (0.9 around a
    seasonal mean: 67-71%), while the errors' lag-1 autocorrelation was 0.55-0.78.

    Rule, treating the errors as an AR(1) sequence with coefficient r:
      r_hat   lag-1 sample autocorrelation of the errors (origin order);
      act only when r_hat > 1.645 / sqrt(n), a one-sided 5% test of white noise (Bartlett's
              standard error), so independent errors keep the exact rank band;
      r       = min(0.95, r_hat + (1 + 4 r_hat) / n): r_hat is biased low by about
              (1 + 4 rho) / n for AR(1) with an estimated mean (Kendall 1954; Marriott & Pope
              1954); uncorrected, AR(1) 0.8 with seasonality at 120 months stayed at 77.5% at
              twelve months ahead (1,000 series, a development run);
      n_eff   = max(2, n (1 - r) / (1 + r)): the errors' mean varies like the mean of n_eff
              independent ones (var ~ s^2 / n_eff), and their own spread is about s^2 (1 - 1/n_eff);
      c_h     = 2 r^h (1 - r^n) / (n (1 - r)): twice the covariance (in units of s^2) of the error
              h steps ahead with the errors' mean -- a month-ahead error stays close to recent
              errors, a year-ahead one does not (0 when lag is None);
      factor  = sqrt(max(1, [(1 + 1/n_eff - c_h) / (1 - 1/n_eff)] / [(1 + 1/n) / (1 - 1/n)])).
    The error to be covered sits from the errors' centre with variance s^2 (1 + 1/n_eff - c_h);
    for independent errors (n_eff = n, c_h = 0) the rank band already absorbs the ratio of that
    to the errors' own spread, so the band is widened, about the median error, by the ratio
    beyond it. It only ever widens (factor >= 1). This is a Gaussian AR(1) correction, not a
    theorem: whether it holds is what the benchmark's AR(1) 0.8/0.9 forecast cells measure, per
    horizon (tests/test_forecast_calibration.py).
    """
    e = np.asarray(errs, dtype=float)
    n = int(len(e))
    out: Dict[str, Any] = {"n": n, "lag": lag, "lag1": float("nan"), "significant": False,
                           "lag1_corrected": None, "n_effective": float(n), "c_h": 0.0, "factor": 1.0}
    core = _dependence_core(e, lag)
    if core is None:
        return out
    out["lag1"] = core[0]
    if core[1] is not None:
        out.update({"significant": True, "lag1_corrected": core[1], "n_effective": core[2],
                    "c_h": core[3], "factor": core[4]})
    return out


def _dependence_core(e: np.ndarray, lag: Optional[int]) -> Optional[Tuple[float, Optional[float], float, float, float]]:
    """(r_hat, r, n_eff, c_h, factor) for :func:`dependence_widening`; r is None when it does not act.
    Kept lean: it runs about 1,700 times per forecast (every replayed band of every model)."""
    n = int(len(e))
    if n < 3:
        return None
    d = e - float(e.sum()) / n
    den = float(np.dot(d, d))
    r_hat = float(np.dot(d[1:], d[:-1])) / den if den > 0 else 0.0
    if not r_hat > _DEP_Z / math.sqrt(n):
        return r_hat, None, float(n), 0.0, 1.0
    r = min(_DEP_MAX_R, r_hat + (1.0 + 4.0 * r_hat) / n)
    ne = max(_DEP_MIN_NEFF, n * (1.0 - r) / (1.0 + r))
    if ne >= n:
        return r_hat, None, float(n), 0.0, 1.0
    ch = (2.0 * r ** int(lag) * (1.0 - r ** n) / (n * (1.0 - r))) if lag is not None and lag >= 1 else 0.0
    ratio = ((1.0 + 1.0 / ne - ch) / (1.0 - 1.0 / ne)) / ((1.0 + 1.0 / n) / (1.0 - 1.0 / n))
    return r_hat, r, ne, ch, math.sqrt(max(1.0, ratio))


def _band(point: float, errs: np.ndarray, mode: str, level: float,
          dependence: str = "none", info: Optional[Dict[str, Any]] = None,
          lag: Optional[int] = None) -> Optional[Tuple[float, float]]:
    """
    The conformal rank band around `point`, or None when `level` needs more errors. With
    dependence="ar1_widen" and time-ordered errors, the band is widened about the median error by
    :func:`dependence_widening`'s factor for an error `lag` steps after the last of them (1 when
    the errors show no significant momentum); the widening's numbers are written into `info`.
    """
    raw = np.asarray(errs, dtype=float)
    e = np.sort(raw)
    r = conformal_ranks(len(e), level)
    if r is None:
        return None
    lo_q, hi_q = float(e[r[0] - 1]), float(e[r[1] - 1])
    if dependence == "ar1_widen":
        if info is not None:
            info.update(dependence_widening(raw, lag))
            fac = float(info["factor"])
        else:
            core = _dependence_core(raw, lag)
            fac = 1.0 if core is None else core[4]
        if fac > 1.0:
            m = len(e)                     # the median error, from the sorted errors
            c = float(e[m // 2]) if m % 2 else 0.5 * (float(e[m // 2 - 1]) + float(e[m // 2]))
            lo_q, hi_q = c - fac * (c - lo_q), c + fac * (hi_q - c)
    elif dependence != "none":
        raise ValueError("band_dependence must be 'ar1_widen' or 'none', not %r" % (dependence,))
    if mode == "ratio":
        return point * (1.0 + lo_q), point * (1.0 + hi_q)
    return point + lo_q, point + hi_q


def interval_score(lo: float, hi: float, y: float, level: float) -> float:
    """Gneiting & Raftery's interval score: width plus 2/alpha times any miss distance."""
    a = _alpha(level)
    return (hi - lo) + (2.0 / a) * max(0.0, lo - y) + (2.0 / a) * max(0.0, y - hi)


def _pct_signed(x: float) -> str:
    """A relative change as '+87.4%' (one decimal)."""
    return "%+.1f%%" % (100.0 * float(x))


def _pct_range(lo: float, hi: float) -> str:
    a, b = int(round(100 * float(lo))), int(round(100 * float(hi)))
    return "%d%%" % a if a == b else "%d%% to %d%%" % (a, b)


def band_sentence(n_errors: int, level: float = 0.80, measured: Optional[float] = None,
                  widened_by: float = 1.0, n_effective: Optional[float] = None,
                  measured_range: Optional[Sequence[float]] = None,
                  measured_widened: Optional[Sequence[float]] = None,
                  momentum: Optional[Sequence[float]] = None) -> str:
    """
    The owner-facing sentence of design §1.3 for a range drawn from `n_errors` past errors.
    `measured` (a share) or `measured_range` (low, high shares across the benchmark's stable
    cells) is the measured coverage of ranges built this way, from a benchmark receipt (see
    :func:`coverage_evidence`); without either the sentence says that figure is not yet
    published.

    A range widened for dependent errors (`widened_by` > 1, see :func:`dependence_widening`) is
    worded differently: the Beta spread of its own coverage assumes exchangeable errors and would
    overstate how precisely it is known, so it is not stated. `measured_widened` is the (low,
    high) pooled coverage of the benchmark's momentum cells (AR(1) coefficients `momentum` =
    (low, high)), and the words follow it: on the R1 receipt those ranges held 84-89% of months
    for a nominal 80% (the widening is conservative), which reads "err on the wide side".
    """
    pct = int(round(100 * level))
    if float(widened_by) > 1.0:
        ne = n_effective if n_effective is not None and math.isfinite(float(n_effective)) else None
        head = ("About %d%% of months are meant to land in ranges built this way. The %d past errors "
                "behind this one move together from month to month%s, so the range was widened by "
                "%d%% to allow for it." % (pct, int(n_errors),
                                           (", carrying the information of only about %d independent "
                                            "errors" % int(math.floor(float(ne)))) if ne else "",
                                           int(math.ceil(100 * (float(widened_by) - 1.0)))))
        if measured_widened is not None:
            mom = ""
            if momentum is not None:
                mom = " (month-to-month momentum %s)" % (
                    "%.1f" % momentum[0] if abs(momentum[0] - momentum[1]) < 1e-9
                    else "%.1f to %.1f" % (momentum[0], momentum[1]))
            lo_w, hi_w = float(measured_widened[0]), float(measured_widened[1])
            # the words follow the measurement: "wide side" only when every momentum cell held
            # at least the stated share (a later receipt that shows otherwise changes them)
            lead = ("Widened ranges err on the wide side" if lo_w >= level
                    else "Widened ranges still fall short" if hi_w < level
                    else "Widened ranges are not exact")
            meas = ("%s: on simulated series with strong momentum%s, ranges built this way held %s "
                    "of months, against the %d%% stated." % (lead, mom, _pct_range(lo_w, hi_w), pct))
        else:
            meas = ("The widening only ever makes a range wider; how often widened ranges hold on "
                    "series like this is not yet published for this engine version.")
        return ("%s %s How far this particular range's own hit rate may sit from that cannot be "
                "stated: the usual formula for it assumes independent errors." % (head, meas))
    sp = band_spread(int(n_errors), level)
    if sp["ranks"] is None:
        return ("No %d%% range is drawn: %d past error(s) cannot support one (it needs at least %d)."
                % (pct, int(n_errors), conformal_min_errors(level)))
    if measured is not None and math.isfinite(float(measured)):
        meas = "measured: %d%%" % int(round(100 * float(measured)))
    elif measured_range is not None:
        meas = "measured: %s on simulated steady series" % _pct_range(*measured_range)
    else:
        meas = "measured coverage not yet published"
    return ("About %d%% of months land in ranges built this way, on average across businesses "
            "like this (%s). With only %d past errors behind it, this particular range could be "
            "somewhat wider or narrower in truth: typically between %d%% and %d%%."
            % (pct, meas, int(n_errors), int(math.floor(100 * sp["p10"])),
               int(math.ceil(100 * sp["p90"]))))


def error_sentence(mase: Optional[float], skill: Optional[float] = None,
                   mape: Optional[float] = None, mape_suppressed: bool = False,
                   mape_min_share: float = 0.10, is_seasonal_naive: bool = False) -> str:
    """
    The forecast's replay error in the order design S7 sets: MASE first (scale-free, defined
    whenever the history varies), then skill against repeating the same month from last year,
    then MAPE as a secondary figure -- withheld when a replayed month was zero or near zero,
    where a percentage miss is undefined or explodes. Never sMAPE.
    """
    def fin(x: Any) -> bool:
        try:
            return x is not None and math.isfinite(float(x))
        except (TypeError, ValueError):
            return False

    if fin(mase):
        out = ("Replay error (MASE, the headline measure): %.2f, the method's average miss divided "
               "by the typical miss of repeating the same month from last year in the history before "
               "the replay (below 1 means smaller than that typical miss)." % float(mase))
    else:
        out = ("MASE is undefined: the history does not vary from month to month, so there is no "
               "typical miss to compare against.")
    if not is_seasonal_naive and fin(skill):
        sk = float(skill)
        if sk >= 0:
            out += (" Over the same replayed months it removed %d%% of that rule's own error."
                    % int(math.floor(100 * sk + 1e-9)))
        else:
            out += (" Over the same replayed months its error was %d%% larger than that rule's."
                    % int(math.ceil(-100 * sk - 1e-9)))
    if mape_suppressed or not fin(mape):
        out += (" Its miss is not stated as a share of the actual value: a replayed month was zero or "
                "under %d%% of the typical month, where a percentage miss is undefined or explodes."
                % int(round(100 * float(mape_min_share))))
    else:
        out += (" As a share of the actual value (secondary), it missed by %.1f%% on average."
                % float(mape))
    return out


# --------------------------------------------------------------------------- measured coverage
def decision_snapshot(engine_dir: Optional[str] = None) -> str:
    """The benchmark receipt's decision-code snapshot of this engine (sha256 of northledger/*.py
    without benchmark.py; the same digest as benchmark.engine_snapshots)."""
    import hashlib
    import os
    here = engine_dir or os.path.dirname(os.path.abspath(__file__))
    h = hashlib.sha256()
    for f in sorted(x for x in os.listdir(here) if x.endswith(".py") and x != "benchmark.py"):
        h.update(f.encode("utf-8") + b"\0")
        with open(os.path.join(here, f), "rb") as fh:
            h.update(fh.read())
        h.update(b"\0")
    return h.hexdigest()


def coverage_evidence(receipt: Optional[Dict[str, Any]],
                      expected_snapshot: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """
    The measured coverage of the 80% ranges, computed from a benchmark receipt's forecast cells
    (tools/run_benchmark.py): pooled coverage per gated cell, then the low and high across the
    STEADY cells (stable seasonal + noise; AR(1) below 0.8 around a level) and across the
    MOMENTUM cells (AR(1) 0.8 and above, around a level or a seasonal mean), where the ranges are
    widened for dependent errors. None without a receipt, when `expected_snapshot` is given and
    the receipt measured other decision code (a stale receipt is never quoted), or when it has no
    such cells.
    """
    if not receipt:
        return None
    got = str(((receipt.get("decision_code_snapshot") or {}).get("id")) or "")
    if expected_snapshot is not None:
        if not got or not (got.startswith(expected_snapshot) or expected_snapshot.startswith(got)):
            return None
    steady: List[Tuple[str, float, float]] = []
    moment: List[Tuple[str, float, float]] = []
    for r in (receipt.get("results") or {}).get("forecast") or []:
        c = r.get("cell") or {}
        cov = r.get("pooled_coverage")
        if not c.get("gated") or not r.get("n") or cov is None or not math.isfinite(float(cov)):
            continue
        if not any(int(h.get("n_band") or 0) for h in r.get("per_horizon") or []):
            continue
        proc, phi = c.get("process"), float(c.get("phi", 0.7) or 0.0)
        if proc == "ar1_season" or (proc == "ar1_level" and phi >= 0.8):
            moment.append((str(c.get("name")), float(cov), phi))
        elif proc in ("season_noise", "ar1_level"):
            steady.append((str(c.get("name")), float(cov), phi))
    if not steady and not moment:
        return None

    def span(rows: List[Tuple[str, float, float]]) -> Optional[Dict[str, Any]]:
        if not rows:
            return None
        return {"lo": min(x[1] for x in rows), "hi": max(x[1] for x in rows),
                "cells": [x[0] for x in rows], "phi": [min(x[2] for x in rows), max(x[2] for x in rows)]}
    return {"snapshot": got, "steady": span(steady), "momentum": span(moment)}


_EVIDENCE_CACHE: Dict[str, Any] = {}


def default_coverage_evidence() -> Optional[Dict[str, Any]]:
    """
    :func:`coverage_evidence` of the receipt shipped beside this engine
    (../benchmark/engine_benchmark.json), only when it measured this very decision code; None
    otherwise (no receipt, as in the browser pack, or a stale one). Read once per process.
    """
    if "default" in _EVIDENCE_CACHE:
        return _EVIDENCE_CACHE["default"]
    ev = None
    try:
        import os
        here = os.path.dirname(os.path.abspath(__file__))
        path = os.path.join(os.path.dirname(here), "benchmark", "engine_benchmark.json")
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as fh:
                ev = coverage_evidence(json.load(fh), expected_snapshot=decision_snapshot(here))
    except (OSError, ValueError, TypeError, KeyError):
        ev = None
    _EVIDENCE_CACHE["default"] = ev
    return ev


def _err(actual: float, pred: float, mode: str) -> float:
    if mode == "ratio":
        return actual / pred - 1.0
    return actual - pred


# --------------------------------------------------------------------------- the run
@dataclass
class ForecastResult:
    config: Dict[str, Any]
    start: str
    end: str
    history_months: int
    horizon: int
    holdout: int
    error_mode: str
    models: Dict[str, Dict[str, Any]]
    champion: str
    params: Dict[str, Any]
    beats_seasonal_naive: bool
    baseline_won: bool
    coverage: Dict[str, Any]
    forward: List[Dict[str, Any]]
    backtest: List[Dict[str, Any]]
    notes: List[str] = field(default_factory=list)
    #: the champion's replayed ranges' interval score (MSIS) against seasonal-naive's built the
    #: same way, and the score of the ranges the replay actually drew ("replay_msis")
    sharpness: Dict[str, Any] = field(default_factory=dict)
    #: design M7: the one-sided Diebold-Mariano test (HLN-corrected) of the nested-selection
    #: procedure's month-ahead misses against seasonal-naive's, on the scored replay origins
    baseline_test: Dict[str, Any] = field(default_factory=dict)
    #: named steps the fit spans (fixer round, 24 Sep 2026): their months and sizes, and how many
    #: replayed forecasts made before a step and scored after it were left out (run_forecast)
    step: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "config": dict(self.config), "start": self.start, "end": self.end,
            "history_months": self.history_months, "horizon": self.horizon,
            "holdout": self.holdout, "error_mode": self.error_mode,
            "models": self.models, "champion": self.champion, "params": self.params,
            "beats_seasonal_naive": self.beats_seasonal_naive, "baseline_won": self.baseline_won,
            "coverage": dict(self.coverage), "forward": list(self.forward),
            "backtest": list(self.backtest), "notes": list(self.notes),
            "sharpness": dict(self.sharpness), "baseline_test": dict(self.baseline_test),
            "step": dict(self.step),
        }

    def target(self, name: str) -> float:
        """A named number from the result: the contract between a Fact and `recompute`."""
        if name.startswith("forward."):
            what, _, h = name[len("forward."):].partition("@")
            row = self.forward[int(h) - 1]
            return float(row[what])
        if name.startswith("champion."):
            return float(self.models[self.champion][name.split(".", 1)[1]])
        if name.startswith("model."):
            _, model, metric = name.split(".", 2)
            return float(self.models[model][metric])
        if name.startswith("coverage."):
            v = self.coverage[name.split(".", 1)[1]]
            return float("nan") if v is None else float(v)
        if name.startswith("sharpness."):
            v = self.sharpness.get(name.split(".", 1)[1])
            return float("nan") if v is None else float(v)
        if name.startswith("baseline_test."):
            v = self.baseline_test.get(name.split(".", 1)[1])
            return float("nan") if v is None else float(v)
        if name == "history_months":
            return float(self.history_months)
        if name == "holdout":
            return float(self.holdout)
        raise KeyError("unknown forecast target %r" % (name,))


def prepare_series(rows: Sequence[Tuple[Any, Any]], fill: str = "zero") -> Tuple[List[int], np.ndarray]:
    """(month, value) rows -> contiguous month indexes and values. Gaps: 0 or refusal."""
    pts: Dict[int, float] = {}
    for m, v in rows:
        if m is None or v is None:
            continue
        idx = month_index(str(m))
        if idx in pts:
            raise ForecastError("month %s appears twice in the series" % month_label(idx))
        fv = float(v)
        if not math.isfinite(fv):
            raise ForecastError("month %s is not a finite number" % month_label(idx))
        pts[idx] = fv
    if not pts:
        raise ForecastError("the series is empty")
    lo, hi = min(pts), max(pts)
    months = list(range(lo, hi + 1))
    missing = [i for i in months if i not in pts]
    if missing and fill != "zero":
        raise ForecastError("the series has %d missing month(s), first %s"
                            % (len(missing), month_label(missing[0])))
    return months, np.array([pts.get(i, 0.0) for i in months], dtype=float)


def _baseline_test(y: np.ndarray, origins: Sequence[int], start: int,
                   preds: Dict[str, np.ndarray], sel: Sequence[str], n: int,
                   skip: Any = None) -> Dict[str, Any]:
    """
    Design §2.1 M7: does the forecasting PROCEDURE beat seasonal-naive one month ahead? At each
    replay origin from `start` on, the procedure's forecast is the model it would have picked then
    (nested selection, `sel`), so picking the best of the five candidates is inside the thing
    being tested rather than a free look at the answers. Its month-ahead absolute misses are
    paired with seasonal-naive's on the same months and compared by :func:`dm_test`
    (one-sided, HLN-corrected, t with n - 1 degrees of freedom).
    """
    out: Dict[str, Any] = {"method": "dm_hln_nested_h1", "n": 0, "p": None, "statistic": None,
                           "procedure_mae_h1": None, "seasonal_naive_mae_h1": None, "gain": None,
                           "share_seasonal_naive": None}
    if "seasonal_naive" not in preds:
        return out
    # skip(k): a month-ahead forecast from train length k that measures a named step, not the
    # method (run_forecast's straddles); it is paired with neither side
    idx = [i for i in range(start, len(origins)) if origins[i] < n
           and not (skip is not None and skip(origins[i]))]
    if not idx:
        return out
    act = np.array([y[origins[i]] for i in idx], dtype=float)
    e_proc = act - np.array([preds[sel[i]][i, 0] for i in idx], dtype=float)
    e_sn = act - np.array([preds["seasonal_naive"][i, 0] for i in idx], dtype=float)
    dm = dm_test(e_proc, e_sn, h=1, power=1)
    mp, ms = float(np.mean(np.abs(e_proc))), float(np.mean(np.abs(e_sn)))
    out.update({"n": int(dm["n"]), "p": dm["p"],
                "statistic": dm["statistic"] if math.isfinite(dm["statistic"]) else None,
                "procedure_mae_h1": mp, "seasonal_naive_mae_h1": ms,
                "gain": (1.0 - mp / ms) if ms > 0 else None,
                "share_seasonal_naive": sum(1 for i in idx if sel[i] == "seasonal_naive") / float(len(idx))})
    return out


def min_history_months(config: Optional[Dict[str, Any]] = None) -> int:
    """The fewest months run_forecast can backtest (at a horizon of one month): the training
    months, the errors a first range needs, and the minimum replay."""
    cfg = dict(DEFAULT_CONFIG)
    cfg.update(config or {})
    return (int(cfg["min_train"]) + max(int(cfg["min_band_errors"]), conformal_min_errors(float(cfg["band"])))
            + int(cfg["min_holdout"]))


def run_forecast(months: Sequence[int], values: Sequence[float],
                 config: Optional[Dict[str, Any]] = None) -> ForecastResult:
    """The whole method: trim, backtest every model, pick the champion, band, forecast."""
    cfg = dict(DEFAULT_CONFIG)
    cfg.update(config or {})
    months = list(months)
    y_all = np.asarray(values, dtype=float)
    notes: List[str] = []
    if len(y_all) != len(months):
        raise ForecastError("months and values differ in length")
    keep = int(cfg["max_history"])
    if len(y_all) > keep:
        notes.append("used the most recent %d of %d months" % (keep, len(y_all)))
        months, y_all = months[-keep:], y_all[-keep:]
    if cfg.get("fit_from"):
        # after a detected step: learn and replay only on the months from the step on
        m_from = month_index(str(cfg["fit_from"]))
        idx = [i for i, m in enumerate(months) if m >= m_from]
        if len(idx) < len(months):
            notes.append("fitted and replayed on the %d months from %s on: the series stepped there, "
                         "and months before the step would teach the models a level it has left"
                         % (len(idx), month_label(m_from)))
            months, y_all = [months[i] for i in idx], y_all[idx]
    n = len(y_all)
    m0 = months[0] % SEASON
    mode = "ratio" if np.all(y_all > 0) else "additive"
    # Named steps the forecast could not fit around (cfg "step_month" with "steps", from the
    # change test; fixer round, 24 Sep 2026). Their positions in the series and their sizes:
    #  * a replayed error whose model saw only months before a step but whose target is at or
    #    after it (origin <= step <= target) measures the step, a known event, not the method:
    #    it is left out of every range, of the replay's scores and of model choice. Left in, the
    #    month-ahead miss at the building purchase (+107%) put the rent fan at 74k-123k around
    #    82k, with every month since the step inside 80k-89k;
    #  * "the same month last year" is scaled by each step in between (_seasonal_naive), so the
    #    skill test compares the method with a rule that knows the step, not with a rule still
    #    repeating the old level (which any method beats).
    step_pos: List[Tuple[int, float]] = []
    if cfg.get("step_month") and not cfg.get("fit_from"):
        for st in (cfg.get("steps") or [{"month": cfg["step_month"], "size": None}]):
            try:
                p_ = month_index(str(st["month"])) - months[0]
            except (KeyError, ValueError, TypeError):
                continue
            size = st.get("size")
            if 0 < p_ < n:
                step_pos.append((int(p_), 1.0 + float(size) if size is not None
                                 and math.isfinite(float(size)) and float(size) > -1.0 else 1.0))
    mcfg = dict(cfg, step_pos=[[p_, r_] for p_, r_ in step_pos]) if step_pos else cfg
    straddled = [0]

    def straddles(k: int, t: int) -> bool:
        """The model saw only months before a step (train length k <= step) and the target t is
        at or after it."""
        return any(k <= p_ <= t for p_, _r in step_pos)
    nn_cfg = cfg.get("nonnegative", "auto")
    floor0 = bool(np.all(y_all >= 0)) if nn_cfg in ("auto", None) else bool(nn_cfg)
    clipped = [False]

    min_train = int(cfg["min_train"])
    # a configured minimum below what the conformal ranks need is raised, never used
    min_err = max(int(cfg["min_band_errors"]), conformal_min_errors(float(cfg["band"])))
    available = n - min_train
    horizon = int(cfg["horizon"])
    # Shorten the horizon before the backtest: every scored origin needs `min_err` earlier
    # errors at each horizon it draws a band for.
    while horizon > 1 and available - (horizon + min_err - 1) < int(cfg["min_holdout"]):
        horizon -= 1
    warm = horizon + min_err - 1
    holdout = min(int(cfg["max_holdout"]), available - warm)
    if holdout < 1:
        raise ForecastError("the series has %d months; a backtest needs at least %d"
                            % (n, min_train + warm + 1))
    if horizon < int(cfg["horizon"]):
        notes.append("horizon shortened to %d month(s): a longer one would leave fewer than %d "
                     "backtest months with a band" % (horizon, int(cfg["min_holdout"])))

    first = n - holdout - warm              # train length at the first origin
    origins = list(range(first, n))         # train lengths; the last origin predicts month n
    n_org = len(origins)
    scored_from = warm                      # position of the first scored origin

    # scale for MASE: in-sample seasonal-naive error before the first scored origin
    train_end = origins[scored_from]
    base = y_all[:train_end]
    diffs = np.abs(base[SEASON:] - base[:-SEASON] * np.array(
        [_step_scale(step_pos, j, j + SEASON) for j in range(len(base) - SEASON)])) \
        if len(base) > SEASON else np.array([])
    scale = float(np.mean(diffs)) if len(diffs) else 0.0
    if not scale > 0:
        d1 = np.abs(np.diff(base))
        scale = float(np.mean(d1)) if len(d1) else 0.0

    level = float(cfg["band"])
    dep = str(cfg.get("band_dependence", "none"))
    if dep not in ("ar1_widen", "none"):
        raise ValueError("band_dependence must be 'ar1_widen' or 'none', not %r" % (dep,))
    # MAPE is secondary and is withheld near zero (design S7): the scored actuals are the same
    # for every model, so this is decided once, for the series.
    act = np.array([y_all[origins[i] + hh] for i in range(scored_from, n_org)
                    for hh in range(horizon) if origins[i] + hh < n
                    and not straddles(origins[i], origins[i] + hh)], dtype=float)
    typical = float(np.mean(np.abs(act))) if len(act) else 0.0
    mape_ok = bool(len(act)) and typical > 0 and \
        float(np.min(np.abs(act))) >= float(cfg.get("mape_min_share", 0.10)) * typical
    if not mape_ok:
        notes.append("the average miss is not stated as a share of the actual value: a replayed "
                     "month was zero or under %d%% of the typical month, where a percentage miss "
                     "is undefined or explodes; MASE carries the error instead"
                     % int(round(100 * float(cfg.get("mape_min_share", 0.10)))))

    def errors_of(P: np.ndarray) -> np.ndarray:
        """Backtest errors by origin and horizon (ratio errors need a positive forecast)."""
        E = np.full((n_org, horizon), np.nan)
        for i, k in enumerate(origins):
            for hh in range(horizon):
                t = k + hh
                if t < n and (mode == "additive" or P[i, hh] > 0) and not straddles(k, t):
                    E[i, hh] = _err(y_all[t], P[i, hh], mode)
        return E

    def replay_bands(P: np.ndarray, E: np.ndarray) -> Dict[Tuple[int, int], Tuple[float, float]]:
        """The band each scored backtest forecast had, from errors observable at its origin."""
        out: Dict[Tuple[int, int], Tuple[float, float]] = {}
        for i in range(scored_from, n_org):
            for hh in range(horizon):
                if origins[i] + hh >= n:
                    continue
                # errors at this horizon from origins whose target was already observed at k
                prior = E[: max(0, i - hh), hh]
                prior = prior[np.isfinite(prior)]
                if len(prior) < min_err or (mode == "ratio" and not P[i, hh] > 0):
                    continue
                # the error to cover falls hh + 1 months after the last prior error's target
                b = _band(float(P[i, hh]), prior, mode, level, dep, lag=hh + 1)
                if b is None:
                    continue
                lo, hi = b
                if floor0 and lo < 0:
                    lo, hi, clipped[0] = 0.0, max(hi, 0.0), True
                out[(i, hh)] = (float(lo), float(hi))
        return out

    models: Dict[str, Dict[str, Any]] = {}
    preds: Dict[str, np.ndarray] = {}
    errs_of: Dict[str, np.ndarray] = {}
    bands_of: Dict[str, Dict[Tuple[int, int], Tuple[float, float]]] = {}
    iscore_of: Dict[str, Dict[Tuple[int, int], float]] = {}
    for name in MODEL_NAMES:
        P = np.full((n_org, horizon), np.nan)
        ok = True
        for i, k in enumerate(origins):
            try:
                P[i], _ = fit_predict(name, y_all[:k], horizon, m0, mcfg)
                if floor0 and np.any(P[i] < 0):
                    # a monthly count forecast at -14 rows (QA, 23 Sep 2026) is not a forecast
                    P[i] = np.maximum(P[i], 0.0)
                    clipped[0] = True
            except ForecastError:
                ok = False
                break
        if not ok or not np.all(np.isfinite(P)):
            models[name] = {"applicable": False}
            continue
        preds[name] = P
        E_m = errors_of(P)
        bands = replay_bands(P, E_m)
        errs_of[name], bands_of[name] = E_m, bands
        iscore_of[name] = {key: interval_score(lo, hi, float(y_all[origins[key[0]] + key[1]]), level)
                           for key, (lo, hi) in bands.items()}
        aerr, pct = [], []
        by_h = []
        for hh in range(horizon):
            e_h, p_h = [], []
            for i in range(scored_from, n_org):
                t = origins[i] + hh
                if t < n and not straddles(origins[i], t):
                    e = y_all[t] - P[i, hh]
                    e_h.append(abs(e))
                    aerr.append(abs(e))
                    if mape_ok:
                        pct.append(abs(e) / abs(y_all[t]))
                        p_h.append(abs(e) / abs(y_all[t]))
            by_h.append({"h": hh + 1, "mae": float(np.mean(e_h)) if e_h else None,
                         "mape": float(100.0 * np.mean(p_h)) if p_h else None, "n": len(e_h)})
        mae = float(np.mean(aerr))
        isc = list(iscore_of[name].values())
        models[name] = {
            "applicable": True,
            "mae": mae,
            # headline error: MASE (design S7); MAPE secondary, withheld near zero
            "mase": (mae / scale) if scale > 0 else float("nan"),
            "mape": float(100.0 * np.mean(pct)) if pct else float("nan"),
            # the month-ahead and the furthest-ahead miss, which a reader can picture
            "mape_h1": by_h[0]["mape"] if by_h[0]["mape"] is not None else float("nan"),
            "mape_end": by_h[-1]["mape"] if by_h[-1]["mape"] is not None else float("nan"),
            "mape_suppressed": not mape_ok,
            # interval score of this model's own replayed 80% ranges, scaled like MASE
            "msis": (float(np.mean(isc)) / scale) if (isc and scale > 0) else float("nan"),
            "n_msis": len(isc),
            "n_errors": len(aerr),
            "n_mape": len(pct),
            "by_horizon": by_h,
        }

    usable = [m for m in MODEL_NAMES if models.get(m, {}).get("applicable")]
    if not usable:
        raise ForecastError("no model could be fitted on this series")
    # lowest backtest MAE; ties go to the earlier (simpler) model in MODEL_NAMES order. Chosen
    # on absolute error, the point forecast is a median-type forecast (Kolassa 2020).
    champion = min(usable, key=lambda m: (models[m]["mae"], MODEL_NAMES.index(m)))
    P = preds[champion]
    sn = models.get("seasonal_naive", {})
    beats = bool(sn.get("applicable")) and champion != "seasonal_naive" and \
        models[champion]["mase"] < sn["mase"]
    sn_mase = sn.get("mase") if sn.get("applicable") else None
    for name in usable:
        mm = models[name]["mase"]
        models[name]["skill_vs_sn"] = (
            1.0 - mm / sn_mase if sn_mase is not None and math.isfinite(float(sn_mase))
            and sn_mase > 0 and math.isfinite(float(mm)) else float("nan"))

    # The range's calibration errors: the champion's, the procedure's (nested selection), or
    # the envelope of the two (see DEFAULT_CONFIG["band_errors"]).
    band_errors = str(cfg.get("band_errors", "envelope"))
    if band_errors not in ("nested", "envelope", "champion"):
        raise ValueError("band_errors must be 'nested', 'envelope' or 'champion', not %r" % band_errors)
    # Nested selection (design S4): at each backtest origin, the model with the lowest MAE on
    # the errors known THEN (seasonal-naive before any are known). Its errors are those of the
    # whole procedure, free of the optimism of choosing on the errors being scored; they feed
    # the range (below) and the baseline test (design M7).
    tgt = np.asarray(origins)[:, None] + np.arange(horizon)[None, :]
    valid = tgt < n
    if step_pos:
        valid = valid & ~np.array([[straddles(k, k + hh) for hh in range(horizon)] for k in origins],
                                  dtype=bool)
        straddled[0] = int(np.sum((tgt < n) & ~valid))
    absm = {m: np.where(valid, np.abs(y_all[np.minimum(tgt, n - 1)] - preds[m]), np.nan)
            for m in usable}
    fallback = "seasonal_naive" if "seasonal_naive" in usable else usable[0]
    sel_nested: List[str] = []
    for i in range(n_org):
        known = valid & (tgt < origins[i])           # every target observed before this origin
        if not known.any():
            sel_nested.append(fallback)              # nothing known yet: the baseline
            continue
        sel_nested.append(min(usable, key=lambda m: (float(np.mean(absm[m][known])),
                                                     MODEL_NAMES.index(m))))
    # The test's months: every origin at which the procedure could already see at least
    # `baseline_test_min_known` replayed errors (any horizon) to choose from -- not only the
    # scored origins, which need 9 earlier errors per horizon for a RANGE but nothing for a point
    # forecast. Measured on the benchmark's cells (300 series each, 23 Sep 2026): against the
    # scored origins alone this raised the test's power on skilled series (stable seasonal 72
    # months 36% -> 46%, 120 months 39% -> 56%) and left the seasonal random walk at 3 in 1,000.
    # Full-size receipt (1,000 series per cell, master seed): seasonal random walk 48 months
    # 42 -> 3 in 1,000 and 72 months 13 -> 0; the cost is advice on skilled series (stable
    # seasonal + noise 72 months 83% -> 42%, AR(1) 0.7 72 months 68% -> 55%).
    min_known = int(cfg.get("baseline_test_min_known", 12))
    bt_from = next((i for i in range(n_org) if int((valid & (tgt < origins[i])).sum()) >= min_known),
                   scored_from)
    baseline = _baseline_test(y_all, origins, min(bt_from, scored_from), preds, sel_nested, n,
                              skip=(lambda k: straddles(k, k)) if step_pos else None)
    E_env: Optional[np.ndarray] = None
    if band_errors in ("nested", "envelope"):
        sel = list(sel_nested)
        Pb = np.vstack([preds[m][i] for i, m in enumerate(sel)])
        E = errors_of(Pb)
        if band_errors == "envelope":
            # the champion's point, and a range that must hold under BOTH calibrations: the
            # champion's own errors and the procedure's, each around the champion's point
            E_env = E
            nb = replay_bands(P, E)
            cb = bands_of[champion]
            Pb, E, sel = P, errs_of[champion], [champion] * n_org
            bands = {key: (min(cb[key][0], nb[key][0]), max(cb[key][1], nb[key][1]))
                     for key in cb if key in nb}
        else:
            bands = replay_bands(Pb, E)
        iscore_b = {key: interval_score(lo, hi, float(y_all[origins[key[0]] + key[1]]), level)
                    for key, (lo, hi) in bands.items()}
    else:
        sel = [champion] * n_org
        Pb, E, bands, iscore_b = P, errs_of[champion], bands_of[champion], iscore_of[champion]
    chosen: Dict[str, int] = {}
    for m in sel[scored_from:]:
        chosen[m] = chosen.get(m, 0) + 1

    # Sharpness (design M8): the champion's interval score against a seasonal-naive range
    # built the same way -- each model's replayed ranges from its OWN earlier errors -- on the
    # months both scored. It is a comparison of the two models as range-makers; the ranges the
    # replay shows (above) are scored separately as "replay_msis".
    sharp: Dict[str, Any] = {"champion_msis": float("nan"), "seasonal_naive_msis": float("nan"),
                             "n": 0, "better": None, "band_errors": band_errors,
                             "replay_msis": (float(np.mean(list(iscore_b.values()))) / scale
                                             if iscore_b and scale > 0 else float("nan")),
                             "chosen_in_replay": chosen}
    if sn.get("applicable") and scale > 0:
        common = sorted(set(iscore_of[champion]) & set(iscore_of["seasonal_naive"]))
        if common:
            c_ = float(np.mean([iscore_of[champion][k] for k in common])) / scale
            s_ = float(np.mean([iscore_of["seasonal_naive"][k] for k in common])) / scale
            sharp.update({"champion_msis": c_, "seasonal_naive_msis": s_, "n": len(common),
                          "better": bool(c_ < s_)})

    backtest_rows: List[Dict[str, Any]] = []
    hits = total = h1_hits = h1_total = 0
    h1_seq: List[bool] = []
    for i in range(scored_from, n_org):
        k = origins[i]
        for hh in range(horizon):
            t = k + hh
            if t >= n or straddles(k, t):
                continue
            lo = hi = None
            inside = None
            if (i, hh) in bands:
                lo, hi = bands[(i, hh)]
                inside = bool(lo <= y_all[t] <= hi)
                total += 1
                hits += int(inside)
                if hh == 0:
                    h1_total += 1
                    h1_hits += int(inside)
                    h1_seq.append(inside)
            backtest_rows.append({
                "origin": month_label(months[k - 1]), "month": month_label(months[t]), "h": hh + 1,
                "model": sel[i], "point": float(Pb[i, hh]),
                "lo80": None if lo is None else float(lo), "hi80": None if hi is None else float(hi),
                "actual": float(y_all[t]), "in_band": inside,
            })
    # The gate reads the MONTH-AHEAD checks: one per replayed month, so the binomial test means
    # what it says. Checks at longer horizons overlap (one surprise month spoils up to h of
    # them); they are reported alongside, never used to claim precision.
    wl, wh = wilson(h1_hits, h1_total)
    ch = christoffersen(h1_seq, level)
    coverage = {"hits": h1_hits, "n": h1_total,
                "rate": (h1_hits / float(h1_total)) if h1_total else float("nan"),
                "wilson_lo": wl, "wilson_hi": wh,
                # exact two-sided binomial test of "coverage = the nominal level" (design M8)
                "binomial_p": binom_test_two_sided(h1_hits, h1_total, level) if h1_total else float("nan"),
                "christoffersen_uc_p": ch["uc_p"], "christoffersen_ind_p": ch["ind_p"],
                "christoffersen_cc_p": ch["cc_p"],
                "all_hits": hits, "all_n": total,
                "all_rate": (hits / float(total)) if total else float("nan")}

    point, params = fit_predict(champion, y_all, horizon, m0, mcfg)
    if floor0 and np.any(point < 0):
        point, clipped[0] = np.maximum(point, 0.0), True
    forward: List[Dict[str, Any]] = []
    widened: List[Tuple[int, float, float, float]] = []   # (h, factor, n_eff, lag-1) when widened
    for hh in range(horizon):
        errs = E[:, hh]
        errs = errs[np.isfinite(errs)]
        w1: Dict[str, Any] = {}
        w2: Dict[str, Any] = {}
        b = _band(float(point[hh]), errs, mode, level, dep, w1, lag=hh + 1) \
            if len(errs) >= min_err and (mode == "additive" or point[hh] > 0) else None
        if b is not None and E_env is not None:
            e2 = E_env[:, hh]
            e2 = e2[np.isfinite(e2)]
            b2 = _band(float(point[hh]), e2, mode, level, dep, w2, lag=hh + 1) if len(e2) >= min_err else None
            b = None if b2 is None else (min(b[0], b2[0]), max(b[1], b2[1]))
        # the dependence statement of this range: the larger widening of the two calibrations
        fac = max(float(w1.get("factor", 1.0)), float(w2.get("factor", 1.0)))
        neff = min(float(w1.get("n_effective", len(errs))), float(w2.get("n_effective", len(errs))))
        lags = [float(w["lag1"]) for w in (w1, w2) if math.isfinite(float(w.get("lag1", float("nan"))))]
        lag1 = max(lags) if lags else float("nan")
        if b is not None and fac > 1.0:
            widened.append((hh + 1, fac, neff, lag1))
        if b is not None:
            lo, hi = b
            if floor0 and lo < 0:
                lo, hi, clipped[0] = 0.0, max(hi, 0.0), True
        else:
            lo = hi = float("nan")
        sp = band_spread(len(errs), level) if b is not None else band_spread(0, level)
        if b is not None and fac > 1.0:
            # the Beta spread of a range's own coverage assumes exchangeable errors; for a range
            # widened because its errors move together it would overstate the precision, so it
            # is not stated (band_sentence says why)
            sp = dict(sp, p10=float("nan"), p90=float("nan"))
        forward.append({"month": month_label(months[-1] + hh + 1), "h": hh + 1,
                        "point": float(point[hh]), "lo80": float(lo), "hi80": float(hi),
                        "n_errors": int(len(errs)),
                        # what this range promises and how far its own coverage may sit from it
                        "ranks": sp["ranks"], "expected_coverage": float(sp["expected"]),
                        "max_level": float(sp["max_level"]),
                        "coverage_p10": float(sp["p10"]), "coverage_p90": float(sp["p90"]),
                        # how far the errors behind it move together, and what that cost
                        "errors_lag1": float(lag1),
                        "n_effective": float(neff) if b is not None else float("nan"),
                        "widened_by": float(fac) if b is not None else float("nan")})

    if widened:
        top = max(widened, key=lambda x: x[1])
        notes.append("the past errors behind the %d%% ranges move together from month to month "
                     "(lag-1 autocorrelation up to %.2f), so they carry the information of fewer "
                     "independent errors (as few as about %d); the ranges for %d of %d months ahead "
                     "were widened, by up to %d%%, to allow for it"
                     % (int(round(100 * level)), max(x[3] for x in widened),
                        int(math.floor(min(x[2] for x in widened))), len(widened), horizon,
                        int(math.ceil(100 * (top[1] - 1.0)))))

    if clipped[0]:
        notes.append("the series has never been below zero, so forecasts and 80% ranges below "
                     "zero were set to zero")
    if cfg.get("step_month"):
        notes.append("the series stepped in %s, and the months since are too few to fit and replay "
                     "a forecast on alone (that needs %d), so the models learned across the step"
                     % (str(cfg["step_month"]), min_history_months(cfg)))
        if step_pos:
            notes.append("the %d replayed forecasts that were made before a step and scored after it "
                         "measure the step, not the method, so they are left out of the ranges and the "
                         "replay scores, and the same-month-last-year rule is scaled by the step (%s) "
                         "for months whose last-year value is from before it"
                         % (straddled[0], "; ".join("%s at %s" % (_pct_signed(r_ - 1.0),
                                                                    month_label(months[0] + p_))
                                                    for p_, r_ in step_pos)))
    if cfg.get("step_month") and len(forward) > 1:
        # fitted across a step it could not fit around (see USEFUL_RANGE_RATIO): months ahead are
        # shown only while the 80% range is at most a factor `ratio` wide
        ratio = float(cfg.get("useful_range_ratio") or USEFUL_RANGE_RATIO)
        shown = 1
        for row in forward[1:]:
            lo_, hi_ = float(row["lo80"]), float(row["hi80"])
            if not (math.isfinite(lo_) and math.isfinite(hi_) and lo_ > 0 and hi_ <= ratio * lo_):
                break
            shown += 1
        if shown < len(forward):
            notes.append("months ahead shown: %d of %d; after a step the forecast could not fit "
                         "around, a month ahead is shown only while its 80%% range's high end is at "
                         "most %s times its low end" % (shown, len(forward), ("%g" % ratio)))
            forward = forward[:shown]
            horizon = shown
    return ForecastResult(
        config=cfg, start=month_label(months[0]), end=month_label(months[-1]),
        history_months=n, horizon=horizon, holdout=holdout, error_mode=mode,
        models=models, champion=champion, params=params, beats_seasonal_naive=beats,
        baseline_won=champion in BASELINES, coverage=coverage, forward=forward,
        backtest=backtest_rows, notes=notes, sharpness=sharp, baseline_test=baseline,
        step=({"steps": [{"month": month_label(months[0] + p_), "size": r_ - 1.0} for p_, r_ in step_pos],
               "straddled": straddled[0]} if step_pos else {}),
    )


# --------------------------------------------------------------------------- policy + gate
@dataclass
class ForecastPolicy:
    """
    The bars a forecast must clear. GatePolicy lives in gate.py; when it grows fields
    with these names, :func:`policy_from` reads them from there, so there is one
    place to tune conservatism.
    """
    min_history_months: int = 36
    min_holdout: int = 12
    # Design §2.1 M8: the replay can only FALSIFY a range. WATCH when an exact two-sided
    # binomial test rejects "month-ahead coverage = the nominal level" at this level. (It was
    # an acceptance window [0.65, 0.95], which called 12 of 12 hits "too wide", 7 of 12 "too
    # narrow", and passed a range whose true coverage is 60% with probability 0.44.)
    coverage_test_alpha: float = 0.05
    # WATCH when the champion's replayed ranges are not sharper (lower MSIS) than
    # seasonal-naive's ranges built the same way, on the same replayed months.
    require_sharper_than_baseline: bool = True
    must_beat: str = "seasonal_naive"
    data_health_floor: float = 70.0
    # Design §2.1 M7: "beats seasonal-naive" must be SHOWN, not just observed. The procedure
    # (nested selection) must beat seasonal-naive one month ahead in a one-sided
    # Diebold-Mariano test (HLN-corrected) at this level, on at least baseline_test_min_n
    # paired months. A lower MASE alone called a seasonal random walk -- where seasonal-naive is
    # the best possible forecast -- advice in 22 of 500 series at 48 months (R1 receipt).
    require_baseline_test: bool = True
    baseline_test_alpha: float = 0.05
    baseline_test_min_n: int = 12


def policy_from(policy: Any = None) -> ForecastPolicy:
    fp = ForecastPolicy()
    if isinstance(policy, ForecastPolicy):
        return policy
    for name in ("min_history_months", "min_holdout", "coverage_test_alpha",
                 "require_sharper_than_baseline", "must_beat", "data_health_floor",
                 "require_baseline_test", "baseline_test_alpha", "baseline_test_min_n"):
        for alias in (name, "forecast_" + name):
            if policy is not None and hasattr(policy, alias):
                setattr(fp, name, getattr(policy, alias))
                break
    return fp


def _pct0(x: float) -> str:
    return "%d%%" % int(math.floor(100.0 * x + 1e-9))


def _chances(p: float) -> str:
    """A p-value as 'about X of 100' (at least 'under 1')."""
    x = 100.0 * float(p)
    return "under 1" if x < 1 else "about %d" % int(round(x))


def payload_of(fact: Fact) -> Optional[Dict[str, Any]]:
    if fact.query_kind != "model":
        return None
    try:
        p = json.loads(fact.query)
    except (TypeError, ValueError):
        return None
    return p if isinstance(p, dict) and p.get("kind") == PAYLOAD_KIND else None


def gate_forecast(fact: Fact, policy: Any = None) -> GateResult:
    """
    RECOMMEND / WATCH / INSUFFICIENT for a forecast fact. Rules, first match wins:
      1. source data health under the floor                     -> INSUFFICIENT
      1b. the first forecast month is more than a month before the analysis date (the data
          stopped long ago: a forecast of it is history, not a plan) -> INSUFFICIENT
      2. no forecast payload, or history under min_history_months -> INSUFFICIENT
      3. backtest shorter than min_holdout months                -> INSUFFICIENT
      4. champion does not beat seasonal-naive on MASE           -> WATCH
      4b. the whole procedure (nested selection) is not shown to beat seasonal-naive one month
         ahead: one-sided Diebold-Mariano (HLN) p > baseline_test_alpha, fewer than
         baseline_test_min_n paired months, or identical misses -> WATCH  baseline_not_shown
         (design M7; a payload written before M7 has no such keys and skips this rule)
      5. an exact two-sided binomial test REJECTS month-ahead coverage = the nominal level
         at coverage_test_alpha (the replay falsifies the range)  -> WATCH  band_miscalibrated
         (Christoffersen's independence and conditional-coverage p-values ride along in the
         signals as diagnostics; they never gate: at 12-24 checks they have little power)
      5b. the champion's replayed ranges are not sharper than seasonal-naive's built the same
         way (MSIS, same months)                                  -> WATCH  band_not_sharper
      6. unmodelled confounders on the fact                      -> WATCH
      7. otherwise                                               -> RECOMMEND
    A range that passes rule 5 is NOT certified: the replay can reveal a badly calibrated
    range, never prove a good one. The RECOMMEND reason says so.
    """
    fp = policy_from(policy)
    sig: Dict[str, Any] = {"rule": "", "fact_id": fact.id, "fact_kind": "forecast",
                           "policy": dict(fp.__dict__)}
    if float(fact.data_health) < fp.data_health_floor:
        sig["rule"] = "data_health_floor"
        return GateResult("INSUFFICIENT",
                          "The data behind this forecast scores %.0f out of 100 on our checks, under "
                          "the %.0f we require; a forecast of a broken series is a forecast of the "
                          "breakage." % (fact.data_health, fp.data_health_floor),
                          "A cleaner source; then this exact forecast can be re-run unchanged.", sig)
    p = payload_of(fact)
    s0 = (p or {}).get("summary", {})
    first, as_of = s0.get("first_forecast_month"), s0.get("as_of")
    if first and as_of and month_index(first) < month_index(as_of) - 1:
        # The data stopped long before the analysis date: the "next" month is long past. (The
        # month before the analysis month is allowed: an export pulled on 2 October whose
        # September was left out as incomplete forecasts September.)
        sig["rule"] = "stale"
        sig.update({"first_forecast_month": first, "as_of": as_of})
        return GateResult("INSUFFICIENT",
                          "The data stops at %s, but the analysis date is %s: a forecast of %s is "
                          "history, not a plan." % (s0.get("end"), as_of, first),
                          "Data up to the month before the analysis date; then this forecast can be "
                          "re-run unchanged.", sig)
    if p is None:
        sig["rule"] = "no_forecast"
        months = int(fact.value) if fact.unit == "months" else int(fact.periods_observed)
        return GateResult("INSUFFICIENT",
                          "There are %d months of history; a forecast we can check needs at least %d "
                          "(%d to replay, the rest to learn from), so none is made."
                          % (months, fp.min_history_months, fp.min_holdout),
                          "About %d more month(s) of history." % max(1, fp.min_history_months - months),
                          sig)
    s = p.get("summary", {})
    sig.update(s)
    hist, hold = int(s.get("history_months", 0)), int(s.get("holdout", 0))
    if hist < fp.min_history_months:
        sig["rule"] = "min_history"
        return GateResult("INSUFFICIENT",
                          "The series has %d months; we forecast only from %d or more, because a "
                          "shorter history cannot show whether a seasonal pattern repeats."
                          % (hist, fp.min_history_months),
                          "%d more month(s) of history." % (fp.min_history_months - hist), sig)
    if hold < fp.min_holdout:
        sig["rule"] = "min_holdout"
        return GateResult("INSUFFICIENT",
                          "The method could only be replayed over %d months, fewer than the %d we "
                          "require to judge it." % (hold, fp.min_holdout),
                          "A longer history, so at least %d months can be held out." % fp.min_holdout, sig)
    if s.get("step_months") and not s.get("band_h1", True):
        # fixer round, 24 Sep 2026: with the replayed forecasts that measured a step left out,
        # too few errors remain to draw a range; a range from the step's own miss was +50% skewed
        sig["rule"] = "step_range"
        return GateResult("INSUFFICIENT",
                          "The series stepped in %s, a change the engine named. With the replayed "
                          "forecasts that measured that step left out, too few past errors remain to "
                          "draw an 80%% range for %s, so no planning range is offered."
                          % (", ".join(s["step_months"]), s.get("first_forecast_month") or "next month"),
                          "More months after the step: then the forecast can be fitted and replayed "
                          "on them alone.", sig)
    champ = str(s.get("champion", ""))
    if not s.get("beats_seasonal_naive"):
        sig["rule"] = "baseline_not_beaten"
        what = ("the champion IS that rule" if champ == "seasonal_naive"
                else "the champion (%s) did not beat it" % PLAIN_NAME.get(champ, champ))
        return GateResult("WATCH",
                          "No method beat the simple rule of repeating the same month from last year "
                          "when we replayed the last %d months: %s. Use it as a guide, not a plan."
                          % (hold, what),
                          "More history, or a series with a steadier pattern, before this forecast "
                          "is advice.", sig)
    if fp.require_baseline_test and "baseline_test_p" in s:
        # (a payload written before M7 has no such key and is judged as it was then)
        bp_, bn_ = s.get("baseline_test_p"), int(s.get("baseline_test_n") or 0)
        shown = (bp_ is not None and math.isfinite(float(bp_)) and bn_ >= int(fp.baseline_test_min_n)
                 and float(bp_) <= float(fp.baseline_test_alpha))
        if not shown:
            sig["rule"] = "baseline_not_shown"
            if bp_ is None or not math.isfinite(float(bp_)):
                why = ("the method it would have picked at each replayed month made the same "
                       "month-ahead misses as that rule, so there is no evidence either way")
            elif bn_ < int(fp.baseline_test_min_n):
                why = ("only %d replayed months could be compared, fewer than the %d the test needs"
                       % (bn_, int(fp.baseline_test_min_n)))
            else:
                why = ("a gain at least this large would turn up in %s of 100 replays like this one "
                       "even if the method were no better than that rule"
                       % _chances(float(bp_)))
            return GateResult("WATCH",
                              "The chosen method (%s) had a lower replay error than the simple rule "
                              "of repeating the same month from last year, but that is not shown to "
                              "be more than luck: when the whole method -- including picking the "
                              "best of the five candidates at each replayed month from what was "
                              "known then -- is compared with that rule one month ahead, %s. Use it "
                              "as a guide, not a plan." % (PLAIN_NAME.get(champ, champ), why),
                              "More replayed months, or a series with a steadier pattern, so a real "
                              "gain over the simple rule can show.", sig)
    k, n = int(s.get("coverage_hits", 0)), int(s.get("coverage_n", 0))
    level = float(s.get("band_level", 0.80) or 0.80)
    rate = (k / float(n)) if n else float("nan")
    lo, hi = wilson(k, n)
    bp = binom_test_two_sided(k, n, level) if n else float("nan")
    sig.update({"coverage_binomial_p": bp, "coverage_rate": rate, "band_level": level})
    if not n or bp < fp.coverage_test_alpha:
        sig["rule"] = "band_miscalibrated"
        if not n:
            return GateResult("WATCH",
                              "The %s range could not be scored on the replay: no replayed month had "
                              "enough earlier errors to draw one." % _pct0(level),
                              "A longer history, so the range can be checked on replayed months.", sig)
        side = ("too narrow: actual months fell outside it too often" if rate < level
                else "wider than it needs to be: actual months fell inside it more often than stated")
        return GateResult("WATCH",
                          "The month-ahead %s range held in %d of %d replayed months (%s; with so few "
                          "months the true rate could be %s to %s). If ranges built this way truly "
                          "held %s of the time, a record at least this far from it would turn up in "
                          "%s of 100 replays like this one, so the range is %s."
                          % (_pct0(level), k, n, _pct0(rate), _pct0(lo), _pct0(hi), _pct0(level),
                             _chances(bp), side),
                          "A replay record that an exact test does not reject at %s coverage."
                          % _pct0(level), sig)
    msis_c, msis_s = s.get("champion_msis"), s.get("seasonal_naive_msis")
    if (fp.require_sharper_than_baseline and champ != "seasonal_naive"
            and msis_c is not None and msis_s is not None
            and math.isfinite(float(msis_c)) and math.isfinite(float(msis_s))
            and not float(msis_c) < float(msis_s)):
        sig["rule"] = "band_not_sharper"
        return GateResult("WATCH",
                          "On the replayed months, the %s range of %s scored no better than the same "
                          "kind of range around the same-month-last-year rule (interval score %.2f "
                          "against %.2f, lower is better): its range is no more useful than the "
                          "simple rule's." % (_pct0(level), PLAIN_NAME.get(champ, champ),
                                              float(msis_c), float(msis_s)),
                          "A method whose range beats the simple rule's on the replay.", sig)
    from .gate import unmodelled_confounders
    un = unmodelled_confounders(fact)
    if un:
        sig["rule"] = "confounder"
        return GateResult("WATCH",
                          "The method passed its replay, but something else moved in the same data "
                          "and was not modelled: %s." % "; ".join(un[:3]),
                          "Re-run once \"%s\" is split out or resolved." % un[0], sig)
    sig["rule"] = "recommend"
    shown = ""
    if fp.require_baseline_test and s.get("baseline_test_p") is not None:
        shown = (" (one month ahead, the whole method -- picking its model at each replayed month "
                 "from what was known then -- beat that rule by more than luck would: a gain this "
                 "large would turn up in %s of 100 replays if it were no better)"
                 % _chances(float(s["baseline_test_p"])))
    return GateResult("RECOMMEND",
                      "Replayed over the last %d months, %s beat the same-month-last-year rule%s, "
                      "and its month-ahead %s range held in %d of %d months (%s; with so few months "
                      "the true rate could be %s to %s). A replay this short can reveal a badly "
                      "calibrated range but cannot certify a good one."
                      % (hold, PLAIN_NAME.get(champ, champ), shown, _pct0(level), k, n, _pct0(rate),
                         _pct0(lo), _pct0(hi)),
                      "", sig)


# --------------------------------------------------------------------------- facts
def _clause(sentence: str) -> str:
    """A sentence as a caveat clause: the brief joins caveats with '; ' and ends them with '.'."""
    t = sentence.strip().rstrip(".")
    return t[:1].lower() + t[1:] if t[:2] != t[:2].upper() else t


def _slug(s: str) -> str:
    import re
    out = re.sub(r"[^a-z0-9]+", "_", str(s).lower()).strip("_")
    return out or "series"


def read_series(con: sqlite3.Connection, series_sql: str) -> List[Tuple[Any, Any]]:
    return [(r[0], r[1]) for r in con.execute(series_sql).fetchall()]


def _payload(series_sql: str, fill: str, cfg: Dict[str, Any], target: str,
             res: ForecastResult, as_of: Optional[str] = None) -> str:
    summary = {
        "history_months": res.history_months, "holdout": res.holdout, "horizon": res.horizon,
        "champion": res.champion, "baseline_won": res.baseline_won,
        "beats_seasonal_naive": res.beats_seasonal_naive,
        "champion_mase": res.models[res.champion]["mase"],
        "seasonal_naive_mase": res.models.get("seasonal_naive", {}).get("mase"),
        "coverage_hits": res.coverage["hits"], "coverage_n": res.coverage["n"],
        "coverage_binomial_p": res.coverage.get("binomial_p"),
        "christoffersen_ind_p": res.coverage.get("christoffersen_ind_p"),
        "christoffersen_cc_p": res.coverage.get("christoffersen_cc_p"),
        "band_level": float(cfg.get("band", 0.80)), "band_method": "conformal_rank",
        "band_scope": "per_month",
        "band_n_errors_h1": res.forward[0]["n_errors"] if res.forward else None,
        "band_max_level_h1": res.forward[0]["max_level"] if res.forward else None,
        "band_coverage_p10_p90_h1": ([res.forward[0]["coverage_p10"], res.forward[0]["coverage_p90"]]
                                     if res.forward and math.isfinite(float(res.forward[0]["coverage_p10"]))
                                     else None),
        "champion_msis": res.sharpness.get("champion_msis"),
        "seasonal_naive_msis": res.sharpness.get("seasonal_naive_msis"),
        # dependent calibration errors (see dependence_widening): the method, and the most any
        # forward range was widened for it (1 = none)
        "band_dependence": str(cfg.get("band_dependence", "none")),
        "band_widened_by_max": max([float(r.get("widened_by", 1.0)) for r in res.forward
                                    if math.isfinite(float(r.get("widened_by", float("nan"))))]
                                   or [1.0]),
        "band_n_effective_h1": (res.forward[0].get("n_effective") if res.forward else None),
        # design M7: the baseline test (see _baseline_test); None when it could not run
        "baseline_test_method": res.baseline_test.get("method"),
        "baseline_test_p": res.baseline_test.get("p"),
        "baseline_test_n": res.baseline_test.get("n"),
        "baseline_test_gain": res.baseline_test.get("gain"),
        "headline_error": "mase",
        "champion_skill_vs_sn": res.models[res.champion].get("skill_vs_sn"),
        "mape_suppressed": bool(res.models[res.champion].get("mape_suppressed")),
        "start": res.start, "end": res.end, "error_mode": res.error_mode,
        "first_forecast_month": res.forward[0]["month"] if res.forward else None,
        # a fit across named steps (fixer round, 24 Sep 2026): their months, the replayed forecasts
        # left out because they measured a step, and whether the first month still has a range
        "step_months": [x["month"] for x in (res.step or {}).get("steps") or []],
        "step_straddled": int((res.step or {}).get("straddled") or 0),
        "band_h1": bool(res.forward and math.isfinite(float(res.forward[0]["lo80"]))
                        and math.isfinite(float(res.forward[0]["hi80"]))),
    }
    if as_of:
        summary["as_of"] = str(as_of)[:10]
    return json.dumps({
        "kind": PAYLOAD_KIND, "series_sql": series_sql, "fill": fill,
        "config": {k: cfg[k] for k in sorted(cfg)}, "target": target,
        "model": res.champion, "params": res.params, "seed": cfg.get("seed", 0),
        "holdout_window": [res.backtest[0]["month"] if res.backtest else None,
                           res.backtest[-1]["month"] if res.backtest else None],
        "summary": summary,
    }, sort_keys=True, default=float)


def forecast_facts(
    fs: FactSet,
    con: sqlite3.Connection,
    series_sql: str,
    label: str,
    unit: str,
    slug: str = "",
    source_table: str = "",
    data_health: float = 100.0,
    rows_scanned: int = 0,
    fill: str = "zero",
    config: Optional[Dict[str, Any]] = None,
    confounders: Sequence[str] = (),
    caveats: Sequence[str] = (),
    as_of: Optional[str] = None,
    coverage_receipt: Any = None,
    step: Optional[Dict[str, Any]] = None,
) -> Optional[ForecastResult]:
    """
    Forecast one monthly series and add its facts to `fs`. Returns the result, or None
    when the series cannot support a forecast -- in which case one INSUFFICIENT-bound
    fact records how many months there were, so the brief says why there is no forecast.

    `coverage_receipt` feeds the measured-coverage words of the range sentence (design §1.3):
    None reads the benchmark receipt shipped beside the engine when it measured this decision
    code (:func:`default_coverage_evidence`), a receipt dict is used as given, False quotes none.
    """
    slug = _slug(slug or label)
    cfg = dict(DEFAULT_CONFIG)
    cfg.update(config or {})
    rows = read_series(con, series_sql)
    try:
        months, values = prepare_series(rows, fill=fill)
        step_m = str((step or {}).get("month") or "")
        if step_m and months[0] < month_index(step_m) <= months[-1]:
            # A level shift the change test detected (ship round, 24 Sep 2026: a building bought
            # in 2025-03 put the rent fan at 30k-230k a year out). Fit on the months from the
            # step on when they hold the backtest the design requires (min_history_months);
            # otherwise fit across the step, say the range is wide because of it, and show months
            # ahead only while the range is useful (USEFUL_RANGE_RATIO). Both choices are in the
            # config, so the ledger's refit repeats them.
            try:
                res = run_forecast(months, values, dict(cfg, fit_from=step_m))
                cfg = dict(cfg, fit_from=step_m)
            except ForecastError:
                # every named step the fit spans, with its size (run_forecast leaves the replayed
                # forecasts that measure a step out of the ranges, and scales the baseline by it)
                steps = [{"month": str(x.get("month")), "size": x.get("size")}
                         for x in ((step or {}).get("steps") or [step]) if x.get("month")]
                cfg = dict(cfg, step_month=step_m, steps=steps)
                res = run_forecast(months, values, cfg)
        else:
            res = run_forecast(months, values, cfg)
    except ForecastError as exc:
        n_sql = "SELECT COUNT(*) FROM (%s)" % series_sql
        fs.add(Fact(
            id="forecast.%s.history_months" % slug,
            claim="Months of history available to forecast %s" % label,
            value=float(con.execute(n_sql).fetchone()[0]), unit="months", query=n_sql,
            query_kind="sql", source_table=source_table, rows_scanned=int(rows_scanned),
            data_health=float(data_health), fact_kind="forecast", role="headline",
            caveats=["no forecast was made: %s" % exc] + list(caveats),
        ))
        return None

    common = dict(source_table=source_table, rows_scanned=int(rows_scanned),
                  data_health=float(data_health), fact_kind="forecast", query_kind="model",
                  periods_observed=res.history_months)
    plain = PLAIN_NAME[res.champion]
    base_caveats = ["method: %s, chosen as the lowest error when the last %d months were replayed"
                    % (plain, res.holdout)] + list(res.notes) + list(caveats)
    if res.baseline_won:
        base_caveats.append("a naive baseline won the replay: no more elaborate model beat it")
    champ = res.models[res.champion]
    if not all(math.isfinite(float(res.forward[0][k])) for k in ("lo80", "hi80")):
        base_caveats.append("no 80%% range for %s: too few replayed errors at that horizon to draw one"
                            % res.forward[0]["month"])
    else:
        # design S7: the range's scope, and what choosing on absolute error makes the point
        base_caveats.append("the 80% range is for each month on its own, not for the whole path "
                            "of months together")
    base_caveats.append("the method was chosen on its average absolute miss, so the forecast is a "
                        "middle value (about as likely to be under as over), not an average")
    # design S7: the replay error, MASE first, MAPE secondary and withheld near zero
    base_caveats.append(_clause(error_sentence(
        champ.get("mase"), champ.get("skill_vs_sn"), champ.get("mape"),
        bool(champ.get("mape_suppressed")), float(cfg.get("mape_min_share", 0.10)),
        res.champion == "seasonal_naive")))
    # design §1.3: what the month-ahead range promises, honestly for a widened range
    f0 = res.forward[0]
    if math.isfinite(float(f0["lo80"])) and math.isfinite(float(f0["hi80"])):
        if coverage_receipt is None:
            ev = default_coverage_evidence()
        elif coverage_receipt is False:
            ev = None
        else:
            ev = coverage_evidence(coverage_receipt)
        st, mo = (ev or {}).get("steady"), (ev or {}).get("momentum")
        base_caveats.append(_clause("the %d%% range for %s: %s" % (
            int(round(100 * float(cfg.get("band", 0.80)))), f0["month"], _clause(band_sentence(
                int(f0["n_errors"]), float(cfg.get("band", 0.80)),
                widened_by=float(f0.get("widened_by", 1.0)), n_effective=f0.get("n_effective"),
                measured_range=(st["lo"], st["hi"]) if st else None,
                measured_widened=(mo["lo"], mo["hi"]) if mo else None,
                momentum=tuple(mo["phi"]) if mo else None)))))

    def add(fid, claim, target, unit_, role="detail", conf=(), cav=()):
        value = res.target(target)
        if not math.isfinite(value):
            # An undefined number (a MASE on a steady series, a range with too few errors) is
            # not a figure. Emitted, it failed verification as "did not reproduce" (nan != nan)
            # and the client was told a falsehood about reproducibility (QA, 23 Sep 2026).
            # The headline's caveats say why it is missing.
            return
        fs.add(Fact(id=fid, claim=claim, value=value, unit=unit_,
                    query=_payload(series_sql, fill, cfg, target, res, as_of), role=role,
                    confounders=list(conf), caveats=list(cav), **common))

    first, last = res.forward[0], res.forward[-1]
    add("forecast.%s.next" % slug, "Forecast of %s for %s" % (label, first["month"]),
        "forward.point@1", unit, role="headline", conf=confounders, cav=base_caveats)
    add("forecast.%s.next.lo80" % slug, "Low end of the 80%% range for %s in %s" % (label, first["month"]),
        "forward.lo80@1", unit)
    add("forecast.%s.next.hi80" % slug, "High end of the 80%% range for %s in %s" % (label, first["month"]),
        "forward.hi80@1", unit)
    if res.horizon > 1:
        h = res.horizon
        add("forecast.%s.end" % slug, "Forecast of %s for %s" % (label, last["month"]),
            "forward.point@%d" % h, unit)
        add("forecast.%s.end.lo80" % slug, "Low end of the 80%% range for %s in %s" % (label, last["month"]),
            "forward.lo80@%d" % h, unit)
        add("forecast.%s.end.hi80" % slug, "High end of the 80%% range for %s in %s" % (label, last["month"]),
            "forward.hi80@%d" % h, unit)
    add("forecast.%s.backtest.months" % slug,
        "Months replayed to choose and check the method (each forecast made from what was known "
        "at the time)", "holdout", "months")
    add("forecast.%s.history.months" % slug, "Months of history the forecast learned from",
        "history_months", "months")
    add("forecast.%s.backtest.mape" % slug,
        "Average miss of the chosen method when the last %d months were replayed, as a share of "
        "the actual value" % res.holdout, "champion.mape", "pct")
    add("forecast.%s.backtest.mape_h1" % slug,
        "Average miss of the chosen method one month ahead, when the last %d months were replayed"
        % res.holdout, "champion.mape_h1", "pct")
    if res.horizon > 1:
        add("forecast.%s.backtest.mape_end" % slug,
            "Average miss of the chosen method at the furthest month ahead, when the last %d months "
            "were replayed" % res.holdout, "champion.mape_end", "pct")
    # design M7: the test behind "beats the same-month-last-year rule"
    add("forecast.%s.baseline_test.months" % slug,
        "Replayed months on which the method's month-ahead forecast (its model picked at each month "
        "from what was known then) was compared with repeating the same month from last year",
        "baseline_test.n", "count")
    add("forecast.%s.baseline_test.gain" % slug,
        "Share of the same-month-last-year rule's month-ahead replay miss that the method removed, "
        "picking its model at each month from what was known then (below 0 means it did worse)",
        "baseline_test.gain", "ratio")
    add("forecast.%s.baseline_test.p" % slug,
        "If the method were no more accurate one month ahead than repeating the same month from last "
        "year, the chance of a replay gain at least this large (one-sided Diebold-Mariano test with "
        "the small-sample correction)", "baseline_test.p", "probability")
    add("forecast.%s.backtest.mase" % slug,
        "Error of the chosen method relative to the same-month-last-year rule's typical miss (MASE)",
        "champion.mase", "ratio")
    if res.champion != "seasonal_naive":
        add("forecast.%s.backtest.skill" % slug,
            "Share of the same-month-last-year rule's replay error that the chosen method removed "
            "(1 - MASE ratio; below 0 means it did worse)", "champion.skill_vs_sn", "ratio")
    # the two numbers rule 5b compares, on the same replayed months
    add("forecast.%s.backtest.msis" % slug,
        "Interval score of the chosen method's replayed 80% ranges, scaled like MASE (width plus a "
        "penalty for each miss; lower is better)", "sharpness.champion_msis", "ratio")
    add("forecast.%s.backtest.msis_seasonal_naive" % slug,
        "Interval score of the same kind of 80% range around the same-month-last-year rule, on "
        "the same replayed months", "sharpness.seasonal_naive_msis", "ratio")
    for m in MODEL_NAMES:
        if res.models.get(m, {}).get("applicable") and m != res.champion:
            add("forecast.%s.model.%s.mase" % (slug, m),
                "Replay error (MASE) of the method: %s" % PLAIN_NAME[m], "model.%s.mase" % m, "ratio")
            add("forecast.%s.model.%s.mape" % (slug, m),
                "Replay average miss of the method: %s" % PLAIN_NAME[m], "model.%s.mape" % m, "pct")
    # The range's own statement (design §1.3): how many past errors it rests on, the most any
    # range from that many can cover, and the 10th-90th percentile spread of ITS coverage.
    add("forecast.%s.next.band_errors" % slug,
        "Past errors the 80%% range for %s is built from" % first["month"], "forward.n_errors@1",
        "count")
    add("forecast.%s.next.band_cov_p10" % slug,
        "Low end (10th percentile) of the share of months the 80%% range for %s may truly cover, "
        "given how few errors it rests on" % first["month"], "forward.coverage_p10@1", "ratio")
    add("forecast.%s.next.band_cov_p90" % slug,
        "High end (90th percentile) of the share of months the 80%% range for %s may truly cover, "
        "given how few errors it rests on" % first["month"], "forward.coverage_p90@1", "ratio")
    add("forecast.%s.next.band_max_level" % slug,
        "Highest coverage any range built from that many errors can reach", "forward.max_level@1",
        "ratio")
    add("forecast.%s.coverage.hits" % slug,
        "Replayed months whose actual value fell inside the month-ahead 80% range",
        "coverage.hits", "count")
    add("forecast.%s.coverage.n" % slug,
        "Replayed months with a month-ahead 80% range built only from errors known at the time",
        "coverage.n", "count")
    add("forecast.%s.coverage.binomial_p" % slug,
        "If the month-ahead 80% range truly held 80% of the time, the chance of a replay record at "
        "least this far from it (exact binomial test)", "coverage.binomial_p", "probability")
    add("forecast.%s.coverage_all.hits" % slug,
        "Replayed forecasts at every horizon whose actual value fell inside the 80% range "
        "(overlapping checks)", "coverage.all_hits", "count")
    add("forecast.%s.coverage_all.n" % slug,
        "Replayed forecasts at every horizon with an 80% range built only from errors known at "
        "the time (overlapping checks)", "coverage.all_n", "count")
    return res


# --------------------------------------------------------------------------- verification
_CACHE: Dict[Tuple[str, str, str], ForecastResult] = {}


def recompute(payload: Dict[str, Any], con: sqlite3.Connection) -> float:
    """Re-read the series, refit everything, and return the payload's target number."""
    key = (payload["series_sql"], payload.get("fill", "zero"),
           json.dumps(payload.get("config", {}), sort_keys=True))
    res = _CACHE.get(key)
    if res is None:
        months, values = prepare_series(read_series(con, payload["series_sql"]),
                                        fill=payload.get("fill", "zero"))
        res = run_forecast(months, values, payload.get("config"))
        _CACHE[key] = res
    if payload.get("model") and res.champion != payload["model"]:
        raise ValueError("the refit chose %s, the fact recorded %s" % (res.champion, payload["model"]))
    return res.target(payload["target"])


def clear_cache() -> None:
    _CACHE.clear()


def calibration_triples(res: ForecastResult) -> List[Tuple[float, float, float]]:
    """Backtest (low, high, actual) triples for evaluate.score_run's calibration input."""
    return [(r["lo80"], r["hi80"], r["actual"]) for r in res.backtest
            if r["lo80"] is not None and r["hi80"] is not None]


# --------------------------------------------------------------------------- CSV command
def forecast_csv(path: str, date_col: str = "", value_col: str = "",
                 config: Optional[Dict[str, Any]] = None) -> ForecastResult:
    """A monthly CSV (e.g. FRED's fredgraph.csv) -> ForecastResult. First two columns by default."""
    import pandas as pd
    df = pd.read_csv(path)
    dc = date_col or df.columns[0]
    vc = value_col or df.columns[1]
    vals = pd.to_numeric(df[vc], errors="coerce")
    dates = pd.to_datetime(df[dc], errors="coerce")
    rows = [(d.strftime("%Y-%m"), float(v)) for d, v in zip(dates, vals)
            if not pd.isna(d) and not pd.isna(v)]
    months, values = prepare_series(rows, fill="none")
    return run_forecast(months, values, config)


def main(argv: Optional[List[str]] = None) -> int:
    import argparse
    import sys
    ap = argparse.ArgumentParser(prog="python -m northledger.forecast",
                                 description="Backtested monthly forecast of a CSV series (numpy only).")
    ap.add_argument("csv")
    ap.add_argument("--date-col", default="")
    ap.add_argument("--value-col", default="")
    ap.add_argument("--horizon", type=int, default=DEFAULT_CONFIG["horizon"])
    ap.add_argument("--max-history", type=int, default=DEFAULT_CONFIG["max_history"])
    ap.add_argument("--out", default="")
    a = ap.parse_args(argv)
    res = forecast_csv(a.csv, a.date_col, a.value_col,
                       {"horizon": a.horizon, "max_history": a.max_history})
    doc = res.to_dict()
    doc["verdict_inputs"] = {"champion": res.champion, "baseline_won": res.baseline_won,
                             "beats_seasonal_naive": res.beats_seasonal_naive}
    text = json.dumps(doc, indent=1, default=float)
    if a.out:
        with open(a.out, "w", encoding="utf-8") as fh:
            fh.write(text + "\n")
    else:
        sys.stdout.write(text + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
