#!/usr/bin/env python3
"""
Stage 0 of the Insight Loop: take a messy file from a business and land it safely.

This is the only module that ever touches real client data, so it is deliberately
conservative:

  * nothing is trusted -- not the extension, not the encoding, not the delimiter,
    not the header row
  * hard caps on size and rows, enforced before pandas is allowed near the file
  * a PII scan runs on every landing, because a small business will absolutely
    email you a spreadsheet with customer emails and phone numbers in it, and
    "I did not realise it was in there" is not a defence you want to make
  * the landed table name is generated, never taken from user input

Python 3.9 compatible. pandas + stdlib only.
"""
from __future__ import annotations

import csv
import hashlib
import hmac
import io
import os
import re
import sqlite3
import unicodedata
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

MAX_BYTES_DEFAULT = 50 * 1024 * 1024        # 50 MB
MAX_ROWS_DEFAULT = 2_000_000
SNIFF_BYTES = 256 * 1024

READABLE_SUFFIXES = (".csv", ".tsv", ".txt", ".xlsx", ".xlsm", ".xls", ".json", ".jsonl")


class IntakeError(Exception):
    """Refusal to land a file. The message is shown to the client."""


# ---------------------------------------------------------------- PII scanning
# Deliberately high-recall / medium-precision on DETECTION: a false positive costs
# a glance, a false negative costs a client's customer list sitting in your repo.
# But ACTION is conservative in the other direction. A structured column is only
# coded (hashed, irreversibly) when three things agree:
#   1. one kind is DOMINANT among its non-null values (>= DOMINANT_SHARE),
#   2. those values pass the kind's type check, and
#   3. for every kind except email, the column NAME confirms it (a "phone" column
#      of phone-shaped values), and the name does not say it belongs to a store,
#      branch or supplier.
# Review of 22 Sep 2026: shape plus type check alone does not prove a column holds
# people. Order ids pass the phone check, CRA Business Numbers pass the SIN Luhn
# check, IMEIs pass the card Luhn check, firmware versions and GL codes read as IP
# addresses and warehouse bins as postal codes. Such columns now go to REVIEW (left
# intact; a human decides), never to coding.

# Separator characters seen in real exports: ASCII and Unicode dashes (Word and
# Excel autocorrect "-" to an en dash), spaces incl. no-break, and zero-width
# characters that survive copy and paste.
_DASH = "\\-\u2010\u2011\u2012\u2013\u2014\u2015\u2212\ufe63\uff0d"
_SPC = " \t\u00a0\u2000-\u200a\u202f\u205f\u3000"
_ZW = "\u200b\u200c\u200d\u2060\ufeff\u00ad"
_SEPC = "[" + _DASH + "." + _SPC + _ZW + "]"            # one separator character
_PSEP = ("(?:[" + _SPC + _ZW + "]{0,2}[" + _DASH + ".][" + _SPC + _ZW + "]{0,2}"
         "|[" + _SPC + _ZW + "]{1,2})")                    # "-", " - ", " ", "\u200b"
# Digit runs are bounded by non-alphanumerics, and not by a decimal point or
# thousands separator: "LOT2026092214", "123456782RT0001" and "4165550173.50" are
# not phone numbers or SINs.
_LB = r"(?<![0-9A-Za-z])(?<![0-9][.,])"
_LA = r"(?![0-9A-Za-z])(?![.,][0-9])"

PII_PATTERNS = {
    "email": re.compile(
        r"(?<![\w.%+'-])(?:\"[^\"\r\n@]{1,64}\"|[\w%+'-]+(?:\.[\w%+'-]+)*)"
        r"(?:@| @ |%40|\s?\[at\]\s?|\s?\(at\)\s?)"
        r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?"
        r"(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*\.[A-Za-z]{2,24}(?![A-Za-z0-9-])"),
    # 4-4-4-(1..7) with one consistent separator (bare 13-19 digits when it is
    # empty), or Amex/Diners 4-6-(4..5). A run of short numbers is not a card.
    "credit_card": re.compile(
        _LB + r"(?:[0-9]{4}(?P<ccsep>[" + _DASH + _SPC + _ZW + r"]?)[0-9]{4}(?P=ccsep)[0-9]{4}"
        r"(?P=ccsep)[0-9]{1,7}|[0-9]{4}(?P<axsep>[" + _DASH + _SPC + _ZW + r"]?)[0-9]{6}"
        r"(?P=axsep)[0-9]{4,5})" + _LA),
    # A leading country code 1 needs a "+" or a separator after it, or a bare
    # 11-digit run: "1652 517 9569" (qty 1652, part 517...) is not +1 652 517 9569.
    "phone_na": re.compile(
        _LB + r"(?:\+1" + _PSEP + r"?|1" + _PSEP + r"|1(?=[2-9][0-9]{9}(?![0-9])))?"
        r"(?:\([0-9]{3}\)|[0-9]{3})" + _PSEP + r"?[0-9]{3}" + _PSEP + r"?[0-9]{4}" + _LA),
    # International numbers are only recognised with their "+": +44 20 7946 0958.
    "phone_intl": re.compile(
        r"(?<![0-9A-Za-z+])\+[2-9](?:[0-9]|" + _SEPC + r"(?=[0-9(])|[()]){7,22}" + _LA),
    # SIN 3-3-3 or SSN 3-2-4, one consistent separator (or none).
    "sin_ssn": re.compile(
        _LB + r"(?:[0-9]{3}(?P<sinsep>" + _SEPC + r"?)[0-9]{3}(?P=sinsep)[0-9]{3}"
        r"|[0-9]{3}(?P<ssnsep>[" + _DASH + _SPC + _ZW + r"]?)[0-9]{2}(?P=ssnsep)[0-9]{4})" + _LA),
    "postal_ca": re.compile(
        _LB + r"[A-Za-z][0-9][A-Za-z][" + _DASH + _SPC + r"]?[0-9][A-Za-z][0-9]" + _LA),
    "ip": re.compile(r"(?<![0-9A-Za-z.])(?:[0-9]{1,3}\.){3}[0-9]{1,3}(?![0-9A-Za-z]|\.[0-9])"),
}

# When one value fits several kinds it is reported ONCE, under the first kind here
# that it genuinely is (pattern + type check). email > phone > SIN is the reviewed
# order; a Luhn-valid card sits above phone because a 16-digit card also contains
# phone-shaped and SIN-shaped runs.
KIND_PRECEDENCE = ("email", "credit_card", "phone_na", "phone_intl", "sin_ssn", "postal_ca", "ip")
_DIGIT_KINDS = ("credit_card", "phone_na", "phone_intl", "sin_ssn")
# Kinds that are one thing for dominance and coding: a contact column may mix
# North American and international numbers.
_FAMILY = {"phone_intl": "phone_na"}

# A structured column is coded only when one kind covers at least this share of
# its non-null values AND those values pass the kind's type check AND (except for
# email) the column name confirms the kind.
DOMINANT_SHARE = 0.80


def _singular(t: str) -> str:
    return t[:-1] if len(t) > 3 and t.endswith("s") and not t.endswith("ss") else t


_SPLIT_CAMEL = re.compile(r"(?<=[a-z0-9])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])"
                          r"|(?<=[A-Za-z])(?=\d)|(?<=\d)(?=[A-Za-z])")
_NON_ALNUM = re.compile(r"[^A-Za-z0-9]+")


def _name_tokens(name: Any) -> Tuple[str, ...]:
    """'patientId' -> (patient, id); 'E-mail' -> (e, mail); 'Customers' -> (customer,)."""
    s = _SPLIT_CAMEL.sub(" ", str(name))
    return tuple(_singular(t) for t in _NON_ALNUM.split(s.lower()) if t)


def _tokset(*words: str) -> frozenset:
    return frozenset(t for w in words for t in _name_tokens(w))


# Column names that declare intent even when the values look innocuous. Matched on
# whole name TOKENS (split on non-alphanumerics, camelCase and letter/digit
# boundaries, plurals folded), never substrings: "zip" must not flag
# "zipper_size", nor "sin" "business", nor "card" "discard_reason".
PII_NAME_HINTS = (
    # contact
    "email", "e-mail", "emailaddress", "phone", "phonenumber", "telephone", "tel", "mobile",
    "mob", "cell", "cellphone", "fax", "whatsapp", "contact", "direct_line",
    # government and health ids
    "ssn", "sin", "social_security", "social_insurance", "passport", "licence", "license",
    "ohip", "health_card", "taxpayer", "insurance",
    # birth
    "dob", "birth", "birthday", "birthdate", "dateofbirth",
    # location
    "address", "addr", "street", "postcode", "postal", "postalcode", "zip", "zipcode", "ip",
    # payment
    "card", "credit_card", "iban", "bank_account",
    # people
    "name", "first_name", "last_name", "full_name", "customer_name", "firstname", "lastname",
    "fullname", "surname", "customername", "username", "fname", "lname", "login", "password",
    "patient", "client", "customer", "cust", "buyer", "employee", "recipient", "guest",
    "tenant", "payee", "owner", "spouse", "kin", "beneficiary", "guardian",
    # special categories
    "diagnosis", "medication", "medical", "allergy", "allergies", "prescription", "health",
    "gender", "sex", "religion", "ethnicity",
    # pay
    "salary", "wage", "wages", "income", "pay_rate", "hourly_rate",
    # free text
    "notes", "note", "comment", "comments",
)

# Never suppressed by another token: these are sensitive whatever they are paired with.
_ALWAYS_HINTS = frozenset((
    "patient", "diagnosis", "ssn", "social_security", "social_insurance", "passport", "ohip",
    "medication", "prescription", "allergy", "allergies", "religion", "ethnicity", "dob",
    "dateofbirth", "birthdate", "password",
))
# A token that says the column describes the thing rather than holding a person's
# value: card_type, cell_count, PhoneModel, health_score, zip_file, Sex_Ratio.
_MODIFIERS = _tokset(
    "type", "category", "kind", "class", "count", "cnt", "qty", "quantity", "balance", "rate",
    "ratio", "pct", "percent", "percentage", "score", "rating", "model", "sku", "case", "file",
    "key", "title", "game", "band", "level", "tier", "status", "flag", "format", "template",
    "length", "len", "size", "avg", "mean", "total", "sum", "min", "max", "tax", "reader",
    "terminal", "fee", "gift", "verified", "enabled", "valid", "optin", "bounce", "domain",
    "provider", "carrier", "brand")
_COMP_HINTS = frozenset(("salary", "wage", "wages", "income", "pay_rate", "hourly_rate"))
_COMP_EXEMPT = _tokset("rate", "total", "sum", "avg", "mean", "min", "max")
# "Customer" is a person; customer_id, customer_segment and client_id are keys and
# attributes, reviewed only if their VALUES look personal.
_ENTITY_HINTS = frozenset(("client", "customer", "cust", "buyer", "employee", "recipient",
                           "guest", "tenant", "payee", "owner", "beneficiary", "guardian",
                           "login"))
_ENTITY_SUPPRESS = _tokset(
    "id", "ids", "no", "num", "nbr", "number", "ref", "code", "key", "uuid", "guid", "since",
    "segment", "tier", "group", "type", "status", "source", "channel", "count", "lifetime",
    "ltv", "value", "class", "category", "rank", "score", "date", "time", "at", "ts",
    "timestamp", "created", "updated", "portal")
# The bare hint "name" means a person unless the name says what else is named...
_NON_PERSON_NAME_QUALIFIERS = _tokset(
    "product", "item", "sku", "file", "filename", "category", "brand", "company", "business",
    "store", "shop", "branch", "city", "region", "country", "province", "state", "sheet",
    "table", "column", "field", "host", "domain", "campaign", "event", "project", "plan",
    "service", "model", "device", "course", "team", "department", "dept", "warehouse",
    "location", "site", "tag", "label", "menu", "channel", "list", "report", "stage",
    "vendor", "supplier", "part", "bank", "color", "colour", "variant", "account", "display",
    "style", "option", "attribute", "promo", "coupon", "discount", "app", "application",
    "role", "job", "position")
# ...unless a person-word comes before "name": "Store Manager Name", "Site Contact Name".
_PERSON_WORDS = _tokset(
    "manager", "contact", "attendee", "instructor", "technician", "member", "owner", "rep",
    "representative", "agent", "employee", "staff", "customer", "client", "cust", "patient",
    "guest", "driver", "cashier", "user", "buyer", "person", "recipient", "tenant", "payee",
    "spouse", "teacher", "student", "doctor", "nurse", "parent", "guardian", "beneficiary",
    "holder", "cardholder", "signer", "approver", "supervisor", "worker", "volunteer",
    "player", "participant", "applicant", "candidate", "author", "sender", "requester",
    "requestor", "submitter", "emergency", "kin", "first", "last", "full", "middle", "given",
    "family", "maiden", "legal", "preferred", "nick")
# Contact details of the business itself, not of people.
_PLACE_TOKENS = _tokset(
    "store", "shop", "branch", "warehouse", "site", "office", "vendor", "supplier", "company",
    "business", "merchant", "depot", "plant", "location", "facility", "hq", "outlet",
    "dealer", "distributor", "manufacturer", "carrier", "courier")

# Name hints that CONFIRM a value kind (condition 3 above), plus tokens that confirm
# a kind without being worth a review on their own.
_CONFIRMING_HINTS = {
    "phone_na": frozenset(("phone", "phonenumber", "telephone", "tel", "mobile", "mob", "cell",
                           "cellphone", "fax", "whatsapp", "contact", "direct_line")),
    "sin_ssn": frozenset(("sin", "ssn", "social_security", "social_insurance", "taxpayer")),
    "credit_card": frozenset(("card", "credit_card")),
    "postal_ca": frozenset(("postal", "postcode", "postalcode", "zip", "zipcode")),
    "ip": frozenset(("ip",)),
}
_CONFIRMING_HINTS["phone_intl"] = _CONFIRMING_HINTS["phone_na"]
_CONFIRMING_TOKENS = {"credit_card": _tokset("cc", "pan", "payment", "creditcard")}

_HINT_TOKENS = tuple(sorted({(h, _name_tokens(h)) for h in PII_NAME_HINTS},
                            key=lambda ht: (-len(ht[1]), ht[0])))


def _hint_suppressed(hint: str, ht: Tuple[str, ...], toks: Tuple[str, ...], i: int) -> bool:
    if hint in _ALWAYS_HINTS:
        return False
    others = set(toks[:i] + toks[i + len(ht):])
    mods = (_MODIFIERS - _COMP_EXEMPT) if hint in _COMP_HINTS else _MODIFIERS
    if others & mods:
        return True
    if hint in _ENTITY_HINTS and others & _ENTITY_SUPPRESS:
        return True
    if ht == ("name",):
        if set(toks[:i]) & _PERSON_WORDS:
            return False
        if set(toks) & _NON_PERSON_NAME_QUALIFIERS:
            return True
    return False


def _hint_hits(name: Any) -> List[str]:
    """Every hint that survives suppression, most specific first."""
    toks = _name_tokens(name)
    hits = []
    for hint, ht in _HINT_TOKENS:
        k = len(ht)
        starts = [i for i in range(len(toks) - k + 1) if toks[i:i + k] == ht]
        if starts and not _hint_suppressed(hint, ht, toks, starts[0]):
            hits.append(hint)
    return hits


def _name_hint(*names: Any) -> Optional[str]:
    """The most specific surviving hint in any of the column's names."""
    for name in names:
        if name is None:
            continue
        hits = _hint_hits(name)
        if hits:
            return hits[0]
    return None


def _confirmed_kinds(*names: Any) -> Tuple[frozenset, bool]:
    """(kinds the column name confirms, whether the name marks a business place)."""
    kinds = set()
    place = False
    for name in names:
        if name is None:
            continue
        toks = set(_name_tokens(name))
        place = place or bool(toks & _PLACE_TOKENS)
        hits = set(_hint_hits(name))
        for kind, hints in _CONFIRMING_HINTS.items():
            if hits & hints or toks & _CONFIRMING_TOKENS.get(kind, frozenset()):
                kinds.add(kind)
    return frozenset(kinds), place


# People's names by the SHAPE of the values, whatever the column is called (review v2, 24 Sep
# 2026: 'assigned_to' held 'Priya Sharma', 'Fatima Okoye'... and the story printed one as
# "the most common assigned_to value"). A value is a person's name when it is two or three
# capitalised words and the first is a common given name; business names ('Danforth
# Triplex', 'Greenwood Cleaning') rarely start with one. A column is flagged when such values
# are most of it. A list cannot be complete: the scan is a net under the name hints, not a
# guarantee, and the report says a scanner cannot find every name.
GIVEN_NAMES = frozenset("""
aaron abdul abdullah adam adrian ahmed aisha alex alexander alexandra alexis ali alice alicia
alison allison amanda amber amelia amina amir amit amy ana andre andrea andrew angela anil anita
ann anna anne anthony antonio anu anya arjun arthur ashley aya ayesha barbara ben benjamin beth
bilal bill bob brandon brenda brian bruce bryan caleb cameron carl carlos carmen carol caroline
catherine charles charlie charlotte chen chloe chris christian christina christine christopher
cindy claire connor craig cynthia daniel danielle david deborah debra deepak denise dennis diana
diane diego dimitri donald donna dorothy douglas dylan edward elena elizabeth ella ellen emily
emma eric erica erin ethan eva evelyn fatima fatma felix fernando fiona frank gabriel gary george
gloria grace greg gregory hana hannah harold harry hassan heather helen henry hiroshi hugo ian
ibrahim irene isaac isabella ivan jack jacob james jamie jane janet janice jasmine jason jean
jeff jeffrey jennifer jeremy jerry jessica jin joan joe john jonathan jordan jose joseph joshua
joyce juan judith julia julie justin karen karim kate katherine kathleen kathryn keith kelly ken
kenneth kevin kim kimberly kyle laura lauren lawrence leah lee leo li liam lily linda lisa liu
logan lucas lucy luis luke madison maria marc marco margaret maria mariam marie marilyn mario mark
martha martin mary mason matthew maya megan melissa mia michael michelle miguel min mohamed
mohammad mohammed muhammad nancy naomi natalie nathan neha nicholas nicole nina noah nora olga
olivia omar owen pamela patricia patrick paul paula peter philip pierre priya rachel rahul raj
rajesh ralph ramesh raymond rebecca richard robert roger ronald rose ruth ryan sam samantha samuel
sandra sanjay sara sarah scott sean sergei sharon shirley simon sofia sophia sophie stephanie
stephen steven sunil susan tanya teresa terry thomas timothy tom tony tyler valerie vanessa victor
victoria vikram vincent virginia walter wayne wei william xavier yan yasmin yusuf zach zachary
zainab zara zoe
""".split())
_PERSON_SHAPE = re.compile(r"^[A-Z][a-z'\u2019\-]+(?: [A-Z][A-Za-z'\u2019\-]+){1,2}$")
PERSON_NAME_MIN_SHARE = 0.60


def _person_name_share(u: pd.Series, w: np.ndarray, total: int) -> Tuple[float, int, str]:
    """(share of the column's values that read as a person's name, distinct such values, one)."""
    shape = u.str.match(_PERSON_SHAPE).to_numpy(dtype=bool)
    if not shape.any():
        return 0.0, 0, ""
    first = u.str.split(" ").str[0].str.lower()
    hit = shape & first.isin(GIVEN_NAMES).to_numpy(dtype=bool)
    if not hit.any():
        return 0.0, 0, ""
    return float(w[hit].sum()) / float(total), int(hit.sum()), str(u[hit].iloc[0])


# A person-word in a column's name ('Active Customers', 'Patients Seen') over values that are
# plain counts is a KPI, not personal data (review v2: an integer 'Active Customers' column was
# withheld on its name alone and dropped from the analysis). Pay is sensitive whatever its type.
_COUNT_OK_HINTS = frozenset(("client", "customer", "cust", "buyer", "employee", "recipient",
                             "guest", "tenant", "payee", "owner", "beneficiary", "guardian",
                             "patient", "name"))
_COUNT_VALUE = re.compile(r"^[+-]?\d{1,5}(?:\.\d+)?$|^[+-]?\d{1,3}(?:,\d{3})(?:\.\d+)?$")


def _is_count_column(u: pd.Series, w: np.ndarray) -> bool:
    """Every value is a small plain number (at most 5 integer digits, or a decimal)."""
    if len(u) == 0:
        return False
    return bool(u.str.fullmatch(_COUNT_VALUE).all())


# Values that mean "no value" and must not dilute a column's shares.
_NULL_TOKENS = ("", "na", "n/a", "none", "null", "nan", "nat", "-", "--", "?", "unknown")

# Free text = long or wordy values. Deliberately simple: a scanner cannot find names
# in free text, so every such column goes to a human anyway.
_FREE_TEXT_MIN_WORDS = 4
_FREE_TEXT_MIN_CHARS = 50
_FREE_TEXT_ALWAYS_WORDS = 6


# ---------------------------------------------------------------- digits
_NON_ASCII_DIGIT = re.compile(r"(?![0-9])\d")


def _fold_one(s: str) -> str:
    """Arabic-Indic, fullwidth and other decimal digits -> ASCII, one char for one,
    so span positions in the folded text are positions in the original."""
    if s.isascii():
        return s
    return _NON_ASCII_DIGIT.sub(lambda m: str(unicodedata.decimal(m.group(0), 0)), s)


def _fold_vec(ser: pd.Series) -> pd.Series:
    if ser.empty:
        return ser
    mask = ser.str.contains(r"[^\x00-\x7f]", regex=True).fillna(False).to_numpy(dtype=bool)
    if not mask.any():
        return ser
    out = ser.copy()
    out[mask] = ser[mask].str.replace(_NON_ASCII_DIGIT, lambda m: str(
        unicodedata.decimal(m.group(0), 0)), regex=True)
    return out


def _luhn_ok(digits: str) -> bool:
    """Credit-card check: without this, every long order number reads as a card."""
    ds = [int(c) for c in _fold_one(digits) if c in "0123456789"]
    if not (13 <= len(ds) <= 19):
        return False
    return _luhn_digits_ok(ds)


def _luhn_digits_ok(ds: List[int]) -> bool:
    total, parity = 0, len(ds) % 2
    for i, d in enumerate(ds):
        if i % 2 == parity:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10 == 0


def _luhn_vec(digits: pd.Series) -> np.ndarray:
    """Luhn over a Series of ASCII digit strings (<= 19 digits), without a row loop.

    Left-padding with zeros never changes a Luhn sum, so every string is padded to
    19 and the doubled positions are the odd indexes counted from the left.
    """
    if digits.empty:
        return np.zeros(0, dtype=bool)
    padded = digits.str.replace(r"[^0-9]", "", regex=True).str.zfill(19).str[-19:]
    arr = (np.frombuffer("".join(padded).encode("ascii"), dtype=np.uint8)
           .reshape(-1, 19).astype(np.int16) - 48)
    dbl = arr[:, 1::2] * 2
    dbl = np.where(dbl > 9, dbl - 9, dbl)
    return ((arr[:, 0::2].sum(axis=1) + dbl.sum(axis=1)) % 10 == 0)


_SSN_FORMAT = re.compile(r"(?!000|666|9[0-9][0-9])[0-9]{3}(?P<s>[" + _DASH + _SPC + _ZW +
                         r"])(?!00)[0-9]{2}(?P=s)(?!0000)[0-9]{4}")
_POSTAL_OK = re.compile(r"[ABCEGHJKLMNPRSTVXY][0-9][ABCEGHJ-NPRSTV-Z][" + _DASH + _SPC +
                        r"]?[0-9][ABCEGHJ-NPRSTV-Z][0-9]", re.IGNORECASE)
_IMAGE_TLD = re.compile(r"\.(?:png|jpe?g|gif|svg|webp|bmp|ico)$", re.IGNORECASE)
_NANP_LEAD = list("23456789")
# Issuer prefixes by length. An IMEI (15 digits, Luhn by design, usually TAC 35 or
# 86) is not an Amex (15 digits, 34 or 37); "3173 3513 ..." is not a card at all.
_MC16 = ["51", "52", "53", "54", "55", "22", "23", "24", "25", "26", "27", "35", "62", "64", "65"]


def _digits_vec(spans: pd.Series) -> pd.Series:
    return spans.str.replace(r"[^0-9]", "", regex=True)


def _iin_ok(d: str) -> bool:
    n = len(d)
    if n == 13:
        return d[:1] == "4"
    if n == 14:
        return d[:2] in ("30", "36", "38", "39")
    if n == 15:
        return d[:2] in ("34", "37")
    if n == 16:
        return d[:1] == "4" or d[:2] in _MC16 or d[:4] == "6011"
    return 17 <= n <= 19 and d[:1] in ("4", "5", "6")


def _iin_vec(d: pd.Series, n: np.ndarray) -> np.ndarray:
    p1, p2 = d.str[:1], d.str[:2]
    ok = (n == 13) & (p1 == "4").to_numpy()
    ok |= (n == 14) & p2.isin(["30", "36", "38", "39"]).to_numpy()
    ok |= (n == 15) & p2.isin(["34", "37"]).to_numpy()
    ok |= (n == 16) & ((p1 == "4") | p2.isin(_MC16) | (d.str[:4] == "6011")).to_numpy()
    ok |= (n >= 17) & (n <= 19) & p1.isin(["4", "5", "6"]).to_numpy()
    return ok


def _valid_vec(kind: str, spans: pd.Series) -> np.ndarray:
    """Type check for matched spans, vectorised. Pattern-shaped is not enough."""
    if spans.empty:
        return np.zeros(0, dtype=bool)
    spans = _fold_vec(spans.astype(str))
    if kind == "email":
        return ~spans.str.contains(_IMAGE_TLD).to_numpy(dtype=bool)   # logo@2x.png
    if kind in _DIGIT_KINDS:
        d = _digits_vec(spans)
        n = d.str.len().to_numpy()
    if kind == "phone_na":
        # North American Numbering Plan: area code and exchange both start 2-9.
        d = d.where(~((n == 11) & d.str.startswith("1").to_numpy()), d.str[1:])
        ok = (d.str.len() == 10).to_numpy()
        ok &= d.str[0].isin(_NANP_LEAD).to_numpy()
        ok &= d.str[3].isin(_NANP_LEAD).to_numpy()
        return ok
    if kind == "phone_intl":
        return (spans.str.startswith("+").to_numpy() & (n >= 8) & (n <= 15)
                & ~d.str.startswith("1").to_numpy())
    if kind == "sin_ssn":
        nine = n == 9
        luhn = np.zeros(len(d), dtype=bool)
        if nine.any():
            luhn[nine] = _luhn_vec(d[nine])
        ssn = spans.str.fullmatch(_SSN_FORMAT).to_numpy(dtype=bool)
        return nine & (luhn | ssn)
    if kind == "credit_card":
        ok = (n >= 13) & (n <= 19)
        ok &= _iin_vec(d, n)
        luhn = np.zeros(len(d), dtype=bool)
        if ok.any():
            luhn[ok] = _luhn_vec(d[ok])
        return ok & luhn
    if kind == "postal_ca":
        return spans.str.fullmatch(_POSTAL_OK).to_numpy(dtype=bool)
    if kind == "ip":
        parts = spans.str.split(".", expand=True).apply(pd.to_numeric, errors="coerce")
        return (parts.le(255) & parts.notna()).all(axis=1).to_numpy()
    return np.ones(len(spans), dtype=bool)


def _valid_one(kind: str, span: str) -> bool:
    """Scalar twin of _valid_vec, for span-by-span replacement in free text.
    (tests/test_intake_scanner.py checks that the two agree.)"""
    span = _fold_one(str(span))
    if kind == "email":
        return not _IMAGE_TLD.search(span)
    if kind in _DIGIT_KINDS:
        d = re.sub(r"[^0-9]", "", span)
        if kind == "phone_na":
            if len(d) == 11 and d.startswith("1"):
                d = d[1:]
            return len(d) == 10 and d[0] in "23456789" and d[3] in "23456789"
        if kind == "phone_intl":
            return span.startswith("+") and 8 <= len(d) <= 15 and not d.startswith("1")
        if kind == "sin_ssn":
            return len(d) == 9 and (_luhn_digits_ok([int(c) for c in d])
                                    or bool(_SSN_FORMAT.fullmatch(span)))
        if not 13 <= len(d) <= 19 or not _iin_ok(d):
            return False
        return _luhn_digits_ok([int(c) for c in d])
    if kind == "postal_ca":
        return bool(_POSTAL_OK.fullmatch(span))
    if kind == "ip":
        return all(p.isdigit() and int(p) <= 255 for p in span.split("."))
    return True


@dataclass
class PIIFinding:
    column: str
    kind: str
    n_matches: int
    sample_redacted: str
    via: str = "value"          # "value" | "column_name"
    # What intake does with the column: "coded" (every value replaced by a keyed
    # code), "spans_redacted" (free text: only matched spans replaced), or
    # "review" (left intact; a human must decide before analysis).
    action: str = "review"
    # Fraction of the column's non-null values that matched this kind and passed
    # its type check. 0.0 for a finding made from the column name alone.
    share: float = 0.0


@dataclass
class _ColumnPlan:
    column: str
    shape: str                  # "structured" | "free_text" | "empty"
    action: str                 # "coded" | "spans_redacted" | "review" | "none"
    code_kind: str = ""
    reason: str = ""


def _as_text(ser: pd.Series) -> pd.Series:
    """Non-null values as stripped strings with ASCII digits, placeholders dropped."""
    s = ser.dropna()
    if s.empty:
        return s.astype(object)
    if pd.api.types.is_float_dtype(s) and np.isfinite(s).all() and (s == np.floor(s)).all() \
            and s.abs().max() < 1e18:
        s = s.astype("int64")                    # 4165550173.0 is 4165550173
    s = _fold_vec(s.astype(str).str.strip())
    return s[~s.str.lower().isin(_NULL_TOKENS)]


def _is_free_text(u: pd.Series, w: np.ndarray, total: int) -> bool:
    """Long or wordy. Weighted medians over unique values.

    Short wordy labels ("Awaiting pickup at depot") repeated down a column are a
    category, so 4-5 word values must also vary; but long values are free text
    even when repeated (standing delivery notes copied onto every order).
    """
    if u.empty:
        return False
    order = np.argsort(u.str.len().to_numpy(), kind="stable")
    lens = u.str.len().to_numpy()[order]
    cum = np.cumsum(w[order])
    med_len = lens[np.searchsorted(cum, total / 2.0)]
    words = (u.str.count(r"\s+") + 1).to_numpy()
    order = np.argsort(words, kind="stable")
    cum = np.cumsum(w[order])
    med_words = words[order][np.searchsorted(cum, total / 2.0)]
    varied = len(u) >= 20 or len(u) / float(total) >= 0.2
    wordy = med_words >= _FREE_TEXT_MIN_WORDS or med_len >= _FREE_TEXT_MIN_CHARS
    return wordy and (varied or med_words >= _FREE_TEXT_ALWAYS_WORDS
                      or med_len >= _FREE_TEXT_MIN_CHARS)


def _column_veto(kind: str, spans: pd.Series, values: pd.Series) -> bool:
    """Column-level evidence that digit runs are generated business numbers.

    Applied when the values share one format (INV-##########, ###-###-####, bare
    digits), so the digits are a key the business generated:
      * a near-contiguous run (order 3000000001, 3000000002, ...),
      * an arithmetic sequence with gaps (a platform stepping ids by 997),
      * for phone-shaped values, digits that read as YYYYMMDD[hh] (dates, lots).
    Never applied when the column name confirms the kind (a "phone" column may be
    a contiguous block of direct lines).
    """
    if kind not in _DIGIT_KINDS or len(spans) < 3:
        return False
    skel = values.str.replace(r"[0-9]", "9", regex=True)
    if skel.value_counts().iloc[0] / float(len(skel)) < 0.8:
        return False
    d = _digits_vec(spans)
    nums = pd.to_numeric(d, errors="coerce").dropna().drop_duplicates().sort_values()
    if len(nums) >= 3:
        arr = nums.to_numpy(dtype="float64")
        if arr[-1] - arr[0] <= 100 * len(arr):
            return True
        gaps = np.diff(arr)
        if len(gaps) >= 2:
            top = pd.Series(gaps).value_counts().iloc[0]
            if top >= max(2, 0.5 * len(gaps)):
                return True
    if kind == "phone_na":
        dt = pd.to_datetime(d.str[:8], format="%Y%m%d", errors="coerce")
        datelike = dt.notna() & (dt.dt.year >= 1900) & (dt.dt.year <= 2099)
        if datelike.mean() >= 0.5:
            return True
    return False


# ---------------------------------------------------------------- free text
# One combined pass, alternatives in precedence order, so a span is replaced once
# and a code already inserted is never re-matched.
_COMBINED = {
    i: re.compile("|".join("(?P<%s>%s)" % (k, PII_PATTERNS[k].pattern)
                           for k in KIND_PRECEDENCE[i:]))
    for i in range(len(KIND_PRECEDENCE))
}

# Free text has no column name to confirm a kind, so the words just before a span
# do that job. A number right after "order", "batch", "part", "BN", "firmware" or
# "bin" is the business's own reference; a bare digit run is only a phone or SIN
# when the note says so ("call", "SIN").
_WORD = re.compile(r"[a-z]+")
_CTX_NEG = _tokset(
    "order", "ord", "invoice", "inv", "po", "part", "sku", "lot", "batch", "serial", "sn",
    "model", "firmware", "version", "ver", "fw", "bin", "aisle", "shelf", "rack", "bay",
    "slot", "imei", "tracking", "track", "ref", "reference", "ticket", "case", "job", "acct",
    "bn", "gst", "hst", "qst", "vat", "item", "product", "upc", "ean", "isbn", "asin",
    "receipt", "transaction", "txn", "paid", "pay", "amount", "total", "qty", "quantity",
    "size", "gl", "build", "release", "unit", "asset", "stock")
_CTX_PHONE = _tokset("phone", "ph", "tel", "telephone", "cell", "mobile", "mob", "call",
                     "called", "calling", "text", "texted", "sms", "whatsapp", "reach", "contact",
                     "number", "fax", "voicemail", "vm", "ring", "dial", "line", "area")
_CTX_SIN = _tokset("sin", "ssn", "social", "insurance", "security", "taxpayer")
_CTX_CARD = _tokset("card", "visa", "mastercard", "amex", "cc", "credit", "debit", "mc")
_CTX_POSTAL = _tokset("postal", "postcode", "zip", "address", "addr", "street", "ave", "rd")
_CTX_IP = _tokset("ip", "ipv", "login", "logged", "connected", "address", "addr")


_CTX_BY_KIND = {"phone_na": _CTX_PHONE, "phone_intl": _CTX_PHONE, "sin_ssn": _CTX_SIN,
                "postal_ca": _CTX_POSTAL, "ip": _CTX_IP}


def _context_ok(kind: str, span: str, before: str) -> bool:
    if kind == "email":
        return True
    toks = [_singular(t) for t in _WORD.findall(before[-40:].lower())]
    near, allt = set(toks[-2:]), set(toks)
    formatted = bool(re.search(r"[^0-9]", span))
    if kind == "credit_card":
        return bool(allt & _CTX_CARD) or not (near & _CTX_NEG)
    # A label for the kind right before the span beats a business word next to it.
    if near & _CTX_NEG and not near & _CTX_BY_KIND.get(kind, frozenset()):
        return False
    if kind in ("phone_na", "phone_intl"):
        return formatted or bool(allt & _CTX_PHONE)
    if kind == "sin_ssn":
        return formatted or bool(allt & _CTX_SIN)
    if kind == "postal_ca":
        return (formatted and len(span) > 6) or bool(allt & _CTX_POSTAL)
    if kind == "ip":
        return bool(allt & _CTX_IP)
    return True


def _replace_spans(text: str, on_valid, level: int = 0, before: str = "") -> str:
    """Replace every type-checked, context-checked PII span via on_valid(kind, span).

    Matching runs on the digit-folded text (same length), splicing into the
    original. A span that fits a kind's pattern but fails its checks is re-searched
    for lower-precedence kinds, so a phone number inside it is still found.
    """
    norm = _fold_one(text)
    kinds = KIND_PRECEDENCE[level:]
    out, last = [], 0
    for m in _COMBINED[level].finditer(norm):
        kind = next(k for k in kinds if m.group(k) is not None)
        s, e = m.span()
        span = m.group(0)
        ctx = before + norm[:s]
        out.append(text[last:s])
        if _valid_one(kind, span) and _context_ok(kind, span, ctx):
            out.append(on_valid(kind, span))
        else:
            nxt = KIND_PRECEDENCE.index(kind) + 1
            out.append(_replace_spans(text[s:e], on_valid, nxt, ctx)
                       if nxt < len(KIND_PRECEDENCE) else text[s:e])
        last = e
    out.append(text[last:])
    return "".join(out)


def _sub_spans(texts: pd.Series, on_valid) -> pd.Series:
    """_replace_spans over a Series of (unique) texts."""
    return texts.map(lambda t: _replace_spans(t, on_valid))


# ---------------------------------------------------------------- planning
def _plan_columns(df: pd.DataFrame, names: Optional[Dict[str, str]] = None,
                  sample_rows: Optional[int] = None,
                  ) -> Tuple[List[PIIFinding], Dict[str, _ColumnPlan]]:
    names = names or {}
    frame = df if sample_rows is None else df.head(sample_rows)
    findings: List[PIIFinding] = []
    plans: Dict[str, _ColumnPlan] = {}
    for pos in range(frame.shape[1]):
        col = str(frame.columns[pos])
        col_findings: List[PIIFinding] = []
        raw = frame.iloc[:, pos]
        hint = _name_hint(names.get(col), col)
        text = _as_text(raw)
        total = len(text)
        if hint is not None and hint in _COUNT_OK_HINTS and total:
            vc0 = text.value_counts(sort=False)
            if _is_count_column(pd.Series(vc0.index.astype(str), dtype=object), vc0.to_numpy()):
                hint = None
        if hint is not None:
            col_findings.append(PIIFinding(col, "named_" + hint, int(raw.notna().sum()),
                                           "(column name declares it)", via="column_name"))
        if total == 0:
            plan = _ColumnPlan(col, "empty", "review" if col_findings else "none",
                               reason="name" if col_findings else "")
        else:
            vc = text.value_counts(sort=False)
            u = pd.Series(vc.index.astype(str), dtype=object)
            w = vc.to_numpy()
            if _is_free_text(u, w, total):
                plan = _plan_free_text(col, u, w, total, col_findings)
            else:
                confirmed, place = _confirmed_kinds(names.get(col), col)
                plan = _plan_structured(col, u, w, total, col_findings, confirmed, place)
        for f in col_findings:
            f.action = plan.action if plan.action != "none" else "review"
        findings.extend(col_findings)
        plans[col] = plan
    return findings, plans


def _extract(vals: pd.Series, kind: str) -> pd.Series:
    got = vals.str.extract("(?P<m>%s)" % PII_PATTERNS[kind].pattern, expand=True)
    return got["m"]


# Signed or decimal numbers are amounts, never ids of people: "-2345678901".
_AMOUNT = re.compile(r"-[0-9]+(?:\.[0-9]+)?|\+?[0-9]+\.[0-9]+")


def _plan_structured(col, u, w, total, col_findings, confirmed=frozenset(),
                     place=False) -> _ColumnPlan:
    claimed = np.zeros(len(u), dtype=bool)
    ndig = u.str.count(r"[0-9]").to_numpy()
    lens = u.str.len().to_numpy()
    amount = u.str.fullmatch(_AMOUNT).to_numpy(dtype=bool)
    low = u.str.lower()
    prefilter = {
        "email": (u.str.contains("@", regex=False) | low.str.contains("%40", regex=False)
                  | low.str.contains("[at]", regex=False)
                  | low.str.contains("(at)", regex=False)).to_numpy(dtype=bool),
        "credit_card": (ndig >= 13) & ~amount,
        "phone_na": (ndig >= 10) & ~amount,
        "phone_intl": (ndig >= 8) & ~amount & u.str.contains("+", regex=False).to_numpy(dtype=bool),
        "sin_ssn": (ndig >= 9) & ~amount,
        "postal_ca": (lens >= 6) & (ndig >= 3),
        "ip": (ndig >= 4) & u.str.contains(".", regex=False).to_numpy(dtype=bool),
    }
    fam_share: Dict[str, float] = {}
    fam_kind: Dict[str, Tuple[str, float]] = {}
    for kind in KIND_PRECEDENCE:
        cand = prefilter[kind] & ~claimed
        if not cand.any():
            continue
        vals = u[cand]
        spans = _extract(vals, kind)
        hit = spans.notna().to_numpy()
        if not hit.any():
            continue
        valid = np.zeros(len(vals), dtype=bool)
        valid[hit] = _valid_vec(kind, spans[hit])
        if not valid.any():
            continue
        if kind not in confirmed and _column_veto(kind, spans[valid], vals[valid]):
            continue
        idx = np.flatnonzero(cand)[valid]
        claimed[idx] = True                      # reported once, under this kind
        n = int(w[idx].sum())
        share = n / float(total)
        col_findings.append(PIIFinding(col, kind, n, _redact(str(spans[valid].iloc[0])),
                                       via="value", share=share))
        fam = _FAMILY.get(kind, kind)
        fam_share[fam] = fam_share.get(fam, 0.0) + share
        if share > fam_kind.get(fam, ("", -1.0))[1]:
            fam_kind[fam] = (kind, share)
    if fam_share:
        fam = max(fam_share, key=lambda f: fam_share[f])
        if fam_share[fam] >= DOMINANT_SHARE:
            if place:
                return _ColumnPlan(col, "structured", "review", reason="business_place")
            if fam == "email" or fam in confirmed:
                return _ColumnPlan(col, "structured", "coded", code_kind=fam_kind[fam][0])
            return _ColumnPlan(col, "structured", "review", reason="unconfirmed")
        return _ColumnPlan(col, "structured", "review", reason="weak")
    share, n_names, one = _person_name_share(u, w, total)
    if share >= PERSON_NAME_MIN_SHARE and n_names >= 2:
        col_findings.append(PIIFinding(col, "person_name", int(round(share * total)), _redact(one),
                                       via="value", share=share))
        return _ColumnPlan(col, "structured", "review", reason="people")
    if col_findings:
        return _ColumnPlan(col, "structured", "review", reason="name")
    return _ColumnPlan(col, "structured", "none")


def _plan_free_text(col, u, w, total, col_findings) -> _ColumnPlan:
    samples: Dict[str, str] = {}

    def mark(kind: str, span: str) -> str:
        if kind not in samples:
            samples[kind] = _redact(span)        # never keep the raw span
        return "\x00%d\x00" % KIND_PRECEDENCE.index(kind)

    marked = _sub_spans(u, mark)
    any_hit = np.zeros(len(u), dtype=bool)
    for i, kind in enumerate(KIND_PRECEDENCE):
        if kind not in samples:
            continue
        per_value = marked.str.count("\x00%d\x00" % i).to_numpy()
        has = per_value > 0
        any_hit |= has
        col_findings.append(PIIFinding(col, kind, int((per_value * w).sum()), samples[kind],
                                       via="value", share=float(w[has].sum()) / total))
    action = "spans_redacted" if any_hit.any() else "review"
    return _ColumnPlan(col, "free_text", action, reason="free_text")


def scan_pii(df: pd.DataFrame, sample_rows: Optional[int] = None) -> List[PIIFinding]:
    """Scan EVERY value of every column (sample_rows only if a caller opts in).

    Returns findings; never logs the raw value. Each finding's `action` says what
    land_file will do with that column and `share` how much of it matched.
    """
    return _plan_columns(df, sample_rows=sample_rows)[0]


def _redact(s: str) -> str:
    """A shape hint for a finding, never enough to recover the value: an email
    keeps only its first character, anything else its first and last."""
    s = str(s)
    if "@" in s or "%40" in s.lower() or "[at]" in s.lower() or "(at)" in s.lower():
        return s[:1] + "***@***"
    if len(s) > 6:
        return s[:1] + "***" + s[-1:]
    return s[:1] + "***"


_EMAIL_AT = re.compile(r"\s?(?:%40|\[at\]|\(at\))\s?| @ ", re.IGNORECASE)


def _normalise_for_kind(value: Any, kind: str) -> str:
    """One person, one code: 416-555-0173 and (416) 555-0173 are the same number."""
    v = _fold_one(str(value).strip())
    if kind == "email":
        return _EMAIL_AT.sub("@", v).lower()
    if kind in _DIGIT_KINDS:
        digits = re.sub(r"[^0-9]", "", v)
        if kind in ("phone_na", "phone_intl") and len(digits) == 11 and digits.startswith("1"):
            digits = digits[1:]
        return digits
    return v


def _check_key(key: Any) -> bytes:
    if not isinstance(key, (bytes, bytearray)) or len(key) < 16:
        raise ValueError("redact_columns needs a secret key of at least 16 bytes; an unkeyed "
                         "hash of a phone number or email can be reversed by guessing")
    return bytes(key)


def _code(key: bytes, value: Any, kind: str) -> str:
    return "rdc_" + hmac.new(key, _normalise_for_kind(value, kind).encode("utf-8"),
                             hashlib.sha256).hexdigest()[:20]


def redact_columns(
    df: pd.DataFrame,
    columns: List[str],
    key: Optional[bytes] = None,
    kinds: Optional[Dict[str, str]] = None,
) -> pd.DataFrame:
    """
    Replace values with KEYED pseudonyms (HMAC-SHA256, per-engagement secret key).

    Within one engagement the same value always gets the same code, so counts and
    joins still work. Without the key, a code cannot be reversed by trying
    candidates, and two engagements' codes for the same person do not match.

    Regression, 22 Sep 2026: codes used to be unsalted, truncated SHA-256 and were
    described as one-way. A Toronto phone number reversed instantly by hashing
    candidates -- a whole area code in about five seconds. A key is now required.
    """
    k = _check_key(key)
    kinds = kinds or {}
    out = df.copy()
    for c in columns:
        if c in out.columns:
            kind = kinds.get(c, "")
            out[c] = out[c].map(lambda v, _k=kind: "" if pd.isna(v) else _code(k, v, _k))
    return out


def redact_text_spans(df: pd.DataFrame, columns: List[str], key: Optional[bytes] = None
                      ) -> pd.DataFrame:
    """
    Free-text columns: replace only the type-checked PII spans, in place, with the
    same keyed code a coded column would use for that value (so an email in a note
    and the same email in an email column still link). The rest of the text stays.
    Names are NOT found this way -- such columns also need human review.
    """
    k = _check_key(key)
    out = df.copy()
    for c in columns:
        if c not in out.columns:
            continue
        ser = out[c]
        nn = ser.notna()
        if not nn.any():
            continue
        txt = ser[nn].astype(str)
        uniq = pd.Series(pd.unique(txt), dtype=object)
        rep = _sub_spans(uniq, lambda kind, span: _code(k, span, kind))
        out[c] = ser.astype(object)
        out.loc[nn, c] = txt.map(dict(zip(uniq, rep)))
    return out


# ---------------------------------------------------------------- reading
def _sniff_text(path: str) -> Tuple[str, str]:
    """Return (encoding, delimiter). Never trusts the extension."""
    with open(path, "rb") as fh:
        raw = fh.read(SNIFF_BYTES)
    encoding = "utf-8"
    for enc in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        try:
            text = raw.decode(enc)
            encoding = enc
            break
        except UnicodeDecodeError:
            continue
    else:
        text = raw.decode("latin-1", errors="replace")
        encoding = "latin-1"

    try:
        delim = csv.Sniffer().sniff(text[:16384], delimiters=",;\t|").delimiter
    except csv.Error:
        counts = {d: text.count(d) for d in (",", ";", "\t", "|")}
        delim = max(counts, key=counts.get) if max(counts.values()) else ","
    return encoding, delim


def _read_any(path: str, max_rows: int, header: Optional[int] = 0,
              skiprows: int = 0) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """Read a file. header=None reads every row as data (numbered columns)."""
    suffix = os.path.splitext(path)[1].lower()
    meta: Dict[str, Any] = {"suffix": suffix}

    if suffix in (".xlsx", ".xlsm", ".xls"):
        # openpyxl is installed; xlrd is not, so legacy .xls will raise clearly.
        try:
            df = pd.read_excel(path, nrows=max_rows, dtype=object, header=header,
                               skiprows=skiprows or None)
            if header == 0 and not skiprows:
                # A title in A1 ("Customer export - September 2026") above the real
                # header: every other header cell is empty. Use the first full row.
                # Only a sentence-like A1 counts as a title, and a row is only promoted
                # when it reads as column names (short, no digits, nothing personal-
                # information shaped); otherwise a data row would become the schema.
                cols = [str(c) for c in df.columns]
                unnamed = sum(c.startswith("Unnamed:") for c in cols)
                if len(cols) >= 2 and unnamed == len(cols) - 1 and len(cols[0].split()) >= 3:
                    for i in range(min(10, len(df))):
                        row = df.iloc[i].dropna()
                        if len(row) < max(2, 0.8 * len(cols)):
                            continue
                        cells = [str(v) for v in row]
                        if all(isinstance(v, str) for v in row) \
                                and not any(re.search(r"[0-9]", c) for c in cells) \
                                and all(len(c.split()) <= 4 for c in cells) \
                                and not _header_looks_like_data(cells):
                            df = pd.read_excel(path, nrows=max_rows, dtype=object, header=i + 1)
                            meta["title_rows_skipped"] = i + 1
                        break
        except Exception as exc:  # noqa: BLE001
            raise IntakeError(
                "Could not read this spreadsheet (%s). If it is an old .xls file, "
                "please re-save it as .xlsx or CSV and send it again." % type(exc).__name__
            )
        meta["reader"] = "excel"
        return df, meta

    if suffix in (".json", ".jsonl"):
        try:
            df = pd.read_json(path, lines=(suffix == ".jsonl"), dtype=object)
        except ValueError as exc:
            raise IntakeError("Could not parse this JSON file: %s" % str(exc)[:160])
        meta["reader"] = "json"
        return df.head(max_rows), meta

    encoding, delim = _sniff_text(path)
    meta.update({"reader": "csv", "encoding": encoding, "delimiter": delim})
    try:
        df = pd.read_csv(
            path, encoding=encoding, sep=delim, dtype=object,
            nrows=max_rows, on_bad_lines="warn", low_memory=False,
            skip_blank_lines=True, header=header, skiprows=skiprows or None,
        )
    except Exception as exc:  # noqa: BLE001
        raise IntakeError("Could not parse this file as a table: %s" % str(exc)[:160])
    return df, meta


def _header_looks_like_data(columns: Any) -> bool:
    """A header cell holding an email, phone, SIN or card is a data row, not names.
    (A headerless export would otherwise turn a customer's details into column
    names, which appear in the schema, the receipt and every finding.)"""
    for c in columns:
        text = _fold_one(str(c))
        for kind in ("email", "credit_card", "phone_na", "phone_intl", "sin_ssn"):
            for m in PII_PATTERNS[kind].finditer(text):
                if _valid_one(kind, m.group(0)):
                    return True
    return False


# ---------------------------------------------------------------- landing
_SAFE = re.compile(r"[^a-z0-9_]+")


def safe_table_name(original: str, prefix: str = "client") -> str:
    """Generated, never taken raw from the upload -- an upload names a file, not a table."""
    stem = os.path.splitext(os.path.basename(original))[0].lower()
    stem = _SAFE.sub("_", stem).strip("_") or "upload"
    name = ("%s_%s" % (_SAFE.sub("_", prefix.lower()).strip("_") or "client", stem))[:48]
    # Guard the FINAL identifier, not the stem: the prefix normally already
    # protects it, so prepending to the stem just produced client_t_2024_sales.
    if name[0].isdigit():
        name = "t_" + name
    return name


def normalise_columns(df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, str]]:
    """Column names arrive as ' Order  ID ', 'Order ID', 'order_id'. Collapse, keep a map."""
    mapping: Dict[str, str] = {}
    seen: Dict[str, int] = {}
    new_cols = []
    for i, c in enumerate(df.columns):
        raw = str(c)
        base = _SAFE.sub("_", raw.strip().lower()).strip("_")
        if not base or base.startswith("unnamed"):
            base = "col_%d" % (i + 1)
        if base in seen:
            seen[base] += 1
            base = "%s_%d" % (base, seen[base])
        else:
            seen[base] = 0
        mapping[raw] = base
        new_cols.append(base)
    out = df.copy()
    out.columns = new_cols
    return out, mapping


@dataclass
class IntakeResult:
    source_path: str
    table: str
    db_path: str
    n_rows: int
    n_cols: int
    bytes_in: int
    sha256: str
    column_map: Dict[str, str] = field(default_factory=dict)
    read_meta: Dict[str, Any] = field(default_factory=dict)
    pii: List[PIIFinding] = field(default_factory=list)
    redacted_columns: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    truncated: bool = False
    # The engagement's pseudonymisation key. Never serialised, never printed; the
    # caller stores it with the engagement, outside the landed database.
    redaction_key: Optional[bytes] = field(default=None, repr=False)
    key_was_created: bool = False
    # Every column a human must decide on before analysis: name-flagged, weak
    # value matches, and all free text. Left intact in the landed table.
    review_columns: List[str] = field(default_factory=list)
    # column -> plain-language reason (never a value).
    review_reasons: Dict[str, str] = field(default_factory=dict)
    # Free-text columns in which only the recognised PII spans were coded.
    span_redacted_columns: List[str] = field(default_factory=list)

    @property
    def has_pii(self) -> bool:
        return bool(self.pii)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d.pop("redaction_key", None)
        d["pii"] = [asdict(p) for p in self.pii]
        d["has_pii"] = self.has_pii
        return d

    def client_summary(self) -> str:
        """Plain-language landing receipt -- the first thing a client ever reads from us."""
        lines = [
            "Received: %s" % os.path.basename(self.source_path),
            "Landed %s rows x %s columns." % (format(self.n_rows, ","), self.n_cols),
        ]
        if self.truncated:
            lines.append(
                "Note: only the first %s rows were read (size cap). Tell us if you need the rest."
                % format(self.n_rows, ",")
            )
        acted_cols = set(self.redacted_columns) | set(self.span_redacted_columns)
        acted = sorted({p.kind for p in self.pii if p.via == "value" and p.column in acted_cols
                        and p.action in ("coded", "spans_redacted")})
        if acted:
            # Plain words for the client; the scanner's kind labels (phone_na, sin_ssn) are
            # internal. And a keyed code is a pseudonym, not "non-identifying": the same value
            # always gets the same code, which is what keeps counts and joins working.
            plain = []
            for k in acted:
                w = _PLAIN_KIND.get(k, k.replace("_", " "))
                if w not in plain:
                    plain.append(w)
            lines.append((
                "Personal information detected: %s. %s"
                % (", ".join(plain),
                   ("These columns were coded with a private key: %s. Each value is replaced by a "
                    "code, the same value always gets the same code so counts still work, and the "
                    "codes cannot be turned back into the values without the key."
                    % ", ".join(self.redacted_columns)) if self.redacted_columns else "")
            ).rstrip())
        elif self.pii:
            # Only flags: say so plainly, and do not claim anything was found or changed.
            lines.append("Possible personal information: nothing was changed. %s" % (
                "The columns below are awaiting your decision." if self.review_columns
                else "Tell us if you would like anything removed."))
        if self.span_redacted_columns:
            lines.append(
                "In the free-text columns %s, we replaced the emails, phone numbers and similar "
                "details we could recognise with codes and left the rest of the text unchanged. "
                "A scanner cannot find names and can miss unusually written details, so these "
                "columns are also awaiting your decision." % ", ".join(self.span_redacted_columns))
        if self.review_columns:
            lines.append(
                "Awaiting your decision before analysis (%d column%s):"
                % (len(self.review_columns), "" if len(self.review_columns) == 1 else "s"))
            for c in self.review_columns:
                lines.append("  - %s: %s." % (c, self.review_reasons.get(c, "needs a look")))
        if (self.redacted_columns or self.span_redacted_columns) and self.key_was_created:
            lines.append(
                "A new private key was created to code these columns. It is kept with your "
                "engagement, never in the data; later files can only be linked to these codes "
                "with it, and without it the codes cannot be reversed or re-created.")
        for w in self.warnings:
            lines.append("Warning: %s" % w)
        return "\n".join(lines)


_PLAIN_KIND = {
    "email": "email addresses",
    "phone_na": "phone numbers",
    "phone_intl": "phone numbers",
    "sin_ssn": "national ID numbers",
    "credit_card": "payment card numbers",
    "postal_ca": "postal codes",
    "ip": "IP addresses",
}

def land_file(
    path: str,
    db_path: str,
    max_bytes: int = MAX_BYTES_DEFAULT,
    max_rows: int = MAX_ROWS_DEFAULT,
    auto_redact: bool = True,
    table_prefix: str = "client",
    redact_key: Optional[bytes] = None,
) -> IntakeResult:
    """Read a messy client file and land it into SQLite. Raises IntakeError on refusal."""
    if not os.path.exists(path):
        raise IntakeError("No such file: %s" % path)
    size = os.path.getsize(path)
    if size == 0:
        raise IntakeError("That file is empty.")
    if size > max_bytes:
        raise IntakeError(
            "That file is %.1f MB; the intake limit is %.0f MB. Send a sample or a date range, "
            "or ask us about a direct database connection."
            % (size / 1e6, max_bytes / 1e6)
        )
    suffix = os.path.splitext(path)[1].lower()
    if suffix not in READABLE_SUFFIXES:
        raise IntakeError(
            "Unsupported file type '%s'. Send CSV, TSV, Excel (.xlsx) or JSON." % (suffix or "none")
        )

    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)

    df, read_meta = _read_any(path, max_rows)
    warnings: List[str] = []
    headerless = False
    if read_meta.get("reader") in ("csv", "excel") and _header_looks_like_data(df.columns):
        # Keep the first row as data and number the columns; never let a value
        # become a column name.
        skip = int(read_meta.get("title_rows_skipped", 0))
        df, meta2 = _read_any(path, max_rows, header=None, skiprows=skip)
        read_meta.update(meta2)
        read_meta["header_row"] = False
        df.columns = ["col_%d" % (i + 1) for i in range(df.shape[1])]
        headerless = True
        warnings.append("the first row looked like data, not column names, so it was kept as "
                        "data and the columns were numbered")
    truncated = len(df) >= max_rows
    if df.empty:
        raise IntakeError("That file parsed to zero rows -- is the data on another sheet or tab?")

    df, colmap = normalise_columns(df)
    if len(df.columns) != len(set(df.columns)):
        warnings.append("duplicate column names were made unique")

    # Scan with the ORIGINAL column names too: normalising turns "FirstName" into
    # "firstname" and would hide the camelCase tokens from the name hints.
    pii, plans = _plan_columns(df, names={v: k for k, v in colmap.items()})
    if not auto_redact:
        # Nothing is coded, so everything the scanner would have acted on waits
        # for a human instead.
        for p in pii:
            p.action = "review"
        for pl in plans.values():
            if pl.action in ("coded", "spans_redacted"):
                pl.reason = "auto_redact_off" if pl.shape != "free_text" else pl.reason
                pl.action = "review"
    # Code only structured columns where one kind is DOMINANT and type-checked. A
    # column merely *named* "address" may hold a warehouse location, and a column
    # that only partly looks like phone numbers may be order ids: flag, let a
    # human decide. Free text keeps its words; only matched spans are coded.
    if headerless:
        # No column names at all: nothing confirms what a column holds.
        for pl in plans.values():
            if pl.action == "none":
                pl.action, pl.reason = "review", "no_header"
    redacted = [c for c in df.columns if plans[c].action == "coded"]
    spans = [c for c in df.columns if plans[c].action == "spans_redacted"]
    review = [c for c in df.columns
              if plans[c].action == "review" or plans[c].shape == "free_text"]
    reasons = {c: _review_reason(plans[c]) for c in review}
    key_created = False
    if redacted or spans:
        if redact_key is None:
            redact_key, key_created = os.urandom(32), True
        df = redact_columns(df, redacted, key=redact_key,
                            kinds={c: plans[c].code_kind for c in redacted})
        df = redact_text_spans(df, spans, key=redact_key)

    table = safe_table_name(path, table_prefix)
    os.makedirs(os.path.dirname(os.path.abspath(db_path)) or ".", exist_ok=True)
    con = sqlite3.connect(db_path)
    try:
        df.to_sql(table, con, if_exists="replace", index=False)
        con.commit()
        n = con.execute('SELECT COUNT(*) FROM "%s"' % table).fetchone()[0]
    finally:
        con.close()

    if n != len(df):
        raise IntakeError(
            "Landing check failed: read %d rows but stored %d. Nothing was published." % (len(df), n)
        )

    return IntakeResult(
        source_path=path, table=table, db_path=db_path, n_rows=int(n),
        n_cols=len(df.columns), bytes_in=size, sha256=h.hexdigest(),
        column_map=colmap, read_meta=read_meta, pii=pii,
        redacted_columns=redacted, warnings=warnings, truncated=truncated,
        redaction_key=redact_key if (redacted or spans) else None, key_was_created=key_created,
        review_columns=review, review_reasons=reasons, span_redacted_columns=spans,
    )


_REVIEW_REASONS = {
    "name": "its name suggests personal information; the values were left as received",
    "weak": "some values look like personal information, but not consistently enough "
            "to code the column automatically; left as received",
    "auto_redact_off": "personal information found, and automatic coding was switched off; "
                       "left as received",
    "free_text": "free text; names and other personal details cannot be found reliably "
                 "by a scanner",
    "unconfirmed": "most values have the shape of personal information (such as phone numbers "
                   "or SINs), but the column name does not confirm it, and business ids, "
                   "versions and codes share these shapes; left as received",
    "business_place": "most values have the shape of personal information, but the column "
                      "name says they belong to a store, branch or supplier; left as received",
    "no_header": "the file had no header row, so nothing says what this column holds; "
                 "left as received",
    "people": "most values read as people's names (a given name and a family name); "
              "left as received",
}


def _review_reason(plan: _ColumnPlan) -> str:
    return _REVIEW_REASONS.get(plan.reason, "needs a look before analysis")
