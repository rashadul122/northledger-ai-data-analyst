#!/usr/bin/env python3
"""
Stage 7: the confidence gate.

This is the module that decides whether a measured `Fact` is allowed to become
ADVICE a business owner acts on. It is the mechanical form of the project's
promise: **a memo is WITHHELD, not wrong**.

Nothing here looks at prose. It looks only at the signals stage 4 recorded on
the Fact -- how much data was scanned, how big the move is, how long it held,
how healthy the source is, whether a chance explanation survives, and what else
moved at the same time -- and returns one of RECOMMEND / WATCH / INSUFFICIENT
with a reason written for the client, not for an analyst.

Conventions this module assumes (stage 4 must honour them):

* ``effect_size`` is a *fraction of the series' own baseline*: 0.06 means the
  measured quantity sits 6% away from its usual level. Direction does not
  matter to the gate -- a 20% drop is as actionable as a 20% rise -- so every
  comparison uses ``abs(effect_size)``.
* ``periods_observed`` counts the time buckets the pattern held (months, in a
  monthly report).
* ``confounders`` lists things that moved alongside the finding. An entry is
  treated as already handled -- and so does not count against the fact -- when
  it starts with one of ``MODELLED_PREFIXES``, e.g.
  ``"modelled: seasonality"``. Anything else is unmodelled.

Python 3.9 compatible.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
from dataclasses import dataclass, asdict
from typing import Any, Dict, Iterable, List, Optional, Tuple

from northledger.facts import Fact, GateResult, GatedFact
from northledger import stats as _stats
from northledger.stats import MIN_MONTHS_PER_WINDOW as _MIN_MONTHS
from northledger.vocab import CLEAN_QUERY_MARKER, RETENTION_CAVEAT, plural_of

#: Allowed values for :attr:`GatePolicy.fdr_method`.
FDR_METHODS = ("bh", "by")

#: Allowed values for :attr:`GatePolicy.confounder_policy`.
CONFOUNDER_POLICIES = ("downgrade_always", "downgrade_if_small")

#: A confounder whose text starts with one of these was already accounted for
#: by the query that produced the fact, so the gate ignores it.
MODELLED_PREFIXES = ("modelled:", "modeled:", "controlled:", "adjusted:")

#: Rule names written into ``GateResult.signals["rule"]``, in precedence order.
RULES = (
    "data_health_floor",      # 1
    "unusable_signal",        # 2
    "zero_tolerance",         # 2b
    "min_rows_watch",         # 3
    "p_value",                # 4
    "confounder",             # 5
    "untested_trend",         # 5b
    "recommend",              # 6
    "below_recommend_bar",    # 7
)

#: Rule names only a change claim carrying the R1 change test can receive (design §2.4), in
#: the order checked. It also receives data_health_floor, unusable_signal, min_rows_watch,
#: untested_trend, confounder, below_recommend_bar and recommend from RULES.
CHANGE_RULES = (
    "tested_below_bar",       # the test asked about a smaller bar than the policy's
    "min_effect_p",           # the change is not shown to be at least the bar
    "too_close_to_call",      # the Monte Carlo interval of p straddles the line
    "benchmark_condition",    # a condition the benchmark cannot certify (§3.4), routed by rule
    "drift_screen",           # the series wanders or drifts steadily
    "short_history",          # fewer months than the certified minimum
    "fdr",                    # did not survive false-discovery control across the run
)


@dataclass
class GatePolicy:
    """
    Every threshold the gate uses, in one tunable place.

    The owner of the engine changes conservatism here and nowhere else. Each
    field names the trade-off it controls: loosening one buys more advice and
    spends some of the trust claim.
    """

    # How much data a finding must rest on before it can be advice. Raise it and
    # thin slices (one branch, one month) stop producing recommendations; lower
    # it and the memo starts advising on samples that will not hold next quarter.
    min_rows_recommend: int = 1000

    # Smallest move worth acting on, as a fraction of the series' own baseline
    # (0.05 = 5%). This is a *materiality* bar, not a statistical one: below it
    # the finding may be perfectly real and still not worth changing anything
    # over. Raise it to stop shipping trivia; lower it and the memo fills with
    # true-but-pointless observations.
    min_effect_recommend: float = 0.05

    # How many time buckets the pattern must have held. This is the defence
    # against one-off spikes. Raise it and advice arrives later but survives
    # longer; lower it and a single strange month becomes a recommendation.
    min_periods_recommend: int = 3

    # HARD VETO. If the source table's stage-1 health score is below this,
    # nothing measured from it may be RECOMMEND no matter how large or durable
    # the effect looks -- a big effect in a poisoned table is usually a big
    # artefact. This is the one threshold that should be raised, never lowered,
    # under pressure to produce findings.
    data_health_floor: float = 70.0

    # Floor for even mentioning a finding as something to WATCH. Below this the
    # number is noise and the gate says so rather than implying a trend exists.
    # Raise it to keep speculative items out of the memo entirely.
    min_rows_watch: int = 100

    # What to do when something moved at the same time as the finding and was
    # not accounted for. "downgrade_always" is the conservative stance: an
    # uncontrolled comparison never becomes advice. "downgrade_if_small" lets a
    # large effect through on the argument that a confounder is unlikely to
    # explain the *whole* of a big move -- faster, and the place where a wrong
    # recommendation is most likely to come from.
    confounder_policy: str = "downgrade_always"

    # Under "downgrade_if_small", the line between "a confounder could explain
    # all of this" and "a confounder could only explain part of this", as a
    # fraction of baseline. Sits above min_effect_recommend on purpose: the two
    # answer different questions (worth acting on vs. safely attributable).
    small_effect_threshold: float = 0.10

    # Largest chance-probability the gate will still call settled. Only applies
    # when stage 4 ran a test and set p_value; facts with no test are judged on
    # size and durability instead. Lower it to demand stronger evidence and get
    # fewer recommendations.
    max_p_value: float = 0.05

    # A CHANGE over time needs a significance test before it is advice. Without one,
    # a move of a few standard deviations in a noisy series clears every size and
    # persistence bar: on 22 Sep 2026 a noise-level month-on-month change was gated
    # RECOMMEND, and roughly 45% of stationary random series would have passed.
    # True: an untested trend is at most WATCH. False: size and persistence alone
    # may make it advice -- faster, and the most likely source of a wrong call.
    # Conditions measured now (fact_kind "state") are not affected.
    require_test_for_trends: bool = True

    # SANITY STOP on the cleaner itself. When cleaning sets aside more than this
    # share of a table's rows (not counting rows collapsed by design to the latest
    # row per key), the cleaner is more likely wrong than the file: every cleaning
    # figure from that table is withheld as INSUFFICIENT. 23 Sep 2026: a date rule
    # on a free-text column quarantined 99.92% of a file and the brief told the
    # client to fix it -- the defect was ours. Raise it only for a source known to
    # be mostly junk; lowering it withholds cleaning results more often.
    max_quarantine_rate: float = 0.20

    # --- the change test (R1, design §2.1 M1-M4 and the §2.4 confidence policy) -----------
    # A change claim from measure.measure_facts carries a one-sided MINIMUM-EFFECT p-value:
    # "is the change at least min_effect_recommend?", from a model of the monthly values
    # calibrated by a parametric bootstrap. These fields judge it. Facts without that test
    # (min_effect is None) are judged by max_p_value exactly as before.

    # Largest minimum-effect p (after false-discovery control) at which a change is
    # CONFIRMED. The primary claim is tested alone at this level; the secondary claims form
    # one Benjamini-Hochberg family at this level, so exploring more columns cannot dilute
    # the headline or inflate the run's false confirmations (M3). Lower it for fewer false
    # alarms and less power; the benchmark (§3) publishes both at the value chosen.
    recommend_q: float = 0.01

    # Two-sided point-null p at or under which a change that did not clear the bar is
    # described as "changed, but not yet shown to be at least the bar" rather than "no
    # change shown". Wording only: both are WATCH.
    watch_p: float = 0.10

    # "bh" (Benjamini-Hochberg) or "by" (Benjamini-Yekutieli, valid under any dependence,
    # about 2.3-2.9 times stricter for 5-10 claims). Switch to "by" if the benchmark's
    # realised false-discovery rate exceeds recommend_q by more than 2 Monte Carlo SEs.
    fdr_method: str = "bh"

    # The claim the visitor cares about most: "volume", or a measure's column name. It is
    # tested alone at recommend_q. "" means volume when the file has a volume claim.
    primary_metric: str = ""

    # Months of history the change model must read before a change can be CONFIRMED. 24 is
    # the least a 12-versus-12 comparison needs; the design withdrew the hard 36-month rule
    # and lets the benchmark (§3) certify each condition. Raise it for a condition the
    # benchmark shows failing at 24.
    min_history_for_trend_recommend: int = 24

    # Hold a change at WATCH when the series wanders (momentum cannot be told from a random
    # walk) or drifts steadily (a linear trend is established): a 12-versus-12 gap is then
    # expected without any change (M2). False lets such claims through: faster, and wrong
    # on every steadily growing business.
    drift_screen: bool = True

    def __post_init__(self) -> None:
        if self.confounder_policy not in CONFOUNDER_POLICIES:
            raise ValueError(
                "confounder_policy must be one of %s, got %r"
                % (CONFOUNDER_POLICIES, self.confounder_policy)
            )
        if not (0.0 <= self.data_health_floor <= 100.0):
            raise ValueError(
                "data_health_floor must be 0-100, got %r" % (self.data_health_floor,)
            )
        if not (0.0 < self.max_p_value <= 1.0):
            raise ValueError(
                "max_p_value must be in (0, 1], got %r" % (self.max_p_value,)
            )
        if not (0.0 < self.max_quarantine_rate <= 1.0):
            raise ValueError(
                "max_quarantine_rate must be in (0, 1], got %r" % (self.max_quarantine_rate,)
            )
        if not (0.0 < self.recommend_q <= 1.0):
            raise ValueError("recommend_q must be in (0, 1], got %r" % (self.recommend_q,))
        if not (0.0 < self.watch_p <= 1.0):
            raise ValueError("watch_p must be in (0, 1], got %r" % (self.watch_p,))
        if self.fdr_method not in FDR_METHODS:
            raise ValueError("fdr_method must be one of %s, got %r" % (FDR_METHODS, self.fdr_method))
        if self.min_history_for_trend_recommend < 24:
            raise ValueError("min_history_for_trend_recommend cannot be under 24: a 12-versus-12 "
                             "comparison needs 24 months")
        if self.min_rows_watch < 0 or self.min_rows_recommend < 0:
            raise ValueError("row thresholds cannot be negative")
        if self.min_periods_recommend < 0:
            raise ValueError("min_periods_recommend cannot be negative")
        if self.min_effect_recommend < 0 or self.small_effect_threshold < 0:
            raise ValueError("effect thresholds cannot be negative")
        if self.min_rows_recommend < self.min_rows_watch:
            raise ValueError(
                "min_rows_recommend (%r) cannot sit below min_rows_watch (%r): a "
                "finding would need more evidence to be worth watching than to be "
                "advice" % (self.min_rows_recommend, self.min_rows_watch)
            )
        if self.small_effect_threshold < self.min_effect_recommend:
            raise ValueError(
                "small_effect_threshold (%r) cannot sit below min_effect_recommend "
                "(%r): confounders would be tolerated on moves too small to act on"
                % (self.small_effect_threshold, self.min_effect_recommend)
            )


DEFAULT_POLICY = GatePolicy()

#: Design §3.4's calibration step, applied: a condition in which the benchmark cannot certify
#: the false-confirm rate is routed to WATCH by rule, never shown CONFIRMED.
#:
#: The one condition a series' own diagnostics can detect is a volume of fewer than
#: ROUTE_MIN_ROWS_A_MONTH rows in the average month of the two compared windows. Measured (23 Sep
#: 2026: the standard receipt, master seed 20260923, plus fresh series at seeds 424242 and
#: 515151; scratchpad v2r/infer-harden), with the true change exactly at the 5% bar and AR(1)
#: momentum 0.8 in the log monthly counts, 24 months: 100 rows a month confirmed 92 of 6,000
#: series (1.53%), the highest rate of any gated condition, where counting noise is half the
#: monthly variance; 300, 500, 1,000 and 3,000 rows a month confirmed 106 of 9,400 together
#: (1.13%; each 0.9-1.2%), no different from each other, so the line sits under 300. At 36
#: months 100 rows a month measured 43 of 4,000 (1.08%); the gated cells there fail
#: certification too (12 and 13 of 1,000 on the standard receipt), and are routed with the rest.
#:
#: What is NOT routed, and why: the other failing cells (momentum 0.8 plus independent noise at
#: 1,000 rows a month; 300 rows a month) confirm when the model UNDER-estimates the momentum,
#: so no run-time diagnostic sees them. Measured on the same design data, every candidate rule
#: on estimated momentum (AR(1) phi <= -0.2, <= -0.3, < 0; the momentum-plus-noise model's phi
#: >= 0.5 or >= 0.7 with a white-noise share; their gap >= 0.3) or on the older year's shift
#: (|t| >= 1.5) either left those cells at 1.1-2.1% or cut power at a 20% change from about 20%
#: to 1.5-2% (24 months, no momentum); a rule on history alone (24 months) would remove all
#: power at 24 months. Those cells need the method repaired (design M2's registered sieve /
#: ARMA(1,1) bootstrap), not a routing rule.
ROUTE_MIN_ROWS_A_MONTH = 200

#: The same calibration step for MONTHLY TOTALS of a money or count column (ship round, 24 Sep
#: 2026), derived from the benchmark's own total cells, not borrowed from the counts' rule above.
#: A monthly total's counting noise is the rows' Poisson noise times the spread of the amounts:
#: on the log scale its variance is (1 + CV^2) / rows, CV the coefficient of variation of the
#: row amounts. So the condition is read on the EFFECTIVE rows a month, rows / (1 + CV^2): the
#: number of rows of one fixed amount that would carry the same noise.
#:
#: Measured (engine f8694260f465, 36 months, true change exactly the 5% bar, AR(1) momentum SD
#: 0.10 on the log scale; rows a month 30/100/300/1,000 Poisson, amounts lognormal with log SD
#: 0.25 (CV 0.25, like rents) or 1.0 (CV 1.31, like shop baskets), momentum 0/0.5/0.8, with and
#: without a site entering 18 months before the end; 1,000 series a cell at master seed
#: 20260923, plus 1,000 more at seed 20260924 in the 15 cells nearest the line; scratchpad
#: ship/engine/bench): no cell's rate was shown above 2% (360 of 63,000 series pooled, 0.57%),
#: and the exact binomial certification with Holm across the 48 cells passed 45. The 3 that did
#: not are momentum 0.8 at 36.8 effective rows (100 rows, CV 1.31, a site entering: 30 of 2,000,
#: 1.50%) and at 110.4 (300 rows, CV 1.31: 31 of 2,000, 1.55%; with a site entering 27 of 2,000,
#: 1.35%). Every cell at 281.8 effective rows or more certified, momentum 0.8 included (0.35-0.90%).
#: The line is put there: under TOTAL_ROUTE_MIN_EFFECTIVE_ROWS effective rows a month a total is
#: routed to WATCH. It is conservative in one place: 93.9 effective rows (100 rows, CV 0.25)
#: certified (24 of 2,000 at momentum 0.8), but it sits between two failing levels, so no line
#: can keep it without keeping them. The cost, measured at a 20% change (momentum 0.5, 500 series
#: a cell): the routed conditions had power 7.0-12.0% (36.8-110.4 effective rows); the kept
#: ones 8.0-11.4%. Under 1,000 rows over the 24 compared months (about 42 a month) a total
#: cannot be confirmed anyway (GatePolicy.min_rows_recommend): the 30-rows cells confirmed 0 of
#: 12,000 null and 0 of 2,000 shifted series.
TOTAL_ROUTE_MIN_EFFECTIVE_ROWS = 280.0


# --------------------------------------------------------------------------
# plain-English formatting helpers
# --------------------------------------------------------------------------

def _plural(n: int, word: str) -> str:
    return "%d %s" % (n, word if n == 1 else word + "s")


def _more(n: int, word: str) -> str:
    """3 -> '3 more periods'; 1 -> '1 more period'."""
    return "%d more %s" % (n, word if n == 1 else word + "s")


def _rows(n: int) -> str:
    return "{:,}".format(int(n))


def _pct(fraction: float) -> str:
    """
    0.06 -> '6%', 0.0499 -> '4.9%', 0.125 -> '12%', 1.8 -> '180%'.

    A fraction of 1 or more is a percentage like any other: +180% is 2.8 times the earlier
    level, so the old '1.8 times the usual level' was off by one whole level (review of R1,
    23 Sep 2026).

    Rounding is always *towards zero*. Two reasons, both about honesty rather
    than taste: the memo must never report a larger move than was measured, and
    a value that fell short of a policy bar must never print as the bar itself
    -- "the difference is 5% where we want at least 5%" is a sentence no client
    should ever be shown.
    """
    a = abs(float(fraction))
    if not math.isfinite(a):
        return "an unmeasurable amount"
    p = a * 100.0
    if a >= 1.0:
        return "{:,}%".format(int(math.floor(p + 1e-9)))
    # the epsilon absorbs binary-float dust (0.29 * 100 == 28.999999999999996)
    if p >= 10.0:
        return "%d%%" % int(math.floor(p + 1e-9))
    text = "%.1f%%" % (int(math.floor(p * 10.0 + 1e-9)) / 10.0)
    return text.replace(".0%", "%")


def _article(phrase: str) -> str:
    """'a' / 'an' for a phrase starting with a number: an 18% gap, a 30% gap."""
    digits = ""
    for ch in phrase.strip():
        if ch.isdigit():
            digits += ch
        else:
            break
    if not digits:
        return "a"
    # "eight", "eighty", "eight hundred", "eleven", "eighteen" take "an"
    if digits[0] == "8" or digits in ("11", "18"):
        return "an"
    return "a"


def _effect_phrase(fraction: float) -> str:
    """'An 18% difference' / 'A difference we could not size'. Capitalised."""
    if not math.isfinite(float(fraction)):
        return "A difference we could not size"
    text = _pct(fraction)
    return "%s %s difference" % (_article(text).capitalize(), text)


def _no_ratio(fact: Fact) -> bool:
    """A change claim with no percentage: its monthly averages are at or below zero or cross
    zero (measure.measure_facts states it as a difference in the measure's own units)."""
    return bool((getattr(fact, "test", None) or {}).get("no_ratio"))


def _unit_difference(fact: Fact) -> str:
    """'-0.095 CURRENT REACTIVE SCORE': the difference exactly as the story prints it."""
    from .narrate import story_number
    unit = str(getattr(fact, "unit", "") or "").strip()
    return "%s%s" % (story_number(fact.value, unit, signed=True), (" " + unit) if unit else "")


def _size_phrase(fact: Fact, effect: float) -> str:
    """_effect_phrase, except that a change with no ratio is stated in its own units, never as a
    percentage (review of R1: 'An 81% difference' for a score whose monthly means are negative)."""
    if _no_ratio(fact):
        return "A difference of %s in the average month" % _unit_difference(fact)
    return _effect_phrase(effect)


def _is_change_claim(fact: Fact) -> bool:
    """A 12-versus-12 change claim, tested (min_effect set) or not (no ratio)."""
    return getattr(fact, "min_effect", None) is not None or _no_ratio(fact)


def _listed(parts: List[str]) -> str:
    """['a'] -> 'a'; ['a','b'] -> 'a and b'; ['a','b','c'] -> 'a, b, and c'."""
    if len(parts) == 1:
        return parts[0]
    if len(parts) == 2:
        return "%s and %s" % (parts[0], parts[1])
    return "%s, and %s" % (", ".join(parts[:-1]), parts[-1])


def _score(v: float) -> str:
    return "%.0f" % float(v)


def _chance_in_100(p: float) -> str:
    """0.12 -> '12', 0.004 -> 'fewer than 1'."""
    x = float(p) * 100.0
    if x < 1.0:
        return "fewer than 1"
    return "%.0f" % x


def unmodelled_confounders(fact: Fact) -> List[str]:
    """Confounders stage 4 did NOT account for. See MODELLED_PREFIXES."""
    out = []
    for c in (fact.confounders or []):
        if c is None:
            continue
        text = str(c).strip()
        if not text:
            continue
        if text.lower().startswith(MODELLED_PREFIXES):
            continue
        out.append(text)
    return out


def _unusable_signal(fact: Fact) -> Optional[str]:
    """
    Plain-English description of a signal that did not come back as a usable
    number, or None when every signal is readable.

    This is not defensive padding. Every comparison against NaN is False, so a
    fact whose test blew up (empty group, zero variance) and returned NaN would
    sail past the chance rule untouched and be published as advice -- the gate
    would be reading "the check did not run" as "chance is ruled out". The same
    goes for a p-value outside 0-1: it is a stage-4 bug, not evidence.
    """
    try:
        effect = float(fact.effect_size)
    except (TypeError, ValueError):
        return "the size of the move did not come back as a number"
    if not math.isfinite(effect):
        return "the size of the move did not come back as a number"
    if fact.p_value is not None:
        try:
            p = float(fact.p_value)
        except (TypeError, ValueError):
            return "the chance check did not come back as a number"
        if not math.isfinite(p):
            return "the chance check did not come back as a number"
        if p < 0.0 or p > 1.0:
            return (
                "the chance check came back as %g, outside the 0 to 1 range any "
                "such figure has to sit in" % p
            )
    return None


def _source_name(fact: Fact) -> str:
    return fact.source_table.strip() if fact.source_table.strip() else "the source table"


def _periods_needed(fact: Fact, policy: GatePolicy) -> int:
    return max(0, policy.min_periods_recommend - int(fact.periods_observed))


def _rows_shortfall_in_periods(fact: Fact, policy: GatePolicy) -> Optional[int]:
    """How many more periods at the current collection rate reach min_rows_recommend."""
    periods = int(fact.periods_observed)
    rows = int(fact.rows_scanned)
    if periods <= 0 or rows <= 0 or rows >= policy.min_rows_recommend:
        return None
    per_period = rows / float(periods)
    if per_period <= 0:
        return None
    return int(math.ceil((policy.min_rows_recommend - rows) / per_period))


# --------------------------------------------------------------------------
# the gate
# --------------------------------------------------------------------------

def _signals(fact: Fact, policy: GatePolicy, rule: str, **extra: Any) -> Dict[str, Any]:
    """Numeric inputs behind the decision, so the harness can audit any verdict."""
    unmodelled = unmodelled_confounders(fact)
    sig: Dict[str, Any] = {
        "rule": rule,
        "fact_id": fact.id,
        "rows_scanned": int(fact.rows_scanned),
        "effect_size": float(fact.effect_size),
        "abs_effect_size": abs(float(fact.effect_size)),
        "periods_observed": int(fact.periods_observed),
        "fact_kind": str(getattr(fact, "fact_kind", "trend")),
        "data_health": float(fact.data_health),
        "p_value": fact.p_value,
        "confounders": list(fact.confounders or []),
        "unmodelled_confounders": unmodelled,
        "unmodelled_confounder_count": len(unmodelled),
        "policy": asdict(policy),
    }
    if getattr(fact, "claim_health", None) is not None:
        sig["claim_health"] = float(fact.claim_health)
    if _has_change_test(fact):
        t = getattr(fact, "test", None) or {}
        sig.update({"p_min_effect": fact.p_value, "p_nonzero": getattr(fact, "p_nonzero", None),
                    "min_effect": fact.min_effect, "claim_key": getattr(fact, "claim_key", ""),
                    "effect_ci_low": getattr(fact, "effect_ci_low", None),
                    "effect_ci_high": getattr(fact, "effect_ci_high", None),
                    "mc_interval": t.get("mc_interval"), "bootstrap_b": t.get("b"),
                    "phi_hat": t.get("phi_hat"), "model_months": t.get("n"),
                    "trend_screen": getattr(fact, "trend_screen", "")})
    sig.update(extra)
    return sig


def gate(fact: Fact, policy: Optional[GatePolicy] = None) -> GateResult:
    """
    Classify one measured fact as RECOMMEND / WATCH / INSUFFICIENT.

    Rules are evaluated in strict precedence order and the first one that fires
    decides the verdict; its name lands in ``result.signals["rule"]``.

      1. data_health below the floor   -> INSUFFICIENT  (a poisoned source
         cannot support advice, whatever the effect looks like)
      2. a signal that is not a usable number (NaN effect size, NaN or
         out-of-range p-value) -> INSUFFICIENT
      3. rows_scanned below min_rows_watch -> INSUFFICIENT
      4. p_value present and above max_p_value -> WATCH
      5. unmodelled confounders present -> WATCH ("downgrade_always"), or WATCH
         only when the effect is small ("downgrade_if_small")
      6. clears min_rows_recommend AND min_effect_recommend AND
         min_periods_recommend -> RECOMMEND
      7. otherwise -> WATCH
    """
    policy = policy if policy is not None else DEFAULT_POLICY

    rows = int(fact.rows_scanned)
    periods = int(fact.periods_observed)
    health = float(fact.data_health)
    effect = abs(float(fact.effect_size))
    src = _source_name(fact)

    # --- rule 1: the data-health veto ------------------------------------
    # Applies to claims ABOUT THE BUSINESS drawn from the data. A measurement of
    # the data's own defects is exempt: "40% of this column is placeholders" on
    # a table scoring 40 is the finding, not a reason to withhold it.
    # A claim that reads particular columns carries claim_health, the minimum of their
    # completeness and validity (M9): a change in a 45%-empty column is not rescued by the
    # table's other, clean columns. The veto reads the lower of the two scores.
    about_business = str(getattr(fact, "measures", "business")) != "data_quality"
    claim_health = getattr(fact, "claim_health", None)
    if claim_health is not None and float(claim_health) < health:
        health = float(claim_health)
    if about_business and health < policy.data_health_floor:
        veto_end = ("it is graded NOT ENOUGH DATA" if _is_change_claim(fact)
                    else "it stays out of the recommendations")
        if claim_health is not None and float(claim_health) <= float(fact.data_health):
            reason = ("The columns this claim reads score %s out of 100 on our checks (the "
                      "weakest of their completeness and validity), under the %s we require "
                      "before advising, however clean the rest of %s is. %s measured on "
                      "values that sparse could as easily come from how they were recorded as "
                      "from the business, so %s."
                      % (_score(health), _score(policy.data_health_floor), src,
                         _size_phrase(fact, effect), veto_end))
            upgrade = ("Fill in or correct the column this claim reads: its completeness and "
                       "validity both have to reach %s out of 100. Then this exact query can "
                       "be re-run unchanged." % _score(policy.data_health_floor))
        else:
            reason = (
                "Data quality on %s scores %s out of 100 on our checks, under the "
                "%s we require before advising. %s measured in a table with gaps "
                "that size could as easily come from how it was recorded as from the "
                "business, so %s."
                % (src, _score(health), _score(policy.data_health_floor),
                   _size_phrase(fact, effect), veto_end)
            )
            upgrade = (
                "A cleaner pull of %s -- the quality score has to reach %s out of "
                "100. Fix the missing and duplicated rows the data-health check "
                "flagged, then this exact query can be re-run unchanged."
                % (src, _score(policy.data_health_floor))
            )
        return GateResult(
            verdict="INSUFFICIENT",
            reason=reason,
            needed_to_upgrade=upgrade,
            signals=_signals(fact, policy, "data_health_floor",
                             health_gap=round(policy.data_health_floor - health, 4)),
        )

    # --- rule 2: a signal that is not a usable number ----------------------
    unusable = _unusable_signal(fact)
    if unusable is not None:
        return GateResult(
            verdict="INSUFFICIENT",
            reason=(
                "This rests on %s rows from %s, but %s. A measurement we cannot "
                "read is withheld rather than reported, so it is not in the "
                "recommendations and not in the things to watch."
                % (_rows(rows), src, unusable)
            ),
            needed_to_upgrade=(
                "Re-run the query behind this fact and fix the step that sizes the "
                "move against its own baseline. It has to return a finite size, and "
                "a chance figure between 0 and 1 or no chance figure at all, before "
                "this can be reported."
            ),
            signals=_signals(fact, policy, "unusable_signal", unusable_reason=unusable),
        )

    # --- rule 2b: zero tolerance -----------------------------------------
    # Before the row floors: a full count is a census, not a sample, and two
    # reused IDs in a 50-row file are still two reused IDs.
    # Engine-set on defects where any occurrence matters (duplicate rows, one ID on two
    # different records). The share of the table is irrelevant: 20 reused delivery IDs
    # were being told to wait until they reached 5% of the file.
    if (str(getattr(fact, "tolerance", "")) == "zero"
            and str(getattr(fact, "measures", "")) == "data_quality" and fact.value > 0):
        return GateResult(
            verdict="RECOMMEND",
            reason=("Any amount of this is a defect: %s found. Fix it at the source, and check "
                    "whatever was counted or billed from these rows." % _fmt_plain(fact.value)),
            needed_to_upgrade="",
            signals=_signals(fact, policy, "zero_tolerance"),
        )

    # --- rule 3: not enough data to say anything --------------------------
    if rows < policy.min_rows_watch:
        more = _rows_shortfall_in_periods(fact, policy)
        if more is not None:
            upgrade = (
                "About %s of history at the current rate of %s rows per "
                "period (roughly %s in total), or a wider pull that goes further "
                "back." % (_more(more, "period"),
                   _rows(int(round(rows / float(max(periods, 1))))),
                   _rows(policy.min_rows_recommend))
            )
        else:
            upgrade = (
                "At least %s rows before this is worth watching and about %s "
                "before it can be advice -- a longer date range, or a source "
                "with fewer gaps."
                % (_rows(policy.min_rows_watch), _rows(policy.min_rows_recommend))
            )
        return GateResult(
            verdict="INSUFFICIENT",
            reason=(
                "Based on %s rows over %s -- too little history to act on yet. "
                "The %s is real in this sample, but a sample this "
                "small moves that much on its own."
                % (_rows(rows), _plural(periods, "period"),
                   ("difference of %s" % _unit_difference(fact)) if _no_ratio(fact)
                   else "%s difference" % _pct(effect))
            ),
            needed_to_upgrade=upgrade,
            signals=_signals(fact, policy, "min_rows_watch",
                             rows_short_by=policy.min_rows_watch - rows),
        )

    # --- a change with no ratio (monthly averages at or below zero, or crossing zero) ------
    # It has no percentage and no change test, so it is stated in its own units and can be
    # watched, not confirmed (review of R1: it read "An 81% difference ... not yet advice").
    if _no_ratio(fact) and str(getattr(fact, "fact_kind", "trend")) == "trend":
        why = (fact.test or {}).get("not_run") or "it has no ratio"
        return GateResult(
            verdict="WATCH",
            reason=("%s, latest 12 months against the 12 before, over %s rows, but %s, so no "
                    "change test was run. Worth watching; not yet a confirmed change."
                    % (_size_phrase(fact, effect), _rows(rows), why)),
            needed_to_upgrade=_no_test_text(fact),
            signals=_signals(fact, policy, "untested_trend", no_ratio=True),
        )

    # --- the change test (R1): a claim that carries it is judged by §2.4 ---------------
    if _has_change_test(fact):
        return _gate_change_claim(fact, policy, rows, periods, effect, src)

    # --- rule 4: chance has not been ruled out ----------------------------
    # The sentence keeps its condition (M12): a p-value is the chance of a result this
    # strong IF the change were smaller than the bar, never "the chance it was chance".
    if fact.p_value is not None and float(fact.p_value) > policy.max_p_value:
        p = float(fact.p_value)
        return GateResult(
            verdict="WATCH",
            reason=(
                "%s across %s rows. %s %s Worth tracking, not worth acting on yet."
                % (_effect_phrase(effect), _rows(rows), p_sentence(p),
                   level_rule_sentence(policy.max_p_value, "call something settled"))
            ),
            needed_to_upgrade=SETTLE_TEXT,
            signals=_signals(fact, policy, "p_value",
                             p_value_excess=round(p - policy.max_p_value, 6)),
        )

    # --- rule 5: something else moved at the same time --------------------
    unmodelled = unmodelled_confounders(fact)
    tolerated_confounders = False
    if unmodelled:
        small = effect < policy.small_effect_threshold
        downgrade = (policy.confounder_policy == "downgrade_always") or small
        if downgrade:
            listed = "; ".join(unmodelled[:3])
            if len(unmodelled) > 3:
                listed += "; and %d more" % (len(unmodelled) - 3)
            verb = "was" if len(unmodelled) == 1 else "were"
            return GateResult(
                verdict="WATCH",
                reason=(
                    "%s across %s rows and %s, but %s moved over the same stretch "
                    "and %s not separated out: %s. We can show the pattern; we "
                    "cannot yet say it is the cause."
                    % (_effect_phrase(effect), _rows(rows),
                       _plural(periods, "period"),
                       _plural(len(unmodelled), "other factor"), verb, listed)
                ),
                needed_to_upgrade=(
                    "Re-run the same query with \"%s\" split out or held fixed. "
                    "If the %s gap survives that split it becomes a recommendation; "
                    "if it collapses, we have the real explanation instead."
                    % (unmodelled[0], _pct(effect))
                ),
                signals=_signals(fact, policy, "confounder",
                                 effect_is_small=small,
                                 confounders_tolerated=False),
            )
        tolerated_confounders = True

    # --- rule 6: clears every bar -----------------------------------------
    # A state fact measures a CONDITION ("488 rows are exact duplicates"), not a
    # movement. It has no baseline and no time dimension, so the periods bar
    # cannot apply -- demanding it made every data-quality finding a WATCH and
    # described the finding to the client as a "difference" that does not exist.
    # For a state fact, effect_size carries materiality: the share affected.
    is_state = str(getattr(fact, "fact_kind", "trend")) == "state"
    clears_rows = rows >= policy.min_rows_recommend
    clears_effect = effect >= policy.min_effect_recommend
    clears_periods = True if is_state else (periods >= policy.min_periods_recommend)

    # --- rule 5b: an untested change is not advice ------------------------
    kind = str(getattr(fact, "fact_kind", "trend"))
    if (policy.require_test_for_trends and kind in ("trend", "forecast")
            and fact.p_value is None and clears_rows and clears_effect and clears_periods):
        return GateResult(
            verdict="WATCH",
            reason=("%s over %s and %s rows, but no statistical test was run on the change, "
                    "so it could still be ordinary variation. Worth watching; not yet advice."
                    % (_effect_phrase(effect), _plural(periods, "period"), _rows(rows))),
            needed_to_upgrade=_no_test_text(fact),
            signals=_signals(fact, policy, "untested_trend", confounders_tolerated=tolerated_confounders),
        )

    if clears_rows and clears_effect and clears_periods:
        note = ""
        if tolerated_confounders:
            note = (
                " Other things moved too (%s), but a gap this size is too large "
                "for them to explain on their own."
                % "; ".join(unmodelled[:2])
            )
        # Only a stage-1 score is a quality score. A cleaning fact with no score
        # supplied carries row retention as a stand-in; it read "a source scoring
        # 0 out of 100 on quality" next to a Health Score of 92.7 (23 Sep 2026).
        retention = RETENTION_CAVEAT in (fact.caveats or [])
        if is_state:
            # A condition is not a movement: "a 50% difference that held across
            # 0 periods" is what a client read before this branch existed.
            if retention:
                reason = ("It affects %s of the table, measured across %s rows. Widespread "
                          "enough to act on.%s" % (_pct(effect), _rows(rows), note))
            else:
                reason = (
                    "It affects %s of the table, measured across %s rows from a source "
                    "scoring %s out of 100 on quality. Widespread enough to act on.%s"
                    % (_pct(effect), _rows(rows), _score(health), note)
                )
        elif retention:
            reason = ("%s that held across %s and %s rows. Consistent enough to act on.%s"
                      % (_effect_phrase(effect), _plural(periods, "period"), _rows(rows), note))
        else:
            reason = (
                "%s that held across %s and %s rows, from a source scoring %s out "
                "of 100 on quality. Consistent enough to act on.%s"
                % (_effect_phrase(effect), _plural(periods, "period"),
                   _rows(rows), _score(health), note)
            )
        return GateResult(
            verdict="RECOMMEND",
            reason=reason,
            needed_to_upgrade="",
            signals=_signals(fact, policy, "recommend",
                             confounders_tolerated=tolerated_confounders),
        )

    # --- rule 7: real enough to track, not enough to act on ---------------
    short: List[str] = []
    fixes: List[str] = []
    if not clears_effect:
        if is_state:
            short.append(
                "it affects %s of the table where we want at least %s before "
                "recommending a change" % (_pct(effect), _pct(policy.min_effect_recommend))
            )
            fixes.append(
                "the condition would have to reach about %s of rows"
                % _pct(policy.min_effect_recommend)
            )
        else:
            short.append(
                "the difference is %s where we want at least %s before changing "
                "anything" % (_pct(effect), _pct(policy.min_effect_recommend))
            )
            fixes.append(
                "the gap would have to widen to about %s" % _pct(policy.min_effect_recommend)
            )
    if not clears_rows:
        short.append(
            "it rests on %s rows where we want %s behind advice"
            % (_rows(rows), _rows(policy.min_rows_recommend))
        )
        more = _rows_shortfall_in_periods(fact, policy)
        if more is not None:
            fixes.append(
                "about %s of history at the current rate reaches %s rows"
                % (_more(more, "period"), _rows(policy.min_rows_recommend))
            )
        else:
            fixes.append(
                "a wider pull reaching %s rows" % _rows(policy.min_rows_recommend)
            )
    if not clears_periods:
        need = _periods_needed(fact, policy)
        short.append(
            "it has held for only %s where we want %s before calling it a pattern"
            % (_plural(periods, "period"), _plural(policy.min_periods_recommend, "period"))
        )
        fixes.append("about %s of the same result" % _more(need, "period"))

    reason = "Solid enough to keep an eye on, not enough to act on: %s." % _listed(short)
    if tolerated_confounders:
        # the RECOMMEND path names these; a WATCH must not quietly drop them
        reason += (
            " Other things moved over the same stretch (%s); a gap this size is "
            "too large for them to explain on their own, but they have still not "
            "been split out." % "; ".join(unmodelled[:2])
        )

    return GateResult(
        verdict="WATCH",
        reason=reason,
        needed_to_upgrade=(
            "To turn this into a recommendation: %s." % _listed(fixes)
        ),
        signals=_signals(fact, policy, "below_recommend_bar",
                         clears_rows=clears_rows,
                         clears_effect=clears_effect,
                         clears_periods=clears_periods,
                         confounders_tolerated=tolerated_confounders),
    )

# --------------------------------------------------------------------------
# the change test's wording (M12) and rules (design §2.4)
# --------------------------------------------------------------------------

#: What would settle a change that is not yet confirmed (M12). Not more rows: the test's unit
#: is the month, so extra rows from the same months add no power, and waiting does not
#: strengthen the same fixed 12-versus-12 comparison.
SETTLE_TEXT = ("What would settle it is not more rows from the same months: the comparison is "
               "between months. A fresh replication would (the next 12 months compared the same "
               "way), or wider windows once the history allows (18 months against 18 at 36 months "
               "of history).")
#: For a series the drift screen holds; apply_trend_families replaces it with what the run
#: actually offers (the series' forecast, or why none can stand in).
DRIFT_SETTLE_TEXT = ("A comparison that allows for the drift, or the series' forecast: a "
                     "12-versus-12 comparison cannot separate a change from a series that drifts.")


def p_sentence(p: float) -> str:
    """The raw p-value's gloss, with its condition (M12). Never used for a q-value."""
    n = _chance_in_100(p)
    return ("If the change were smaller than the bar, a result at least this strong would appear "
            "in %s of 100 comparisons like this one." % (n if n.startswith("fewer") else "about " + n))


def level_rule_sentence(level: float, what: str = "confirm a change",
                        after_allowance: bool = False) -> str:
    """
    The decision level worded as the RULE it is, never as a rate (23 Sep 2026 review): "1 in
    100" beside a verdict reads as the engine's false-alarm rate, which is only what the
    benchmark measures under stated conditions (design §1.5).
    """
    return ("Our rule is to %s only when that figure is at most %s in 100 (p \u2264 %g)%s; "
            "that is the line we hold to, not a measured false-alarm rate."
            % (what, "%g" % round(100.0 * float(level), 4), float(level),
               " after that allowance" if after_allowance else ""))


def interval_caution(fact: Fact, with_level: bool = True) -> str:
    """
    The clause every change interval carries: its label is how it was built, not a measured
    hit rate (23 Sep 2026 review).

    The review proposed cautioning only when the model's phi_hat >= 0.8 or the drift screen
    fired. The benchmark measured the opposite (review cells at the 5% bar, 2,000 series each:
    100/300 counts a month and AR(1)+white noise at phi 0.5-0.8, plus the 1,000-a-month phi 0.8
    cells; scratchpad r1/benchfix/review_cells_full.json): coverage of the 95% interval was
    98.2% where phi_hat >= 0.8 and 97.5% where the drift screen fired, but 85.0% where
    phi_hat < 0.5. The shortfall comes from series whose true momentum the model
    UNDERestimates, which phi_hat cannot flag, so the caution cannot be targeted from the
    series' own diagnostics and is stated for every interval, without a measured number.
    with_level=False leaves out the interval's own level too, for text (the brief) where every
    printed number must be a cited fact.
    """
    t = getattr(fact, "test", None) or {}
    if getattr(fact, "effect_ci_low", None) is None and t.get("ci_low") is None:
        return ""
    if not with_level:
        return ("built to hold the true change at its stated level; in simulated series with "
                "strong momentum, which the model can underestimate, it held it less often")
    level = float(getattr(fact, "effect_ci_level", None) or t.get("ci_level") or 0.95)
    return ("built to hold the true change %g%% of the time; in simulated series with strong "
            "momentum, which the model can underestimate, it held it less often"
            % round(100.0 * level, 4))


def q_sentence(q_value: float, m: int) -> str:
    """The q-value, described separately from p (M12): never inside the p-value sentence."""
    return ("After allowing for the %s tested in this run, the false-discovery-adjusted figure "
            "is %s in 100." % (_plural(int(m), "change claim"), _chance_in_100(q_value)))


def _has_change_test(fact: Fact) -> bool:
    return (getattr(fact, "min_effect", None) is not None
            and str(getattr(fact, "fact_kind", "trend")) == "trend")


def _pct1(fraction: float) -> str:
    """|fraction| as a percentage to one decimal: 0.2584 -> '25.8%', 1.169 -> '116.9%'."""
    return "%.1f%%" % (100.0 * abs(float(fraction)))


def _signed_pct(fraction: float) -> str:
    """
    A change on the ledger's percentage scale, signed, to one decimal: exactly what the
    narrator prints for the same fact (narrate.story_number on 100 * fraction), so the brief
    never shows two values for one ledger figure. Before the R1 review this truncated toward
    zero, which moved both ends of an interval INWARD (a narrower interval than measured) and
    printed a +117% end as "+1.17 times the usual level".
    """
    v = 100.0 * float(fraction)
    return ("+" if v > 0 else "") + "%.1f%%" % v


def _interval_text(lo: Optional[float], hi: Optional[float], level: Optional[float]) -> str:
    if lo is None or hi is None:
        return ""
    return "%g%% interval %s to %s" % (round(100.0 * float(level or 0.95), 4), _signed_pct(lo),
                                        _signed_pct(hi))


def _headline_pct(fact: Fact) -> float:
    """The headline change as a fraction, read from the ledger value when it is a percentage."""
    if str(getattr(fact, "unit", "")) == "pct":
        try:
            return float(fact.value) / 100.0
        except (TypeError, ValueError):
            pass
    return float(fact.effect_size)


def _change_words(fact: Fact, effect: float) -> str:
    """'A 20.4% rise in the average month (95% interval +12.1% to +29.3%)'."""
    ef = float(fact.effect_size)
    kind = "rise" if ef > 0 else "fall" if ef < 0 else "change"
    size = _pct1(_headline_pct(fact))
    head = "%s %s %s in the average month, latest 12 months against the 12 before" % (
        _article(size).capitalize(), size, kind)
    iv = _interval_text(fact.effect_ci_low, fact.effect_ci_high, fact.effect_ci_level)
    if iv:
        lo, hi = float(fact.effect_ci_low), float(fact.effect_ci_high)
        h = _headline_pct(fact)
        if not (lo - 1e-9 <= h <= hi + 1e-9):
            # One estimand (design §1.2): an interval that does not contain its own headline is
            # never printed as if it were that headline's range (review of R1, 23 Sep 2026).
            iv = ("the model's %s does not contain this plain ratio of the average months: the "
                  "model weighs the months differently, so read that range as the model's, not "
                  "as a range for this figure" % iv)
        why = interval_caution(fact)
        if why:
            iv += "; %s" % why
        if (getattr(fact, "test", None) or {}).get("ci_test_agree") is False:
            # review v2: the interval's near end is the more cautious of two inversions, so the
            # test at the bar can clear at the 2.5% level while the interval still reaches it
            iv += ("; the test of the bar clears at the 2.5% level, but this interval, which also "
                   "allows for the momentum estimated at its own end, still reaches the bar")
    return head + (" (%s)" % iv if iv else "")


def settle_text(fact: Optional[Fact] = None) -> str:
    """
    What would settle a change claim that is not confirmed (M12), by what the file allows:
    the wider-windows option is offered as possible later only when the history is short of
    36 months; with 36 or more it is said to be possible now and not run by this release
    (review of R1, 23 Sep 2026: the reviews file had 117 months and was told "once the history
    allows").
    """
    t = (getattr(fact, "test", None) or {}) if fact is not None else {}
    hist = int(t.get("months_in_model") or t.get("n") or 0)
    if hist >= 36:
        wider = ("or a comparison of wider windows (18 months against 18), which this file's "
                 "history already allows but this release does not run")
    else:
        wider = ("or wider windows once the history reaches 36 months (18 months against 18)")
    return ("What would settle it is not more rows from the same months: the comparison is "
            "between months. A fresh replication would (the next 12 months compared the same "
            "way), %s." % wider)


def _month_names(idx: Iterable[int]) -> str:
    names = ("January", "February", "March", "April", "May", "June", "July", "August",
             "September", "October", "November", "December")
    return _listed([names[int(i) % 12] for i in idx])


def _untested_settle(t: Dict[str, Any]) -> str:
    """Why no test ran decides what would settle it (review of R1, 23 Sep 2026)."""
    never = t.get("never_observed_months") or []
    if never:
        seen = [i for i in range(12) if i not in set(int(x) for x in never)]
        return ("This file holds no values for %s in any year, so a comparison of every month "
                "cannot run on this collection pattern, and waiting will not change that. What "
                "would settle it is comparing only the months that are sampled (%s) year against "
                "year, which this release does not run." % (_month_names(never), _month_names(seen)))
    if t.get("estimand_mismatch"):
        return ("A comparison that allows for the series' own drift; the plain 12-versus-12 "
                "comparison cannot separate a change from it.")
    if t.get("nonpositive_months"):
        return ("Monthly values above zero in the two compared 12-month windows: a ratio of "
                "average months needs them.")
    if t.get("months_usable"):
        return ("At least %d usable months in each of the two 12-month windows." % _MIN_MONTHS)
    return ("A monthly series the model can fit: at least %d usable months in each of the two "
            "12-month windows, with values above zero, that vary from month to month."
            % _MIN_MONTHS)


def _no_test_text(fact: Fact) -> str:
    """
    Rule 5b's "what would settle it": what the reader could supply, never the engine's own
    missing feature (review of R1, 23 Sep 2026: "A significance test of the change against the
    series' normal period-to-period variation" is not something a client can provide).
    """
    t = getattr(fact, "test", None) or {}
    if t.get("no_ratio"):
        return ("No change test is available for this measure: %s. It would need a materiality "
                "bar in the measure's own units, which this release does not take, so it can be "
                "watched but not confirmed." % t.get("not_run", "it has no ratio"))
    return ("This release runs no change test on this kind of figure, so it can be watched but "
            "not confirmed.")


def composition_step_words(fact: Fact) -> Tuple[str, bool]:
    """
    'The monthly total steps up by +88.0% in 2025-03, when 'East York Low-Rise' first appears,
    and by +30.1% in 2024-07, when ...' for the level shifts the change test detected at the
    months what the file covers changed (stats.TrendModel.composition_steps), largest first; and
    whether they explain what the drift screen saw. ('', False) when none was detected.
    """
    t = getattr(fact, "test", None) or {}
    cs = t.get("composition_steps") or {}
    named = cs.get("named") or []
    if not named:
        return "", False
    what = "monthly total" if str(getattr(fact, "claim_key", "") or "").startswith("total:") else (
        "monthly row count" if str(getattr(fact, "claim_key", "")) == "volume" else "series")
    parts = []
    for i, x in enumerate(named[:3]):
        who = "; ".join("'%s' %s" % (lv, verb) for lv, verb in x.get("levels") or []) or \
            "what the file covers changes"
        size = float(x["size"])
        parts.append("%sby %s in %s, when %s" % ("" if i else ("up " if size > 0 else "down "),
                                                 _signed_pct(size), x["month"], who))
    more = len(named) - len(parts)
    text = "The %s steps %s%s" % (what, ", and ".join(parts), (" (and %d more)" % more) if more > 0 else "")
    return text, bool(cs.get("explains"))


def _gate_change_claim(fact: Fact, policy: GatePolicy, rows: int, periods: int, effect: float,
                       src: str) -> GateResult:
    """
    A change claim carrying the R1 change test, judged by the §2.4 confidence policy after
    rules 1-3. The per-claim level is recommend_q (the primary claim's); the family pass
    (apply_trend_families) then holds back any claim its false-discovery control rejects.
    """
    t = getattr(fact, "test", None) or {}
    bar = float(fact.min_effect)
    words = _change_words(fact, effect)
    held = _extreme_rows_rule(fact, policy, words, bar)
    if held is not None:
        return held
    if fact.p_value is None:
        why = t.get("not_run") or "the monthly series could not be modelled"
        return GateResult(
            verdict="WATCH",
            reason=("%s, but no change test could be run: %s. Worth watching; not yet a "
                    "confirmed change." % (words, why)),
            needed_to_upgrade=_untested_settle(t),
            signals=_signals(fact, policy, "untested_trend", test_not_run=why,
                             estimand_mismatch=bool(t.get("estimand_mismatch"))),
        )
    if bar + 1e-12 < policy.min_effect_recommend:
        return GateResult(
            verdict="WATCH",
            reason=("%s. It was tested against a %s bar, smaller than the %s this report "
                    "requires, so it cannot be confirmed here." % (words, _pct(bar),
                                                                  _pct(policy.min_effect_recommend))),
            needed_to_upgrade=("Re-run the analysis with the %s bar; the same monthly figures "
                               "are re-tested unchanged." % _pct(policy.min_effect_recommend)),
            signals=_signals(fact, policy, "tested_below_bar"),
        )
    p = float(fact.p_value)
    screen = str(getattr(fact, "trend_screen", "") or "")
    comp = t.get("composition")
    if comp:
        # Review v2 (24 Sep 2026): two buildings bought mid-way were graded "the series drifts",
        # and the story said nothing in the data explained the change. A change in what the file
        # covers is the explanation, stated first; the like-for-like comparison answers whether
        # the business itself changed. Ship round (24 Sep 2026): the level shifts the change test
        # fits at the months the coverage changed are named by month, size and level, and when
        # they account for what the drift screen saw, drift is not given as a reason at all.
        lf = comp.get("like_for_like") or ""
        steps_txt, explained = composition_step_words(fact)
        tail = ""
        failed = ["composition"]
        if steps_txt:
            tail = " %s." % steps_txt
            if explained:
                tail += (" With those shifts allowed for, no drift remains: the shifts, not a trend, "
                         "move the series.")
        if policy.drift_screen and screen:
            failed.append("drift_screen")
            tail += (" With %s allowed for, the series still %s, so part of the 12-versus-12 gap is "
                     "expected without any change." % ("those shifts" if steps_txt else
                                                       "the change in coverage",
                                                       "wanders" if t.get("screen_kind") == "wanders"
                                                       else "drifts"))
        n_stable = len(comp.get("stable") or [])
        return GateResult(
            verdict="WATCH",
            reason=("%s, but part of it is a change in what the file covers, not in the business: "
                    "in %s, %s.%s %s" % (words, comp.get("column"), comp.get("words"), tail,
                                         ("The like-for-like comparison, on the %d %s present "
                                          "in every modelled month, is tested on its own."
                                          % (n_stable, plural_of(comp.get("column")))) if lf else
                                         "No like-for-like comparison could be made.")),
            needed_to_upgrade=(("Read the like-for-like comparison: it compares only the %s "
                                "present in every modelled month." % plural_of(comp.get("column")))
                               if lf else "A comparison on the %s present in both years."
                               % plural_of(comp.get("column"))),
            signals=_signals(fact, policy, "composition", composition=comp.get("column"),
                             like_for_like=lf, checks_failed=failed,
                             composition_steps=[x.get("month") for x in
                                                ((t.get("composition_steps") or {}).get("named") or [])],
                             composition_explains=bool(explained)),
        )
    # A claim in a condition the benchmark cannot certify (a volume under 200 rows a month)
    # cannot end CONFIRMED whatever its test says, so no settle line may promise a route through
    # the test (review v2, 24 Sep 2026: a 69-rows-a-month claim whose p failed was told "a fresh
    # replication would"). Its failed checks name the condition too.
    routed_early = uncertified_condition(fact)
    if policy.drift_screen and screen:
        # The screen explains the rest, so it leads the reason (review of R1, 23 Sep 2026:
        # "wanders" reached the ledger 4 times and the brief 0 times, because the p rule
        # returned first). Every other failing check is named after it.
        also = ""
        failed = ["drift_screen"]
        if p > policy.recommend_q:
            failed.append("min_effect_p")
            also = (" The test of a change of at least the %s bar does not clear either. %s"
                    % (_pct(bar), p_sentence(p)))
        settle = DRIFT_SETTLE_TEXT
        rule = "drift_screen"
        step = t.get("step") or {}
        if t.get("screen_kind") == "step" and step.get("month") is not None:
            # a single level shift somewhere else than the window start (review v2)
            rule = "step_elsewhere"
            failed[0] = "step_elsewhere"
            m = int(step["month"])
            settle = ("Compare the months from %04d-%02d on with the months before it: the series "
                      "stepped there, and a comparison split at that month measures the step itself."
                      % (m // 12, m % 12 + 1))
        if routed_early is not None:
            failed.append("benchmark_condition")
            settle = routed_early["settle"]
        return GateResult(
            verdict="WATCH",
            reason=("%s, but %s. It is not confirmed as a change.%s" % (words, screen, also)),
            needed_to_upgrade=settle,
            signals=_signals(fact, policy, rule, checks_failed=failed,
                             **({"condition": routed_early["condition"]} if routed_early else {})),
        )
    if p > policy.recommend_q:
        pz = getattr(fact, "p_nonzero", None)
        changed = pz is not None and float(pz) <= policy.watch_p
        lead = ("Changed, but not yet shown to be at least the %s bar" % _pct(bar) if changed
                else "No change of at least the %s bar is shown" % _pct(bar))
        failed = ["min_effect_p"]
        settle = settle_text(fact)
        extra: Dict[str, Any] = {}
        if routed_early is not None:
            failed.append("benchmark_condition")
            settle = routed_early["settle"]
            extra = {"condition": routed_early["condition"],
                     "rows_a_month": routed_early.get("rows_a_month")}
            if "effective_rows_a_month" in routed_early:
                extra["effective_rows_a_month"] = routed_early["effective_rows_a_month"]
        return GateResult(
            verdict="WATCH",
            reason=("%s: %s. %s %s"
                    % (lead, words[0].lower() + words[1:], p_sentence(p),
                       level_rule_sentence(policy.recommend_q))),
            needed_to_upgrade=settle,
            signals=_signals(fact, policy, "min_effect_p", changed=changed,
                             p_value_excess=round(p - policy.recommend_q, 6),
                             checks_failed=failed, **extra),
        )
    mc = t.get("mc_interval")
    if mc and float(mc[0]) <= policy.recommend_q <= float(mc[1]):
        return _too_close(fact, policy, words, policy.recommend_q)
    routed = uncertified_condition(fact)
    if routed is not None:
        return GateResult(
            verdict="WATCH",
            reason=("%s, but %s. In that condition the benchmark could not show that the engine "
                    "confirms fewer than 2 in 100 series whose true change is no bigger than the "
                    "bar, so by rule no change there is graded CONFIRMED, whatever its test says. "
                    "It is held as a change to watch." % (words, routed["why"])),
            needed_to_upgrade=routed["settle"],
            signals=_signals(fact, policy, "benchmark_condition", condition=routed["condition"],
                             rows_a_month=routed.get("rows_a_month"),
                             **({"effective_rows_a_month": routed["effective_rows_a_month"]}
                                if "effective_rows_a_month" in routed else {})),
        )
    months = int(t.get("n") or 0)
    if months < policy.min_history_for_trend_recommend:
        return GateResult(
            verdict="WATCH",
            reason=("%s, but the model read %s where we require %s before confirming a change."
                    % (words, _plural(months, "month"),
                       _plural(policy.min_history_for_trend_recommend, "month"))),
            needed_to_upgrade=("%s of history." % _more(policy.min_history_for_trend_recommend
                                                         - months, "month").capitalize()),
            signals=_signals(fact, policy, "short_history"),
        )
    unmodelled = unmodelled_confounders(fact)
    tolerated = False
    if unmodelled:
        small = effect < policy.small_effect_threshold
        if policy.confounder_policy == "downgrade_always" or small:
            listed = "; ".join(unmodelled[:3])
            if len(unmodelled) > 3:
                listed += "; and %d more" % (len(unmodelled) - 3)
            return GateResult(
                verdict="WATCH",
                reason=("%s, but %s moved over the same stretch and %s not separated out: %s. "
                        "The change is associated with the period, and part of it may come from "
                        "that instead." % (words, _plural(len(unmodelled), "other factor"),
                                           "was" if len(unmodelled) == 1 else "were", listed)),
                needed_to_upgrade=("Re-run the same query with \"%s\" split out or held fixed. "
                                   "If the %s gap survives that split it can be confirmed."
                                   % (unmodelled[0], _pct(effect))),
                signals=_signals(fact, policy, "confounder", effect_is_small=small,
                                 confounders_tolerated=False),
            )
        tolerated = True
    clears_rows = rows >= policy.min_rows_recommend
    clears_periods = periods >= policy.min_periods_recommend
    if not (clears_rows and clears_periods):
        short: List[str] = []
        fixes: List[str] = []
        if not clears_rows:
            short.append("it rests on %s rows where we want %s behind a confirmed change"
                         % (_rows(rows), _rows(policy.min_rows_recommend)))
            fixes.append("a wider pull reaching %s rows" % _rows(policy.min_rows_recommend))
        if not clears_periods:
            short.append("it has held in only %s of the latest 12 where we want %s"
                         % (_plural(periods, "month"), _plural(policy.min_periods_recommend, "month")))
            fixes.append("about %s of the same result" % _more(_periods_needed(fact, policy), "month"))
        return GateResult(
            verdict="WATCH",
            reason="%s. The test clears the bar, but %s." % (words, _listed(short)),
            needed_to_upgrade="To confirm it: %s." % _listed(fixes),
            signals=_signals(fact, policy, "below_recommend_bar", clears_rows=clears_rows,
                             clears_effect=True, clears_periods=clears_periods,
                             confounders_tolerated=tolerated),
        )
    note = ""
    if tolerated:
        note = (" Other things moved too (%s), but a gap this size is too large for them to "
                "explain on their own." % "; ".join(unmodelled[:2]))
    return GateResult(
        verdict="RECOMMEND",
        reason=("Confirmed: %s. The change is at least the %s bar: %s It is an association "
                "with the period, measured on %s, not a finding about its cause.%s"
                % (words[0].lower() + words[1:], _pct(bar), p_sentence(p),
                   _plural(months, "month"), note)),
        needed_to_upgrade="",
        signals=_signals(fact, policy, "recommend", confounders_tolerated=tolerated),
    )


def _extreme_rows_rule(fact: Fact, policy: GatePolicy, words: str, bar: float) -> Optional[GateResult]:
    """
    A change that a handful of extreme rows drives (review v2, 24 Sep 2026: six rows of
    Units = 9,999 put "average units -68.2%" in the bottom line). When the same change without
    them has the other sign, lands on the other side of the bar, or the other side of the
    test's level, the claim is held at WATCH and says so.
    """
    t = getattr(fact, "test", None) or {}
    ex = t.get("extremes")
    if not ex or ex.get("change_without") is None:
        return None
    full = float(fact.effect_size)
    cw = float(ex["change_without"])
    moved_sign = full != 0 and cw != 0 and (full > 0) != (cw > 0)
    moved_bar = (abs(full) >= bar - 1e-12) != (abs(cw) >= bar - 1e-12)
    pw = ex.get("p_without")
    moved_p = (fact.p_value is not None and pw is not None
               and (float(fact.p_value) <= policy.recommend_q) != (float(pw) <= policy.recommend_q))
    if not (moved_sign or moved_bar or moved_p):
        return None
    k = int(ex.get("rows") or 0)
    how = ("the other way" if moved_sign else
           "on the other side of the %s bar" % _pct(bar) if moved_bar else
           "on the other side of the test's level")
    return GateResult(
        verdict="WATCH",
        reason=("%s, but it is driven by %s: without them the change is %s, %s. It is not "
                "confirmed as a change." % (words, _plural(k, "extreme row"), _signed_pct(cw), how)),
        needed_to_upgrade=("Check the %s (%s): if they are entry errors, correct them at the source "
                           "and re-run; if they are real, the change rests on them alone."
                           % (_plural(k, "extreme row"), ex.get("fact", "the extreme-rows figure"))),
        signals=_signals(fact, policy, "extreme_rows", extreme_rows=k,
                         change_without=cw, checks_failed=["extreme_rows"]),
    )


def uncertified_condition(fact: Fact) -> Optional[Dict[str, Any]]:
    """
    The benchmark condition a change claim falls in that the benchmark cannot certify (see
    ROUTE_MIN_ROWS_A_MONTH), with the words that name it and what would settle it; None when the
    claim is in no such condition.
    """
    t = getattr(fact, "test", None) or {}
    if claim_type(fact) == "total":
        return _uncertified_total(t)
    if claim_type(fact) != "volume":
        return None
    # a monthly count's average month is its rows a month; a monthly total (review v2) and a
    # like-for-like count record their rows a month separately
    rows_v = t.get("rows_a_month", t.get("mean_month"))
    if rows_v is None:
        return None
    rows = float(rows_v)
    if rows >= ROUTE_MIN_ROWS_A_MONTH:
        return None
    return {"condition": "fewer than %d rows a month" % ROUTE_MIN_ROWS_A_MONTH,
            "rows_a_month": rows,
            "why": ("its average month holds about %s rows, fewer than the %d a month below which "
                    "counting noise hides the business's own momentum"
                    % (_rows(int(round(rows))), ROUTE_MIN_ROWS_A_MONTH)),
            "settle": ("What would settle it is volume, not time: at least %d rows in the average "
                       "month of the compared series (for example the whole business rather than "
                       "one branch or category, if that answers the same question). More months "
                       "at this volume do not: the benchmark condition fails at 36 months too."
                       % ROUTE_MIN_ROWS_A_MONTH)}


def _uncertified_total(t: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """The monthly-total condition the benchmark could not certify (TOTAL_ROUTE_MIN_EFFECTIVE_ROWS),
    read on the claim's rows a month and the CV of its row amounts; None outside it."""
    rows_v = t.get("rows_a_month", t.get("mean_month"))
    if rows_v is None:
        return None
    rows = float(rows_v)
    cv = t.get("amount_cv")
    cv = 0.0 if cv is None else float(cv)
    eff = rows / (1.0 + cv * cv)
    if eff >= TOTAL_ROUTE_MIN_EFFECTIVE_ROWS:
        return None
    line = int(TOTAL_ROUTE_MIN_EFFECTIVE_ROWS)
    return {"condition": "fewer than %d effective rows a month (a monthly total)" % line,
            "rows_a_month": rows, "effective_rows_a_month": eff, "amount_cv": cv,
            "why": ("its average month adds up about %s rows whose amounts vary by about %s (their "
                    "coefficient of variation), which carries the noise of about %s rows of one fixed "
                    "amount, fewer than the %d below which the benchmark could not certify the "
                    "engine's false-confirm rate for monthly totals"
                    % (_rows(int(round(rows))), "%d%%" % int(round(100 * cv)),
                       _rows(int(round(eff))), line)),
            "settle": ("What would settle it is volume, not time: a total over more rows (at least "
                       "%d effective rows a month: rows a month divided by 1 plus the squared "
                       "coefficient of variation of the amounts), for example the whole business "
                       "rather than one building or category, if that answers the same question. "
                       "The benchmark measured this condition at 36 months." % line)}


def _too_close(fact: Fact, policy: GatePolicy, words: str, line: float) -> GateResult:
    t = getattr(fact, "test", None) or {}
    mc = t.get("mc_interval") or [float("nan"), float("nan")]
    return GateResult(
        verdict="WATCH",
        reason=("%s, but it is too close to the line to call: after %s resamples the chance "
                "figure could still sit either side of %s in 100." % (
                    words, "{:,}".format(int(t.get("b") or 0)), _chance_in_100(line))),
        needed_to_upgrade=settle_text(fact),
        signals=_signals(fact, policy, "too_close_to_call", line=line, mc_interval=list(mc)),
    )


def _family_threshold(ps: List[float], q: float, method: str) -> Dict[str, Any]:
    from .stats import benjamini_hochberg
    m = len(ps)
    qq = q
    if method == "by" and m:
        qq = q / sum(1.0 / i for i in range(1, m + 1))
    res = benjamini_hochberg(ps, qq)
    if method == "by" and m:
        res["q_values"] = [min(1.0, v * (q / qq)) for v in res["q_values"]]
    return res


def apply_trend_families(gated: Iterable[GatedFact],
                         policy: Optional[GatePolicy] = None) -> List[GatedFact]:
    """
    False-discovery control on the decision question, structured by metric role (M3).

    The change claims carrying the R1 test are split into the PRIMARY claim (policy.
    primary_metric, or volume), tested alone at recommend_q, and the SECONDARY claims, one
    Benjamini-Hochberg (or -Yekutieli) family at recommend_q over their minimum-effect
    p-values. A claim its family does not reject, or whose Monte Carlo interval straddles its
    family's line, is held at WATCH. For each CONFIRMED claim the selection-adjusted interval
    (false coverage rate, level 1 - R*q/m for R confirmed of m in the family) is attached.
    Every tested claim's signals record family, family_size, p_raw and q_value.
    """
    policy = policy if policy is not None else DEFAULT_POLICY
    gated = list(gated)
    tested = [g for g in gated if getattr(g.fact, "role", "headline") == "headline"
              and _has_change_test(g.fact) and g.fact.p_value is not None]
    if not tested:
        _drift_settle(gated)
        return gated
    keys = {str(getattr(g.fact, "claim_key", "")) for g in tested}
    cand = [str(getattr(g.fact, "claim_key", "")) for g in tested
            if (getattr(g.fact, "test", None) or {}).get("primary_candidate")]
    # the policy's primary metric, else the largest money total the analysis marked (review v2:
    # money is the business story), else volume
    primary_key = policy.primary_metric or (cand[0] if cand else ("volume" if "volume" in keys else ""))
    families: Dict[str, List[GatedFact]] = {"primary": [], "primary_like_for_like": [], "secondary": []}
    # the primary claim's like-for-like twin is tested alone too (see stats.family_lines: the
    # primary claim itself is then held by the composition rule, so one claim can confirm)
    primary_lf = (primary_key + _stats.LIKE_FOR_LIKE_SUFFIX) if primary_key else ""
    for g in tested:
        key = str(getattr(g.fact, "claim_key", ""))
        if primary_key and key == primary_key and not families["primary"]:
            families["primary"].append(g)
        elif primary_lf and key == primary_lf and not families["primary_like_for_like"]:
            families["primary_like_for_like"].append(g)
        else:
            families["secondary"].append(g)
    n_tested = len(tested)
    for fam, members in families.items():
        if not members:
            continue
        ps = [float(g.fact.p_value) for g in members]
        alone = fam in ("primary", "primary_like_for_like")
        if alone:
            res = {"reject": [p <= policy.recommend_q for p in ps], "q_values": ps,
                   "threshold": policy.recommend_q, "m": 1}
        else:
            res = _family_threshold(ps, policy.recommend_q, policy.fdr_method)
        line = policy.recommend_q if alone else (
            res["threshold"] if res["threshold"] > 0 else policy.recommend_q / len(members))
        for g, rej, qv in zip(members, res["reject"], res["q_values"]):
            sig = g.gate.signals
            sig.update({"family": fam, "family_size": len(members), "family_method":
                        "alone" if alone else policy.fdr_method,
                        "claims_tested_in_run": n_tested, "p_raw": float(g.fact.p_value),
                        "q_value": float(qv), "family_line": line})
            if g.gate.verdict != "RECOMMEND":
                continue
            f = g.fact
            effect = abs(float(f.effect_size))
            words = _change_words(f, effect)
            if not rej:
                g.gate = GateResult(
                    verdict="WATCH",
                    reason=("%s, but not once the other claims are allowed for: %s %s %s"
                            % (words, p_sentence(float(f.p_value)), q_sentence(qv, len(members)),
                               level_rule_sentence(policy.recommend_q, after_allowance=True))),
                    needed_to_upgrade=settle_text(f),
                    signals=dict(sig, rule="fdr", verdict_before_fdr="RECOMMEND"))
                continue
            mc = (getattr(f, "test", None) or {}).get("mc_interval")
            if mc and float(mc[0]) <= line <= float(mc[1]):
                r = _too_close(f, policy, words, line)
                r.signals.update({k: v for k, v in sig.items() if k not in r.signals})
                r.signals["verdict_before_fdr"] = "RECOMMEND"
                g.gate = r
        confirmed = [g for g in members if g.gate.verdict == "RECOMMEND"]
        # Benjamini-Yekutieli (2005): the R claims the family's step-up rejects get bounds at
        # level 1 - R*q/m; the dual of the ONE-sided test that confirmed them, so each such bound
        # clears the bar (review of R1, 23 Sep 2026: the two-sided 1 - R*q/m interval printed a
        # lower end below the bar for 15-57% of confirmations). R is the rejections, not the
        # confirmations left after the other checks.
        if alone:
            tail = policy.recommend_q
        else:
            qq = policy.recommend_q
            if policy.fdr_method == "by":
                qq = policy.recommend_q / sum(1.0 / i for i in range(1, len(members) + 1))
            tail = int(res.get("k") or 0) * qq / float(len(members))
        for g in confirmed:
            _attach_adjusted_interval(g, tail)
    _drift_settle(gated)
    _composition_settle(gated)
    return gated


def _composition_settle(gated: List[GatedFact]) -> None:
    """
    A claim held by the composition rule points to its like-for-like twin by id; once the twin
    is graded (families included), the claim's reason states the twin's change and grade, and its
    settle line is the twin's (ship round, 24 Sep 2026: the sample's RENT total said "read the
    like-for-like comparison" while that comparison was an untested description).
    """
    from .vocab import visitor_verdict
    by_id = {g.fact.id: g for g in gated}
    for g in gated:
        sig = g.gate.signals or {}
        if sig.get("rule") != "composition":
            continue
        tw = by_id.get(str(sig.get("like_for_like") or ""))
        if tw is None or not _has_change_test(tw.fact):
            continue
        grade = visitor_verdict(tw.gate.verdict)
        if tw.fact.p_value is not None and not _no_ratio(tw.fact):
            g.gate.reason += (" Like for like, the change is %s, graded %s."
                              % (_signed_pct(float(tw.fact.effect_size)), grade))
        else:
            g.gate.reason += " Like for like, the comparison is graded %s." % grade
        twin_settle = str(tw.gate.needed_to_upgrade or "").strip()
        g.gate.needed_to_upgrade = (
            "The like-for-like comparison answers whether the business itself changed, and it is "
            "graded %s.%s" % (grade, (" For that comparison: " + twin_settle)
                              if twin_settle and tw.gate.verdict != "RECOMMEND" else ""))
        sig["like_for_like_verdict"] = tw.gate.verdict


def _forecast_for(fact: Fact) -> str:
    """The forecast fact id that projects the same series as a change claim, if any."""
    fid = str(fact.id)
    ser = (getattr(fact, "test", None) or {}).get("series_slug")
    if ser:
        return "forecast.%s.next" % ser
    key = str(getattr(fact, "claim_key", "") or "")
    if key == "volume" or (fid.startswith("measure.volume.") and key in ("", "volume")):
        return "forecast.monthly_rows.next"
    if key.startswith("volume:"):
        return ""
    parts = fid.split(".")
    return "forecast.%s.next" % parts[1] if len(parts) >= 3 and parts[0] == "measure" else ""


def _drift_settle(gated: List[GatedFact]) -> None:
    """
    What would settle a claim the drift screen holds (or whose model and headline disagree),
    by what this run offers: its forecast when one was made and graded, otherwise why neither
    the forecast nor a drift-aware comparison can stand in (review of R1, 23 Sep 2026: the
    brief pointed to a forecast that was stale or NOT ENOUGH DATA).
    """
    from .vocab import visitor_verdict
    by_id = {g.fact.id: g for g in gated}
    for g in gated:
        sig = g.gate.signals or {}
        rule = sig.get("rule")
        if not (rule == "drift_screen" or (rule == "untested_trend" and sig.get("estimand_mismatch"))):
            continue
        fc = by_id.get(_forecast_for(g.fact))
        if fc is not None and fc.gate.verdict != "INSUFFICIENT":
            text = ("Read this series through its forecast instead (%s, graded %s): the forecast "
                    "projects the drift itself. A 12-versus-12 comparison cannot separate a change "
                    "from a series that drifts." % (fc.fact.id, visitor_verdict(fc.gate.verdict)))
        elif fc is not None:
            text = ("Neither route is open in this run: the series' forecast (%s) was graded %s, "
                    "and this release runs no comparison that allows for the drift. A 12-versus-12 "
                    "comparison cannot separate a change from a series that drifts."
                    % (fc.fact.id, visitor_verdict(fc.gate.verdict)))
        else:
            text = ("Neither route is open in this run: no forecast is made for this series, and "
                    "this release runs no comparison that allows for the drift. A 12-versus-12 "
                    "comparison cannot separate a change from a series that drifts.")
        routed = uncertified_condition(g.fact)
        if routed is not None:
            # the comparison route is closed at this volume whatever the drift (review v2)
            text += " And a comparison would not settle it either: " + routed["settle"][0].lower() \
                + routed["settle"][1:]
        g.gate.needed_to_upgrade = text
        sig["settle"] = "forecast" if (fc is not None and fc.gate.verdict != "INSUFFICIENT") else "none"


def _attach_adjusted_interval(g: GatedFact, tail: float) -> None:
    """
    The selection-adjusted bound for a confirmed claim (M4): the ONE-sided bound at level
    1 - tail in the claim's direction, tail = R*q/m. It comes from measure's provisional family
    pass (test["fcr_bounds"], a model fact the ledger re-runs); a fact without it falls back to
    the widest interval-table row whose one-sided tail is at most `tail` (conservative).
    """
    f = g.fact
    t = getattr(f, "test", None) or {}
    rise = float(f.effect_size) >= 0
    sig = g.gate.signals
    sig["fcr_level_needed"] = 1.0 - tail
    bound, level = None, None
    for row in t.get("fcr_bounds") or []:
        if row.get("bound") is not None and abs(float(row["tail"]) - tail) <= 1e-9 * max(1.0, tail):
            bound, level = float(row["bound"]), float(row["level"])
            break
    if bound is None:
        usable = [row for row in t.get("ci_table") or [] if float(row["tail"]) <= tail + 1e-15]
        if usable:
            row = max(usable, key=lambda r: float(r["tail"]))
            bound = float(row["lo"] if rise else row["hi"])
            level = 1.0 - float(row["tail"])
    if bound is None:
        sig["fcr_interval"] = "not available at the bootstrap size used"
        return
    if rise:
        f.effect_ci_adj_low, f.effect_ci_adj_high = bound, None
    else:
        f.effect_ci_adj_low, f.effect_ci_adj_high = None, bound
    f.effect_ci_adj_level = level
    sig["fcr_interval"] = ["lower" if rise else "upper", bound, level]
    g.gate.reason += (" Adjusted for picking the strongest results, the change is %s %s (a "
                      "one-sided %g%% bound)." % ("at least" if rise else "at most",
                                                 _signed_pct(bound), round(100.0 * level, 4)))



def gate_all(facts: Iterable[Fact], policy: Optional[GatePolicy] = None) -> List[GatedFact]:
    """
    Gate every fact, preserving order. Accepts a list or a FactSet.

    After the per-fact rules, two passes run over the whole batch: false-discovery control
    across the change claims (apply_trend_families, M3), then the cleaner's sanity stop
    (see withhold_suspect_cleaning), which needs the table's quarantine rate, one fact
    among many.
    """
    policy = policy if policy is not None else DEFAULT_POLICY
    gated = [GatedFact(fact=f, gate=gate(f, policy)) for f in facts]
    gated = apply_trend_families(gated, policy)
    return withhold_suspect_cleaning(gated, policy)


def _is_cleaning_fact(f: Fact) -> bool:
    return CLEAN_QUERY_MARKER in str(getattr(f, "query", "") or "")


def withhold_suspect_cleaning(gated: Iterable[GatedFact],
                              policy: Optional[GatePolicy] = None) -> List[GatedFact]:
    """
    The cleaner's sanity stop. For each cleaning pass in the batch (its facts share
    an id prefix and carry clean.py's query marker), take the share of rows its rules
    rejected -- the quarantine rate less any rows collapsed by design to the latest
    row per key. Above policy.max_quarantine_rate, every figure from that pass is
    withheld as INSUFFICIENT: at that rate the cleaner is more likely wrong than the
    file. The original verdict is kept in the signals, as withhold_unreproduced does.
    """
    policy = policy if policy is not None else DEFAULT_POLICY
    gated = list(gated)
    passes: Dict[str, Dict[str, float]] = {}
    for gf in gated:
        f = gf.fact
        if not _is_cleaning_fact(f):
            continue
        fid = str(f.id)
        if fid.endswith(".quarantine_rate") and f.unit == "pct":
            p = passes.setdefault(fid[: -len(".quarantine_rate")], {})
            p["rate"] = float(f.value) / 100.0
            p["rows_in"] = float(f.rows_scanned)
        elif fid.endswith(".collapsed_rows"):
            passes.setdefault(fid[: -len(".collapsed_rows")], {})["collapsed"] = float(f.value)
    suspect: Dict[str, float] = {}
    for prefix, p in passes.items():
        if "rate" not in p:
            continue
        collapsed = p.get("collapsed", 0.0)
        rows_in = p.get("rows_in", 0.0)
        rate = p["rate"] - (collapsed / rows_in if rows_in else 0.0)
        if math.isfinite(rate) and rate > policy.max_quarantine_rate:
            suspect[prefix] = rate
    if not suspect:
        return gated
    out: List[GatedFact] = []
    for gf in gated:
        f = gf.fact
        prefix = next((p for p in suspect if str(f.id).startswith(p + ".")), None)
        if prefix is None or not _is_cleaning_fact(f):
            out.append(gf)
            continue
        rate = suspect[prefix]
        src = _source_name(f)
        sig = dict(gf.gate.signals or {})
        sig["withheld"] = "cleaner_sanity"
        sig["verdict_before_sanity"] = gf.gate.verdict
        sig["suspect_quarantine_rate"] = round(rate, 6)
        sig["max_quarantine_rate"] = policy.max_quarantine_rate
        out.append(GatedFact(f, GateResult(
            verdict="INSUFFICIENT",
            reason=("Cleaning set aside %s of the rows from %s, above the %s we accept "
                    "before trusting the cleaning itself. A rate that high usually means a "
                    "rule is misreading the file rather than the file being that broken: "
                    "the cleaner may be wrong; review rules before relying on any cleaning "
                    "figure, including this one."
                    % (_pct(rate), src, _pct(policy.max_quarantine_rate))),
            needed_to_upgrade=("Read a sample of the quarantined rows (each carries its "
                               "reason), correct the rule that caught most of them, and "
                               "re-run; the share set aside has to fall to %s or below."
                               % _pct(policy.max_quarantine_rate)),
            signals=sig)))
    return out



def withhold_unreproduced(gated: Iterable[GatedFact]) -> List[GatedFact]:
    """
    After EvidenceLedger.verify: any figure whose own query did not reproduce is
    withheld. It is moved to "cannot answer", stating what was claimed and what the
    re-run gave, instead of being narrated as a finding.

    Found 22 Sep 2026: a query using random() was gated RECOMMEND. Verification ran,
    saw it fail, and nothing acted on the result -- verification ran after the brief.
    """
    out: List[GatedFact] = []
    for gf in gated:
        f = gf.fact
        if getattr(f, "verified", None) is not False:
            out.append(gf)
            continue
        if f.query_kind == "derived":
            why = ("This figure is computed from other figures, and at least one of them did "
                   "not reproduce when re-run, so it is withheld.")
            fix = "The input figures must reproduce first."
        else:
            got = getattr(f, "verified_value", None)
            why = ("This figure did not reproduce when its own query was re-run on the same "
                   "data (stated %s, re-run gave %s), so it is withheld rather than reported."
                   % (_fmt_plain(f.value), "no value" if got is None else _fmt_plain(got)))
            fix = ("A deterministic query: no random sampling, and an ORDER BY with any LIMIT, "
                   "so the same data always gives the same answer.")
        sig = dict(gf.gate.signals or {})
        sig["withheld"] = "unreproduced"
        sig["verdict_before_verification"] = gf.gate.verdict
        out.append(GatedFact(f, GateResult(verdict="INSUFFICIENT", reason=why,
                                           needed_to_upgrade=fix, signals=sig)))
    return out


def _fmt_plain(v: Any) -> str:
    try:
        fv = float(v)
    except (TypeError, ValueError):
        return str(v)
    return format(int(fv), ",") if fv.is_integer() else ("%.4g" % fv)


# --------------------------------------------------------------------------
# the measured false-confirm rate (design §1.5, §3.5)
# --------------------------------------------------------------------------
#: The slim benchmark receipt the brief quotes: per simulated condition with no change beyond
#: the bar, how often the engine said CONFIRMED (k of n), with only the fields the sentence
#: needs. It ships beside this module (the browser pack includes it) and is written from full
#: receipts (tools/run_benchmark.py) by slim_benchmark_receipt.
RECEIPT_FILE = "benchmark_receipt.json"
RECEIPT_SPEC = "northledger.benchmark_receipt/1"
RECEIPT_KIND = "northledger.benchmark_receipt/1"
#: The modules a change claim's verdict runs through (rows -> measure -> stats -> gate, via
#: loop.gate_analysis). A receipt is quoted only when these files are byte for byte the ones
#: it measured: an edit to the forecast, the narrator or the benchmark itself does not change
#: a change claim's verdict, so it does not retire the receipt; an edit to any of these does.
CHANGE_PATH_MODULES: Tuple[str, ...] = ("_sqlite", "clean", "facts", "gate", "health", "loop",
                                        "measure", "stats", "vocab")
#: Another receipt file to read instead of the one beside this module (tests, a lead's check).
RECEIPT_PATH: Optional[str] = None
_SNAPSHOT_CACHE: Dict[Any, Optional[str]] = {}
_RECEIPT_CACHE: Dict[Any, Any] = {}


def _engine_dir() -> str:
    return os.path.dirname(os.path.abspath(__file__))


def change_path_snapshot(engine_dir: Optional[str] = None) -> Optional[str]:
    """sha256 over CHANGE_PATH_MODULES (name, NUL, bytes, NUL, sorted), or None if one is missing."""
    d = engine_dir or _engine_dir()
    paths = [os.path.join(d, m + ".py") for m in sorted(CHANGE_PATH_MODULES)]
    try:
        key = (d,) + tuple(os.stat(p).st_mtime_ns for p in paths) + tuple(os.stat(p).st_size for p in paths)
    except OSError:
        return None
    if key in _SNAPSHOT_CACHE:
        return _SNAPSHOT_CACHE[key]
    h = hashlib.sha256()
    for p in paths:
        with open(p, "rb") as fh:
            data = fh.read()
        h.update(os.path.basename(p).encode("utf-8") + b"\0")
        h.update(data)
        h.update(b"\0")
    _SNAPSHOT_CACHE[key] = h.hexdigest()
    return _SNAPSHOT_CACHE[key]


def load_benchmark_receipt(path: Optional[str] = None,
                           check: bool = True) -> Tuple[Optional[Dict[str, Any]], str]:
    """
    (receipt, "") or (None, why none is quoted). With `check`, a receipt recorded on other code
    than the change path this engine runs is never quoted (a stale rate is not a measured one).
    """
    path = path or RECEIPT_PATH or os.path.join(_engine_dir(), RECEIPT_FILE)
    try:
        st = os.stat(path)
        key = (path, st.st_mtime_ns, st.st_size)
        rec = _RECEIPT_CACHE.get(key)
        if rec is None:
            with open(path, "r", encoding="utf-8") as fh:
                rec = json.load(fh)
            _RECEIPT_CACHE.clear()
            _RECEIPT_CACHE[key] = rec
    except (OSError, ValueError):
        return None, "no benchmark receipt ships with this engine"
    if not isinstance(rec, dict) or rec.get("spec") != RECEIPT_SPEC or not rec.get("cells"):
        return None, "the benchmark receipt beside this engine is not one this release reads"
    if check:
        want = change_path_snapshot()
        got = str(((rec.get("change_path_snapshot") or {}).get("id")) or "")
        if want is None or got != want:
            return None, ("the benchmark receipt beside this engine was recorded on other code than "
                          "this engine runs, so its rates are not quoted")
    return rec, ""


#: Matching distances (design §3.5: "the cell matched to the client's own diagnostics"): one
#: step is history x1.5, noise 5 points, estimated momentum 0.3 (against the cell's MEAN
#: estimated momentum, like with like: the model underestimates momentum, so a client's
#: estimate is compared with what the engine estimated in the cell, not with its true value),
#: and rows a month x3 for a volume (counting noise; 1,000 or more counts as 1,000).
def claim_type(fact: Fact) -> str:
    """The benchmark's claim type for a change claim: 'volume' for a monthly count, 'total' for a
    monthly total of a money or count column (like-for-like twins included: counting noise times
    the spread of the row amounts; the benchmark measures it in cells of its own since the ship
    round of 24 Sep 2026), 'measure' for a monthly average."""
    key = str(getattr(fact, "claim_key", "") or "")
    if key.startswith("total:"):
        return "total"
    return "volume" if (key == "volume" or key.startswith("volume:")) else "measure"


def nearest_benchmark_cell(receipt: Dict[str, Any], months: float, cv: float, phi_hat: float,
                           level: Optional[float] = None, claim: Optional[str] = None,
                           seasonal: Optional[bool] = None) -> Optional[Dict[str, Any]]:
    """
    The benchmark condition nearest a claim's own diagnostics. Only cells of the claim's own
    type ('volume' or 'measure') are candidates when `claim` is given (review v2, 24 Sep 2026:
    a volume claim quoted a measure cell and a measure claim a volume cell); seasonality counts
    when `seasonal` is given, and a gated cell (certified at its full size) is preferred to a
    reported one.
    """
    best, best_d = None, math.inf
    for c in receipt.get("cells") or []:
        if not c.get("n"):
            continue
        if claim is not None and str(c.get("claim") or "volume") != claim:
            continue
        lvl = float(c.get("level") or 1000.0)
        if str(c.get("claim") or "") == "total":
            # a monthly-total cell is matched on its EFFECTIVE rows a month (see
            # TOTAL_ROUTE_MIN_EFFECTIVE_ROWS); the caller passes the claim's own
            lvl = lvl / (1.0 + math.expm1(float(c.get("amount_sd") or 0.0) ** 2))
        d = (abs(math.log(max(float(months), 1.0) / float(c["months"]))) / math.log(1.5)
             + abs(float(cv) - float(c["cv"])) / 0.05
             + abs(float(phi_hat) - float(c.get("phi_hat_mean", c.get("phi", 0.0)) or 0.0)) / 0.3)
        if level is None:
            d += 0.0 if lvl >= 1000 else 99.0          # a measure's mean carries no counting noise
        else:
            d += abs(math.log(min(max(float(level), 1.0), 1000.0) / min(lvl, 1000.0))) / math.log(3.0)
        if seasonal is not None and bool(c.get("seasonal")) != bool(seasonal):
            d += 1.0
        if claim is not None and not c.get("gated"):
            d += 0.5
        if d < best_d - 1e-12:
            best, best_d = c, d
    return best


#: A quoted condition this far from the claim's own estimated momentum is not "like" it (fixer round,
#: 24 Sep 2026: a claim with momentum 0.99, a near unit root, was matched to a 0.06 condition and
#: shown as "false alarms 0.0%"). No rate is quoted for it; the reason says so. The grid's
#: momentum conditions sit about 0.4 apart in estimated momentum (0.0, 0.4, 0.6 on the measure
#: cells), so a claim between two of them is always within 0.45 of one: the line flags only a
#: claim outside what was measured, not one between two measured conditions.
BENCH_FAR_PHI = 0.45
#: ... and a claim whose momentum lies more than this beyond every measured condition of its
#: type (the highest total cell's estimated momentum is about 0.63) is outside what was measured.
BENCH_OUTSIDE_PHI = 0.3


def benchmark_far(phi_hat: Any, cell: Optional[Dict[str, Any]],
                  cells: Optional[Iterable[Dict[str, Any]]] = None) -> Optional[str]:
    """Why the nearest measured condition is not like the claim's own, or None when it is near
    enough to quote (see BENCH_FAR_PHI). `cells`: the measured conditions of the claim's type."""
    if cell is None or phi_hat is None:
        return None

    def ph(c: Dict[str, Any]) -> float:
        return float(c.get("phi_hat_mean", c.get("phi", 0.0)) or 0.0)
    try:
        a, b = float(phi_hat), ph(cell)
        span = [ph(c) for c in (cells or [])]
    except (TypeError, ValueError):
        return None
    if not math.isfinite(a):
        return None
    if span and (a > max(span) + BENCH_OUTSIDE_PHI or a < min(span) - BENCH_OUTSIDE_PHI):
        return ("its estimated momentum is %.2f, outside every simulated condition of its kind "
                "(%.2f to %.2f)" % (a, min(span), max(span)))
    if abs(a - b) > BENCH_FAR_PHI:
        return ("its estimated momentum is %.2f, and the nearest simulated condition's is %.2f"
                % (a, b))
    return None


def _condition_gaps(t: Dict[str, Any], cell: Dict[str, Any], level: Optional[float]) -> List[str]:
    """How the quoted cell's condition differs from the claim's own, in the reader's words."""
    gaps: List[str] = []
    if str(t.get("total_of") or "") and str(cell.get("claim") or "volume") != "total":
        # a receipt from before the benchmark had monthly-total cells (ship round, 24 Sep 2026)
        gaps.append("monthly counts, not monthly totals")
    months = int(t.get("n") or 0)
    if months and int(cell["months"]) != months:
        gaps.append("%d months, not %d" % (int(cell["months"]), months))
    if level is not None:
        lvl = float(cell.get("level") or 1000.0)
        what = "rows a month"
        if str(cell.get("claim") or "") == "total":
            lvl = lvl / (1.0 + math.expm1(float(cell.get("amount_sd") or 0.0) ** 2))
            what = "effective rows a month"
        if lvl / max(float(level), 1.0) > 3.0 or max(float(level), 1.0) / lvl > 3.0:
            gaps.append("about %s %s, not %s" % (format(int(round(lvl)), ","), what,
                                                  format(int(round(float(level))), ",")))
    return gaps


#: The facts one quoted rate rests on: (suffix, field, unit, claim).
_RATE_FIELDS: Tuple[Tuple[str, str, str, str], ...] = (
    ("rate", "rate_pct", "pct", "Share of simulated series with no change beyond the bar that the "
                                "engine confirmed, in the benchmark condition nearest this claim"),
    ("lo", "cp_lo_pct", "pct", "Lower end of the 95% Clopper-Pearson interval of that share"),
    ("hi", "cp_hi_pct", "pct", "Upper end of the 95% Clopper-Pearson interval of that share"),
    ("level", "cp_level_pct", "pct", "Level of that interval (Clopper-Pearson, exact binomial)"),
    ("k", "k", "count", "Simulated series in that condition the engine confirmed"),
    ("n", "n", "count", "Simulated series in that condition"),
    ("months", "months", "months", "Months of history in that condition"),
    ("noise", "cv_pct", "pct", "Month-to-month noise in that condition (SD of the log monthly values)"),
    ("momentum", "phi_hat_mean", "ratio", "Average momentum the engine estimated in that condition"),
    ("rows", "level", "count", "Rows a month in that condition"),
)


def _cell_value(cell: Dict[str, Any], field: str) -> float:
    if field == "rate_pct":
        return 100.0 * float(cell["k"]) / float(cell["n"])
    if field == "cp_lo_pct":
        return 100.0 * float(cell["cp95"][0])
    if field == "cp_hi_pct":
        return 100.0 * float(cell["cp95"][1])
    if field == "cp_level_pct":
        return 95.0
    if field == "cv_pct":
        return 100.0 * float(cell["cv"])
    return float(cell[field])


def recompute_receipt_fact(payload: Dict[str, Any]) -> float:
    """EvidenceLedger.verify's re-run of a quoted rate: read it again from the receipt."""
    rec, why = load_benchmark_receipt(check=False)
    if rec is None:
        raise ValueError(why)
    if str(((rec.get("change_path_snapshot") or {}).get("id")) or "") != payload.get("receipt"):
        raise ValueError("the benchmark receipt changed since the rate was quoted")
    for c in rec.get("cells") or []:
        if c.get("name") == payload.get("cell"):
            return _cell_value(c, str(payload.get("field")))
    raise ValueError("cell %r is not in the benchmark receipt" % payload.get("cell"))


def _rate_sentence(vals: Dict[str, str], at_bar: bool) -> str:
    """The §1.5 sentence for one confirmed claim, from printed fact values (vals)."""
    cond = "%s months, month-to-month noise about %s, estimated momentum about %s" % (
        vals["months"], vals["noise"], vals["momentum"])
    if "rows" in vals:
        cond += ", about %s rows a month" % vals["rows"]
    truth = "the true change was exactly the bar" if at_bar else "nothing had changed"
    return ("Measured, not promised: when %s, in simulated series like this one (%s), the engine "
            "said CONFIRMED in %s of them (%s of %s; %s interval %s to %s). That is how often a "
            "series with no change beyond the bar was confirmed, not the chance that this change "
            "is real." % (truth, cond, vals["rate"], vals["k"], vals["n"], vals["level"], vals["lo"],
                          vals["hi"]))


def attach_measured_rates(gated: List[GatedFact]) -> List[GatedFact]:
    """
    For every CONFIRMED change claim, the false-confirm rate the benchmark measured in the
    condition nearest its own diagnostics (months, noise, estimated momentum, rows a month for a
    volume), with its 95% interval (design §1.5): appended to the claim's reason, and recorded as
    background facts the ledger re-reads from the receipt. With no usable receipt the reason
    says so, without a number.
    """
    from .facts import Fact as _Fact
    from .narrate import story_number
    confirmed = [g for g in gated if g.gate.verdict == "RECOMMEND" and _has_change_test(g.fact)
                 and getattr(g.fact, "role", "headline") == "headline"]
    if not confirmed:
        return gated
    rec, why = load_benchmark_receipt()
    out = list(gated)
    for g in confirmed:
        f = g.fact
        t = getattr(f, "test", None) or {}
        cell = None
        kind = claim_type(f)
        level = None
        if rec is not None and t.get("n") and t.get("sigma_hat") is not None and t.get("phi_hat") is not None:
            rv = t.get("rows_a_month", t.get("mean_month"))
            level = float(rv) if (kind in ("volume", "total") and rv is not None) else None
            if kind == "total" and level is not None and t.get("amount_cv") is not None:
                level = level / (1.0 + float(t["amount_cv"]) ** 2)      # effective rows a month
            seas = t.get("seasonal")
            cell = nearest_benchmark_cell(rec, float(t["n"]), float(t["sigma_hat"]),
                                          float(t["phi_hat"]), level, claim=kind,
                                          seasonal=None if seas is None else bool(seas))
        far = benchmark_far(t.get("phi_hat"), cell,
                            [c for c in rec.get("cells") or []
                             if c.get("n") and str(c.get("claim") or "volume") == kind]) \
            if cell is not None else None
        if far is not None:
            g.gate.reason += (" No measured false-confirm rate is quoted for it: no simulated condition "
                              "is like this claim's (%s)." % far)
            g.gate.signals["benchmark_cell"] = None
            g.gate.signals["benchmark_far"] = far
            continue
        if cell is None:
            g.gate.reason += (" No measured false-confirm rate is quoted for it: %s."
                              % (why or "the benchmark measured no condition of this claim's type"))
            g.gate.signals["benchmark_cell"] = None
            continue
        rid = str((rec.get("change_path_snapshot") or {}).get("id"))
        vals: Dict[str, str] = {}
        ids: List[str] = []
        for suffix, field, unit, claim in _RATE_FIELDS:
            if field == "level" and float(cell.get("level") or 1000) >= 1000:
                continue
            v = _cell_value(cell, field)
            fid = "%s.bench.%s" % (f.id, suffix)
            fact = _Fact(id=fid, claim="%s (%s)" % (claim, cell["name"]), value=v, unit=unit,
                         query=json.dumps({"kind": RECEIPT_KIND, "receipt": rid, "cell": cell["name"],
                                           "field": field}, sort_keys=True),
                         query_kind="model", source_table="benchmark receipt",
                         data_health=float(f.data_health), fact_kind="state", role="detail",
                         computed_at=getattr(f, "computed_at", "") or "")
            out.append(GatedFact(fact=fact, gate=GateResult(
                "WATCH", "A benchmark figure quoted beside a confirmed change; it describes the "
                "engine, not the business.", "", {"rule": "benchmark_rate", "fact_id": fid})))
            vals[suffix] = story_number(v, unit)
            ids.append(fid)
        at_bar = bool(float(cell.get("shift") or 0.0))
        gaps = _condition_gaps(t, cell, level)
        sentence = _rate_sentence(vals, at_bar)
        if level is not None and "rows" not in vals:
            # the claim's own rows a month are part of its condition even when the cell carries
            # no counting noise: the sentence must not hide the difference
            gaps = gaps or ["about 1,000 rows a month or more, not %s" % format(int(round(level)), ",")] \
                if level < 1000 / 3.0 else gaps
        if gaps:
            sentence += (" The nearest measured condition is not this claim's own: %s."
                         % "; ".join(gaps))
            g.gate.signals["benchmark_condition_gaps"] = gaps
        g.gate.reason += " " + sentence + " [fact: %s]" % ", ".join(ids)
        g.gate.signals["benchmark_cell"] = cell["name"]
        g.gate.signals["benchmark_at_bar"] = at_bar
        g.gate.signals["benchmark_fact_ids"] = ids
    return out


def slim_benchmark_receipt(full_receipts: List[Dict[str, Any]], measured_change_paths: List[str],
                           engine_dir: Optional[str] = None) -> Dict[str, Any]:
    """
    The slim receipt from full benchmark receipts (tools/run_benchmark.py) measured on THIS
    change path: `measured_change_paths` holds, per receipt, the change_path_snapshot the runner
    recorded before and after its run (the same both times), and each must equal the engine's
    now. (The full receipt's own decision-code hash also covers the forecast and the narrator,
    which do not decide a change claim, so it is kept as provenance only.) Per cell with no
    change beyond the bar (single claim, ordinary noise, no trend, outlier or gap), the most
    replicated measurement wins.
    """
    d = engine_dir or _engine_dir()
    here = change_path_snapshot(d)
    if len(measured_change_paths) != len(full_receipts):
        raise ValueError("one measured change-path snapshot per receipt")
    for r, cp in zip(full_receipts, measured_change_paths):
        if cp != here:
            raise ValueError("receipt %s measured change path %s, not this engine's %s"
                             % (r.get("ran_at"), str(cp)[:12], str(here)[:12]))
    from .stats import clopper_pearson
    cells: Dict[str, Dict[str, Any]] = {}
    sources = []
    for r in full_receipts:
        sources.append({"size": r.get("size"), "ran_at": r.get("ran_at"),
                        "master_seed": r.get("master_seed"), "wall_seconds": r.get("wall_seconds"),
                        "engine_snapshot": (r.get("engine_snapshot") or {}).get("id"),
                        "decision_code_snapshot": (r.get("decision_code_snapshot") or {}).get("id")})
        for x in (r.get("results") or {}).get("change") or []:
            c = x.get("cell") or {}
            if (c.get("role") != "null" or c.get("n_null_measures") or c.get("trend")
                    or c.get("outlier_months") or c.get("missing_months")
                    or c.get("innov", "gauss") != "gauss" or float(c.get("phi") or 0) >= 0.95
                    or not x.get("n")):
                continue
            k, n = int(x["k_confirm"]), int(x["n"])
            cv = float((x.get("effective_monthly_noise") or {}).get("cv_total") or c["cv"])
            item = {"name": c["name"], "claim": c["claim"], "months": int(c["months"]), "cv": cv,
                    "phi": float(c.get("phi") or 0.0), "phi_hat_mean": x.get("phi_hat_mean"),
                    "seasonal": bool(c.get("seasonal")), "level": int(c.get("level") or 1000),
                    "white_sd": float(c.get("white_sd") or 0.0), "shift": float(c.get("shift") or 0.0),
                    "amount_sd": float(c.get("amount_sd") or 0.0),
                    "comp_step": float(c.get("comp_step") or 0.0),
                    "gated": bool(c.get("gated")), "k": k, "n": n,
                    "cp95": list(clopper_pearson(k, n)), "size": r.get("size"), "ran_at": r.get("ran_at")}
            if item["phi_hat_mean"] is None:
                continue
            old = cells.get(c["name"])
            if old is None or n > old["n"]:
                cells[c["name"]] = item
    return {"spec": RECEIPT_SPEC,
            "change_path_snapshot": {"id": here, "modules": list(CHANGE_PATH_MODULES)},
            "sources": sources, "cells": [cells[k] for k in sorted(cells)],
            "note": ("k of n simulated series with no change beyond the bar that the engine said "
                     "CONFIRMED, per condition; a rate under stated conditions, not the chance a "
                     "confirmed change is real (design §1.5).")}
