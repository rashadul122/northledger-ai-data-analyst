#!/usr/bin/env python3
"""
Tier 1 of the self-validation benchmark (design §3, item M5): how often the SHIPPED engine
confirms a change that is not there, how often it confirms one that is, and how often its
forecast ranges hold.

Nothing here re-implements a decision. Every replication generates data with a known truth,
then hands it to the code a visitor's run uses:

  change claims   rows -> measure.build_analysis_table -> measure.measure_facts
                  -> loop.gate_analysis (the analysis path's gate) -> the verdict of the
                  headline trend fact for the claim under test;
  forecasts       a monthly series -> forecast.forecast_facts (which runs run_forecast)
                  -> loop.gate_analysis -> the forecast's verdict, and the forward 80% range
                  checked against the 12 months the generator kept back.

So when the inference code changes (M1-M4, M6, M8), this module measures the new code with
no edit here. It skips only EvidenceLedger.verify, which re-runs the same deterministic code
and doubles the cost.

Data-generating grid (§3.2, Tier 1 part): monthly series with AR(1) noise (phi 0, 0.5, 0.8,
0.95 as a stress cell), fixed multiplicative +/-20% seasonality, a month-level random effect
under row-level data ("month shocks"), a planted level shift in the latest 12 months, outlier
months, blocks of missing months, Student-t(4) innovations and a slow trend; forecast
processes from grid C. The 23 Sep 2026 review added the conditions R1 fails in as gated
cells: volume claims on small counts (100 and 300 a month, AR(1) 0.5/0.8 with Poisson noise
on top) and AR(1)-plus-white-noise series, both at the 5% bar, and forecast AR(1) 0.8/0.9 at
72 and 120 months (the forecast fix added 48 months, and AR(1) 0.8/0.9 around a
seasonal mean at 48, 72 and 120 months). Every draw comes from a seeded numpy Generator, and only from
``Generator.random()`` (normals by Box-Muller, counts by inversion or a normal
approximation), which NumPy's NEP 19 keeps stable across releases, so a receipt re-runs to
the same numbers on another numpy.

Sizes (§3.3): 2,000 replications per gated null cell, 1,000 per gated power cell and per
forecast cell, 500 per reported cell; ``quick`` sizes for the per-commit tests. A rate from
n replications carries a Monte Carlo standard error sqrt(p(1-p)/n); every rate is published
with its Wilson and Clopper-Pearson 95% intervals.

Pass rules (§3.4):
  * gated null cell: H0 "false-confirm rate >= 2%" rejected by an exact binomial test, with
    Holm's correction across the gated null cells of the run at family level 5%;
  * quick (falsification) form, for the per-commit tests: a cell FAILS when an exact
    one-sided binomial test shows its false-confirm rate is above 2% at the 0.1% level;
  * power cell: power at least the cell's floor (POWER_FLOORS);
  * forecast cell (stationary processes): per-horizon coverage of the nominal 80% range at
    least 80% minus 2 Monte Carlo SE; seasonal random walk: "beats seasonal-naive" advice at
    most 2% (hypothesis form).

Python 3.9, numpy + pandas + stdlib (no scipy): the binomial tail, the Wilson and the
Clopper-Pearson intervals are written here.
"""
from __future__ import annotations

import math
import os
import sqlite3
import tempfile
import time
import zlib
from dataclasses import asdict, dataclass
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

SPEC = "northledger.benchmark/1"
MASTER_SEED = 20260923
START_MONTH = 2020 * 12          # January 2020: every window holds each calendar month once
FUTURE = 12                      # months the forecast generator keeps back to score ranges

#: The §3.4 thresholds, in one place. The receipt copies them.
THRESHOLDS: Dict[str, float] = {
    "false_confirm_cap": 0.02,        # per gated null cell and per 10-measure run
    "family_alpha": 0.05,             # Holm across the gated null cells of one run
    "quick_alpha": 0.001,             # falsification form used by the per-commit tests
    "forecast_nominal": 0.80,         # the engine's range level
    "forecast_mcse_k": 2.0,           # coverage >= nominal - k * MCSE
    "interval_coverage_min": 0.93,    # effect intervals (95% nominal), M4
}

#: Replications per cell for each size tier (§3.3). "quick" is the per-commit test size.
SIZES: Dict[str, Dict[str, int]] = {
    "full": {"null_gated": 2000, "alt_gated": 1000, "reported": 500, "forecast": 1000},
    "standard": {"null_gated": 1000, "alt_gated": 500, "reported": 250, "forecast": 500},
    "quick": {"null_gated": 150, "alt_gated": 100, "reported": 60, "forecast": 200},
}

#: Power floors for the gated power cells: (floor, where the number comes from). The design
#: sets the floor at "the value measured at R1 minus 3 points" (§3.4). These are R1's values:
#: the standard-size run (500 series a cell, master seed 20260923) on engine 5e65cf374c09 (decision
#: code cc993331ef0b), 23 Sep 2026; the benchmark receipt beside the engine re-measures them. The earlier
#: placeholder floors (about half of the reviser's prototype) predate the review's 12-versus-12
#: estimand; the pre-review full-size run measured 22-24.5% on a different estimand, so it is
#: not a previous release's value for the "never more than 5 points below" clause.
POWER_FLOORS: Dict[str, Tuple[float, str]] = {
    "alt.month_shock.icc01.24m.shift20": (0.172, "R1 measured 101/500 = 20.2% minus 3 points"),
    "alt.volume.24m.phi0.cv10.shift20": (0.162, "R1 measured 96/500 = 19.2% minus 3 points"),
    "alt.volume.36m.phi05.cv10.shift20": (0.086, "R1 measured 58/500 = 11.6% minus 3 points, §3.4 reference cell"),
    "alt.volume.36m.phi05.cv10.seas.shift20": (0.104, "R1 measured 67/500 = 13.4% minus 3 points"),
    "alt.volume.36m.phi08.cv10.shift20": (0.054, "R1 measured 42/500 = 8.4% minus 3 points"),
    "alt.volume.24m.phi0.cv10.seas.shift20": (0.2, "R1 measured 115/500 = 23.0% minus 3 points"),
    "alt.month_shock.icc01.24m.seas.shift20": (0.156, "R1 measured 93/500 = 18.6% minus 3 points"),
    "alt.month_shock.icc01.36m.phi05.shift20": (0.066, "R1 measured 48/500 = 9.6% minus 3 points"),
    "alt.multi10.24m.phi0.cv10.shift20": (0.162, "R1 measured 96/500 = 19.2% minus 3 points"),
}


# =========================================================================== statistics
def _log_binom_pmf(i: int, n: int, p: float) -> float:
    if p <= 0.0:
        return 0.0 if i == 0 else -math.inf
    if p >= 1.0:
        return 0.0 if i == n else -math.inf
    return (math.lgamma(n + 1) - math.lgamma(i + 1) - math.lgamma(n - i + 1)
            + i * math.log(p) + (n - i) * math.log1p(-p))


def binom_cdf(k: int, n: int, p: float) -> float:
    """P(X <= k) for X ~ Binomial(n, p), exact (sum of pmf terms in log space)."""
    if k < 0:
        return 0.0
    if k >= n:
        return 1.0
    return float(min(1.0, sum(math.exp(_log_binom_pmf(i, n, p)) for i in range(0, k + 1))))


def binom_sf(k: int, n: int, p: float) -> float:
    """P(X >= k) for X ~ Binomial(n, p), exact."""
    if k <= 0:
        return 1.0
    if k > n:
        return 0.0
    return float(min(1.0, sum(math.exp(_log_binom_pmf(i, n, p)) for i in range(k, n + 1))))


def wilson(k: int, n: int, z: float = 1.959964) -> Tuple[float, float]:
    """95% Wilson score interval for k successes in n trials."""
    if n <= 0:
        return (float("nan"), float("nan"))
    ph = k / float(n)
    den = 1.0 + z * z / n
    centre = (ph + z * z / (2.0 * n)) / den
    half = z * math.sqrt(ph * (1.0 - ph) / n + z * z / (4.0 * n * n)) / den
    return (max(0.0, centre - half), min(1.0, centre + half))


def clopper_pearson(k: int, n: int, alpha: float = 0.05) -> Tuple[float, float]:
    """Exact (Clopper-Pearson) interval, by bisection on the binomial tails."""
    if n <= 0:
        return (float("nan"), float("nan"))

    def solve(f: Callable[[float], float]) -> float:
        lo, hi = 0.0, 1.0
        for _ in range(60):
            mid = 0.5 * (lo + hi)
            if f(mid) > 0:
                hi = mid
            else:
                lo = mid
        return 0.5 * (lo + hi)

    lower = 0.0 if k == 0 else solve(lambda q: binom_sf(k, n, q) - alpha / 2.0)
    upper = 1.0 if k == n else solve(lambda q: alpha / 2.0 - binom_cdf(k, n, q))
    return (lower, upper)


def holm(pvalues: Sequence[float], alpha: float) -> List[bool]:
    """Holm's step-down procedure: which hypotheses are rejected at family level alpha."""
    order = sorted(range(len(pvalues)), key=lambda i: pvalues[i])
    m = len(pvalues)
    reject = [False] * m
    for rank, i in enumerate(order):
        if pvalues[i] <= alpha / float(m - rank):
            reject[i] = True
        else:
            break
    return reject


def exceeds(k: int, n: int, p0: float, alpha: float) -> Tuple[bool, float]:
    """Falsification: is the rate shown to be ABOVE p0? One-sided exact test, P(X >= k | p0)."""
    pv = binom_sf(k, n, p0)
    return pv < alpha, pv


def below_pvalue(k: int, n: int, p0: float) -> float:
    """Certification: p-value of H0 "rate >= p0" against "rate < p0", P(X <= k | p0)."""
    return binom_cdf(k, n, p0)


def mcse(p: float, n: int) -> float:
    return math.sqrt(max(p * (1.0 - p), 0.0) / n) if n > 0 else float("nan")


# =========================================================================== random draws
# Only Generator.random() is used (NEP 19's stable subset), so a seed means the same stream
# on any numpy release.
def normals(rng: np.random.Generator, n: int) -> np.ndarray:
    """n standard normals by Box-Muller on rng.random()."""
    m = (n + 1) // 2
    u1 = rng.random(m)
    u2 = rng.random(m)
    r = np.sqrt(-2.0 * np.log1p(-u1))
    z = np.concatenate([r * np.cos(2.0 * np.pi * u2), r * np.sin(2.0 * np.pi * u2)])
    return z[:n]


def innovations(rng: np.random.Generator, n: int, kind: str = "gauss") -> np.ndarray:
    """Unit-variance innovations: Gaussian, or Student-t with 4 degrees of freedom."""
    z = normals(rng, n)
    if kind == "gauss":
        return z
    if kind == "t4":
        # chi-square(4) = 2 * (E1 + E2), E ~ Exp(1) = -log(1 - U); t4 has variance 2
        chi = -2.0 * (np.log1p(-rng.random(n)) + np.log1p(-rng.random(n)))
        return z / np.sqrt(chi / 4.0) / math.sqrt(2.0)
    raise ValueError("unknown innovation kind %r" % kind)


def ar1(rng: np.random.Generator, n: int, phi: float, sd: float, kind: str = "gauss") -> np.ndarray:
    """A stationary AR(1) path with marginal standard deviation `sd` (started in equilibrium)."""
    e = innovations(rng, n, kind)
    x = np.empty(n)
    x[0] = sd * e[0]
    s = sd * math.sqrt(max(1.0 - phi * phi, 0.0))
    for t in range(1, n):
        x[t] = phi * x[t - 1] + s * e[t]
    return x


def poisson(rng: np.random.Generator, lam: np.ndarray) -> np.ndarray:
    """Poisson counts from rng.random(): inversion below a mean of 30, normal approximation above."""
    lam = np.asarray(lam, dtype=float)
    out = np.zeros(lam.shape, dtype=np.int64)
    small = lam < 30.0
    if np.any(small):
        for idx in np.flatnonzero(small):
            L, u = float(lam.flat[idx]), float(rng.random())
            k, pk = 0, math.exp(-L)
            cdf = pk
            while u > cdf and k < 1000:
                k += 1
                pk *= L / k
                cdf += pk
            out.flat[idx] = k
    big = ~small
    if np.any(big):
        z = normals(rng, int(np.sum(big)))
        out[big] = np.maximum(0, np.round(lam[big] + np.sqrt(lam[big]) * z)).astype(np.int64)
    return out


def _seed_for(cell_name: str, rep: int, master: int = MASTER_SEED) -> np.random.SeedSequence:
    return np.random.SeedSequence([int(master), zlib.crc32(cell_name.encode("utf-8")), int(rep)])


def _month_label(idx: int) -> str:
    return "%04d-%02d" % (idx // 12, idx % 12 + 1)


def season_factor(n: int, start: int = START_MONTH, amp: float = 0.20) -> np.ndarray:
    """Fixed multiplicative seasonality, +/- amp, by calendar month."""
    moy = (np.arange(start, start + n) % 12).astype(float)
    return 1.0 + amp * np.sin(2.0 * np.pi * moy / 12.0)


# =========================================================================== change cells
@dataclass(frozen=True)
class ChangeCell:
    """One data-generating condition for a 12-versus-12 change claim."""
    name: str
    claim: str = "volume"            # "volume": monthly row counts; "measure": a column's monthly
                                     # mean; "total": the monthly total of a money column (rows a
                                     # month Poisson x row amounts lognormal; ship round 24 Sep 2026)
    months: int = 24
    phi: float = 0.0                 # AR(1) coefficient of the monthly noise
    cv: float = 0.10                 # SD of the monthly noise on the log scale (about the CV)
    seasonal: bool = False           # fixed multiplicative +/-20% seasonality
    shift: float = 0.0               # true change in the latest 12 months (fraction); 0 = null
    level: int = 1000                # volume: mean rows per month (Poisson noise is 1/level of
                                     # the variance: at 1,000 and CV 10% it is a tenth of it)
    white_sd: float = 0.0            # white (month-to-month independent) noise SD on the log
                                     # scale, INCLUDING a volume claim's Poisson counting noise;
                                     # the AR(1) part then carries the rest of cv. 0 = counting
                                     # noise only (volume) or none (measure): the grid before
                                     # 23 Sep 2026 review, whose draws are unchanged.
    rows_per_month: int = 1000       # measure: rows per month
    row_sd: float = 0.5              # measure: row-level SD as a fraction of the mean
    n_null_measures: int = 0         # extra measure columns in the same file (M3)
    n_shifted_measures: int = 0      # ... of which the first k carry a real change (mixed truth)
    measure_shift: float = 0.20      # the change those k measures carry
    innov: str = "gauss"             # "gauss" or "t4"
    trend: float = 0.0               # slow log-linear trend per month (misspecification cell)
    outlier_months: int = 0          # months within the 24 compared whose level is x outlier_factor
    outlier_factor: float = 2.5
    missing_months: int = 0          # consecutive months with no rows, inside the prior window
    role: str = "null"               # "null" (no true change at the bar) or "alt" (planted change)
    gated: bool = False              # gates CI (hypothesis-test form) or is only reported
    note: str = ""
    seed_key: str = ""               # cells sharing a key draw the same primary series (paired)
    amount_sd: float = 0.0           # total: SD of the log row amounts (lognormal, mean 100); the
                                     # monthly total's white noise is (1 + CV_amount^2) / level
    comp_step: float = 0.0           # total: a new category level enters `comp_at` months before
                                     # the end with this share of the old levels' rows (0.8 = +80%,
                                     # like the sample's East York Low-Rise); 0 = no change in coverage
    comp_at: int = 18

    @property
    def truth(self) -> float:
        return float(self.shift)


def month_shock_cell(name: str, icc: float, total_cv: float = 1.0, **kw: Any) -> ChangeCell:
    """A measure whose rows share their month's condition: month effect = icc of the variance."""
    return ChangeCell(name=name, claim="measure", cv=math.sqrt(icc) * total_cv,
                      row_sd=math.sqrt(1.0 - icc) * total_cv, **kw)


def simulate_change(cell: ChangeCell, rng: np.random.Generator) -> pd.DataFrame:
    """Rows for one replication: a date on the 1st of each month, and measure columns."""
    n = int(cell.months)
    season = season_factor(n) if cell.seasonal else np.ones(n)
    step = np.where(np.arange(n) >= n - 12, 1.0 + cell.shift, 1.0)
    trend = np.exp(cell.trend * (np.arange(n) - (n - 1) / 2.0))
    compared = np.arange(n - 24, n)
    outl = np.ones(n)
    if cell.outlier_months:
        pick = compared[np.argsort(rng.random(len(compared)))[: cell.outlier_months]]
        outl[pick] = cell.outlier_factor
    present = np.ones(n, dtype=bool)
    if cell.missing_months:
        # a gap inside the prior window, never touching the window's first or last month
        lo, hi = n - 23, n - 13 - cell.missing_months + 1
        s = lo + int(rng.random() * max(1, hi - lo + 1))
        present[s: s + cell.missing_months] = False

    if cell.claim == "volume":
        # Poisson counting noise is part of the monthly CV: the extra noise makes up the rest.
        # With white_sd > 0 the white part (counting noise plus extra Gaussian white noise) is
        # white_sd, and the AR(1) part is the remainder of cv (AR(1) plus white noise, the
        # ARMA(1,1) departure the engine's pure-AR(1) model does not contain).
        white2 = max(cell.white_sd ** 2, 1.0 / cell.level)
        sd_u = math.sqrt(max(cell.cv ** 2 - white2, 0.0))
        u = ar1(rng, n, cell.phi, sd_u, cell.innov)
        if cell.white_sd > 0:
            u = u + math.sqrt(max(cell.white_sd ** 2 - 1.0 / cell.level, 0.0)) * normals(rng, n)
        lam = cell.level * season * step * trend * outl * np.exp(u)
        counts = poisson(rng, lam)
    elif cell.claim == "total":
        return _simulate_total(cell, rng, n, season, step, trend, outl, present)
    else:
        counts = np.full(n, int(cell.rows_per_month), dtype=np.int64)
    counts = np.where(present, counts, 0)
    month_starts = np.array(["%s-01" % _month_label(START_MONTH + i) for i in range(n)],
                            dtype="datetime64[D]")
    total = int(counts.sum())
    df = pd.DataFrame({"d": np.repeat(month_starts, counts).astype("datetime64[ns]")})
    month_of_row = np.repeat(np.arange(n), counts)

    def measure_column(shift_series: np.ndarray, month_sd: float, row_sd: float) -> np.ndarray:
        if cell.white_sd > 0:        # month effect = AR(1) part + white part (sd white_sd)
            u = ar1(rng, n, cell.phi, math.sqrt(max(month_sd ** 2 - cell.white_sd ** 2, 0.0)),
                    cell.innov) + cell.white_sd * normals(rng, n)
        else:
            u = ar1(rng, n, cell.phi, month_sd, cell.innov)
        base = 100.0 * season * shift_series * trend * outl * np.exp(u)
        return base[month_of_row] + 100.0 * row_sd * normals(rng, total)

    if cell.claim == "measure":
        # a non-additive name (review v2): an additive one ('amount') would also get a
        # monthly-total claim and become the run's primary claim, and the cell measures the
        # average-month claim alone, as before
        df["score"] = measure_column(step, cell.cv, cell.row_sd)
    moved = np.where(np.arange(n) >= n - 12, 1.0 + cell.measure_shift, 1.0)
    for j in range(cell.n_null_measures):
        df["m%02d" % (j + 1)] = measure_column(moved if j < cell.n_shifted_measures else np.ones(n),
                                               cell.cv, cell.row_sd)
    return df


TOTAL_SITES = ("north", "south", "west")
TOTAL_NEW_SITE = "east"


def amount_cv(sd: float) -> float:
    """The CV of lognormal row amounts whose log has SD `sd`."""
    return math.sqrt(math.expm1(float(sd) ** 2))


def _simulate_total(cell: ChangeCell, rng: np.random.Generator, n: int, season: np.ndarray,
                    step: np.ndarray, trend: np.ndarray, outl: np.ndarray,
                    present: np.ndarray) -> pd.DataFrame:
    """
    Rows for a monthly-total cell: rows a month Poisson around level x season x the planted change
    x exp(u), u the business's AR(1) momentum; each row an amount, lognormal with mean 100 and log
    SD amount_sd; a 'site' column with three sites present throughout. With comp_step > 0 a fourth
    site enters comp_at months before the end (sharing the business's momentum), the change in
    coverage the engine must name and compare like for like. The monthly total's white noise
    (counting times amount spread) is (1 + CV^2)/level on the log scale; the AR(1) part carries
    the rest of cv.
    """
    white2 = (1.0 + amount_cv(cell.amount_sd) ** 2) / float(cell.level)
    sd_u = math.sqrt(max(cell.cv ** 2 - white2, 0.0))
    u = ar1(rng, n, cell.phi, sd_u, cell.innov)
    base = season * step * trend * outl * np.exp(u)
    counts = poisson(rng, cell.level * base)
    counts = np.where(present, counts, 0)
    new = np.zeros(n, dtype=np.int64)
    if cell.comp_step > 0:
        live = np.arange(n) >= n - int(cell.comp_at)
        new = np.where(live & present, poisson(rng, cell.level * cell.comp_step * base), 0)
    month_starts = np.array(["%s-01" % _month_label(START_MONTH + i) for i in range(n)],
                            dtype="datetime64[D]")
    tot = counts + new
    total = int(tot.sum())
    d = np.repeat(month_starts, tot).astype("datetime64[ns]")
    # within a month: the old sites' rows first (dealt round the three sites), then the new site's
    site = []
    for i in range(n):
        site.extend(TOTAL_SITES[j % 3] for j in range(int(counts[i])))
        site.extend([TOTAL_NEW_SITE] * int(new[i]))
    sd = float(cell.amount_sd)
    amt = np.exp(math.log(100.0) - 0.5 * sd * sd + sd * normals(rng, total))
    return pd.DataFrame({"d": d, "site": site, "amount": np.round(amt, 2)})


def effective_noise(cell: ChangeCell) -> Dict[str, float]:
    """
    What the monthly series' noise really is. For a volume claim the Poisson counting noise
    (variance 1/level on the log scale) is white, so the lag-1 autocorrelation of the monthly
    noise is phi times the AR share, not phi: a receipt states both.
    """
    if cell.claim == "total":
        white = min((1.0 + amount_cv(cell.amount_sd) ** 2) / cell.level, cell.cv ** 2)
        ar_share = (cell.cv ** 2 - white) / (cell.cv ** 2) if cell.cv > 0 else 0.0
    elif cell.claim == "volume":
        white = min(max(1.0 / cell.level, cell.white_sd ** 2), cell.cv ** 2)
        ar_share = (cell.cv ** 2 - white) / (cell.cv ** 2) if cell.cv > 0 else 0.0
    else:
        extra = min(cell.white_sd ** 2, cell.cv ** 2)            # white part of the month effect
        white = (cell.row_sd ** 2) / cell.rows_per_month + extra  # + the month mean's sampling noise
        ar_share = (cell.cv ** 2 - extra) / (cell.cv ** 2 + white - extra) if (cell.cv or white) else 0.0
    total = math.sqrt(cell.cv ** 2 if cell.claim in ("volume", "total") else
                      cell.cv ** 2 + (cell.row_sd ** 2) / cell.rows_per_month)
    return {"cv_total": total, "ar_share_of_variance": ar_share,
            "ar_sd": math.sqrt(max(ar_share, 0.0)) * total,
            "white_sd": math.sqrt(max(1.0 - ar_share, 0.0)) * total,
            "lag1_autocorrelation": cell.phi * ar_share}


def _as_of(months: int) -> str:
    nxt = START_MONTH + months
    return "%s-15" % _month_label(nxt)


class _Workdir:
    """One SQLite file per process, rewritten each replication."""

    def __init__(self, path: Optional[str] = None) -> None:
        self.dir = path or tempfile.mkdtemp(prefix="nl_bench_")
        self.db = os.path.join(self.dir, "bench.db")
        if path is None:
            import atexit
            import shutil
            atexit.register(shutil.rmtree, self.dir, True)


def run_change_rep(cell: ChangeCell, rep: int, workdir: Optional[_Workdir] = None,
                   master: int = MASTER_SEED, keep_facts: bool = False) -> Dict[str, Any]:
    """One replication through the shipped measure -> gate path; returns the outcome."""
    from . import measure as _ms
    from .facts import FactSet
    from .loop import gate_analysis
    wd = workdir or _Workdir()
    rng = np.random.default_rng(_seed_for(cell.seed_key or cell.name, rep, master))
    df = simulate_change(cell, rng)
    measures = (["score"] if cell.claim == "measure" else []) + \
               (["amount"] if cell.claim == "total" else []) + \
               ["m%02d" % (j + 1) for j in range(cell.n_null_measures)]
    roles = _ms.Roles(date="d", measures=measures,
                      dimensions=["site"] if cell.claim == "total" else [], grain="events")
    t0 = time.perf_counter()
    at = _ms.build_analysis_table(wd.db, "bench", df, roles)
    fs = FactSet()
    _ms.measure_facts(fs, wd.db, at, as_of=_as_of(cell.months), data_health=100.0, label="bench")
    gated = gate_analysis(fs.facts)
    seconds = time.perf_counter() - t0
    prefix = "measure.volume.change_pct" if cell.claim == "volume" else "measure.score.change"
    trends = [g for g in gated if g.fact.role == "headline" and g.fact.fact_kind == "trend"]
    target = [g for g in trends if g.fact.id.startswith(prefix)]
    parent = None
    if cell.claim == "total":
        # the claim a reader acts on: the monthly total, or, when a site entered part-way (the
        # total itself is then held by the composition rule), its like-for-like twin
        tid = "measure.amount.total.like_for_like.change" if cell.comp_step else "measure.amount.total.change"
        target = [g for g in trends if g.fact.id == tid]
        parent = next((g for g in trends if g.fact.id == "measure.amount.total.change"), None)
    out: Dict[str, Any] = {"rep": rep, "seconds": seconds, "n_claims": len(trends),
                           "run_any_confirm": any(g.gate.verdict == "RECOMMEND" for g in trends),
                           "n_confirm_file": sum(1 for g in trends if g.gate.verdict == "RECOMMEND"),
                           "found": bool(target)}
    if cell.n_shifted_measures:
        # mixed truth: false and true discoveries in the file, for the realised FDR (§3.4)
        false_d = true_d = 0
        for g in trends:
            if g.gate.verdict != "RECOMMEND":
                continue
            fid = g.fact.id
            j = int(fid.split(".")[1][1:]) if fid.startswith("measure.m") and fid.split(".")[1][1:].isdigit() else 0
            real = (1 <= j <= cell.n_shifted_measures) or (fid.startswith("measure.volume.") and cell.shift)
            if real and float(g.fact.effect_size) > 0:
                true_d += 1
            else:
                false_d += 1
        out.update(false_discoveries=false_d, true_discoveries=true_d,
                   fdp=false_d / float(max(1, false_d + true_d)))
    if not target:
        out.update(verdict=None, confirm=False, p=None, effect=None, ci=None, rule=None)
        return out
    # One headline per claim is expected. Should a release keep a second (say, a labelled
    # row-weighted change) under the same prefix, the claim is the one carrying the test.
    target.sort(key=lambda g: (getattr(g.fact, "effect_ci_low", None) is None, g.fact.p_value is None))
    out["n_candidates"] = len(target)
    g = target[0]
    f = g.fact
    confirm = g.gate.verdict == "RECOMMEND"
    if cell.role == "alt" and cell.shift != 0:
        confirm = confirm and (float(f.effect_size) * cell.shift > 0)
    lo, hi = getattr(f, "effect_ci_low", None), getattr(f, "effect_ci_high", None)
    ci = None
    if lo is not None and hi is not None and all(math.isfinite(float(v)) for v in (lo, hi)):
        ci = (float(lo), float(hi))
    t = getattr(f, "test", None) or {}
    phi_hat = t.get("phi_hat")
    out.update(verdict=g.gate.verdict, confirm=bool(confirm), rule=g.gate.signals.get("rule"),
               p=None if f.p_value is None else float(f.p_value), effect=float(f.effect_size),
               ci=ci, ci_level=getattr(f, "effect_ci_level", None),
               covered=None if ci is None else bool(ci[0] <= cell.truth <= ci[1]),
               # what the engine itself saw, so coverage can be read by the engine's own
               # diagnostics (the brief's interval caution keys on them, finding 2 of the review)
               phi_hat=None if phi_hat is None else float(phi_hat),
               drift=bool(str(getattr(f, "trend_screen", "") or "")),
               rows_a_month=t.get("rows_a_month", t.get("mean_month")), amount_cv=t.get("amount_cv"),
               p_nonzero=None if getattr(f, "p_nonzero", None) is None else float(f.p_nonzero),
               family=g.gate.signals.get("family"))
    if cell.claim == "total" and cell.comp_step and parent is not None:
        # the change in coverage: was the total held by the composition rule, was the shift at
        # the month the site entered named, did it explain the series, and was drift ever given
        # as a reason for the total
        pt = getattr(parent.fact, "test", None) or {}
        cs = pt.get("composition_steps") or {}
        entry = _month_label(START_MONTH + int(cell.months) - int(cell.comp_at))
        sig = parent.gate.signals or {}
        out.update(parent_verdict=parent.gate.verdict, parent_rule=sig.get("rule"),
                   comp_named=any(x.get("month") == entry for x in cs.get("named") or []),
                   comp_explains=bool(cs.get("explains")),
                   parent_drift_reason="drift_screen" in (sig.get("checks_failed") or [])
                   or sig.get("rule") == "drift_screen",
                   parent_screen=str(pt.get("screen_kind") or ""))
    if keep_facts:
        out["gated"] = gated
    return out


def summarise_change(cell: ChangeCell, reps: List[Dict[str, Any]]) -> Dict[str, Any]:
    n = len(reps)
    k = sum(1 for r in reps if r["confirm"])
    verdicts: Dict[str, int] = {}
    for r in reps:
        verdicts[str(r["verdict"])] = verdicts.get(str(r["verdict"]), 0) + 1
    rate = k / float(n) if n else float("nan")
    res: Dict[str, Any] = {
        "cell": asdict(cell), "n": n, "k_confirm": k, "rate": rate,
        "effective_monthly_noise": effective_noise(cell),
        "wilson95": list(wilson(k, n)), "clopper_pearson95": list(clopper_pearson(k, n)),
        "mcse": mcse(rate, n), "verdicts": verdicts,
        "target_missing": sum(1 for r in reps if not r["found"]),
        "seconds_per_rep": float(np.mean([r["seconds"] for r in reps])) if reps else None,
    }
    runk = sum(1 for r in reps if r["run_any_confirm"])
    if cell.n_null_measures:
        res.update(run_level_k=runk, run_level_rate=runk / float(n),
                   run_level_wilson95=list(wilson(runk, n)),
                   mean_confirmed_per_file=float(np.mean([r["n_confirm_file"] for r in reps])))
    if cell.n_shifted_measures:
        fdp = np.array([r["fdp"] for r in reps], dtype=float)
        res.update(realised_fdr=float(fdp.mean()),
                   realised_fdr_mcse=float(fdp.std(ddof=1) / math.sqrt(len(fdp))) if len(fdp) > 1 else None,
                   mean_true_discoveries=float(np.mean([r["true_discoveries"] for r in reps])),
                   mean_false_discoveries=float(np.mean([r["false_discoveries"] for r in reps])))
    ps = [r["p"] for r in reps if r.get("p") is not None]
    res["p_value_median"] = float(np.median(ps)) if ps else None
    # the test alone at its nominal 5% (what §0 of the design quotes), apart from the verdict
    k05 = sum(1 for p in ps if p <= 0.05)
    res["p_le_05"] = {"k": k05, "n": len(ps), "rate": (k05 / float(len(ps))) if ps else None,
                      "wilson95": list(wilson(k05, len(ps))) if ps else None}
    effs = [r["effect"] for r in reps if r.get("effect") is not None]
    res["effect_mean"] = float(np.mean(effs)) if effs else None
    with_ci = [r for r in reps if r.get("ci") is not None]
    res["n_with_interval"] = len(with_ci)
    if with_ci:
        kc = sum(1 for r in with_ci if r["covered"])
        res.update(interval_coverage=kc / float(len(with_ci)),
                   interval_coverage_wilson95=list(wilson(kc, len(with_ci))))
    else:
        res["interval_coverage"] = None
    res["interval_coverage_by_diagnostic"] = coverage_by_diagnostic(with_ci)
    phis = [r["phi_hat"] for r in reps if r.get("phi_hat") is not None]
    res["phi_hat_mean"] = float(np.mean(phis)) if phis else None
    res["drift_screen_rate"] = (sum(1 for r in reps if r.get("drift")) / float(n)) if n else None
    rows = [float(r["rows_a_month"]) for r in reps if r.get("rows_a_month") is not None]
    res["rows_a_month_mean"] = float(np.mean(rows)) if rows else None
    comp = [r for r in reps if "comp_named" in r]
    if comp:
        # a change in coverage (total cells with a site entering): how the engine told it
        m = float(len(comp))
        res["composition"] = {
            "n": len(comp),
            "total_held_by_composition": sum(1 for r in comp if r.get("parent_rule") == "composition") / m,
            "total_confirmed": sum(1 for r in comp if r.get("parent_verdict") == "RECOMMEND") / m,
            "step_named_at_entry": sum(1 for r in comp if r["comp_named"]) / m,
            "steps_explain_series": sum(1 for r in comp if r["comp_explains"]) / m,
            "drift_given_as_reason": sum(1 for r in comp if r["parent_drift_reason"]) / m,
        }
    return res


#: The engine diagnostic bands the interval coverage is split by: whether the series' own
#: diagnostics (phi_hat, the drift screen) can tell where the 95% interval falls short. The
#: 23 Sep 2026 review proposed cautioning at phi_hat >= 0.8 or drift; these bands measured
#: coverage ABOVE 95% there and the shortfall at phi_hat < 0.5 (see gate.interval_caution).
PHI_HAT_BANDS: Tuple[Tuple[str, float, float], ...] = (
    ("phi_hat < 0.5", -math.inf, 0.5), ("0.5 <= phi_hat < 0.8", 0.5, 0.8),
    ("phi_hat >= 0.8", 0.8, math.inf))


def coverage_by_diagnostic(with_ci: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    """Interval coverage split by the engine's phi_hat band and by the drift screen."""
    out: Dict[str, Any] = {}

    def put(label: str, rs: List[Dict[str, Any]]) -> None:
        k = sum(1 for r in rs if r["covered"])
        out[label] = {"k": k, "n": len(rs), "coverage": (k / float(len(rs))) if rs else None,
                      "wilson95": list(wilson(k, len(rs))) if rs else None}

    for label, lo, hi in PHI_HAT_BANDS:
        put(label, [r for r in with_ci if r.get("phi_hat") is not None and lo <= r["phi_hat"] < hi])
    put("drift screen fired", [r for r in with_ci if r.get("drift")])
    put("phi_hat >= 0.8 or drift", [r for r in with_ci if r.get("drift") or (
        r.get("phi_hat") is not None and r["phi_hat"] >= 0.8)])
    put("neither", [r for r in with_ci if not r.get("drift") and not (
        r.get("phi_hat") is not None and r["phi_hat"] >= 0.8)])
    return out


def run_change_cell(cell: ChangeCell, reps: int, master: int = MASTER_SEED,
                    workdir: Optional[_Workdir] = None, start: int = 0) -> Dict[str, Any]:
    wd = workdir or _Workdir()
    out = [run_change_rep(cell, i, wd, master) for i in range(start, start + reps)]
    return summarise_change(cell, out)


# =========================================================================== forecast cells
FORECAST_PROCESSES = ("seasonal_rw", "season_noise", "ar1_level", "ar1_season", "damped_trend",
                      "level_shift", "pandemic", "intermittent")
STATIONARY = ("season_noise", "ar1_level")


@dataclass(frozen=True)
class ForecastCell:
    name: str
    process: str
    months: int = 48
    shift_k: int = 6                 # level_shift: months before the origin the shift happened
    phi: float = 0.7                 # ar1_level / ar1_season: the AR(1) coefficient (innovation SD 30)
    gated: bool = False
    note: str = ""


def simulate_forecast(cell: ForecastCell, rng: np.random.Generator) -> np.ndarray:
    """History of `months` values followed by FUTURE held-back values."""
    n = int(cell.months)
    N = n + FUTURE
    t = np.arange(N)
    moy = ((START_MONTH + t) % 12).astype(float)
    sin = np.sin(2.0 * np.pi * moy / 12.0)
    p = cell.process
    if p == "seasonal_rw":           # seasonal-naive is the optimal forecast
        y = np.empty(N)
        y[:12] = 1000.0 + 100.0 * sin[:12]
        e = normals(rng, N)
        for i in range(12, N):
            y[i] = y[i - 12] + 25.0 * e[i]
    elif p == "season_noise":        # stable seasonal mean + iid noise
        y = 1000.0 + 100.0 * sin + 40.0 * normals(rng, N)
    elif p == "ar1_level":           # non-seasonal AR(1) around a level
        # innovation SD 30 at every phi; at phi 0.7 this is the pre-review cell, same draws
        y = 1000.0 + ar1(rng, N, cell.phi, 30.0 / math.sqrt(1 - cell.phi * cell.phi))
    elif p == "ar1_season":          # AR(1) around a stable seasonal mean (stationary)
        y = 1000.0 + 100.0 * sin + ar1(rng, N, cell.phi, 30.0 / math.sqrt(1 - cell.phi * cell.phi))
    elif p == "damped_trend":
        y = 1000.0 * (1.0 + 0.3 * (1.0 - 0.97 ** t)) + 50.0 * sin + 30.0 * normals(rng, N)
    elif p == "level_shift":         # -25% level shift k months before the origin, persisting
        y = 1000.0 + 100.0 * sin + 40.0 * normals(rng, N)
        y[n - int(cell.shift_k):] *= 0.75
    elif p == "pandemic":            # a dip to 40% and a linear recovery, earlier in the history
        y = 1000.0 + 100.0 * sin + 40.0 * normals(rng, N)
        f = np.ones(N)
        a, b = n - 30, n - 18
        f[a:a + 6] = 0.4
        f[a + 6:b] = np.linspace(0.4, 1.0, b - (a + 6) + 2)[1:-1]
        y = y * f
    elif p == "intermittent":        # small counts with many zero months
        y = poisson(rng, np.full(N, 0.8) * (1.0 + 0.5 * sin)).astype(float)
    else:
        raise ValueError("unknown forecast process %r" % p)
    return y


def run_forecast_rep(cell: ForecastCell, rep: int, master: int = MASTER_SEED) -> Dict[str, Any]:
    """One replication through forecast.forecast_facts and the analysis gate."""
    from . import forecast as _fc
    from .facts import FactSet
    from .loop import gate_analysis
    rng = np.random.default_rng(_seed_for(cell.name, rep, master))
    y = simulate_forecast(cell, rng)
    n = int(cell.months)
    con = sqlite3.connect(":memory:")
    t0 = time.perf_counter()
    try:
        con.execute("CREATE TABLE s (_month TEXT, v REAL)")
        con.executemany("INSERT INTO s VALUES (?, ?)",
                        [(_month_label(START_MONTH + i), float(y[i])) for i in range(n)])
        fs = FactSet()
        res = _fc.forecast_facts(fs, con, "SELECT _month, v FROM s ORDER BY _month", "series",
                                 "units", slug="bench", source_table="bench", data_health=100.0,
                                 rows_scanned=n, fill="zero", as_of="%s-01" % _month_label(START_MONTH + n))
        gated = gate_analysis(fs.facts)
    finally:
        con.close()
    seconds = time.perf_counter() - t0
    head = [g for g in gated if g.fact.fact_kind == "forecast" and g.fact.role == "headline"]
    verdict = head[0].gate.verdict if head else None
    rule = head[0].gate.signals.get("rule") if head else None
    inside: List[Optional[bool]] = []
    beats = None
    replay = None
    if res is not None:
        beats = bool(res.beats_seasonal_naive)
        replay = res.coverage.get("rate")
        for row in res.forward:
            h = int(row["h"]) - 1
            lo, hi = float(row.get("lo80", float("nan"))), float(row.get("hi80", float("nan")))
            if math.isfinite(lo) and math.isfinite(hi):
                inside.append(bool(lo <= y[n + h] <= hi))
            else:
                inside.append(None)
    return {"rep": rep, "seconds": seconds, "verdict": verdict, "rule": rule, "inside": inside,
            "beats_sn": beats, "replay_h1_rate": replay, "forecast_made": res is not None}


def summarise_forecast(cell: ForecastCell, reps: List[Dict[str, Any]]) -> Dict[str, Any]:
    n = len(reps)
    H = max([len(r["inside"]) for r in reps] or [0])
    per_h = []
    for h in range(H):
        vals = [r["inside"][h] for r in reps if len(r["inside"]) > h]
        drawn = [v for v in vals if v is not None]
        k = sum(1 for v in drawn if v)
        m = len(drawn)
        cov = k / float(m) if m else float("nan")
        per_h.append({"h": h + 1, "n_series": len(vals), "n_band": m, "hits": k, "coverage": cov,
                      "mcse": mcse(cov, m) if m else None, "wilson95": list(wilson(k, m)) if m else None,
                      "band_drawn_share": m / float(len(vals)) if vals else None})
    # pooled coverage with a cluster-robust MCSE: one mean per replication (its horizons share
    # a series and calibration errors), SE across replications
    means = []
    for r in reps:
        d = [v for v in r["inside"] if v is not None]
        if d:
            means.append(float(np.mean(d)))
    pooled = float(np.mean(means)) if means else float("nan")
    pooled_se = float(np.std(means, ddof=1) / math.sqrt(len(means))) if len(means) > 1 else float("nan")
    verdicts: Dict[str, int] = {}
    for r in reps:
        verdicts[str(r["verdict"])] = verdicts.get(str(r["verdict"]), 0) + 1
    krec = verdicts.get("RECOMMEND", 0)
    adv = [r["inside"][0] for r in reps if r["verdict"] == "RECOMMEND" and r["inside"]
           and r["inside"][0] is not None]
    made = [r for r in reps if r["forecast_made"]]
    kb = sum(1 for r in made if r["beats_sn"])
    return {
        "cell": asdict(cell), "n": n, "horizons": H, "per_horizon": per_h,
        "pooled_coverage": pooled, "pooled_mcse_cluster": pooled_se,
        "verdicts": verdicts, "k_recommend": krec, "recommend_rate": krec / float(n) if n else None,
        "recommend_wilson95": list(wilson(krec, n)),
        "h1_coverage_among_advice": (sum(adv) / float(len(adv))) if adv else None,
        "beats_sn_rate": kb / float(len(made)) if made else None,
        "replay_h1_rate_mean": float(np.nanmean([r["replay_h1_rate"] for r in made
                                                if r["replay_h1_rate"] is not None])) if made else None,
        "seconds_per_rep": float(np.mean([r["seconds"] for r in reps])) if reps else None,
    }


def run_forecast_cell(cell: ForecastCell, reps: int, master: int = MASTER_SEED,
                      start: int = 0) -> Dict[str, Any]:
    return summarise_forecast(cell, [run_forecast_rep(cell, i, master) for i in range(start, start + reps)])


# =========================================================================== the grid
def _vol(name: str, **kw: Any) -> ChangeCell:
    return ChangeCell(name=name, claim="volume", **kw)


def change_grid() -> List[ChangeCell]:
    """The Tier 1 change-claim cells: gated adverse null cells, gated power cells, reported cells."""
    cells: List[ChangeCell] = []
    # --- gated null cells: momentum x seasonality x history x noise (volume claim) ----------
    for months in (24, 36):
        for phi in (0.0, 0.5, 0.8):
            for seas in (False, True):
                for cv in (0.10, 0.20):
                    cells.append(_vol("null.volume.%dm.phi%s.cv%d%s" % (
                        months, str(phi).replace(".", "").rstrip("0") or "0", int(cv * 100),
                        ".seas" if seas else ""), months=months, phi=phi, cv=cv, seasonal=seas,
                        gated=True))
    # --- gated null cells: month shocks under row-level data (M1) ---------------------------
    cells.append(month_shock_cell("null.month_shock.icc01.24m", 0.01, gated=True,
                                  note="24 months x 1,000 rows, month effect 1% of the variance"))
    cells.append(month_shock_cell("null.month_shock.icc05.24m", 0.05, gated=True,
                                  note="24 months x 1,000 rows, month effect 5% of the variance"))
    cells.append(month_shock_cell("null.month_shock.icc01.24m.seas", 0.01, seasonal=True, gated=True,
                                  note="month shocks on a +/-20% seasonal measure"))
    cells.append(month_shock_cell("null.month_shock.icc01.36m.phi05", 0.01, months=36, phi=0.5,
                                  gated=True, note="month effects with momentum (AR(1) 0.5)"))
    # --- gated null cells: at the materiality bar (true change exactly 5%: min-effect null, M4)
    for phi in (0.0, 0.5):
        for seas in (False, True):
            cells.append(_vol("null.bar.volume.24m.phi%s.cv10%s" % ("05" if phi else "0",
                              ".seas" if seas else ""), phi=phi, cv=0.10, seasonal=seas,
                              shift=0.05, gated=True, note="true change = the 5% bar"))
    # --- gated null cells: multiplicity, volume + 10 null measures (M3), run level ----------
    for phi in (0.0, 0.5):
        for seas in (False, True):
            cells.append(_vol("null.multi10.24m.phi%s.cv10%s" % ("05" if phi else "0",
                              ".seas" if seas else ""), phi=phi, cv=0.10, seasonal=seas,
                              level=1000, n_null_measures=10, gated=True,
                              note="volume + 10 no-change measures; gate reads the run level"))
    # --- gated null cells added by the 23 Sep 2026 review: the conditions R1 fails in -------
    # (1) counting noise: small monthly counts, AR(1) sd 0.10 on the log scale with Poisson
    # noise on top, at the 5% bar. The 1,000-a-month cells above dilute that white noise to a
    # tenth of the variance; at 100-300 a month it is a quarter to a half.
    for level in (100, 300):
        for months in (24, 36):
            for phi in (0.5, 0.8):
                for seas in (False, True):
                    cells.append(count_cell("null.bar.count%d.%dm.phi%s.ar10%s" % (
                        level, months, "05" if phi == 0.5 else "08", ".seas" if seas else ""),
                        level=level, months=months, phi=phi, seasonal=seas, shift=0.05,
                        gated=True))
    # (2) AR(1) plus white noise (ARMA(1,1)): AR sd 0.10 at phi 0.8 plus white noise sd 0.07
    # (Poisson counting noise at 1,000 a month included), at the 5% bar.
    for months in (24, 36):
        for seas in (False, True):
            cells.append(arwn_cell("null.bar.arwn.%dm.phi08.ar10.wn07%s" % (
                months, ".seas" if seas else ""), months=months, phi=0.8, ar_sd=0.10,
                white=0.07, seasonal=seas, shift=0.05, gated=True))
    # --- gated power cells (20% planted shift) -------------------------------------------
    cells.append(month_shock_cell("alt.month_shock.icc01.24m.shift20", 0.01, shift=0.20,
                                  role="alt", gated=True))
    cells.append(month_shock_cell("alt.month_shock.icc01.24m.seas.shift20", 0.01, seasonal=True,
                                  shift=0.20, role="alt", gated=True))
    cells.append(month_shock_cell("alt.month_shock.icc01.36m.phi05.shift20", 0.01, months=36,
                                  phi=0.5, shift=0.20, role="alt", gated=True))
    for months, phi, seas in ((24, 0.0, False), (24, 0.0, True), (36, 0.5, False), (36, 0.5, True),
                              (36, 0.8, False)):
        cells.append(_vol("alt.volume.%dm.phi%s.cv10%s.shift20" % (
            months, {0.0: "0", 0.5: "05", 0.8: "08"}[phi], ".seas" if seas else ""),
            months=months, phi=phi, cv=0.10, seasonal=seas, shift=0.20, role="alt", gated=True))
    cells.append(_vol("alt.multi10.24m.phi0.cv10.shift20", cv=0.10, shift=0.20, level=1000,
                      n_null_measures=10, role="alt", gated=True, seed_key="pair.primary.24m.shift20",
                      note="primary (volume) shifted 20% beside 10 null secondary measures"))
    cells.append(_vol("alt.volume.24m.phi0.cv10.shift20.alone", cv=0.10, shift=0.20, level=1000,
                      role="alt", seed_key="pair.primary.24m.shift20",
                      note="the same primary series, no secondary measures (M3 pair: same draws)"))
    # --- mixed truth: 10 measures, 1 / 3 / 5 of them moved 20% (realised FDR, §3.4) ----------
    for k in (1, 3, 5):
        cells.append(_vol("mixed.multi10.24m.phi0.cv10.moved%d" % k, cv=0.10, level=1000,
                          n_null_measures=10, n_shifted_measures=k, gated=True, role="mixed",
                          note="%d0%% of the 10 secondary measures moved 20%%; volume unchanged" % k))
    # --- reported cells ------------------------------------------------------------------
    for months in (24, 36, 60):
        for cv in (0.05, 0.10, 0.20):
            cells.append(_vol("rep.volume.%dm.phi05.cv%d" % (months, int(cv * 100)),
                              months=months, phi=0.5, cv=cv))
    cells.append(_vol("rep.volume.60m.phi08.cv10.seas", months=60, phi=0.8, cv=0.10, seasonal=True))
    cells.append(_vol("rep.volume.36m.phi095.cv10.stress", months=36, phi=0.95, cv=0.10,
                      note="stress: near unit root"))
    cells.append(_vol("rep.volume.24m.phi05.cv10.t4", phi=0.5, cv=0.10, innov="t4",
                      note="Student-t(4) innovations"))
    cells.append(_vol("rep.volume.36m.trend1pct.cv5", months=36, cv=0.05, trend=0.01,
                      note="steady +1%/month growth, no step: drift screen (M2)"))
    cells.append(_vol("rep.volume.24m.outlier1.cv10", cv=0.10, outlier_months=1,
                      note="one month at 2.5x among the 24 compared"))
    cells.append(_vol("rep.volume.24m.missing3.cv10", cv=0.10, missing_months=3,
                      note="three consecutive months with no rows in the prior window"))
    cells.append(month_shock_cell("rep.month_shock.icc0.24m", 0.0,
                                  note="no month effect: rows truly independent"))
    cells.append(month_shock_cell("rep.month_shock.icc01.24m.rows500", 0.01, rows_per_month=500,
                                  note="500 rows/month: the shuffle-test branch (12,000 rows)"))
    cells.append(_vol("rep.volume.24m.phi0.cv10.shift055", cv=0.10, shift=0.055,
                      note="5.5% true change in 10% noise: point estimate often clears the bar (M4)"))
    for shift in (0.05, 0.10):
        cells.append(_vol("rep.alt.volume.24m.phi0.cv10.shift%d" % int(shift * 100), cv=0.10,
                          shift=shift, role="alt"))
    cells.append(_vol("rep.alt.volume.24m.phi05.cv10.seas.shift20", phi=0.5, cv=0.10,
                      seasonal=True, shift=0.20, role="alt"))
    # reported beside the review's gated cells: the harder AR(1)+white condition, and power
    # pairs, so that routing these conditions to WATCH shows its cost (§2.1: every size test
    # has a power pair)
    cells.append(arwn_cell("rep.volume.36m.phi09.ar10.wn05", months=36, phi=0.9, ar_sd=0.10,
                           white=0.05, shift=0.05,
                           note="AR(1) 0.9 sd 0.10 + white sd 0.05, at the bar (reported)"))
    cells.append(count_cell("rep.alt.count300.36m.phi08.ar10.seas.shift20", level=300, months=36,
                            phi=0.8, seasonal=True, shift=0.20, role="alt"))
    cells.append(arwn_cell("rep.alt.arwn.36m.phi08.ar10.wn07.shift20", months=36, phi=0.8,
                           ar_sd=0.10, white=0.07, shift=0.20, role="alt"))
    cells.extend(total_grid())
    return cells


#: The monthly-total grid (ship round, 24 Sep 2026): rows a month, the spread of the row
#: amounts, the business's momentum, and whether a site enters part-way.
TOTAL_LEVELS = (30, 100, 300, 1000)
TOTAL_AMOUNT_SDS = (0.25, 1.0)
TOTAL_PHIS = (0.0, 0.5, 0.8)


def _tag(x: float) -> str:
    return {0.0: "0", 0.25: "025", 0.5: "05", 0.8: "08", 1.0: "10"}[float(x)]


def total_grid() -> List[ChangeCell]:
    """
    Monthly totals of a money column (ship round, 24 Sep 2026): a monthly-total claim quoted the
    nearest COUNT cell and borrowed the counts' routing rule. Null cells at the 5% bar (the
    min-effect null), 36 months: rows a month 30/100/300/1,000 (Poisson), row amounts lognormal
    with log SD 0.25 (tight, like rents) or 1.0 (spread, like shop baskets), AR(1) momentum
    0/0.5/0.8 at SD 0.10 on the log scale, and with or without a site entering 18 months before
    the end at +80% of the old sites' rows (the sample's story). With a site entering, the claim
    measured is the like-for-like total (the total itself is held by the composition rule).
    Power cells at a 20% change: momentum 0.5, both spreads, every level, with and without the
    entering site. All are reported cells; the routing rule for totals (gate.uncertified_condition)
    is derived from them.
    """
    cells: List[ChangeCell] = []
    for level in TOTAL_LEVELS:
        for sd in TOTAL_AMOUNT_SDS:
            for phi in TOTAL_PHIS:
                for comp in (False, True):
                    cells.append(total_cell("null.bar.total%d.a%s.36m.phi%s.ar10%s" % (
                        level, _tag(sd), _tag(phi), ".comp" if comp else ""), level=level,
                        amount_sd=sd, months=36, phi=phi, shift=0.05,
                        comp_step=0.8 if comp else 0.0))
    for level in TOTAL_LEVELS:
        for sd in TOTAL_AMOUNT_SDS:
            for comp in (False, True):
                cells.append(total_cell("alt.total%d.a%s.36m.phi05.ar10%s.shift20" % (
                    level, _tag(sd), ".comp" if comp else ""), level=level, amount_sd=sd, months=36,
                    phi=0.5, shift=0.20, role="alt", comp_step=0.8 if comp else 0.0))
    return cells


def total_cell(name: str, level: int, amount_sd: float, ar_sd: float = 0.10, **kw: Any) -> ChangeCell:
    """
    A monthly-total claim: log-scale AR(1) momentum with SD `ar_sd`, and the white noise of a total
    of Poisson(level) rows of lognormal amounts ON TOP (variance (1 + CV_amount^2) / level), so the
    monthly CV is sqrt(ar_sd^2 + (1 + CV_amount^2) / level).
    """
    white2 = (1.0 + amount_cv(amount_sd) ** 2) / float(level)
    return ChangeCell(name=name, claim="total", level=int(level), amount_sd=float(amount_sd),
                      cv=math.sqrt(ar_sd ** 2 + white2), **kw)


def count_cell(name: str, level: int, ar_sd: float = 0.10, **kw: Any) -> ChangeCell:
    """
    A volume claim on small monthly counts: log-scale AR(1) noise with SD `ar_sd`, and Poisson
    counting noise ON TOP (variance 1/level), so the monthly CV is sqrt(ar_sd^2 + 1/level).
    """
    return ChangeCell(name=name, claim="volume", level=int(level),
                      cv=math.sqrt(ar_sd ** 2 + 1.0 / level), **kw)


def arwn_cell(name: str, ar_sd: float, white: float, level: int = 1000, **kw: Any) -> ChangeCell:
    """
    A volume claim whose log monthly noise is AR(1) (SD `ar_sd`) plus white noise (SD `white`,
    Poisson counting noise at `level` included): the ARMA(1,1) departure from the engine's
    pure-AR(1) model.
    """
    if white ** 2 < 1.0 / level:
        raise ValueError("white SD %.3f is below the counting noise at %d a month" % (white, level))
    return ChangeCell(name=name, claim="volume", level=int(level), white_sd=float(white),
                      cv=math.sqrt(ar_sd ** 2 + white ** 2), **kw)


def forecast_grid() -> List[ForecastCell]:
    cells: List[ForecastCell] = []
    for proc in STATIONARY:
        for months in (36, 48, 72, 120):
            cells.append(ForecastCell("fc.%s.%dm" % (proc, months), proc, months, gated=True))
    # added by the 23 Sep 2026 review: the ar1_level cells above use phi 0.7, where coverage
    # passes; at 0.8-0.9 the long horizons fall short. Gated per horizon like the others.
    for phi in (0.8, 0.9):
        for months in (72, 120):
            cells.append(ForecastCell("fc.ar1_level.phi%s.%dm" % ("08" if phi == 0.8 else "09", months),
                                      "ar1_level", months, phi=phi, gated=True,
                                      note="AR(1) %.1f around a level, innovation SD 30" % phi))
    # added with the forecast fix for that finding (dependence-widened ranges): the same
    # momentum at 48 months, and around a seasonal mean at 48, 72 and 120 months, where the
    # seasonal models' errors are the AR(1) noise itself (lag-1 autocorrelation ~0.7 even one
    # month ahead). Stationary processes: gated per horizon like the others.
    for phi in (0.8, 0.9):
        tag = "08" if phi == 0.8 else "09"
        cells.append(ForecastCell("fc.ar1_level.phi%s.48m" % tag, "ar1_level", 48, phi=phi, gated=True,
                                  note="AR(1) %.1f around a level, innovation SD 30" % phi))
        for months in (48, 72, 120):
            cells.append(ForecastCell("fc.ar1_season.phi%s.%dm" % (tag, months), "ar1_season", months,
                                      phi=phi, gated=True,
                                      note="AR(1) %.1f around a seasonal mean, innovation SD 30" % phi))
    for months in (48, 72):
        cells.append(ForecastCell("fc.seasonal_rw.%dm" % months, "seasonal_rw", months, gated=True,
                                  note="seasonal-naive optimal: 'beats seasonal-naive' is false"))
    for k in (3, 6, 12):
        cells.append(ForecastCell("fc.level_shift.k%d.72m" % k, "level_shift", 72, shift_k=k))
    cells.append(ForecastCell("fc.damped_trend.72m", "damped_trend", 72))
    cells.append(ForecastCell("fc.pandemic.72m", "pandemic", 72))
    cells.append(ForecastCell("fc.intermittent.48m", "intermittent", 48))
    return cells


def cell_by_name(name: str) -> Any:
    for c in list(change_grid()) + list(forecast_grid()):
        if c.name == name:
            return c
    raise KeyError(name)


def reps_for(cell: Any, size: str = "full") -> int:
    s = SIZES[size]
    if isinstance(cell, ForecastCell):
        return s["forecast"]
    if not cell.gated:
        return s["reported"]
    if cell.role == "mixed":
        return s["reported"]
    return s["null_gated"] if cell.role == "null" else s["alt_gated"]


# =========================================================================== judging
def judge_null_quick(res: Dict[str, Any], key: str = "k_confirm") -> Dict[str, Any]:
    """Falsification: FAIL when the rate is shown to exceed the 2% cap at the 0.1% level."""
    k = int(res[key] if key in res else res["k_confirm"])
    n = int(res["n"])
    bad, pv = exceeds(k, n, THRESHOLDS["false_confirm_cap"], THRESHOLDS["quick_alpha"])
    return {"form": "falsification", "k": k, "n": n, "p_above_cap": pv, "pass": not bad}


def judge_nulls_certify(results: List[Dict[str, Any]], key: str = "k_confirm") -> List[Dict[str, Any]]:
    """Certification (§3.3): H0 rate >= 2% rejected per cell, Holm across the cells given."""
    cap = THRESHOLDS["false_confirm_cap"]
    pvs = [below_pvalue(int(r.get(key, r["k_confirm"])), int(r["n"]), cap) for r in results]
    rej = holm(pvs, THRESHOLDS["family_alpha"])
    return [{"form": "certification (Holm)", "k": int(r.get(key, r["k_confirm"])), "n": int(r["n"]),
             "p_rate_ge_cap": pv, "pass": bool(ok)} for r, pv, ok in zip(results, pvs, rej)]


def judge_power(res: Dict[str, Any], floor: float) -> Dict[str, Any]:
    return {"form": "floor", "floor": floor, "power": res["rate"], "pass": res["rate"] >= floor}


def judge_fdr(res: Dict[str, Any], q: float = 0.01) -> Dict[str, Any]:
    """§3.4: realised FDR <= recommend_q + 2 MCSE (recommend_q 0.01 from §2.4)."""
    fdr, se = res.get("realised_fdr"), res.get("realised_fdr_mcse") or 0.0
    return {"form": "realised FDR <= q + 2 MCSE", "q": q, "fdr": fdr, "mcse": se,
            "pass": fdr is not None and fdr <= q + 2.0 * se}


def judge_forecast(res: Dict[str, Any]) -> Dict[str, Any]:
    c = res["cell"]
    if c["process"] == "seasonal_rw":
        k, n = res["k_recommend"], res["n"]
        return {"form": "certification", "measure": "false 'beats seasonal-naive' advice",
                "k": k, "n": n, "p_rate_ge_cap": below_pvalue(k, n, THRESHOLDS["false_confirm_cap"]),
                "pass": below_pvalue(k, n, THRESHOLDS["false_confirm_cap"]) <= THRESHOLDS["family_alpha"]}
    nominal, kk = THRESHOLDS["forecast_nominal"], THRESHOLDS["forecast_mcse_k"]
    fails = []
    for row in res["per_horizon"]:
        if not row["n_band"]:
            continue
        if row["coverage"] < nominal - kk * row["mcse"]:
            fails.append(row["h"])
    drawn = [row["band_drawn_share"] for row in res["per_horizon"] if row["band_drawn_share"] is not None]
    return {"form": "coverage >= 80% - 2 MCSE per horizon", "failing_horizons": fails,
            "min_band_drawn_share": min(drawn) if drawn else None,
            "pass": bool(res["per_horizon"]) and not fails}


# =========================================================================== parallel runs
_POOL_WD: Optional[_Workdir] = None


def _pool_init(root: str, base: Optional[str] = None) -> None:
    import sys
    import warnings
    warnings.filterwarnings("ignore")
    if root not in sys.path:
        sys.path.insert(0, root)
    global _POOL_WD
    if base:
        d = os.path.join(base, "w%d" % os.getpid())
        os.makedirs(d, exist_ok=True)
        _POOL_WD = _Workdir(d)
    else:
        _POOL_WD = _Workdir()


def _pool_task(args: Tuple[Any, int, int, int]) -> Tuple[str, List[Dict[str, Any]]]:
    cell, start, count, master = args
    out = []
    for i in range(start, start + count):
        if isinstance(cell, ForecastCell):
            out.append(run_forecast_rep(cell, i, master))
        else:
            r = run_change_rep(cell, i, _POOL_WD, master)
            out.append(r)
    return cell.name, out


def run_cells(specs: Sequence[Tuple[Any, int]], workers: Optional[int] = None,
              master: int = MASTER_SEED, chunk: int = 20) -> Dict[str, Dict[str, Any]]:
    """
    Run (cell, replications) pairs and return {cell name: summary}. With workers > 1 the
    replications are spread over processes (desktop only; the browser engine never calls this).
    The numbers do not depend on `workers`: each replication has its own seed.
    """
    if workers is None:
        workers = int(os.environ.get("NL_BENCH_WORKERS", "0") or 0) or \
            max(1, min(8, (os.cpu_count() or 2) - 1))
    tasks = [(c, s, min(chunk, n - s), master) for c, n in specs for s in range(0, n, chunk)]
    reps: Dict[str, List[Dict[str, Any]]] = {c.name: [] for c, _ in specs}
    if workers > 1 and len(tasks) > 1:
        import multiprocessing as mp
        import shutil
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        base = tempfile.mkdtemp(prefix="nl_bench_")
        try:
            with mp.get_context("spawn").Pool(min(workers, len(tasks)), initializer=_pool_init,
                                              initargs=(root, base)) as pool:
                for name, out in pool.imap_unordered(_pool_task, tasks):
                    reps[name].extend(out)
        finally:
            shutil.rmtree(base, True)
    else:
        global _POOL_WD
        _POOL_WD = _POOL_WD or _Workdir()
        for t in tasks:
            name, out = _pool_task(t)
            reps[name].extend(out)
    res: Dict[str, Dict[str, Any]] = {}
    for c, _ in specs:
        rs = sorted(reps[c.name], key=lambda r: r["rep"])
        res[c.name] = (summarise_forecast(c, rs) if isinstance(c, ForecastCell)
                       else summarise_change(c, rs))
        res[c.name]["reps"] = rs
    return res


# =========================================================================== receipt helpers
def engine_snapshots(engine_dir: Optional[str] = None) -> Dict[str, Any]:
    """
    loop.engine_snapshot()'s hash of northledger/*.py, and the same hash without this file, so
    a receipt names the decision code it measured (the benchmark is not a decision).
    """
    import hashlib
    here = engine_dir or os.path.dirname(os.path.abspath(__file__))

    def digest(skip: Sequence[str]) -> Tuple[str, int]:
        h = hashlib.sha256()
        files = sorted(f for f in os.listdir(here) if f.endswith(".py") and f not in skip)
        for f in files:
            h.update(f.encode("utf-8") + b"\0")
            with open(os.path.join(here, f), "rb") as fh:
                h.update(fh.read())
            h.update(b"\0")
        return h.hexdigest(), len(files)

    full, nf = digest(())
    dec, nd = digest(("benchmark.py",))
    return {"engine_snapshot": {"id": full, "files": nf,
                                "kind": "sha256 of northledger/*.py (loop.engine_snapshot)"},
            "decision_code_snapshot": {"id": dec, "files": nd,
                                       "kind": "the same hash leaving out benchmark.py"}}


# =========================================================================== the §1.5 sentence
def _plain_null(c: Dict[str, Any]) -> bool:
    """A no-change volume cell with nothing else going on: the cells a client is matched to."""
    return (c.get("claim") == "volume" and c.get("role") == "null" and not c.get("shift")
            and not c.get("n_null_measures") and not c.get("trend") and not c.get("outlier_months")
            and not c.get("missing_months") and c.get("innov", "gauss") == "gauss"
            and not c.get("white_sd") and float(c.get("phi", 0.0)) < 0.95)


def _rate_text(k: int, n: int) -> str:
    return "%s%%" % (("%.2f" % (100.0 * k / n)).rstrip("0").rstrip(".") if n else "?")


def describe_cell(c: Dict[str, Any]) -> str:
    """A change cell's conditions in plain words, for the sentence a visitor reads."""
    parts = ["%d months" % int(c["months"])]
    if c.get("claim") == "measure":
        parts.append("an average over %s rows a month" % "{:,}".format(int(c.get("rows_per_month") or 0)))
    elif int(c.get("level") or 1000) < 1000:
        parts.append("about %d rows a month" % int(c["level"]))
    parts.append("month-to-month noise about %d%%" % int(round(100 * float(c["cv"]))))
    parts.append("momentum %.1f" % float(c.get("phi") or 0.0))
    if c.get("white_sd"):
        parts.append("plus independent noise about %d%%" % int(round(100 * float(c["white_sd"]))))
    if c.get("seasonal"):
        parts.append("seasonal")
    if c.get("n_null_measures"):
        parts.append("%d other unchanged measures in the file" % int(c["n_null_measures"]))
    if c.get("shift"):
        parts.append("a true change of %d%%, right at the bar" % int(round(100 * float(c["shift"]))))
    return ", ".join(parts)


def matched_cell(receipt: Dict[str, Any], months: int, cv: float, phi: float,
                 seasonal: Optional[bool] = None) -> Optional[Dict[str, Any]]:
    """
    The receipt's no-change cell nearest a client's own diagnostics (design §3.5: the cell
    matched to the client, never a pooled average). Distance: history on a log scale (a step
    of x1.5 counts 1), noise in steps of 5 points, momentum in steps of 0.3, and 1 for a
    seasonality mismatch when the client's is known.
    """
    best, best_d = None, math.inf
    for r in (receipt.get("results") or {}).get("change") or []:
        c = r.get("cell") or {}
        if not _plain_null(c) or not r.get("n"):
            continue
        d = (abs(math.log(max(months, 1) / float(c["months"]))) / math.log(1.5)
             + abs(float(cv) - float(c["cv"])) / 0.05 + abs(float(phi) - float(c["phi"])) / 0.3
             + (1.0 if seasonal is not None and bool(seasonal) != bool(c.get("seasonal")) else 0.0))
        if d < best_d - 1e-12:
            best, best_d = r, d
    return best


def conditional_rate_sentence(receipt: Optional[Dict[str, Any]], months: int, cv: float,
                              phi: float, seasonal: Optional[bool] = None,
                              expected_snapshot: Optional[str] = None) -> Optional[str]:
    """
    The design §1.5 sentence, from a benchmark receipt: the measured false-confirm rate in
    the simulated no-change cell nearest the client's series, and in the hardest gated
    no-change condition. None when there is no receipt, when `expected_snapshot` is given and
    the receipt measured other decision code (a stale receipt is never quoted), or when no
    cell matches. A rate, stated with its conditions; never "the chance a confirmation is right".
    """
    if not receipt:
        return None
    if expected_snapshot is not None:
        got = str(((receipt.get("decision_code_snapshot") or {}).get("id")) or "")
        if not got or not (got.startswith(expected_snapshot) or expected_snapshot.startswith(got)):
            return None
    r = matched_cell(receipt, months, cv, phi, seasonal)
    if r is None:
        return None
    c = r["cell"]
    k, n = int(r["k_confirm"]), int(r["n"])
    up = clopper_pearson(k, n)[1]
    gated = [x for x in (receipt.get("results") or {}).get("change") or []
             if (x.get("cell") or {}).get("gated") and (x.get("cell") or {}).get("role") == "null"
             and x.get("n")]

    def key_rate(x: Dict[str, Any]) -> Tuple[int, int]:
        kk = x.get("run_level_k") if (x.get("cell") or {}).get("n_null_measures") else x.get("k_confirm")
        return int(kk or 0), int(x["n"])

    worst = max(gated, key=lambda x: key_rate(x)[0] / float(key_rate(x)[1])) if gated else None
    text = ("When nothing had changed, in simulated series like yours (%s, month-to-month noise "
            "about %d%%, momentum %.1f%s), this engine said confirmed %s of the time (%s of %s "
            "series; upper 95%% bound %s)."
            % ("%d months" % int(c["months"]), int(round(100 * float(c["cv"]))), float(c["phi"]),
               ", seasonal" if c.get("seasonal") else "", _rate_text(k, n), "{:,}".format(k),
               "{:,}".format(n), _rate_text(int(round(up * 1e6)), 1000000)))
    if worst is not None:
        wk, wn = key_rate(worst)
        text += (" In the hardest condition we simulated (%s), it was %s."
                 % (describe_cell(worst["cell"]), _rate_text(wk, wn)))
    text += (" This is how often a no-change series was called confirmed, not the chance that "
             "a confirmed change is real.")
    return text


def environment() -> Dict[str, Any]:
    import platform
    import sys
    return {"python": platform.python_version(), "implementation": platform.python_implementation(),
            "numpy": np.__version__, "pandas": pd.__version__, "sqlite": sqlite3.sqlite_version,
            "platform": platform.platform(), "machine": platform.machine(),
            "pyodide": "pyodide" in sys.modules}


__all__ = [
    "SPEC", "THRESHOLDS", "SIZES", "POWER_FLOORS", "ChangeCell", "ForecastCell",
    "change_grid", "forecast_grid", "cell_by_name", "reps_for", "month_shock_cell",
    "run_change_rep", "run_change_cell", "run_cells", "summarise_change", "run_forecast_rep",
    "run_forecast_cell", "summarise_forecast", "judge_null_quick", "judge_nulls_certify",
    "judge_power", "judge_forecast", "judge_fdr", "binom_cdf", "binom_sf", "wilson", "clopper_pearson",
    "holm", "exceeds", "below_pvalue", "engine_snapshots", "environment", "count_cell", "arwn_cell",
    "coverage_by_diagnostic", "PHI_HAT_BANDS", "describe_cell", "matched_cell", "conditional_rate_sentence",
]
