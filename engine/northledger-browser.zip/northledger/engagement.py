#!/usr/bin/env python3
"""
One engagement: a client's file from landing, through a human decision on every
personal-data column, to a delivered audit -- and then to deletion.

Why this module exists (review item 2.1, 22 Sep 2026): the intake scanner, the
keyed pseudonyms and the report writer had no caller outside their own tests;
both real audits had skipped intake entirely; the AI analyst could read any
column of a client's data; and the data policy promised a deletion job that did
not exist. The pieces were sound and nothing connected them.

Layout of one engagement folder:
    engagement.json          what happened, when (no data)
    receipt.txt              the landing receipt the client is sent
    secret/redaction.key     the engagement's pseudonymisation key (0600), NEVER beside the data
    work/upload/             our copy of the client's file
    work/data.db             the landed working database + the intake record
    work/run/                the audit's working outputs
    deliverables/            what the client receives

The intake record lives inside the working database, so every engine entry
point can check it: `run_loop` and `run_analysis` refuse a database that did not
come through `land`, or that still has a column awaiting a decision.

Python 3.9 compatible.
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
import os
import shutil
import sqlite3
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set
from urllib.parse import urlparse
from ._sqlite import connect_ro  # noqa: E402

INTAKE_TABLE = "_northledger_intake"
COLUMNS_TABLE = "_northledger_columns"
CONSENT_TABLE = "_northledger_consent"
ENGINE_TABLE_PREFIX = "_northledger"

# pending : a human must decide before anything runs
# coded   : replaced with keyed pseudonyms at intake (or on decision)
# keep    : not personal data; usable everywhere
# withhold: usable by the no-AI audit (counts, shapes), never shown to an AI model
DECISIONS = ("pending", "coded", "keep", "withhold")
LOCAL_HOSTS = ("localhost", "127.0.0.1", "::1")
DEFAULT_RETENTION_DAYS = 14


class NotReady(Exception):
    """Raised instead of running on data that has not been cleared. Never echoes a value."""


def _now() -> _dt.datetime:
    return _dt.datetime.now().replace(microsecond=0)


def _sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


# ------------------------------------------------------------------ the folder
@dataclass
class Engagement:
    root: str

    @property
    def id(self) -> str:
        return os.path.basename(os.path.normpath(self.root))

    @property
    def db_path(self) -> str:
        return os.path.join(self.root, "work", "data.db")

    @property
    def key_path(self) -> str:
        return os.path.join(self.root, "secret", "redaction.key")

    @property
    def upload_dir(self) -> str:
        return os.path.join(self.root, "work", "upload")

    @property
    def run_dir(self) -> str:
        return os.path.join(self.root, "work", "run")

    @property
    def deliverables_dir(self) -> str:
        return os.path.join(self.root, "deliverables")

    @property
    def meta_path(self) -> str:
        return os.path.join(self.root, "engagement.json")

    def meta(self) -> Dict[str, Any]:
        return json.load(open(self.meta_path))

    def save_meta(self, meta: Dict[str, Any]) -> None:
        tmp = self.meta_path + ".tmp"
        with open(tmp, "w") as fh:
            json.dump(meta, fh, indent=1)
        os.replace(tmp, self.meta_path)


def open_engagement(root: str, create: bool = False,
                    retention_days: int = DEFAULT_RETENTION_DAYS) -> Engagement:
    eng = Engagement(os.path.abspath(root))
    if create:
        for d in (eng.upload_dir, eng.run_dir, eng.deliverables_dir):
            os.makedirs(d, exist_ok=True)
        os.makedirs(os.path.dirname(eng.key_path), mode=0o700, exist_ok=True)
        os.chmod(os.path.dirname(eng.key_path), 0o700)
        if not os.path.exists(eng.meta_path):
            eng.save_meta({"id": eng.id, "created_at": _now().isoformat(), "landings": [],
                           "delivered_at": None, "retention_days": retention_days, "consent": []})
    elif not os.path.exists(eng.meta_path):
        raise FileNotFoundError("no engagement at %s (create it with create=True)" % root)
    return eng


def _load_or_create_key(eng: Engagement) -> bytes:
    if os.path.exists(eng.key_path):
        return open(eng.key_path, "rb").read()
    key = os.urandom(32)
    fd = os.open(eng.key_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "wb") as fh:
        fh.write(key)
    os.chmod(eng.key_path, 0o600)
    return key


# ------------------------------------------------------------------ the intake record
def _ensure_tables(con: sqlite3.Connection) -> None:
    con.execute("CREATE TABLE IF NOT EXISTS %s (table_name TEXT, source_file TEXT, "
                "source_sha256 TEXT, rows INTEGER, cols INTEGER, landed_at TEXT, "
                "public_data INTEGER)" % INTAKE_TABLE)
    con.execute("CREATE TABLE IF NOT EXISTS %s (table_name TEXT, column_name TEXT, kinds TEXT, "
                "flagged_by TEXT, decision TEXT, decided_at TEXT, note TEXT)" % COLUMNS_TABLE)
    con.execute("CREATE TABLE IF NOT EXISTS %s (provider TEXT, model TEXT, base_url TEXT, "
                "host TEXT, recorded_at TEXT)" % CONSENT_TABLE)


def land(eng: Engagement, file_path: str, allow_public_data: bool = False) -> Any:
    """
    Copy the client's file into the engagement, land it with the engagement's key,
    and record what was found and what still needs a human decision.
    """
    from .intake import land_file

    os.makedirs(eng.upload_dir, exist_ok=True)
    copy = os.path.join(eng.upload_dir, os.path.basename(file_path))
    shutil.copy2(file_path, copy)
    key = _load_or_create_key(eng)
    res = land_file(copy, eng.db_path, redact_key=key)

    coded = list(res.redacted_columns)
    review = list(getattr(res, "review_columns", None) or [])
    if not review:     # an intake without review_columns: name-flagged, uncoded columns
        review = sorted({p.column for p in res.pii
                         if p.via == "column_name" and p.column not in coded})
    kinds: Dict[str, Set[str]] = {}
    via: Dict[str, Set[str]] = {}
    for p in res.pii:
        kinds.setdefault(p.column, set()).add(p.kind)
        via.setdefault(p.column, set()).add(p.via)

    now = _now().isoformat()
    con = sqlite3.connect(eng.db_path)
    try:
        _ensure_tables(con)
        con.execute("INSERT INTO %s VALUES (?,?,?,?,?,?,?)" % INTAKE_TABLE,
                    (res.table, os.path.basename(file_path), res.sha256, res.n_rows, res.n_cols,
                     now, 1 if allow_public_data else 0))
        for col in coded:
            con.execute("INSERT INTO %s VALUES (?,?,?,?,?,?,?)" % COLUMNS_TABLE,
                        (res.table, col, ",".join(sorted(kinds.get(col, ()))),
                         ",".join(sorted(via.get(col, ()))), "coded", now, "coded at intake"))
        for col in review:
            if col in coded:
                continue
            decision = "keep" if allow_public_data else "pending"
            con.execute("INSERT INTO %s VALUES (?,?,?,?,?,?,?)" % COLUMNS_TABLE,
                        (res.table, col, ",".join(sorted(kinds.get(col, ()))),
                         ",".join(sorted(via.get(col, ()))), decision,
                         now if decision != "pending" else None,
                         "public data" if allow_public_data else "awaiting a decision"))
        con.commit()
    finally:
        con.close()

    pending = [c for c in review if c not in coded] if not allow_public_data else []
    summary = res.client_summary()
    lines = [summary]
    if pending:
        # The intake summary already lists these columns and why; add only the choice,
        # rather than asking a second time.
        if "awaiting your decision" not in summary.lower():
            lines.append("Awaiting your decision before analysis: %s." % ", ".join(pending))
        lines.append("For each of these, tell us which you want: code it, keep it for counting only "
                     "(never shown to an AI model), or keep it as it is.")
    with open(os.path.join(eng.root, "receipt.txt"), "a") as fh:
        fh.write("\n".join(lines) + "\n\n")

    meta = eng.meta()
    meta["landings"].append({"file": os.path.basename(file_path),
                             "original_path": os.path.abspath(file_path),
                             "sha256": res.sha256, "table": res.table,
                             "landed_at": now, "public_data": bool(allow_public_data)})
    eng.save_meta(meta)
    return res


def landing_stamp(meta: Dict[str, Any], table: str) -> Optional[Dict[str, Any]]:
    """The latest landing of `table`: which file, its sha256, when, and its position."""
    for i in range(len(meta.get("landings", [])) - 1, -1, -1):
        l = meta["landings"][i]
        if l.get("table") == table:
            return {"file": l.get("file"), "sha256": l.get("sha256"),
                    "landed_at": l.get("landed_at"), "index": i}
    return None


def decide(eng: Engagement, column: str, decision: str, table: Optional[str] = None,
           note: str = "") -> None:
    """Record a human decision on a flagged column. 'code' pseudonymises it now."""
    if decision not in ("keep", "withhold", "code"):
        raise ValueError("decision must be keep, withhold or code")
    con = sqlite3.connect(eng.db_path)
    try:
        _ensure_tables(con)
        rows = con.execute("SELECT table_name, kinds FROM %s WHERE column_name = ?%s"
                           % (COLUMNS_TABLE, " AND table_name = ?" if table else ""),
                           (column, table) if table else (column,)).fetchall()
        if not rows:
            raise ValueError("column %r was not flagged at intake" % column)
        for tname, kinds in rows:
            if decision == "code":
                _code_column_in_place(con, eng, tname, column, (kinds or "").split(",")[0])
            con.execute("UPDATE %s SET decision = ?, decided_at = ?, note = ? "
                        "WHERE table_name = ? AND column_name = ?" % COLUMNS_TABLE,
                        ("coded" if decision == "code" else decision, _now().isoformat(),
                         note or "decided by the consultant", tname, column))
        con.commit()
    finally:
        con.close()


def _code_column_in_place(con, eng, table, column, kind) -> None:
    import pandas as pd
    from .intake import redact_columns
    key = _load_or_create_key(eng)
    qt, qc = '"%s"' % table.replace('"', '""'), '"%s"' % column.replace('"', '""')
    values = [r[0] for r in con.execute("SELECT DISTINCT %s FROM %s WHERE %s IS NOT NULL"
                                        % (qc, qt, qc))]
    if not values:
        return
    coded = redact_columns(pd.DataFrame({column: values}), [column], key=key,
                           kinds={column: kind} if kind else None)[column]
    con.executemany("UPDATE %s SET %s = ? WHERE %s = ?" % (qt, qc, qc),
                    list(zip(coded.tolist(), values)))


def record_consent(eng: Engagement, provider: str, model: str, base_url: str) -> None:
    """Record the client's consent to send query results to a named third-party AI service."""
    host = urlparse(base_url).hostname or ""
    now = _now().isoformat()
    con = sqlite3.connect(eng.db_path)
    try:
        _ensure_tables(con)
        con.execute("INSERT INTO %s VALUES (?,?,?,?,?)" % CONSENT_TABLE,
                    (provider, model, base_url, host, now))
        con.commit()
    finally:
        con.close()
    meta = eng.meta()
    meta.setdefault("consent", []).append({"provider": provider, "model": model,
                                           "host": host, "recorded_at": now})
    eng.save_meta(meta)


# ------------------------------------------------------------------ readiness
@dataclass
class IntakeState:
    has_record: bool = False
    public: bool = False
    pending: List[str] = field(default_factory=list)
    withheld: Dict[str, Set[str]] = field(default_factory=dict)
    consent_hosts: Set[str] = field(default_factory=set)


def intake_state(db_path: str) -> IntakeState:
    st = IntakeState()
    con = connect_ro(db_path)
    try:
        names = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if INTAKE_TABLE not in names:
            return st
        st.has_record = True
        pub = [r[0] for r in con.execute("SELECT public_data FROM %s" % INTAKE_TABLE)]
        st.public = bool(pub) and all(pub)
        if COLUMNS_TABLE in names:
            for t, c, d in con.execute("SELECT table_name, column_name, decision FROM %s"
                                       % COLUMNS_TABLE):
                if d == "pending":
                    st.pending.append("%s.%s" % (t, c))
                if d in ("pending", "withhold"):
                    st.withheld.setdefault(t, set()).add(c)
        if CONSENT_TABLE in names:
            st.consent_hosts = {r[0] for r in con.execute("SELECT host FROM %s" % CONSENT_TABLE)}
    finally:
        con.close()
    return st


def is_local(base_url: Optional[str]) -> bool:
    return bool(base_url) and (urlparse(base_url).hostname or "") in LOCAL_HOSTS


def check_ready(db_path: str, allow_public_data: bool = False, for_ai: bool = False,
                base_url: Optional[str] = None) -> IntakeState:
    """
    Refuse to run on data that has not been cleared. Called by run_loop and
    run_analysis themselves, so no caller can skip it by not using the CLI.
    """
    st = intake_state(db_path)
    if not st.has_record:
        if allow_public_data:
            return st
        raise NotReady(
            "%s has no intake record, so it did not come through landing (which scans for and "
            "codes personal data). Land the client's file first with `python -m northledger "
            "land`, or pass allow_public_data=True for public open data."
            % os.path.basename(db_path))
    if st.pending:
        raise NotReady(
            "Waiting for a decision on %d column(s) flagged at intake: %s. Decide each with "
            "`python -m northledger decide` (keep, withhold or code) before running anything."
            % (len(st.pending), ", ".join(st.pending)))
    if for_ai and not allow_public_data and not st.public and not is_local(base_url):
        host = urlparse(base_url).hostname if base_url else "an unidentified AI service"
        if host not in st.consent_hosts:
            raise NotReady(
                "This would send query results, which can include rows of the client's data, to "
                "%s, a third-party AI service, and there is no recorded client consent for it. "
                "Record consent first with `python -m northledger consent`, or run the no-AI "
                "audit instead." % host)
    return st


# ------------------------------------------------------------------ the audit
@dataclass
class AuditOutput:
    summary: str
    deliverables: Dict[str, str]
    run_dir: str
    brief: Any = None
    gated: Any = None


def run_audit(eng: Engagement, objective: str, table: Optional[str] = None) -> AuditOutput:
    """The no-AI Data Health Audit: profile, clean, gate, narrate, deliver."""
    from . import report
    from .loop import run_loop

    check_ready(eng.db_path)
    meta = eng.meta()
    if not table:
        if not meta.get("landings"):
            raise NotReady("nothing has been landed in this engagement yet")
        table = meta["landings"][-1]["table"]
    source = next((l["file"] for l in reversed(meta.get("landings", [])) if l["table"] == table), table)
    # The audit's own date, recorded so a later export cleans the rows exactly as it did.
    as_of = _now().date().isoformat()
    r = run_loop(eng.db_path, table, objective, out_dir=eng.run_dir, display_name=source,
                 as_of=as_of)
    made = report.deliverables(r.brief, r.gated, eng.deliverables_dir, stem="data-health-audit",
                               title="Data Health Audit - %s" % source, full_brief=r.full_brief)
    meta = eng.meta()
    meta["delivered_at"] = _now().isoformat()
    meta.setdefault("audits", []).append({"table": table, "at": meta["delivered_at"],
                                          "as_of": as_of, "summary": r.summary()})
    eng.save_meta(meta)
    return AuditOutput(summary=r.summary(), deliverables=made, run_dir=eng.run_dir,
                       brief=r.brief, gated=r.gated)


# ------------------------------------------------------------------ deletion
def purge(engagements_dir: str, now: Optional[_dt.datetime] = None,
          retention_days: Optional[int] = None, engagement_id: Optional[str] = None,
          force: bool = False) -> List[Dict[str, Any]]:
    """
    Delete every engagement whose report was delivered more than the retention
    period ago (or one named engagement, with force=True), and append a receipt
    to engagements_dir/deletion-receipts.jsonl. Receipts hold file names, the
    source files' hashes and dates -- never data. The client's ORIGINAL file,
    wherever it came from, is not ours to delete; the receipt says if it still
    exists so the consultant can deal with it.
    """
    now = now or _now()
    out: List[Dict[str, Any]] = []
    if not os.path.isdir(engagements_dir):
        return out
    receipts = os.path.join(engagements_dir, "deletion-receipts.jsonl")
    for name in sorted(os.listdir(engagements_dir)):
        path = os.path.join(engagements_dir, name)
        meta_path = os.path.join(path, "engagement.json")
        if not (os.path.isdir(path) and os.path.exists(meta_path)):
            continue
        if engagement_id and name != engagement_id:
            continue
        meta = json.load(open(meta_path))
        days = retention_days if retention_days is not None else meta.get(
            "retention_days", DEFAULT_RETENTION_DAYS)
        delivered = meta.get("delivered_at")
        due_by_time = bool(delivered) and now >= _dt.datetime.fromisoformat(delivered) + \
            _dt.timedelta(days=days)
        if not (force or due_by_time):
            continue
        files = []
        for d, _, fs in os.walk(path):
            for f in fs:
                files.append(os.path.relpath(os.path.join(d, f), path))
        originals = []
        for l in meta.get("landings", []):
            op = l.get("original_path") or ""
            if op and os.path.exists(op) and not os.path.abspath(op).startswith(os.path.abspath(path)):
                originals.append(os.path.basename(op))
        shutil.rmtree(path)
        receipt = {
            "engagement": name,
            "deleted_at": now.isoformat(),
            "reason": "requested" if force else "retention period of %d days ended" % days,
            "delivered_at": delivered,
            "files_deleted": sorted(files),
            "sources": [{"file": l.get("file"), "sha256": l.get("sha256")}
                        for l in meta.get("landings", [])],
            "originals_still_present": sorted(set(originals)),
        }
        with open(receipts, "a") as fh:
            fh.write(json.dumps(receipt) + "\n")
        out.append(receipt)
    return out
