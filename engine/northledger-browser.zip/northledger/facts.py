#!/usr/bin/env python3
"""
The evidence contract for the NorthLedger Insight Loop.

Central idea: the agent NEVER writes prose while it has access to raw data.
It accumulates typed `Fact` objects, each carrying the exact query that produced
it. The narrative (stage 8) is generated from the gated fact set alone. A model
that cannot reach the data at writing time cannot invent a number.

Everything downstream -- the gate, the narrator, the evaluation harness, the
client-facing evidence ledger -- speaks this contract.

Python 3.9 compatible.
"""
from __future__ import annotations

import csv
import json
import os
import sqlite3
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional
from ._sqlite import connect_ro  # noqa: E402

VERDICTS = ("RECOMMEND", "WATCH", "INSUFFICIENT")
# "sql"/"python": re-runnable against the data.
# "computed":      produced by module code, formula in `query`, not a function of other Facts.
# "derived":       a function of OTHER FACTS -- records the operation and input ids, and is
#                  re-checked arithmetically by EvidenceLedger.verify.
# "external":      came from outside the client's data; may explain a number, never be one.
# "model":         produced by a fitted model (a forecast, a change test). `query` is a
#                  JSON payload naming the series SQL, the model, its configuration and seed;
#                  EvidenceLedger.verify refits it and must land on the same number.
QUERY_KINDS = ("sql", "python", "computed", "derived", "external", "model")
DERIVATIONS = ("sum", "difference", "ratio", "share_pct", "product", "mean")

# A measured condition ("488 rows are exact duplicates") is not a trend and has
# no baseline to move against. Judging it with trend criteria produced the
# client-facing nonsense "the difference is 0% where we want at least 5%" on
# every audit finding. For a state fact, effect_size carries MATERIALITY --
# the share of the table the condition affects.
FACT_KINDS = ("state", "trend", "forecast")


@dataclass
class Fact:
    """One measured claim. Produced in stage 4; never written freehand by an LLM."""

    id: str
    claim: str                       # "P90 resolution time for HPD is 41.8 days"
    value: float
    unit: str                        # "days" | "pct" | "count" | "CAD" | "ratio"
    query: str                       # the exact, re-runnable SQL or Python
    source_table: str = ""
    query_kind: str = "sql"          # one of QUERY_KINDS
    rows_scanned: int = 0

    # --- signals the confidence gate reads -------------------------------
    effect_size: float = 0.0         # magnitude vs the series' own baseline
    periods_observed: int = 0        # how many time buckets the pattern held
    data_health: float = 100.0       # 0-100 score of the source table (stage 1)
    p_value: Optional[float] = None  # None when no test applies
    confounders: List[str] = field(default_factory=list)
    caveats: List[str] = field(default_factory=list)

    # --- provenance -------------------------------------------------------
    computed_at: str = ""            # ISO8601; stamped by FactSet.add
    verified: Optional[bool] = None  # set by EvidenceLedger.verify
    verified_value: Optional[float] = None

    # --- derivation -------------------------------------------------------
    # A number the agent worked out from other numbers (a total, a share, a gap)
    # is still a claim, and in the September 2026 audit it was the ONLY place a
    # wrong number survived: 92/92 queries reproduced, but one total had been
    # added up inside prose and was off by 1,000. Recording the operation and its
    # inputs makes the arithmetic re-checkable instead of merely plausible.
    derivation: str = ""             # one of DERIVATIONS
    derived_from: List[str] = field(default_factory=list)   # input fact ids

    # "trend" by default so existing callers keep their semantics.
    fact_kind: str = "trend"

    # "headline" facts are findings; "detail" facts are breakdowns that support a
    # headline. Both are evidence and both go in the ledger, but only headlines
    # are narrated -- the first live run stated one problem three times (a total
    # and its two parts as separate findings).
    role: str = "headline"

    # What the number is ABOUT. "business": a claim about the client's operations,
    # drawn from their data -- vetoed when that data is too broken to trust.
    # "data_quality": a measurement of the data's own defects, produced by the
    # engine's profiler or cleaner. Vetoing that on the ground that the table is
    # broken would hide the very finding. Only engine code sets "data_quality";
    # the analyst's tools do not expose it, so a model cannot use it to slip a
    # business claim past the veto.
    measures: str = "business"

    # "zero": any occurrence is a defect (duplicate rows, one ID on two different
    # records). Materiality thresholds do not apply -- 20 reused delivery IDs can be
    # 20 double-billed customers. Set only by engine code.
    tolerance: str = ""

    # --- the change test (R1, design §2.1 M1-M4, M9) ----------------------
    # Set by measure.measure_facts on a change claim; every field defaults to "absent", so a
    # fact built without them keeps the pre-R1 meaning (p_value is then whatever chance
    # figure its producer recorded, judged against GatePolicy.max_p_value).
    # On a change claim `p_value` is the one-sided MINIMUM-EFFECT p ("the change is at least
    # `min_effect`"), the decision number; `p_nonzero` is the two-sided point-null p.
    p_nonzero: Optional[float] = None
    min_effect: Optional[float] = None      # the materiality bar the test asked about (fraction)
    # the effect interval from inverting the same test, on effect_size's scale (0.20 = +20%)
    effect_ci_low: Optional[float] = None
    effect_ci_high: Optional[float] = None
    effect_ci_level: Optional[float] = None
    effect_ci_method: str = ""
    # for a CONFIRMED claim, the interval adjusted for selection (false coverage rate,
    # Benjamini-Yekutieli 2005, level 1 - R*q/m); set by the gate's family pass
    effect_ci_adj_low: Optional[float] = None
    effect_ci_adj_high: Optional[float] = None
    effect_ci_adj_level: Optional[float] = None
    # the minimum health over the columns the claim reads (M9); None when not measured
    claim_health: Optional[float] = None
    # why the drift screen holds this claim (a wandering or steadily trending series), or ""
    trend_screen: str = ""
    # what the claim is about ("volume", or the measure's column): the gate's primary-metric key
    claim_key: str = ""
    # the change test's summary (model, momentum, bootstrap size, Monte Carlo interval,
    # interval table); the full recipe is in the payload of the claim's ".p" fact
    test: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.query_kind not in QUERY_KINDS:
            raise ValueError(
                "query_kind must be one of %s, got %r" % (QUERY_KINDS, self.query_kind)
            )
        if not self.claim.strip():
            raise ValueError("a Fact must carry a human-readable claim")
        if self.query_kind in ("sql", "python", "model") and not self.query.strip():
            raise ValueError(
                "fact %r is %s-derived but carries no query; every number needs "
                "a re-runnable source" % (self.id, self.query_kind)
            )
        if not (0.0 <= self.data_health <= 100.0):
            raise ValueError("data_health must be 0-100, got %r" % (self.data_health,))
        if self.tolerance not in ("", "zero"):
            raise ValueError("tolerance must be '' or 'zero', got %r" % (self.tolerance,))
        if self.measures not in ("business", "data_quality"):
            raise ValueError("measures must be 'business' or 'data_quality', got %r" % (self.measures,))
        if self.role not in ("headline", "detail"):
            raise ValueError("role must be 'headline' or 'detail', got %r" % (self.role,))
        if self.fact_kind not in FACT_KINDS:
            raise ValueError("fact_kind must be one of %s, got %r" % (FACT_KINDS, self.fact_kind))
        if self.derivation and self.derivation not in DERIVATIONS:
            raise ValueError(
                "derivation must be one of %s, got %r" % (DERIVATIONS, self.derivation)
            )
        if self.derivation and not self.derived_from:
            raise ValueError(
                "fact %r claims to be derived but names no input facts; an unrecorded "
                "calculation is exactly the failure this field exists to prevent" % (self.id,)
            )
        if self.claim_health is not None and not (0.0 <= float(self.claim_health) <= 100.0):
            raise ValueError("claim_health must be 0-100, got %r" % (self.claim_health,))
        if self.query_kind == "derived" and not self.derivation:
            raise ValueError("fact %r is query_kind='derived' but records no operation" % (self.id,))

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class GateResult:
    """Stage 7 output. `reason` is shown to the client verbatim."""

    verdict: str
    reason: str
    needed_to_upgrade: str = ""
    signals: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.verdict not in VERDICTS:
            raise ValueError("verdict must be one of %s, got %r" % (VERDICTS, self.verdict))

    @property
    def actionable(self) -> bool:
        return self.verdict == "RECOMMEND"


@dataclass
class GatedFact:
    """A fact bound to its verdict. The ONLY thing the narrator is allowed to read."""

    fact: Fact
    gate: GateResult

    def to_dict(self) -> Dict[str, Any]:
        d = self.fact.to_dict()
        d["verdict"] = self.gate.verdict
        d["gate_reason"] = self.gate.reason
        d["needed_to_upgrade"] = self.gate.needed_to_upgrade
        return d



def compute_derivation(op: str, values: List[float]) -> float:
    """The one place derived arithmetic happens. Callers pass inputs, never a result."""
    if not values:
        raise ValueError("derivation %r needs at least one input value" % (op,))
    if op == "sum":
        return float(sum(values))
    if op == "mean":
        return float(sum(values)) / len(values)
    if op == "product":
        out = 1.0
        for v in values:
            out *= float(v)
        return out
    if op == "difference":
        if len(values) != 2:
            raise ValueError("difference needs exactly 2 inputs, got %d" % len(values))
        return float(values[0]) - float(values[1])
    if op in ("ratio", "share_pct"):
        if len(values) != 2:
            raise ValueError("%s needs exactly 2 inputs, got %d" % (op, len(values)))
        denom = float(values[1])
        if denom == 0:
            raise ValueError("%s has a zero denominator" % (op,))
        r = float(values[0]) / denom
        return r * 100.0 if op == "share_pct" else r
    raise ValueError("unknown derivation %r" % (op,))


def derive(
    fact_set: "FactSet",
    id: str,
    claim: str,
    unit: str,
    op: str,
    input_ids: List[str],
    caveats: Optional[List[str]] = None,
) -> Fact:
    """
    Build a derived Fact by ACTUALLY COMPUTING it from facts already in the set.

    There is deliberately no `value` parameter. A caller cannot assert a total --
    it can only name the inputs and the operation, and the arithmetic is done here.
    That is the structural fix for the one defect the September 2026 audit found.
    """
    inputs = []
    for fid in input_ids:
        f = fact_set.by_id(fid)
        if f is None:
            raise ValueError(
                "derived fact %r names input %r which is not in the fact set" % (id, fid)
            )
        inputs.append(f)

    value = compute_derivation(op, [f.value for f in inputs])
    rows = max([f.rows_scanned for f in inputs] or [0])
    worst_health = min([f.data_health for f in inputs] or [100.0])
    def _exact(v):
        # The audit trail must be exact: %g turned 1672577 into 1.67258e+06.
        return str(int(v)) if float(v).is_integer() else repr(float(v))

    expr = "%s(%s)" % (op, ", ".join("%s=%s" % (f.id, _exact(f.value)) for f in inputs))

    return fact_set.add(Fact(
        id=id, claim=claim, value=value, unit=unit,
        query=expr, query_kind="derived", derivation=op, derived_from=list(input_ids),
        rows_scanned=rows, data_health=worst_health,
        source_table=inputs[0].source_table if inputs else "",
        caveats=list(caveats or []),
    ))

class FactSet:
    """Accumulator used during stage 4. Enforces unique ids and stamps provenance."""

    def __init__(self, run_id: str = "", now_iso: str = "") -> None:
        self.run_id = run_id
        self._now = now_iso
        self._facts: List[Fact] = []
        self._ids = set()

    def add(self, fact: Fact) -> Fact:
        if fact.id in self._ids:
            raise ValueError("duplicate fact id %r" % (fact.id,))
        if not fact.computed_at:
            fact.computed_at = self._now
        self._ids.add(fact.id)
        self._facts.append(fact)
        return fact

    def __len__(self) -> int:
        return len(self._facts)

    def __iter__(self):
        return iter(self._facts)

    @property
    def facts(self) -> List[Fact]:
        return list(self._facts)

    def by_id(self, fact_id: str) -> Optional[Fact]:
        for f in self._facts:
            if f.id == fact_id:
                return f
        return None


def recompute_model(query: str, con: Any) -> float:
    """
    Re-derive a query_kind='model' fact from its payload. Dispatches on the payload's
    "kind"; imports lazily because the model modules import this one.
    """
    payload = json.loads(query)
    kind = payload.get("kind") if isinstance(payload, dict) else None
    if kind == "northledger.forecast/1":
        from . import forecast
        return forecast.recompute(payload, con)
    if kind in ("northledger.permutation/1", "northledger.trend_test/1"):
        from . import measure
        return measure.recompute(payload, con)
    if kind == "northledger.benchmark_receipt/1":
        from . import gate
        return gate.recompute_receipt_fact(payload)
    raise ValueError("unknown model payload kind %r" % (kind,))


class EvidenceLedger:
    """
    The client-facing audit trail, and the mechanism behind the false-claim metric.

    `verify` re-runs every SQL-derived fact's query against the database and
    compares the result to the stated value. A fact whose query no longer
    reproduces its number is the definition of a false claim -- whether the model
    hallucinated it or the data moved underneath it.
    """

    def __init__(self, gated: List[GatedFact]) -> None:
        self.gated = list(gated)

    # -- verification -------------------------------------------------------
    def verify(self, db_path: str, tolerance: float = 1e-6) -> Dict[str, Any]:
        checked = reproduced = failed = skipped = 0
        failures: List[Dict[str, Any]] = []

        # A refit cache must never outlive one verification: the data may have moved.
        import sys as _sys
        _fc = _sys.modules.get(__package__ + ".forecast")
        if _fc is not None:
            _fc.clear_cache()
        _ms = _sys.modules.get(__package__ + ".measure")
        if _ms is not None and hasattr(_ms, "clear_cache"):
            _ms.clear_cache()
        con = connect_ro(db_path)
        try:
            by_id = {gf.fact.id: gf.fact for gf in self.gated}
            # SQL facts first, derived facts after: a derived fact is only as good as
            # its inputs, so their verdicts must exist before it is judged.
            order = sorted(self.gated, key=lambda g: 1 if g.fact.query_kind == "derived" else 0)
            for gf in order:
                f = gf.fact
                if f.query_kind == "derived":
                    bad = [i for i in f.derived_from if i in by_id and by_id[i].verified is False]
                    if bad:
                        checked += 1
                        f.verified = False
                        failed += 1
                        failures.append({"id": f.id, "claim": f.claim,
                                         "error": "input(s) did not reproduce: %s" % ", ".join(bad)})
                        continue
                    # Re-do the arithmetic from the recorded inputs. This is the check
                    # that would have caught the 2,564,854 total in the Sept 2026 audit.
                    checked += 1
                    try:
                        vals = [by_id[i].value for i in f.derived_from]
                    except KeyError as missing:
                        f.verified = False
                        failed += 1
                        failures.append({"id": f.id, "claim": f.claim,
                                         "error": "input fact %s is missing" % missing})
                        continue
                    try:
                        recomputed = compute_derivation(f.derivation, vals)
                    except ValueError as exc:
                        f.verified = False
                        failed += 1
                        failures.append({"id": f.id, "claim": f.claim, "error": str(exc)[:200]})
                        continue
                    f.verified_value = recomputed
                    denom = max(abs(f.value), 1.0)
                    ok = abs(recomputed - f.value) / denom <= max(tolerance, 1e-9)
                    f.verified = ok
                    if ok:
                        reproduced += 1
                    else:
                        failed += 1
                        failures.append({"id": f.id, "claim": f.claim,
                                         "stated": f.value, "recomputed": recomputed})
                    continue
                if f.query_kind == "model":
                    # A fitted number: refit from the recorded payload and compare.
                    checked += 1
                    try:
                        got = float(recompute_model(f.query, con))
                    except Exception as exc:  # noqa: BLE001 - a refit that fails IS the finding
                        f.verified = False
                        failed += 1
                        failures.append({"id": f.id, "claim": f.claim,
                                         "error": "refit failed: %s" % str(exc)[:200]})
                        continue
                    f.verified_value = got
                    if got != got or f.value != f.value:      # NaN never reproduces
                        ok = False
                    else:
                        denom = max(abs(f.value), 1.0)
                        ok = abs(got - f.value) / denom <= max(tolerance, 1e-9)
                    f.verified = ok
                    if ok:
                        reproduced += 1
                    else:
                        failed += 1
                        failures.append({"id": f.id, "claim": f.claim, "stated": f.value,
                                         "refit": got})
                    continue
                if f.query_kind != "sql":
                    skipped += 1
                    continue
                checked += 1
                try:
                    cur = con.execute(f.query)
                    row = cur.fetchone()
                    got = None if row is None else row[0]
                    got = float(got) if got is not None else None
                except Exception as exc:  # noqa: BLE001 - a broken query IS the finding
                    f.verified = False
                    failed += 1
                    failures.append({"id": f.id, "claim": f.claim, "error": str(exc)[:200]})
                    continue

                f.verified_value = got
                if got is None:
                    ok = False
                else:
                    denom = max(abs(f.value), 1.0)
                    ok = abs(got - f.value) / denom <= max(tolerance, 1e-9)
                f.verified = ok
                if ok:
                    reproduced += 1
                else:
                    failed += 1
                    failures.append(
                        {"id": f.id, "claim": f.claim, "stated": f.value, "reproduced": got}
                    )
        finally:
            con.close()

        # With nothing re-run there is no rate -- reporting 0.0 would read as "perfect".
        # Named honestly: this is the share of figures whose own query, re-run on the
        # same data, gave a different number. It cannot catch a query that answers the
        # wrong question; "false_claim_rate" is kept only as a compatibility alias.
        rate = round(failed / checked, 4) if checked else None
        return {
            "checked": checked,
            "reproduced": reproduced,
            "failed": failed,
            "skipped_unverifiable": skipped,
            "unreproduced_rate": rate,
            "false_claim_rate": rate,
            "failures": failures,
        }

    # -- export -------------------------------------------------------------
    FIELDS = [
        "id", "verdict", "claim", "value", "unit", "source_table", "rows_scanned",
        "effect_size", "periods_observed", "data_health", "p_value",
        "confounders", "caveats", "gate_reason", "needed_to_upgrade",
        "computed_at", "verified", "verified_value", "role", "fact_kind", "measures", "tolerance", "query",
        "p_nonzero", "min_effect", "effect_ci_low", "effect_ci_high", "effect_ci_level",
        "effect_ci_adj_low", "effect_ci_adj_high", "effect_ci_adj_level", "claim_health",
        "trend_screen",
    ]

    def to_csv(self, path: str) -> str:
        os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
        with open(path, "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=self.FIELDS, extrasaction="ignore")
            w.writeheader()
            for gf in self.gated:
                row = gf.to_dict()
                row["confounders"] = "; ".join(row.get("confounders") or [])
                row["caveats"] = "; ".join(row.get("caveats") or [])
                w.writerow(row)
        return path

    def to_json(self, path: str) -> str:
        os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump([gf.to_dict() for gf in self.gated], fh, indent=1, default=str)
        return path

    def counts(self) -> Dict[str, int]:
        out = {v: 0 for v in VERDICTS}
        for gf in self.gated:
            out[gf.gate.verdict] += 1
        return out
