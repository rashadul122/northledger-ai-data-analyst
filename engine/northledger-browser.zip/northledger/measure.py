#!/usr/bin/env python3
"""
Business analysis with no AI: what the client's own numbers did.

The audit (health + clean) says whether a file can be trusted. This stage answers the
question the client actually asked -- "what is happening to our volume and ratings?" --
from the roles the profile found:

    date column  -> monthly volume, and the last 12 months against the 12 before
    measures     -> mean and median, and the latest 12 months against the 12 before
    dimensions   -> the top categories' shares of rows

A change claim (R1, design §2.1 M1-M4) has one estimand, one unit and one model: the ratio
of the average month in the latest 12 months to the average month in the 12 before (a month
is the monthly total for volume, the monthly mean for a measure), tested by
stats.trend_test on the monthly values: a model of their logs with seasonal terms and AR(1)
momentum, a parametric bootstrap for the one-sided "at least the materiality bar" p-value,
and the effect interval by inverting that test. Row count is a precision note, never the
sample size: rows in one month share its conditions. The row-weighted gap stays in the
ledger as a labelled descriptive fact.

Every number is a SQL fact over an analysis table this module writes into the same
database (``_northledger_measure_<table>``: the CLEANED rows, typed, with an ISO date and
month). EvidenceLedger.verify re-runs each query. The numbers SQL cannot produce -- the
change test's p-values and interval ends -- are query_kind "model" facts whose payload
holds the monthly series' SQL, the bar, the seed and the bootstrap sizes; verify re-runs
the test.

Conservative by construction:
  * windows end at the last COMPLETE month, and a series-end cliff (a tail of three or
    more months, none recovering above 10% of the previous year's median: typo'd dates
    between the real end of the data and today) is cut, with the rows past the end
    counted as a fact;
  * when the share of rows cleaning set aside differs a lot between months, that is
    attached to every trend as a named confounder, so the gate cannot call it advice.

Python 3.9 compatible. numpy + pandas + stdlib.
"""
from __future__ import annotations

import calendar
import datetime as _dt
import json
import math
import re
import sqlite3
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from . import stats as _stats
from .facts import Fact, FactSet

PERM_KIND = "northledger.permutation/1"
#: The change test's payload kind (design §2.1 M1-M2): see stats.trend_test.
TREND_KIND = _stats.TREND_KIND
#: The materiality bar and the confirmation level the change test is run at, when the caller
#: does not pass the policy's (gate.GatePolicy.min_effect_recommend / recommend_q).
DEFAULT_BAR = 0.05
DEFAULT_Q = 0.01
N_PERM = 9999
SEED = 20260923
TABLE_PREFIX = "_northledger_measure_"
TOP_N = 5
MAX_DIM_LEVELS = 50
UNEVEN_QUARANTINE_PTS = 10.0      # max-min monthly set-aside share, in percentage points
CLIFF_SHARE = 0.10                # a month under 10% of the previous 12 months' median
CLIFF_RUN = 3                     # ... three months in a row, and never recovering


# --------------------------------------------------------------------------- helpers
def qi(name: str) -> str:
    return '"%s"' % str(name).replace('"', '""')


def ql(value: str) -> str:
    return "'%s'" % str(value).replace("'", "''")


def slug(text: str) -> str:
    out = re.sub(r"[^a-z0-9]+", "_", str(text).lower()).strip("_")
    return out or "col"


def _mi(label: str) -> int:
    y, m = str(label)[:7].split("-")
    return int(y) * 12 + int(m) - 1


def _ml(idx: int) -> str:
    return "%04d-%02d" % (idx // 12, idx % 12 + 1)


def _between(a: int, b: int) -> str:
    return "_month BETWEEN %s AND %s" % (ql(_ml(a)), ql(_ml(b)))


def _months_cte(a: int, b: int) -> str:
    vals = ", ".join("(%s)" % ql(_ml(i)) for i in range(a, b + 1))
    return "WITH m(_month) AS (VALUES %s)" % vals


# --------------------------------------------------------------------------- statistics
def permutation_p(a: Sequence[float], b: Sequence[float], n_perm: int = N_PERM,
                  seed: int = SEED) -> float:
    """
    Two-sided permutation test of a difference in means: the share of shuffles of the
    pooled values whose mean gap is at least the observed one, (count + 1) / (n + 1).
    Deterministic for a given seed and input ORDER (callers pass ORDER BY queries).

    Kept for recorded payloads and callers; since R1 no change claim uses it (a row-level
    shuffle treats rows of one month as independent, design M1). Its draws changed in R1 to
    rng.random() only, so a pre-R1 payload re-runs to a slightly different p.
    """
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    if len(a) == 0 or len(b) == 0:
        raise ValueError("a permutation test needs two non-empty samples")
    pool = np.concatenate([a, b])
    n1, n = len(a), len(pool)
    obs = abs(a.mean() - b.mean())
    tol = 1e-12 * max(1.0, float(np.abs(pool).max()))
    total = float(pool.sum())
    rng = np.random.default_rng(int(seed))
    batch = max(1, min(int(n_perm), 2000000 // n))
    count = done = 0
    while done < n_perm:
        k = min(batch, n_perm - done)
        # a uniform random permutation per row from rng.random() alone (NEP 19's stable
        # subset: design M13); argsort of iid uniforms is uniform over permutations
        idx = np.argsort(rng.random((k, n)), axis=1, kind="stable")[:, :n1]
        s1 = pool[idx].sum(axis=1)
        gap = np.abs(s1 / n1 - (total - s1) / (n - n1))
        count += int(np.sum(gap >= obs - tol))
        done += k
    return (count + 1) / float(n_perm + 1)


#: Kept for pre-R1 payloads (method "welch"). Since R1 no change claim runs a row-level test:
#: the month is the unit (design M1), so the change test's cost does not grow with rows.
WELCH_ABOVE = 20000


def welch_p(a: Sequence[float], b: Sequence[float]) -> float:
    """Two-sided p of a difference in means: Welch's t against the normal distribution."""
    import math
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    if len(a) < 2 or len(b) < 2:
        raise ValueError("Welch's test needs at least two values in each sample")
    se = math.sqrt(float(a.var(ddof=1)) / len(a) + float(b.var(ddof=1)) / len(b))
    gap = abs(float(a.mean()) - float(b.mean()))
    if se == 0:
        return 1.0 if gap == 0 else 0.0
    return float(math.erfc(gap / se / math.sqrt(2.0)))


def _column(con: sqlite3.Connection, sql: str) -> List[float]:
    return [float(r[0]) for r in con.execute(sql).fetchall() if r[0] is not None]


_TREND_CACHE: Dict[str, Dict[str, Any]] = {}


def clear_cache() -> None:
    """Forget re-run change tests (EvidenceLedger.verify calls this: the data may have moved)."""
    _TREND_CACHE.clear()
    _stats.clear_cache()


def _series_values(con: sqlite3.Connection, sql: str) -> Tuple[List[int], List[Optional[float]]]:
    rows = con.execute(sql).fetchall()
    return ([_mi(r[0]) for r in rows], [None if r[1] is None else float(r[1]) for r in rows])



def _trend_values(payload: Dict[str, Any], months: Sequence[int],
                  values: Sequence[Optional[float]]) -> Dict[str, Any]:
    """The change test a payload records, on monthly values already read; cached per recipe+values."""
    # keyed by the recipe AND the values read: the same SQL on other data is another test
    key = _trend_key(payload, months, values)
    hit = _TREND_CACHE.get(key)
    if hit is not None:
        return hit
    if "b" in payload:
        # since the R1 review: a fixed B (the analysis extends it only against the line that
        # decides the claim), the interval's B, and the selection-adjusted tails asked for
        res = _stats.trend_test(values, months, _mi(payload["latest_start"]), float(payload["bar"]),
                                int(payload["seed"]), thresholds=(), b_ladder=(int(payload["b"]),),
                                ci_b=int(payload.get("ci_b") or _stats.B_CI),
                                fcr_tails=[float(x) for x in payload.get("fcr_tails") or []],
                                nonpositive=payload.get("nonpositive", "refuse"),
                                composition_months=[_mi(x) for x in payload.get("composition_months") or []])
    else:
        # a payload recorded before the review: its thresholds and B ladder
        res = _stats.trend_test(values, months, _mi(payload["latest_start"]), float(payload["bar"]),
                                int(payload["seed"]), thresholds=payload.get("thresholds") or [DEFAULT_Q],
                                b_ladder=payload.get("b_ladder") or _stats.B_LADDER,
                                nonpositive=payload.get("nonpositive", "refuse"))
    _TREND_CACHE[key] = res
    return res


def run_trend_payload(payload: Dict[str, Any], con: sqlite3.Connection) -> Dict[str, Any]:
    """Run (or re-run) the change test a payload records; cached per payload within a verify."""
    months, values = _series_values(con, payload["series_sql"])
    return _trend_values(payload, months, values)


def _trend_key(payload: Dict[str, Any], months: Sequence[int], values: Sequence[Optional[float]]) -> str:
    recipe = {k: v for k, v in payload.items() if k != "target"}
    return json.dumps([recipe, list(months), [None if v is None else repr(float(v)) for v in values]],
                      sort_keys=True)


#: What a trend payload's `target` names, and how it is read from the test's result.
TREND_TARGETS = {
    "p_min_effect": lambda r: r["p_min_effect"],
    "p_nonzero": lambda r: r["p_nonzero"],
    "ci_low_pct": lambda r: 100.0 * r["ci_low"],
    "ci_high_pct": lambda r: 100.0 * r["ci_high"],
    "fcr_bound_pct": lambda r: 100.0 * [x for x in r["fcr_bounds"] if x.get("bound") is not None][0]["bound"],
}


def trend_target(res: Dict[str, Any], target: str) -> float:
    """A trend payload's target read from its test's result; 'composition_step_pct@YYYY-MM' is
    the size of the level shift at that month (TrendModel.composition_steps), in percent."""
    if target.startswith("composition_step_pct@"):
        m = _mi(target.split("@", 1)[1])
        for st in (res.get("composition_step") or {}).get("steps") or []:
            if int(st["month"]) == m:
                return 100.0 * float(st["size"])
        raise ValueError("no composition step at %s on re-run" % target.split("@", 1)[1])
    return TREND_TARGETS[target](res)


def recompute(payload: Dict[str, Any], con: sqlite3.Connection) -> float:
    """Re-run a recorded test (EvidenceLedger.verify calls this)."""
    if payload.get("kind") == TREND_KIND:
        res = run_trend_payload(payload, con)
        if not res.get("ran"):
            raise ValueError("the change test did not run on re-run: %s" % res.get("not_run", "?"))
        return float(trend_target(res, payload["target"]))
    if payload.get("kind") != PERM_KIND:
        raise ValueError("not a permutation or change-test payload")
    a, b = _column(con, payload["sql_a"]), _column(con, payload["sql_b"])
    if payload.get("method") == "welch":
        return welch_p(a, b)
    return permutation_p(a, b, int(payload.get("n_perm", N_PERM)), int(payload.get("seed", SEED)))


# --------------------------------------------------------------------------- roles
@dataclass
class Roles:
    date: str = ""
    measures: List[str] = field(default_factory=list)
    dimensions: List[str] = field(default_factory=list)
    grain: str = "events"                      # events | monthly (one row per month)
    excluded: Dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {"date": self.date, "measures": list(self.measures),
                "dimensions": list(self.dimensions), "grain": self.grain,
                "excluded": dict(self.excluded)}


def _id_like(name: str, s: pd.Series, profiled: Dict[str, Any]) -> bool:
    ch = profiled.get(name)
    if ch is not None and getattr(ch, "is_id_like", False):
        return True
    t = _name_tokens(name)
    if t and t[-1] in ("id", "key"):                     # id, customer_id, WardID, account key
        return True
    nn = s.dropna()
    # Nearly every value distinct reads as a key, unless the name's HEAD says it is an amount: a
    # rent roll in whole dollars is nearly unique too (QA round 2, 23 Sep 2026). Only the last
    # token counts: sales_order_number and rent_receipt_no are keys (QA round 3), after trailing
    # qualifiers are dropped: amount_usd and revenue_2023 are amounts (round-3 review).
    if (len(nn) > 20 and pd.api.types.is_integer_dtype(nn) and nn.nunique() / float(len(nn)) > 0.95
            and not _head_is_quantity(t)):
        return True
    return False


# Numbers that are labels, not quantities: averaging them means nothing (QA, 23 Sep 2026: the
# raw RentSafeTO file gave "average rsn -1,669", "average ward", "average x" and
# "average year_evaluated +99.0" as 7 of its 65 "measures").
#
# A code or year word makes a label only in the right place: the rules read the HEAD (last) token
# of the name. Round 2 (23 Sep 2026) let a quantity word anywhere veto the code rule, which
# averaged cost_code, sales_region and rent_zone; round 1 matched a code word anywhere, which
# dropped a landlord's rent_roll, code_violations and region_revenue. Round 3: the last token
# decides, and camelCase is split first (WardID, YearBuilt, PostalCode).
_COORD_RE = re.compile(r"^(lat|latitude|lon|lng|long|longitude|easting|northing|x_coord|y_coord|"
                       r"geo_x|geo_y)$")
# a name ending in one of these is a label: ward, postal_code, census_tract, sales_region
_CODE_WORDS = frozenset(("ward", "rsn", "code", "zip", "zipcode", "postal", "postcode", "fsa",
                         "district", "region", "zone", "precinct", "tract", "grid", "census",
                         "sic", "naics", "pin"))
# a name ending in one of these is a key, whatever comes before it: sales_order_number,
# rent_receipt_no, cost_code, ward_id
_KEY_SUFFIXES = frozenset(("id", "key", "code", "no", "num", "nbr", "number"))
# a year word anywhere (year_built, fiscal_year, fy); values must also read as years
_YEAR_WORDS = frozenset(("year", "yr", "fy"))
# a name ENDING in one of these is a quantity: rent_roll, code_violations, district_units
_QUANTITY_WORDS = frozenset(("count", "counts", "total", "totals", "sum", "amount", "amounts",
                             "revenue", "revenues", "sales", "violations", "units", "population",
                             "roll", "rent", "rents", "cost", "costs", "price", "prices", "fee",
                             "fees", "spend", "qty"))
# a name ending in one of these, or holding "per", is a rate: fy_growth_pct, units_per_zone
_RATE_WORDS = frozenset(("pct", "percent", "percentage", "rate", "ratio", "share"))
# trailing words that qualify a quantity without changing what it is, dropped before the head is
# read: amount_usd, revenue_2023, rent_monthly, sales_k (round-3 review, 23 Sep 2026: they had
# become "an identifier")
_MODIFIER_WORDS = frozenset(("usd", "cad", "eur", "gbp", "aud", "inr", "bdt", "dollar", "dollars",
                             "cents", "monthly", "annual", "annually", "yearly", "quarterly",
                             "weekly", "daily", "ytd", "mtd", "qtd", "k", "m", "mm", "bn",
                             "thousand", "thousands", "million", "millions"))
_YEAR_TOKEN_RE = re.compile(r"^(19|20)[0-9]{2}$")


def _name_tokens(name: Any) -> List[str]:
    """Lower-case words of a column name, camelCase split: WardID -> ['ward', 'id']."""
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", str(name))
    s = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1_\2", s)
    return [x for x in re.split(r"[^a-z0-9]+", s.lower()) if x]


def _head_tokens(tokens: Sequence[str]) -> List[str]:
    """
    The words that name what a column measures: "X_by_<code>" and "X_in_<code>" are read by the
    part before "by"/"in" (sales_by_region), then trailing qualifiers are dropped (amount_usd,
    total_cost_2024). At least one word is always kept.
    """
    t = [x for x in tokens if x]
    if len(t) > 2 and t[-1] in _CODE_WORDS:
        for i in range(1, len(t) - 1):
            if t[i] in ("by", "in"):
                t = t[:i]
                break
    while len(t) > 1 and (t[-1] in _MODIFIER_WORDS or _YEAR_TOKEN_RE.match(t[-1])):
        t = t[:-1]
    return t


def _head_is_quantity(tokens: Sequence[str]) -> bool:
    h = _head_tokens(tokens)
    return bool(h) and h[-1] in _QUANTITY_WORDS


def _is_quantity_or_rate(tokens: Sequence[str]) -> bool:
    h = _head_tokens(tokens)
    return bool(h) and (h[-1] in _QUANTITY_WORDS or h[-1] in _RATE_WORDS or "per" in tokens)


def _names_a_code(tokens: Sequence[str]) -> bool:
    t = [x for x in tokens if x]
    if not t or _is_quantity_or_rate(t):
        return False
    return t[-1] in _CODE_WORDS or t[-1] in _KEY_SUFFIXES


def _names_a_year(tokens: Sequence[str]) -> bool:
    t = [x for x in tokens if x]
    return any(x in _YEAR_WORDS for x in t) and not _is_quantity_or_rate(t)


def _label_number(name: str, s: pd.Series, all_names: Sequence[str]) -> str:
    """Why a numeric column is a label rather than a measure, or ""."""
    n = slug(name)
    tokens = _name_tokens(name)
    names = {slug(c) for c in all_names}
    if _COORD_RE.match(n) or (n in ("x", "y") and {"x", "y"} <= names):
        return "a map coordinate, not a measure"
    nn = pd.to_numeric(s, errors="coerce").dropna()
    integer = len(nn) > 0 and bool((nn == nn.round()).all())
    if integer and _names_a_year(tokens) and bool(((nn >= 1800) & (nn <= 2100)).mean() >= 0.95):
        return "a year label, not a quantity"
    if integer and _names_a_code(tokens):
        return "a code or key, not a quantity"
    return ""


def infer_roles(df: pd.DataFrame, health: Any = None, private: Sequence[str] = ()) -> Roles:
    """
    Date, measures and dimensions from the cleaned frame's types and the profile.
    `private` columns (withheld, coded or pending at intake) are never a dimension: their
    values would be printed in claims.
    """
    profiled = {c.name: c for c in (getattr(health, "columns", None) or [])}
    r = Roles()
    dates = [c for c in df.columns if pd.api.types.is_datetime64_any_dtype(df[c])]
    preferred = getattr(health, "date_column", "") or ""
    if preferred in dates:
        r.date = preferred
    elif dates:
        r.date = max(dates, key=lambda c: (int(df[c].notna().sum()), -list(df.columns).index(c)))
    for c in df.columns:
        if c == r.date or c.startswith("_"):
            continue
        s = df[c]
        if c in private:
            r.excluded[c] = "personal data decision at intake"
            continue
        if pd.api.types.is_bool_dtype(s):
            r.excluded[c] = "true/false flag"
            continue
        if pd.api.types.is_datetime64_any_dtype(s):
            r.excluded[c] = "a second date column"
            continue
        if pd.api.types.is_numeric_dtype(s):
            label = _label_number(c, s, list(df.columns))
            if _id_like(c, s, profiled):
                r.excluded[c] = "an identifier, not a measure"
            elif label:
                r.excluded[c] = label
            elif s.dropna().nunique() < 2:
                r.excluded[c] = "a constant"
            else:
                r.measures.append(c)
            continue
        nn = s.dropna().astype(str)
        levels = nn.nunique()
        if len(nn) == 0 or levels < 2:
            r.excluded[c] = "fewer than two values"
        elif levels > MAX_DIM_LEVELS or levels > 0.5 * len(nn):
            r.excluded[c] = "free text or too many distinct values to be a category"
        elif nn.str.len().mean() > 60:
            r.excluded[c] = "long text"
        else:
            r.dimensions.append(c)
    if r.date:
        per_month = df[r.date].dropna().dt.to_period("M").value_counts()
        if len(per_month) >= 12 and (per_month == 1).mean() >= 0.9:
            r.grain = "monthly"
    return r


# --------------------------------------------------------------------------- analysis table
@dataclass
class AnalysisTable:
    name: str
    quarantine_name: str
    n_rows: int
    n_quarantined: int
    roles: Roles
    # client column -> the analysis table's column, and -> the fact-id slug. Unique even
    # when two client columns differ only by case ('Rating', 'rating': SQLite names are
    # case-insensitive) or slug alike ('Rent ($)', 'rent'): QA, 23 Sep 2026.
    columns: Dict[str, str] = field(default_factory=dict)
    slugs: Dict[str, str] = field(default_factory=dict)

    def col(self, c: str) -> str:
        return self.columns.get(c, c)

    def slug(self, c: str) -> str:
        return self.slugs.get(c, slug(c))


def _unique_names(cols: Sequence[str]) -> Tuple[Dict[str, str], Dict[str, str]]:
    names: Dict[str, str] = {}
    slugs: Dict[str, str] = {}
    seen_n: set = {"_d", "_month"}
    seen_s: set = set()
    for c in cols:
        n, k = str(c), 2
        while n.lower() in seen_n:
            n, k = "%s_%d" % (c, k), k + 1
        seen_n.add(n.lower())
        names[c] = n
        sl, k = slug(c), 2
        while sl in seen_s:
            sl, k = "%s_%d" % (slug(c), k), k + 1
        seen_s.add(sl)
        slugs[c] = sl
    return names, slugs


def build_analysis_table(db_path: str, table: str, clean_df: pd.DataFrame, roles: Roles,
                         quarantine_df: Optional[pd.DataFrame] = None,
                         date_formats: Optional[Sequence[str]] = None) -> AnalysisTable:
    """Write the cleaned, typed rows the SQL facts read. Replaces an earlier copy.

    `date_formats` are the formats the cleaner tried on the date column (most-seen first);
    set-aside rows are read with the cleaner's own date reader and them, so a day-first
    file's set-aside months are not re-read month-first (QA, 23 Sep 2026)."""
    name = TABLE_PREFIX + slug(table)
    qname = name + "_quarantine"
    cols = list(roles.measures) + list(roles.dimensions)
    names, slugs = _unique_names(cols)
    out = pd.DataFrame(index=clean_df.index)
    if roles.date:
        d = pd.to_datetime(clean_df[roles.date], errors="coerce")
        out["_d"] = d.dt.strftime("%Y-%m-%d")
        out["_month"] = d.dt.strftime("%Y-%m")
    else:
        out["_d"] = None
        out["_month"] = None
    for c in roles.measures:
        out[c] = pd.to_numeric(clean_df[c], errors="coerce").astype(float)
    for c in roles.dimensions:
        out[c] = clean_df[c].map(lambda v: None if v is None or (isinstance(v, float) and v != v)
                                 else str(v))
    q_months: List[Optional[str]] = []
    if quarantine_df is not None and len(quarantine_df) and roles.date in quarantine_df.columns:
        from . import clean as _clean
        raw = quarantine_df[roles.date]
        fmts = list(date_formats or []) + [f for f in _clean.DEFAULT_DATE_FORMATS
                                           if f not in (date_formats or [])]
        raw_text = raw.map(lambda v: None if v is None or (isinstance(v, float) and v != v) else
                           (v if isinstance(v, (pd.Timestamp, _dt.date)) else str(v)))
        parsed = _clean._coerce_dates(raw_text, fmts)
        q_months = [None if pd.isna(x) else x.strftime("%Y-%m") for x in parsed]
    elif quarantine_df is not None:
        q_months = [None] * len(quarantine_df)

    con = sqlite3.connect(db_path)
    try:
        con.execute("DROP TABLE IF EXISTS %s" % qi(name))
        con.execute("DROP TABLE IF EXISTS %s" % qi(qname))
        decl = ["_d TEXT", "_month TEXT"] + ["%s REAL" % qi(names[c]) for c in roles.measures] + \
               ["%s TEXT" % qi(names[c]) for c in roles.dimensions]
        con.execute("CREATE TABLE %s (%s)" % (qi(name), ", ".join(decl)))
        rows = []
        for rec in out[["_d", "_month"] + cols].itertuples(index=False, name=None):
            rows.append(tuple(None if (isinstance(v, float) and v != v) else v for v in rec))
        con.executemany("INSERT INTO %s VALUES (%s)" % (qi(name), ", ".join("?" * (2 + len(cols)))), rows)
        con.execute("CREATE TABLE %s (_month TEXT)" % qi(qname))
        con.executemany("INSERT INTO %s VALUES (?)" % qi(qname), [(m,) for m in q_months])
        con.commit()
    finally:
        con.close()
    return AnalysisTable(name=name, quarantine_name=qname, n_rows=len(out),
                         n_quarantined=len(q_months), roles=roles, columns=names, slugs=slugs)


# --------------------------------------------------------------------------- the window
@dataclass
class Window:
    start: int
    end: int
    cut_reason: str = ""
    rows_after_end: int = 0
    # why the first month in the file was left out as a partial month, or ""
    start_cut_reason: str = ""

    @property
    def months(self) -> int:
        return self.end - self.start + 1


INCOMPLETE_SHARE = 0.5            # a last month under half the median of the 6 before it


def _incomplete_last_month(con: sqlite3.Connection, at: AnalysisTable, as_of: str, end: int,
                           series: Sequence[int], last_date: str) -> str:
    """
    Why the last month in the file should be left out as incomplete, or "" to keep it.

    Only a month the export could have caught part-way is suspect: the month holding the
    analysis date (not over yet), or a month whose dates stop early AND that holds under half
    the rows of a typical month (review v2, 24 Sep 2026: the month before the analysis date is
    no longer cut on its last row alone). Before QA (23 Sep 2026) any month whose
    last row fell before the 29th was dropped: every rent roll dated the 1st, every small log
    and every year-level file lost its latest, complete period, and the story said so falsely.
    Files dated only on the 1st of the month (monthly or yearly records) are never cut.
    """
    t = qi(at.name)
    not_first = con.execute("SELECT COUNT(*) FROM %s WHERE _d IS NOT NULL AND _d <= %s AND "
                            "substr(_d, 9, 2) != '01'" % (t, ql(as_of))).fetchone()[0]
    if not not_first:
        return ""
    y, m = end // 12, end % 12 + 1
    month_len = calendar.monthrange(y, m)[1]
    as_of_m = _mi(as_of)
    label = _ml(end)
    if end >= as_of_m:
        if int(as_of[8:10]) < month_len:
            return ("the last month in the file (%s) holds the analysis date %s, so it is not over yet"
                    % (label, as_of))
        return ""
    stops_early = bool(last_date) and int(last_date[8:10]) < month_len - 2
    if not stops_early:
        return ""
    prior = [v for v in series[-7:-1]]
    typical = float(np.median(prior)) if prior else 0.0
    # A month that is over, and whose rows stop early, is incomplete only when it holds
    # materially fewer rows than a typical month. Before review v2 (24 Sep 2026) the month
    # before the analysis date was cut whenever its last row fell before its last days: a
    # complete August (rows to the 27th, at the usual rate) was cut, and then forecast.
    low = bool(prior) and series[-1] < INCOMPLETE_SHARE * typical
    if low:
        return ("the last month in the file (%s) is incomplete: its rows stop on %s and it holds "
                "%s rows against a typical %s" % (label, last_date[:10], format(series[-1], ","),
                                                  format(int(round(typical)), ",")))
    return ""


def _incomplete_first_month(con: sqlite3.Connection, at: AnalysisTable, start: int,
                            series: Sequence[int], first_date: str) -> str:
    """
    Why the first month in the file should be left out as partial, or "" to keep it: its rows
    start after the 3rd of the month AND it holds under half the median of the 6 months after
    it (the last month's rule, mirrored). An extract that starts on the 28th put a four-day
    month into the change model as a month whose volume "fell" 87% (review of R1, 23 Sep 2026);
    a quiet business whose first row falls on the 5th of a full month is kept. Files dated only
    on the 1st of the month are never cut.
    """
    t = qi(at.name)
    not_first = con.execute("SELECT COUNT(*) FROM %s WHERE _d IS NOT NULL AND substr(_d, 9, 2) != '01'"
                            % t).fetchone()[0]
    if not not_first or not first_date or len(series) < 2:
        return ""
    if int(first_date[8:10]) <= 3:
        return ""
    after = [v for v in series[1:7]]
    typical = float(np.median(after)) if after else 0.0
    if not after or series[0] >= INCOMPLETE_SHARE * typical:
        return ""
    return ("the first month in the file (%s) is partial: its rows start on %s and it holds %s rows "
            "against a typical %s" % (_ml(start), first_date[:10], format(series[0], ","),
                                      format(int(round(typical)), ",")))


#: A run of at least this many empty months, with under GAP_MAX_SHARE of the rows before it,
#: marks where a series really starts.
GAP_MIN_MONTHS = 12
GAP_MAX_SHARE = 0.02


def _series_start_after_gap(series: Sequence[int]) -> int:
    """The index where the series starts after its last long empty run, or 0 for none."""
    total = float(sum(series))
    if total <= 0:
        return 0
    best = 0
    run = 0
    for i, v in enumerate(series):
        if v == 0:
            run += 1
            continue
        if run >= GAP_MIN_MONTHS and sum(series[:i]) <= GAP_MAX_SHARE * total:
            best = i
        run = 0
    return best


def find_window(con: sqlite3.Connection, at: AnalysisTable, as_of: str) -> Optional[Window]:
    """
    The months the analysis may use: from the first dated month to the last COMPLETE one,
    stopping before future dates and before a series-end cliff.
    """
    t = qi(at.name)
    rows = con.execute("SELECT _month, COUNT(*), MAX(_d), MIN(_d) FROM %s WHERE _month IS NOT NULL AND "
                       "_d <= %s GROUP BY _month ORDER BY _month" % (t, ql(as_of))).fetchall()
    if not rows:
        return None
    counts = {_mi(m): int(n) for m, n, _, _ in rows}
    last_day = {_mi(m): d for m, _, d, _ in rows}
    first_day = {_mi(m): d for m, _, _, d in rows}
    start, end = min(counts), max(counts)
    series = [counts.get(i, 0) for i in range(start, end + 1)]
    reason = ""
    start_reason = ""
    # A few stray early rows, then a long run of empty months, then the series: the series
    # starts after the run (review v2, 24 Sep 2026: 8 rows at 1900-01-01 started the window in
    # 1900 and the forecast replayed 123 empty years).
    gap_start = _series_start_after_gap(series)
    if gap_start:
        before = int(sum(series[:gap_start]))
        empty = 0
        k = gap_start - 1
        while k >= 0 and series[k] == 0:
            empty, k = empty + 1, k - 1
        start_reason = ("the series starts in %s: the %s dated %s to %s are separated from the rest "
                        "of the file by %s with no rows"
                        % (_ml(start + gap_start), _rows_word(before), _ml(start), _ml(start + k),
                           _plural_months(empty)))
        start += gap_start
        series = series[gap_start:]
    if at.roles.grain == "events" and not start_reason:
        start_reason = _incomplete_first_month(con, at, start, series, str(first_day.get(start) or ""))
        if start_reason:
            start += 1
            series = series[1:]
    if at.roles.grain == "events":
        for i in range(12, len(series) - CLIFF_RUN + 1):
            med = float(np.median(series[i - 12:i]))
            # A TAIL, not a gap: from here to the end no month recovers. A quiet spell in the
            # middle of the history (a slow start, a shutdown) is business, and is kept.
            if med > 0 and all(v < CLIFF_SHARE * med for v in series[i:]):
                end = start + i - 1
                reason = ("volume collapses after %s (every later month under a tenth of the "
                          "previous year's median, for three months or more): probably mistyped "
                          "dates, not business"
                          % _ml(end))
                break
        if not reason:
            reason = _incomplete_last_month(con, at, as_of, end, series, str(last_day.get(end) or ""))
            if reason:
                end -= 1
    as_of_m = _mi(as_of)
    if end > as_of_m:
        end = as_of_m
    if end < start:
        return None
    after = con.execute("SELECT COUNT(*) FROM %s WHERE _month > %s" % (t, ql(_ml(end)))).fetchone()[0]
    return Window(start=start, end=end, cut_reason=reason, rows_after_end=int(after),
                  start_cut_reason=start_reason)


# --------------------------------------------------------------------------- the facts
@dataclass
class Series:
    slug: str
    label: str
    sql: str
    unit: str
    fill: str
    rows: int
    # a level shift the series' change test found at a change in what the file covers (ship
    # round): {"month": "YYYY-MM", "size": fraction, "why": words}; the forecast reads it
    step: Optional[Dict[str, Any]] = None


@dataclass
class MeasureResult:
    table: AnalysisTable
    window: Optional[Window]
    series: List[Series] = field(default_factory=list)
    confounders: List[str] = field(default_factory=list)
    caveats: List[str] = field(default_factory=list)
    unmeasured: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        w = self.window
        return {
            "table": self.table.name, "roles": self.table.roles.to_dict(),
            "window": None if w is None else {"start": _ml(w.start), "end": _ml(w.end),
                                               "months": w.months, "cut_reason": w.cut_reason,
                                               "rows_after_end": w.rows_after_end,
                                               "start_cut_reason": w.start_cut_reason},
            "series": [s.__dict__ for s in self.series],
            "confounders": list(self.confounders), "caveats": list(self.caveats),
            "unmeasured": list(self.unmeasured),
        }


def _scalar(con: sqlite3.Connection, sql: str) -> Optional[float]:
    row = con.execute(sql).fetchone()
    return None if row is None or row[0] is None else float(row[0])


def _median_sql(t: str, col: str, where: str) -> str:
    base = "FROM %s WHERE %s IS NOT NULL AND %s" % (t, col, where)
    return ("SELECT AVG(v) FROM (SELECT %s AS v %s ORDER BY v LIMIT 2 - (SELECT COUNT(*) %s) %% 2 "
            "OFFSET ((SELECT COUNT(*) %s) - 1) / 2)" % (col, base, base, base))


def measure_facts(
    fs: FactSet,
    db_path: str,
    at: AnalysisTable,
    as_of: Optional[str] = None,
    data_health: float = 100.0,
    label: str = "",
    claim_health: Optional[Dict[str, float]] = None,
    min_effect: float = DEFAULT_BAR,
    q: float = DEFAULT_Q,
    primary_metric: str = "",
    fdr_method: str = "bh",
) -> MeasureResult:
    """
    Add the business-measure facts for one analysis table to `fs`.

    `claim_health` maps a client column to its health for claims that read it (0-100, the
    minimum of completeness and validity, with the table's uniqueness: column_claim_health
    builds it); each change claim carries the minimum over the columns it reads (M9).
    `min_effect` is the materiality bar the change test asks about and `q` the confirmation
    level; the analysis passes the gate policy's (min_effect_recommend, recommend_q), and its
    primary_metric and fdr_method, so the provisional family pass that decides where to spend
    bootstrap draws is the gate's own.
    """
    from ._sqlite import connect_ro
    as_of = as_of or _dt.date.today().isoformat()
    label = label or at.name[len(TABLE_PREFIX):]
    t = qi(at.name)
    roles = at.roles
    res = MeasureResult(table=at, window=None)
    con = connect_ro(db_path)
    try:
        def add(fid, claim, sql, unit, role="detail", kind="state", **kw):
            v = _scalar(con, sql)
            if v is None:
                return None
            return fs.add(Fact(id=fid, claim=claim, value=v, unit=unit, query=sql, query_kind="sql",
                               source_table=label, data_health=float(data_health),
                               fact_kind=kind, role=role, **kw))

        add("measure.rows", "Cleaned rows in the business analysis of %s" % label,
            "SELECT COUNT(*) FROM %s" % t, "count", rows_scanned=at.n_rows)
        if not roles.date:
            res.unmeasured.append("No column holds dates, so nothing can be said about change "
                                  "over time and no forecast is possible.")
            return res
        w = find_window(con, at, as_of)
        res.window = w
        undated_sql = "SELECT COUNT(*) FROM %s WHERE _month IS NULL" % t
        if (_scalar(con, undated_sql) or 0) > 0:     # zero is not worth a line in the ledger
            add("measure.rows_undated", "Cleaned rows with no usable date", undated_sql, "count",
                rows_scanned=at.n_rows)
        if w is None:
            first = con.execute("SELECT MIN(_d), MIN(_month) FROM %s WHERE _month IS NOT NULL" % t).fetchone()
            if first and first[0] is not None and str(first[0]) <= as_of:
                # Every dated row is in one month, and that month was left out as incomplete.
                res.unmeasured.append(
                    "The dated rows cover a single month (%s), and it is not complete, so there is "
                    "nothing to compare over time and no forecast." % first[1])
            else:
                res.unmeasured.append("No dated rows fall on or before %s." % as_of)
            return res
        in_span = _between(w.start, w.end)
        if w.rows_after_end:
            add("measure.rows_after_end", "Cleaned rows dated after %s, left out of the monthly "
                "analysis" % _ml(w.end), "SELECT COUNT(*) FROM %s WHERE _month > %s" % (t, ql(_ml(w.end))),
                "count", rows_scanned=at.n_rows,
                caveats=[w.cut_reason or "dated after the analysis date"])
            res.caveats.append("rows dated after %s are left out: %s"
                               % (_ml(w.end), w.cut_reason or "they are after the analysis date"))
        if w.start_cut_reason:
            add("measure.rows_before_start", "Cleaned rows before the series starts, left out of the "
                "monthly analysis", "SELECT COUNT(*) FROM %s WHERE _month < %s" % (t, ql(_ml(w.start))),
                "count", rows_scanned=at.n_rows, caveats=[w.start_cut_reason])
            res.caveats.append("rows before %s are left out: %s" % (_ml(w.start), w.start_cut_reason))
        add("measure.months", "Months covered by the analysis, %s to %s" % (_ml(w.start), _ml(w.end)),
            "SELECT COUNT(DISTINCT _month) FROM %s WHERE %s" % (t, in_span), "count")

        last = (w.end - 11, w.end)
        prior = (w.end - 23, w.end - 12)
        can_compare = w.months >= 24
        rows24 = 0
        if can_compare:
            rows24 = int(_scalar(con, "SELECT COUNT(*) FROM %s WHERE %s" % (t, _between(prior[0], last[1]))) or 0)
        else:
            res.unmeasured.append(
                "The file covers %d months (%s to %s); comparing the latest 12 months with the 12 "
                "before needs 24, so no change over time is tested." % (w.months, _ml(w.start), _ml(w.end)))

        # -- confounder: uneven set-aside share ---------------------------------
        confounders: List[str] = []
        if can_compare and at.n_quarantined:
            qt = qi(at.quarantine_name)
            share = ("SELECT %%s(s) FROM (SELECT a._month, 100.0 * COALESCE(q.n, 0) / (COALESCE(q.n, 0) + a.n) "
                     "AS s FROM (SELECT _month, COUNT(*) AS n FROM %s WHERE %s GROUP BY _month) a LEFT JOIN "
                     "(SELECT _month, COUNT(*) AS n FROM %s GROUP BY _month) q ON q._month = a._month)"
                     % (t, _between(prior[0], last[1]), qt))
            lo = add("measure.set_aside_share.lowest_month",
                     "Lowest monthly share of rows set aside by cleaning, over the 24 months compared",
                     share % "MIN", "pct")
            hi = add("measure.set_aside_share.highest_month",
                     "Highest monthly share of rows set aside by cleaning, over the 24 months compared",
                     share % "MAX", "pct")
            und = add("measure.set_aside_undated", "Rows set aside by cleaning whose month cannot be read",
                      "SELECT COUNT(*) FROM %s WHERE _month IS NULL" % qt, "count")
            if lo is not None and hi is not None and hi.value - lo.value > UNEVEN_QUARANTINE_PTS:
                confounders.append(
                    "the share of rows set aside by cleaning differs from month to month (see "
                    "measure.set_aside_share.lowest_month and .highest_month), so part of any change "
                    "may come from cleaning rather than the business")
            if und is not None and und.value > 0.05 * (at.n_rows + at.n_quarantined):
                confounders.append(
                    "rows set aside by cleaning include some whose month cannot be read (see "
                    "measure.set_aside_undated), so they could belong to either period")
        res.confounders = confounders

        # -- the change claims: one estimand, one unit (the month), one model -------
        # (design §2.1 M1): the ratio of the average month in the latest 12 months to the
        # average month in the 12 before, where a month is the monthly total (volume) or the
        # monthly mean (a measure). The headline figure is that ratio in SQL; the test and
        # its interval are stats.trend_test on the same monthly values (up to 36 months; the
        # months before the prior window carry their own level, so the test's change is the
        # headline's 12-versus-12 change).
        #
        # Cost (review of R1, 23 Sep 2026): every claim is tested once at B = 1,999; then one
        # provisional pass of the gate's own false-discovery rule (stats.family_lines, the same
        # rule gate.apply_trend_families applies) finds the line that decides each claim, and
        # only a claim whose Monte Carlo interval straddles THAT line is extended to 9,999. A
        # claim the family rejects gets its one-sided selection-adjusted bound (M4) at the
        # single tail its family needs. Before, every claim was extended against every step
        # q*j/m of a family of m, and six interval tails were inverted at B = 9,999.
        model_start = max(w.start, w.end - _stats.MODEL_MONTHS_MAX + 1)
        pending: List[Dict[str, Any]] = []
        # the primary claim when the policy names none: the largest money total (review v2)
        auto_primary: List[str] = [""]

        # -- composition (review v2, 24 Sep 2026) ----------------------------------------
        # A category whose levels start or stop inside the modelled months changes what the
        # file covers: the change is stated with that as its explanation, and volume is also
        # compared like for like, on the levels present across every modelled month.
        comp = _composition(con, t, at, model_start, w.end) \
            if (can_compare and roles.grain == "events") else None
        comp_extra: Dict[str, Any] = {}
        comp_where = ""
        # the months where what the file covers changes (a level's first month, or the month
        # after its last), known before any value is read: the change test fits a level shift
        # at each (stats.TrendModel.composition_steps; ship round, 24 Sep 2026)
        comp_at: Dict[int, List[Tuple[str, str]]] = {}
        if comp is not None:
            ckey = comp["key"]
            comp_where = _in_list(ckey, comp["stable"])
            for lv, m in comp["entered"]:
                comp_at.setdefault(int(m), []).append((lv, "first appears"))
            for lv, m in comp["left"]:
                comp_at.setdefault(int(m) + 1, []).append((lv, "has no rows after %s" % _ml(int(m))))
            add("measure.composition",
                "Values of %s that start or stop inside the modelled months (%s to %s): %s"
                % (comp["column"], _ml(model_start), _ml(w.end), composition_words(comp)),
                "SELECT COUNT(DISTINCT %s) FROM %s WHERE %s" % (ckey, t, _in_list(ckey, comp["moved"])),
                "count", rows_scanned=at.n_rows)
            add("measure.composition.stable",
                "Values of %s present across all the modelled months (%s to %s), the like-for-like "
                "set" % (comp["column"], _ml(model_start), _ml(w.end)),
                "SELECT COUNT(DISTINCT %s) FROM %s WHERE %s" % (ckey, t, comp_where), "count",
                rows_scanned=at.n_rows)
            comp_extra = {"composition": {
                "column": comp["column"], "fact": "measure.composition",
                "entered": [[lv, _ml(m)] for lv, m in comp["entered"]],
                "left": [[lv, _ml(m)] for lv, m in comp["left"]],
                "stable": list(comp["stable"]), "words": composition_words(comp)}}
            confounders.append(
                "the mix of %s changed inside the compared months (%s), so part of any change in an "
                "average may come from the mix rather than a like-for-like change"
                % (comp["column"], composition_words(comp)))
            res.confounders = confounders

        def what_unit(what: str) -> str:
            return "totals" if (what == "volume" or what.startswith("volume:")
                                or what.startswith("total:")) else "averages"

        def attach(item: Dict[str, Any], res: Dict[str, Any]) -> None:
            """Put one test result on its headline and (re)write its model facts."""
            fid, headline, payload, what = item["fid"], item["headline"], item["payload"], item["what"]
            headline.test = _test_summary(res, _ml(model_start), _ml(w.end))
            headline.test.update(item.get("extra") or {})
            if item.get("floor"):
                headline.test["month_row_floor"] = item["floor"]
            if not res.get("ran"):
                headline.p_value = None
                if not item.get("not_run_noted"):
                    headline.caveats = list(headline.caveats) + [
                        "no change test was run: %s" % res.get("not_run", "the model could not be fitted")]
                    item["not_run_noted"] = True
                return
            headline.p_value = float(res["p_min_effect"])
            headline.p_nonzero = float(res["p_nonzero"])
            headline.trend_screen = str(res.get("drift_screen") or "")
            if res.get("ci_low") is not None and res.get("ci_high") is not None:
                headline.effect_ci_low = float(res["ci_low"])
                headline.effect_ci_high = float(res["ci_high"])
                headline.effect_ci_level = 0.95
                headline.effect_ci_method = ("test inversion of the same bootstrap test (95%%, B = %d)"
                                             % int(res["ci_b"]))
            note = ("the month is the unit: %d months (%s to %s) in a model of the log monthly values "
                    "with %d monthly seasonal terms%s and AR(1) momentum (estimated %.2f), fitted by "
                    "REML; the p-value is a one-sided parametric bootstrap test (B = %s) of 'the "
                    "change is at least %s', re-estimating momentum in every resample, drawn from "
                    "momentum %.2f (the momentum-plus-noise model sees %.2f with a %.0f%% white-noise "
                    "share); row count is a precision note, not the sample size"
                    % (int(res["n"]), _ml(model_start), _ml(w.end), int(res["seasonal_terms"]),
                       ", a separate level for the months before the 12 compared" if res.get("older_term")
                       else "", float(res["phi_hat"]), format(int(res["b"]), ","),
                       _pct_text(min_effect), float(res["phi_restricted"]),
                       float(res.get("phi_hat_2d") or 0.0), 100.0 * float(res.get("noise_share_hat") or 0.0)))
            cav = [c for c in headline.caveats if not c.startswith("the month is the unit:")]
            headline.caveats = cav + [note]
            base = dict(source_table=label, data_health=float(data_health),
                        rows_scanned=int(headline.rows_scanned), fact_kind="state", role="detail")
            model_facts = [
                ("p", "p_min_effect", "probability",
                 "Chance of a result at least this strong if the change were smaller than the %s bar "
                 "(one-sided bootstrap test on the monthly %s, momentum and seasonal terms "
                 "re-estimated in every resample)" % (_pct_text(min_effect), what_unit(what))),
                ("p_nonzero", "p_nonzero", "probability",
                 "Chance of a gap at least this large if nothing had changed at all (two-sided "
                 "bootstrap test on the monthly %s)" % what_unit(what)),
                ("ci_low", "ci_low_pct", "pct",
                 "Lower end of the 95% interval for the change, by inverting the same test"),
                ("ci_high", "ci_high_pct", "pct",
                 "Upper end of the 95% interval for the change, by inverting the same test"),
            ]
            fcr = [r for r in (res.get("fcr_bounds") or []) if r.get("bound") is not None]
            if fcr:
                r0 = fcr[0]
                model_facts.append(
                    ("ci_adj", "fcr_bound_pct", "pct",
                     "%s end of the one-sided %s bound for the change, adjusted for picking the "
                     "strongest results (tail %s: the claim's family's R*q/m), by inverting the "
                     "same test" % ("Lower" if r0["side"] == "lower" else "Upper",
                                     "%g%%" % round(100.0 * float(r0["level"]), 4), "%g" % float(r0["tail"]))))
            named: List[Dict[str, Any]] = []
            for st in ((res.get("composition_step") or {}).get("steps") or []) \
                    if payload.get("composition_months") else []:
                if not st.get("detected"):
                    continue
                lab = _ml(int(st["month"]))
                who = comp_at.get(int(st["month"])) or []
                named.append({"month": lab, "size": float(st["size"]), "p": float(st["p"]),
                              "levels": [[lv, verb] for lv, verb in who],
                              "fact": "%s.step.%s" % (fid, lab.replace("-", "_"))})
                model_facts.append(
                    ("step.%s" % lab.replace("-", "_"), "composition_step_pct@%s" % lab, "pct",
                     "Level shift in the monthly %s at %s, when %s (the model's estimate, with the "
                     "monthly terms, the other such shifts and AR(1) momentum allowed for)"
                     % (what_unit(what), lab, "; ".join("'%s' %s" % (lv[:40], verb) for lv, verb in who)
                        or "what the file covers changes")))
            named.sort(key=lambda x: -abs(x["size"]))
            cs = res.get("composition_step") or {}
            headline.test["composition_steps"] = {"explains": bool(cs.get("explains")), "named": named,
                                                  "trend_p": cs.get("trend_p"),
                                                  "unit_root_lr": cs.get("unit_root_lr")} \
                if payload.get("composition_months") else None
            for suffix, target, unit, claim in model_facts:
                if target.startswith("ci_") and headline.effect_ci_low is None:
                    continue
                val = float(trend_target(res, target))
                query = json.dumps(dict(payload, target=target), sort_keys=True)
                cav = (["seed %d, B = %s, 99%% Monte Carlo interval of p %.4f to %.4f"
                        % (int(payload["seed"]), format(int(res["b"]), ","), res["mc_interval"][0],
                           res["mc_interval"][1])] if suffix == "p" else [])
                old = item["facts"].get(suffix)
                if old is not None:
                    old.value, old.query, old.caveats, old.claim = val, query, cav, claim
                    continue
                item["facts"][suffix] = fs.add(Fact(id="%s.%s" % (fid, suffix), claim=claim, value=val,
                                                    unit=unit, query=query, query_kind="model",
                                                    caveats=cav, **base))

        def trend(fid: str, headline: Fact, series_sql: str, nonpositive: str, cols: Sequence[str],
                  what: str, floor: str = "", extra: Optional[Dict[str, Any]] = None,
                  composition: bool = False) -> None:
            """Run the change test for one headline at B = 1,999 and attach its numbers.
            `composition`: the series spans the change in what the file covers, so its test also
            fits a level shift at each month where that changed."""
            months, values = _series_values(con, series_sql)
            payload = {"kind": TREND_KIND, "claim": fid, "series_sql": series_sql,
                       "latest_start": _ml(last[0]), "bar": float(min_effect), "seed": _claim_seed(fid),
                       "b": int(_stats.B_TEST), "ci_b": int(_stats.B_CI), "fcr_tails": [],
                       "nonpositive": nonpositive}
            if composition and comp_at:
                payload["composition_months"] = [_ml(m) for m in sorted(comp_at)]
            headline.min_effect = float(min_effect)
            headline.claim_key = what
            headline.claim_health = _claim_health(claim_health, cols)
            item = {"fid": fid, "headline": headline, "payload": payload, "months": months,
                    "values": values, "what": what, "facts": {}, "floor": floor,
                    "extra": dict(extra or {})}
            attach(item, _trend_values(payload, months, values))
            pending.append(item)

        def robust_twin(rid: str, what: str, r_sql: str, r_series: str, nonpositive: str, n_obs: int,
                        ex: Dict[str, Any], efact: str) -> Dict[str, Any]:
            """The same change without a measure's extreme rows: a descriptive headline and its own
            test (a model fact the ledger re-runs), so the gate can see whether they drive it."""
            rh = add(rid, "Change in %s without its extreme rows, latest 12 months against the 12 "
                     "before" % what, r_sql, "pct", rows_scanned=n_obs)
            if rh is None:
                return {}
            r_months, r_values = _series_values(con, r_series)
            r_pay = {"kind": TREND_KIND, "claim": rid, "series_sql": r_series,
                     "latest_start": _ml(last[0]), "bar": float(min_effect), "seed": _claim_seed(rid),
                     "b": int(_stats.B_TEST), "ci_b": int(_stats.B_CI), "fcr_tails": [],
                     "nonpositive": nonpositive}
            r_res = _trend_values(r_pay, r_months, r_values)
            r_p = r_res.get("p_min_effect") if r_res.get("ran") else None
            if r_p is not None:
                fs.add(Fact(id=rid + ".p", claim="Chance of a result at least this strong if the change "
                            "without the extreme rows were smaller than the %s bar" % _pct_text(min_effect),
                            value=float(r_p), unit="probability",
                            query=json.dumps(dict(r_pay, target="p_min_effect"), sort_keys=True),
                            query_kind="model", source_table=label, data_health=float(data_health),
                            rows_scanned=n_obs, fact_kind="state", role="detail"))
            return {"extremes": {"rows": int(ex["k"]), "fact": efact, "without": rid,
                                 "change_without": float(rh.value) / 100.0,
                                 "p_without": None if r_p is None else float(r_p),
                                 "lo": ex["lo"], "hi": ex["hi"]}}

        def settle_claims() -> None:
            """The provisional family pass: extend straddlers of their deciding line, add FCR bounds."""
            ran = [it for it in pending if it["headline"].p_value is not None]
            if not ran:
                return

            def lines() -> Dict[str, Dict[str, Any]]:
                return _stats.family_lines([(it["fid"], it["what"], float(it["headline"].p_value))
                                            for it in ran], q, primary_metric or auto_primary[0],
                                           fdr_method)
            fam = lines()
            top = int(_stats.B_LADDER[-1])
            for _ in range(3):
                grown = False
                for it in ran:
                    mc = (it["headline"].test or {}).get("mc_interval")
                    line = fam[it["fid"]]["line"]
                    if it["payload"]["b"] < top and mc and float(mc[0]) <= line <= float(mc[1]):
                        it["payload"]["b"] = top
                        attach(it, _trend_values(it["payload"], it["months"], it["values"]))
                        grown = True
                if not grown:
                    break
                fam = lines()
            for it in ran:
                f = fam[it["fid"]]
                if f["reject"] and f.get("fcr_tail"):
                    it["payload"]["fcr_tails"] = [float(f["fcr_tail"])]
                    attach(it, _trend_values(it["payload"], it["months"], it["values"]))

        # -- monthly volume -----------------------------------------------------
        if roles.grain == "events":
            vol_sql = ("SELECT _month, COUNT(*) FROM %s WHERE %s GROUP BY _month ORDER BY _month"
                       % (t, in_span))
            res.series.append(Series("monthly_rows", "monthly rows in %s" % label, vol_sql, "rows",
                                     "zero", int(_scalar(con, "SELECT COUNT(*) FROM %s WHERE %s" % (t, in_span)) or 0)))
            if can_compare:
                cnt = "SELECT COUNT(*) FROM %s WHERE %s"
                add("measure.volume.last12", "Rows in the latest 12 months (%s to %s)" % (_ml(last[0]), _ml(last[1])),
                    cnt % (t, _between(*last)), "count", rows_scanned=rows24)
                add("measure.volume.prior12", "Rows in the 12 months before (%s to %s)" % (_ml(prior[0]), _ml(prior[1])),
                    cnt % (t, _between(*prior)), "count", rows_scanned=rows24)
                per_month = ("%s SELECT COUNT(a._month) FROM m LEFT JOIN %s a ON a._month = m._month "
                             "GROUP BY m._month ORDER BY 1")
                sql_a = per_month % (_months_cte(*last), t)
                # the average month in each window is its total / 12, so this ratio of totals is
                # the ratio of average months: the estimand (M1)
                chg_sql = ("SELECT 100.0 * (%s) / (%s) - 100.0"
                           % (cnt % (t, _between(*last)), cnt % (t, _between(*prior))))
                prior_n = _scalar(con, cnt % (t, _between(*prior))) or 0
                if prior_n > 0:
                    a_vals = _column(con, sql_a)
                    change = _scalar(con, chg_sql) or 0.0
                    h = add("measure.volume.change_pct",
                            "Change in the average month's row volume, latest 12 months against the "
                            "12 before", chg_sql, "pct", role="headline", kind="trend",
                            rows_scanned=rows24, effect_size=change / 100.0,
                            periods_observed=_held(a_vals, prior_n / 12.0, change),
                            confounders=list(confounders))
                    series_sql = ("%s SELECT m._month, COALESCE(a.v, 0) FROM m LEFT JOIN (SELECT _month, "
                                  "COUNT(*) AS v FROM %s WHERE %s GROUP BY _month) a ON a._month = m._month "
                                  "ORDER BY m._month" % (_months_cte(model_start, w.end), t,
                                                         _between(model_start, w.end)))
                    vx = dict(comp_extra)
                    if comp is not None:
                        vx["composition"] = dict(vx["composition"],
                                                 like_for_like="measure.volume.like_for_like.change_pct")
                    trend("measure.volume.change_pct", h, series_sql, "gap", [roles.date], "volume",
                          extra=vx, composition=comp is not None)
                if comp is not None:
                    # like for like: the same comparison on the levels present in every modelled month
                    lf_last = cnt % (t, "%s AND %s" % (comp_where, _between(*last)))
                    lf_prior = cnt % (t, "%s AND %s" % (comp_where, _between(*prior)))
                    lf_prior_n = _scalar(con, lf_prior) or 0
                    if lf_prior_n > 0:
                        add("measure.volume.like_for_like.last12",
                            "Rows in the latest 12 months from the %s values present throughout"
                            % comp["column"], lf_last, "count", rows_scanned=rows24)
                        add("measure.volume.like_for_like.prior12",
                            "Rows in the 12 months before from the %s values present throughout"
                            % comp["column"], lf_prior, "count", rows_scanned=rows24)
                        lf_sql = "SELECT 100.0 * (%s) / (%s) - 100.0" % (lf_last, lf_prior)
                        lf_change = _scalar(con, lf_sql) or 0.0
                        lf_monthly = _column(con, "%s SELECT (SELECT COUNT(*) FROM %s x WHERE x._month = "
                                                  "m._month AND %s) FROM m ORDER BY m._month"
                                             % (_months_cte(*last), t, comp_where))
                        lf_rows24 = int(_scalar(con, cnt % (t, "%s AND %s" % (comp_where, _between(prior[0], last[1])))) or 0)
                        hl = add("measure.volume.like_for_like.change_pct",
                                 "Change in the average month's row volume like for like (the %d %s values "
                                 "present in every modelled month), latest 12 months against the 12 before"
                                 % (len(comp["stable"]), comp["column"]), lf_sql, "pct", role="headline",
                                 kind="trend", rows_scanned=lf_rows24, effect_size=lf_change / 100.0,
                                 periods_observed=_held(lf_monthly, lf_prior_n / 12.0, lf_change))
                        lf_series = ("%s SELECT m._month, COALESCE(a.v, 0) FROM m LEFT JOIN (SELECT _month, "
                                     "COUNT(*) AS v FROM %s WHERE %s AND %s GROUP BY _month) a ON a._month = "
                                     "m._month ORDER BY m._month" % (_months_cte(model_start, w.end), t,
                                                                    comp_where, _between(model_start, w.end)))
                        if hl is not None:
                            trend("measure.volume.like_for_like.change_pct", hl, lf_series, "gap",
                                  [roles.date, comp["column"]], "volume:like_for_like",
                                  extra={"like_for_like_of": "measure.volume.change_pct",
                                         "rows_a_month": lf_rows24 / 24.0})

        # -- monthly totals of additive measures (review v2, 24 Sep 2026) ----------------------
        # Money and counts of things add up: their monthly TOTAL is compared, 12 against 12, with
        # the same test. A measure whose rows are two kinds of value (rent near 2,050 and repairs
        # near 300 in one 'Amount' column) is totalled per kind, never across them.
        splits: Dict[str, Optional[Dict[str, Any]]] = {}
        totals: List[Dict[str, Any]] = []
        extremes: Dict[str, Dict[str, Any]] = {}
        if roles.grain == "events" and can_compare:
            span24 = _between(prior[0], last[1])
            for c in roles.measures:
                col, s = qi(at.col(c)), at.slug(c)
                ex = _extremes(con, t, col, span24)
                if ex is None:
                    continue
                extremes[c] = ex
                add("measure.%s.extreme_rows" % s,
                    "Rows of %s more than %g robust standard deviations from its median (below %s or "
                    "above %s), over the 24 months compared: kept, and the change is also stated "
                    "without them" % (c, EXTREME_MADS, _fmt(ex["lo"]), _fmt(ex["hi"])),
                    "SELECT COUNT(*) FROM %s WHERE %s IS NOT NULL AND %s AND (%s < %r OR %s > %r)"
                    % (t, col, span24, col, ex["lo"], col, ex["hi"]), "count", rows_scanned=rows24)
                add("measure.%s.extreme_rows.largest" % s,
                    "The most extreme value of %s over the 24 months compared" % c,
                    "SELECT %s FROM %s WHERE %s IS NOT NULL AND %s ORDER BY ABS(%s - %r) DESC LIMIT 1"
                    % (col, t, col, span24, col, ex["median"]), c, rows_scanned=rows24)
                add("measure.%s.median24" % s, "Median %s over the 24 months compared" % c,
                    _median_sql(t, col, span24), c, rows_scanned=rows24)
                add("measure.%s.last12_median" % s, "Median %s in the latest 12 months" % c,
                    _median_sql(t, col, _between(*last)), c, rows_scanned=rows24)
                add("measure.%s.prior12_median" % s, "Median %s in the 12 months before" % c,
                    _median_sql(t, col, _between(*prior)), c, rows_scanned=rows24)
        currency: Optional[Dict[str, Any]] = None
        status_ex: Optional[Dict[str, Any]] = None
        if roles.grain == "events" and can_compare:
            span24_ = _between(prior[0], last[1])
            if any(additive_kind(c) == "money" for c in roles.measures):
                currency = _currency_split(con, t, at, span24_)
                status_ex = _status_exclusion(con, t, at, span24_)
            if currency is not None:
                ccol_ = qi(at.col(currency["column"]))
                add("measure.currency.count", "Currencies in %s, each on at least %s of the rows over the "
                    "24 months compared (%s)" % (currency["column"], _pct_text(CURRENCY_MIN_SHARE),
                                                 ", ".join(v for v, _k in currency["levels"])),
                    "SELECT COUNT(*) FROM (SELECT UPPER(TRIM(%s)) AS v, COUNT(*) AS n FROM %s WHERE %s IS NOT "
                    "NULL AND %s GROUP BY 1 HAVING n >= %r * (SELECT COUNT(*) FROM %s WHERE %s IS NOT NULL AND %s))"
                    % (ccol_, t, ccol_, span24_, CURRENCY_MIN_SHARE, t, ccol_, span24_), "count", rows_scanned=rows24)
                for lv, _k in currency["levels"]:
                    add("measure.currency.rows.%s" % (slug(lv) or "x"), "Rows in %s over the 24 months compared"
                        % lv, "SELECT COUNT(*) FROM %s WHERE UPPER(TRIM(%s)) = %s AND %s" % (t, ccol_, ql(lv), span24_),
                        "count", rows_scanned=rows24)
            if status_ex is not None:
                scol_ = qi(at.col(status_ex["column"]))
                add("measure.status_excluded.rows",
                    "Rows whose %s is %s, over the 24 months compared: not money received, so left out of "
                    "every money total" % (status_ex["column"], " or ".join("'%s'" % v for v in status_ex["values"])),
                    "SELECT COUNT(*) FROM %s WHERE LOWER(TRIM(%s)) IN (%s) AND %s"
                    % (t, scol_, ", ".join(ql(v) for v in status_ex["values"]), span24_), "count",
                    rows_scanned=rows24)
            cnt_all = "SELECT COUNT(*) FROM %s WHERE %s"
            for c in roles.measures:
                kind = additive_kind(c)
                if not kind:
                    continue
                col, s = qi(at.col(c)), at.slug(c)
                split = _kind_split(con, t, at, c, _between(prior[0], last[1]))
                cur_ = currency if kind == "money" else None
                if cur_ is not None:
                    split = None               # never both: the currency split comes first
                splits[c] = split
                st_where = ""
                if kind == "money" and status_ex is not None:
                    scol_ = qi(at.col(status_ex["column"]))
                    st_where = " AND (%s IS NULL OR LOWER(TRIM(%s)) NOT IN (%s))" % (
                        scol_, scol_, ", ".join(ql(v) for v in status_ex["values"]))
                if cur_ is not None:
                    ccol_ = qi(at.col(cur_["column"]))
                    groups = [(slug(lv) or "cur%d" % i, "UPPER(TRIM(%s)) = %s" % (ccol_, ql(lv)), " in %s" % lv)
                              for i, (lv, _k) in enumerate(cur_["levels"])]
                elif split is None:
                    groups = [("", "", "")]
                else:
                    dcol = qi(at.col(split["column"]))
                    lvq = ql(split["level"])
                    groups = [(slug(split["level"]) or "level", "%s = %s" % (dcol, lvq),
                               " where %s is '%s'" % (split["column"], split["level"][:40])),
                              ("other", "(%s IS NULL OR %s <> %s)" % (dcol, dcol, lvq),
                               " for the other %s values" % split["column"])]
                for gslug, gwhere, gwords in groups:
                    base = "measure.%s.total%s" % (s, ("." + gslug) if gslug else "")
                    cond = "%s IS NOT NULL%s%s" % (col, (" AND " + gwhere) if gwhere else "", st_where)
                    sum_sql = "SELECT SUM(%s) FROM %s WHERE %s AND %%s" % (col, t, cond)
                    t1 = add(base + ".last12", "Total %s%s in the latest 12 months (%s to %s)"
                             % (c, gwords, _ml(last[0]), _ml(last[1])), sum_sql % _between(*last), c,
                             rows_scanned=rows24)
                    t0 = add(base + ".prior12", "Total %s%s in the 12 months before (%s to %s)"
                             % (c, gwords, _ml(prior[0]), _ml(prior[1])), sum_sql % _between(*prior), c,
                             rows_scanned=rows24)
                    if t0 is None or t1 is None or t0.value <= 0 or t1.value <= 0:
                        res.unmeasured.append(
                            "The total %s%s is not compared: its total in one of the two 12-month "
                            "windows is zero or below, so it has no percentage change." % (c, gwords))
                        continue
                    chg_sql = "SELECT 100.0 * (%s) / (%s) - 100.0" % (sum_sql % _between(*last),
                                                                   sum_sql % _between(*prior))
                    change = _scalar(con, chg_sql)
                    if change is None:
                        continue
                    n_g = int(_scalar(con, cnt_all % (t, "%s AND %s" % (cond, _between(prior[0], last[1]))))
                              or 0)
                    monthly_t = _column(con, "%s SELECT (SELECT SUM(%s) FROM %s x WHERE x._month = m._month "
                                             "AND %s) FROM m ORDER BY m._month"
                                        % (_months_cte(*last), col, t, cond.replace(col, "x." + col, 1)))
                    monthly_t = [0.0 if v is None else v for v in monthly_t]
                    h = add(base + ".change",
                            "Change in the monthly total of %s%s, latest 12 months against the 12 before"
                            % (c, gwords), chg_sql, "pct", role="headline", kind="trend",
                            rows_scanned=n_g, effect_size=change / 100.0,
                            periods_observed=_held(monthly_t, t0.value / 12.0, change),
                            confounders=[x for x in confounders if not x.startswith("the mix of ")])
                    if h is None:
                        continue
                    ser_slug = "total_%s%s" % (s, ("_" + gslug) if gslug else "")
                    series_sql = ("%s SELECT m._month, COALESCE(a.v, 0) FROM m LEFT JOIN (SELECT _month, "
                                  "SUM(%s) AS v FROM %s WHERE %s AND %s GROUP BY _month) a ON a._month = "
                                  "m._month ORDER BY m._month" % (_months_cte(model_start, w.end), col, t,
                                                                 cond, _between(model_start, w.end)))
                    # one key per group ('total:amount:rent', 'total:amount:other'): a key holds
                    # no raw data value, and the two groups never share one
                    key = "total:%s%s" % (c, (":" + gslug) if gslug else "")
                    extra: Dict[str, Any] = {"rows_a_month": n_g / 24.0, "series_slug": ser_slug,
                                             "total_of": c, "additive": kind,
                                             "amount_cv": _amount_cv(con, t, col, "%s AND %s" % (
                                                 cond, _between(prior[0], last[1])))}
                    if gwhere and cur_ is not None:
                        extra["currency"] = {"column": cur_["column"], "code": gwords.strip()[3:],
                                             "levels": [v for v, _k in cur_["levels"]]}
                    elif gwhere:
                        extra["kind_split"] = {"column": split["column"], "level": split["level"],
                                               "group": "level" if gslug != "other" else "other"}
                    if st_where:
                        extra["status_excluded"] = {"column": status_ex["column"], "values": list(status_ex["values"]),
                                                    "fact": "measure.status_excluded.rows"}
                    ex = extremes.get(c)
                    if ex is not None:
                        rob = " AND NOT (%s < %r OR %s > %r)" % (col, ex["lo"], col, ex["hi"])
                        extra.update(robust_twin(
                            base + ".change_without_extremes", "the monthly total of %s%s" % (c, gwords),
                            "SELECT 100.0 * (%s) / (%s) - 100.0" % ((sum_sql % _between(*last)) + rob,
                                                                    (sum_sql % _between(*prior)) + rob),
                            series_sql.replace("WHERE %s AND %s GROUP BY" % (cond, _between(model_start, w.end)),
                                               "WHERE %s AND %s%s GROUP BY" % (cond, _between(model_start, w.end), rob), 1),
                            "gap", n_g, ex, "measure.%s.extreme_rows" % s))
                    lf_item: Optional[Dict[str, Any]] = None
                    if comp is not None:
                        extra.update(comp_extra)
                        extra["composition"] = dict(extra["composition"],
                                                    like_for_like=base + ".like_for_like.change")
                        lf_item = {"s": "SELECT SUM(%s) FROM %s WHERE %s AND %s AND %%s" % (col, t, cond, comp_where),
                                   "cond": "%s AND %s" % (cond, comp_where)}
                    trend(base + ".change", h, series_sql, "gap", [roles.date, c], key, extra=extra,
                          composition=comp is not None)
                    # the rows a month are the total's counting condition (the benchmark's level and
                    # the routing rule read mean_month); the average monthly total is kept beside it
                    it = pending[-1]
                    if it["fid"] == base + ".change":
                        it["extra"]["mean_month_total"] = (h.test or {}).get("mean_month")
                        it["extra"]["mean_month"] = n_g / 24.0
                        h.test.update({"mean_month_total": it["extra"]["mean_month_total"],
                                       "mean_month": n_g / 24.0})
                    if lf_item is not None:
                        # like for like (ship round, 24 Sep 2026): the same total on the category
                        # levels present in every modelled month, TESTED as a claim of its own (it
                        # was a descriptive SQL figure, so the primary money claim of a file whose
                        # coverage changed had no graded answer at all)
                        lf_s = lf_item["s"]
                        lcond = lf_item["cond"]
                        l1 = add(base + ".like_for_like.last12",
                                 "Total %s%s in the latest 12 months from the %s values present throughout"
                                 % (c, gwords, comp["column"]), lf_s % _between(*last), c, rows_scanned=rows24)
                        l0 = add(base + ".like_for_like.prior12",
                                 "Total %s%s in the 12 months before from the %s values present throughout"
                                 % (c, gwords, comp["column"]), lf_s % _between(*prior), c, rows_scanned=rows24)
                        if l0 is None or l1 is None or l0.value <= 0 or l1.value <= 0:
                            res.unmeasured.append(
                                "The total %s%s like for like is not compared: its total in one of the two "
                                "12-month windows is zero or below." % (c, gwords))
                        else:
                            lf_sql = "SELECT 100.0 * (%s) / (%s) - 100.0" % (lf_s % _between(*last),
                                                                            lf_s % _between(*prior))
                            lf_change = _scalar(con, lf_sql) or 0.0
                            n_lf = int(_scalar(con, cnt_all % (t, "%s AND %s" % (lcond, _between(prior[0], last[1]))))
                                       or 0)
                            lf_monthly = _column(con, "%s SELECT (SELECT SUM(%s) FROM %s x WHERE x._month = "
                                                      "m._month AND %s) FROM m ORDER BY m._month"
                                                 % (_months_cte(*last), col, t,
                                                    lcond.replace(col, "x." + col, 1)))
                            lf_monthly = [0.0 if v is None else v for v in lf_monthly]
                            lh = add(base + ".like_for_like.change",
                                     "Change in the monthly total of %s%s like for like (the %d %s values "
                                     "present in every modelled month), latest 12 months against the 12 "
                                     "before" % (c, gwords, len(comp["stable"]), comp["column"]),
                                     lf_sql, "pct", role="headline", kind="trend", rows_scanned=n_lf,
                                     effect_size=lf_change / 100.0,
                                     periods_observed=_held(lf_monthly, l0.value / 12.0, lf_change))
                            if lh is not None:
                                lf_series = ("%s SELECT m._month, COALESCE(a.v, 0) FROM m LEFT JOIN (SELECT "
                                             "_month, SUM(%s) AS v FROM %s WHERE %s AND %s GROUP BY _month) a "
                                             "ON a._month = m._month ORDER BY m._month"
                                             % (_months_cte(model_start, w.end), col, t, lcond,
                                                _between(model_start, w.end)))
                                lx: Dict[str, Any] = {"like_for_like_of": base + ".change",
                                                      "rows_a_month": n_lf / 24.0, "total_of": c,
                                                      "additive": kind,
                                                      "amount_cv": _amount_cv(con, t, col, "%s AND %s" % (
                                                          lcond, _between(prior[0], last[1]))),
                                                      "subset": {"column": comp["column"],
                                                                 "levels": list(comp["stable"])}}
                                if gwhere and "kind_split" in extra:
                                    lx["kind_split"] = dict(extra["kind_split"])
                                if "currency" in extra:
                                    lx["currency"] = dict(extra["currency"])
                                trend(base + ".like_for_like.change", lh, lf_series, "gap",
                                      [roles.date, c, comp["column"]], key + ":like_for_like", extra=lx)
                                it = pending[-1]
                                if it["fid"] == base + ".like_for_like.change":
                                    it["extra"]["mean_month_total"] = (lh.test or {}).get("mean_month")
                                    it["extra"]["mean_month"] = n_lf / 24.0
                                    lh.test.update({"mean_month_total": it["extra"]["mean_month_total"],
                                                    "mean_month": n_lf / 24.0})
                    ser = Series(ser_slug, "monthly total %s%s in %s" % (c, gwords, label),
                                 "SELECT _month, SUM(%s) FROM %s WHERE %s AND %s GROUP BY _month ORDER BY _month"
                                 % (col, t, cond, in_span), "", "zero",
                                 int(_scalar(con, cnt_all % (t, "%s AND %s" % (cond, in_span))) or 0))
                    totals.append({"key": key, "kind": kind, "size": abs(t0.value) + abs(t1.value),
                                   "series": ser, "fid": base + ".change", "base": base, "col": col,
                                   "cond": cond, "what": "%s%s" % (c, gwords), "unit": c})
            money = [x for x in totals if x["kind"] == "money"]
            if money:
                top = max(money, key=lambda x: x["size"])
                auto_primary[0] = top["key"]
                for it in pending:
                    if it["fid"] == top["fid"]:
                        it["extra"]["primary_candidate"] = True
                        it["headline"].test["primary_candidate"] = True
                _peak_fact(add, con, t, top, model_start, w.end, min_effect, rows24)
            # the forecast follows the money: the primary total first, then the row count
            ordered = sorted(totals, key=lambda x: (x["key"] != auto_primary[0], -x["size"]))
            head = [x["series"] for x in ordered[:1] if x["key"] == auto_primary[0]]
            rest = [x["series"] for x in ordered if x["series"] not in head]
            res.series[:0] = head
            res.series.extend(rest)

        # -- measures -------------------------------------------------------------
        for c in roles.measures:
            col, s = qi(at.col(c)), at.slug(c)
            where_all = "%s IS NOT NULL AND %s" % (col, in_span)
            add("measure.%s.mean" % s, "Average %s over %s to %s" % (c, _ml(w.start), _ml(w.end)),
                "SELECT AVG(%s) FROM %s WHERE %s" % (col, t, where_all), c,
                rows_scanned=at.n_rows)
            add("measure.%s.median" % s, "Median %s over %s to %s" % (c, _ml(w.start), _ml(w.end)),
                _median_sql(t, col, in_span), c, rows_scanned=at.n_rows)
            if roles.grain == "monthly":
                res.series.append(Series(s, "monthly %s" % c,
                                         "SELECT _month, SUM(%s) FROM %s WHERE %s GROUP BY _month ORDER BY _month"
                                         % (col, t, where_all), c, "none",
                                         int(_scalar(con, "SELECT COUNT(*) FROM %s WHERE %s" % (t, where_all)) or 0)))
            if not can_compare:
                continue
            w_last = "%s IS NOT NULL AND %s" % (col, _between(*last))
            w_prior = "%s IS NOT NULL AND %s" % (col, _between(*prior))
            if currency is not None and additive_kind(c) == "money":
                res.unmeasured.append(
                    "The average %s is not compared: %s holds %d currencies (%s), and an average across "
                    "currencies means nothing; each currency's monthly total is compared instead."
                    % (c, currency["column"], len(currency["levels"]),
                       ", ".join(v for v, _k in currency["levels"])))
                continue
            split = splits.get(c)
            if split is not None:
                # two kinds of value in one column: their average means nothing (review v2)
                dcol = qi(at.col(split["column"]))
                lvq = ql(split["level"])
                span24 = _between(prior[0], last[1])
                add("measure.%s.kinds.median_level" % s,
                    "Median %s where %s is '%s', over the 24 months compared"
                    % (c, split["column"], split["level"][:40]),
                    _median_sql(t, col, "%s = %s AND %s" % (dcol, lvq, span24)), c, rows_scanned=rows24)
                add("measure.%s.kinds.median_rest" % s,
                    "Median %s for the other %s values, over the 24 months compared"
                    % (c, split["column"]),
                    _median_sql(t, col, "(%s IS NULL OR %s <> %s) AND %s" % (dcol, dcol, lvq, span24)),
                    c, rows_scanned=rows24)
                res.unmeasured.append(
                    "The average %s is not compared: rows where %s is '%s' and the other rows hold "
                    "different kinds of %s, so an average across them means nothing; each kind's "
                    "monthly total is compared instead." % (c, split["column"], split["level"][:40], c))
                continue
            ex = extremes.get(c)
            rob = (" AND NOT (%s < %r OR %s > %r)" % (col, ex["lo"], col, ex["hi"])) if ex else ""
            # A month holding under a twentieth of the median month's rows is a gap, in the
            # headline and in the test alike: the month is the unit, so a one-row month would
            # weigh as much as a month of 573 rows (review of R1, 23 Sep 2026: one such month
            # flipped a measure's sign against its row-weighted change).
            floor_n, thin = _month_row_floor(con, t, col, model_start, w.end) \
                if roles.grain == "events" else (0, [])
            having = (" HAVING COUNT(%s) >= %d" % (col, floor_n)) if floor_n else ""
            floor_note = ""
            if thin:
                floor_note = ("%s with fewer than %d rows of %s (under %s of the median month) %s "
                              "left out of the change as gaps: %s"
                              % (_plural_months(len(thin)), floor_n, c, _pct_text(MONTH_ROWS_FLOOR),
                                 "is" if len(thin) == 1 else "are",
                                 ", ".join("%s (%s)" % (m, _rows_word(n)) for m, n in thin[:6])
                                 + (", ..." if len(thin) > 6 else "")))
            # the average month: the mean of the monthly means (the estimand's unit, M1)
            avg_month = ("SELECT AVG(v) FROM (SELECT AVG(%s) AS v FROM %s WHERE %%s GROUP BY _month%s)"
                         % (col, t, having))
            a1 = add("measure.%s.last12_mean" % s,
                     "Average month of %s in the latest 12 months (the mean of the monthly averages)" % c,
                     avg_month % w_last, c, rows_scanned=rows24)
            a0 = add("measure.%s.prior12_mean" % s,
                     "Average month of %s in the 12 months before (the mean of the monthly averages)" % c,
                     avg_month % w_prior, c, rows_scanned=rows24)
            if a1 is None or a0 is None:
                continue
            n_obs = int(_scalar(con, "SELECT COUNT(*) FROM %s WHERE %s IS NOT NULL AND %s"
                                % (t, col, _between(prior[0], last[1]))) or 0)
            avg = "SELECT AVG(%s) FROM %s WHERE %%s" % (col, t)
            # the row-weighted gap stays in the ledger as a labelled description, never the headline
            add("measure.%s.change_row_weighted" % s,
                "Change in the row-weighted average %s, latest 12 months against the 12 before "
                "(descriptive: every row counts once, so busy months weigh more; not the tested "
                "change)" % c, "SELECT (%s) - (%s)" % (avg % w_last, avg % w_prior), c,
                rows_scanned=n_obs)
            month_mean = ("(SELECT CASE WHEN COUNT(%s) >= %d THEN AVG(%s) END FROM %s x WHERE x._month = m._month)"
                          % (col, floor_n, col, t)) if floor_n else \
                ("(SELECT AVG(%s) FROM %s x WHERE x._month = m._month)" % (col, t))
            monthly = _column(con, "%s SELECT %s FROM m ORDER BY m._month" % (_months_cte(*last), month_mean))
            floor_cav = [floor_note] if floor_note else []
            # A percentage needs every average month in the two compared windows above zero: a
            # score whose monthly means are negative, or cross zero, has no ratio (the R1 review:
            # "An 81% difference" for a score whose monthly means ran -0.117 to -0.211). Such a
            # change is stated as a difference in the measure's own units.
            w_both = "%s IS NOT NULL AND %s" % (col, _between(prior[0], last[1]))
            lowest = _scalar(con, avg_month.replace("SELECT AVG(v)", "SELECT MIN(v)", 1) % w_both)
            ratio_ok = a0.value > 0 and a1.value > 0 and lowest is not None and lowest > 0
            if ratio_ok:
                chg_sql = "SELECT 100.0 * (%s) / (%s) - 100.0" % (avg_month % w_last, avg_month % w_prior)
                change = _scalar(con, chg_sql)
                if change is None:
                    continue
                h = add("measure.%s.change" % s,
                        "Change in the average month of %s, latest 12 months against the 12 before" % c,
                        chg_sql, "pct", role="headline", kind="trend", rows_scanned=n_obs,
                        effect_size=change / 100.0,
                        periods_observed=_held(monthly, a0.value, change), confounders=list(confounders),
                        caveats=floor_cav)
                series_sql = ("%s SELECT m._month, a.v FROM m LEFT JOIN (SELECT _month, AVG(%s) AS v "
                              "FROM %s WHERE %s IS NOT NULL AND %s GROUP BY _month%s) a ON a._month = m._month "
                              "ORDER BY m._month" % (_months_cte(model_start, w.end), col, t, col,
                                                     _between(model_start, w.end), having))
                mx: Dict[str, Any] = {}
                if ex is not None:
                    mx = robust_twin(
                        "measure.%s.change_without_extremes" % s, "the average month of %s" % c,
                        "SELECT 100.0 * (%s) / (%s) - 100.0" % (avg_month % (w_last + rob),
                                                                avg_month % (w_prior + rob)),
                        ("%s SELECT m._month, a.v FROM m LEFT JOIN (SELECT _month, AVG(%s) AS v FROM %s "
                         "WHERE %s IS NOT NULL AND %s%s GROUP BY _month%s) a ON a._month = m._month "
                         "ORDER BY m._month" % (_months_cte(model_start, w.end), col, t, col,
                                                _between(model_start, w.end), rob, having)),
                        "refuse", n_obs, ex, "measure.%s.extreme_rows" % s)
                trend("measure.%s.change" % s, h, series_sql, "refuse", [roles.date, c], c, floor_note,
                      extra=mx)
            else:
                # no ratio: the gap is reported in the measure's own unit, untested (the gate
                # holds an untested change at WATCH at most and never prints it as a percentage)
                diff_sql = "SELECT (%s) - (%s)" % (avg_month % w_last, avg_month % w_prior)
                diff = _scalar(con, diff_sql) or 0.0
                why = ("its average month in the earlier window is at or below zero"
                       if a0.value <= 0 else
                       "its average month in the latest window is at or below zero"
                       if a1.value <= 0 else
                       "some of its monthly averages in the two compared windows are at or below "
                       "zero (they cross zero)")
                h = add("measure.%s.change" % s,
                        "Change in the average month of %s, latest 12 months against the 12 before" % c,
                        diff_sql, c, role="headline", kind="trend", rows_scanned=n_obs,
                        effect_size=(diff / abs(a0.value)) if a0.value else 0.0,
                        periods_observed=_held(monthly, a0.value, diff), confounders=list(confounders),
                        caveats=["%s, so the change has no ratio and is stated in the measure's own "
                                 "units; no change test was run" % why] + floor_cav)
                if h is not None:
                    h.claim_key = c
                    h.claim_health = _claim_health(claim_health, [roles.date, c])
                    # why no test (the gate's "what would settle it" reads this: review of R1)
                    h.test = {"ran": False, "no_ratio": True, "lowest_month_mean": lowest,
                              "not_run": ("%s, so a percentage change, and a percentage bar, have "
                                          "no meaning for it" % why)}

        settle_claims()

        # -- what this engine does not measure, named when the file invites the question ------
        cust = [c for c in list(roles.excluded) + list(roles.dimensions)
                if set(_name_tokens(c)) & _CUSTOMER_WORDS]
        if cust and can_compare:
            res.unmeasured.append(
                "Churn and retention are not measured: the file names each %s (%s) and dates each row, "
                "but this engine compares monthly totals and counts, not how long each %s stays or "
                "what each one spends." % (sorted(set(_name_tokens(cust[0])) & _CUSTOMER_WORDS)[0].rstrip("s"),
                                           cust[0], sorted(set(_name_tokens(cust[0])) & _CUSTOMER_WORDS)[0].rstrip("s")))

        # -- steps the forecast must know about (ship round, 24 Sep 2026) -----------------
        # A level shift a change test found in a series (at a change in what the file covers,
        # or the step screen's single shift) is handed to that series' forecast: a model fitted
        # across it carries the old level in its errors, and its range widens with them.
        by_slug = {x.slug: x for x in res.series}
        for it in pending:
            tt = it["headline"].test or {}
            slug_ = tt.get("series_slug") or ("monthly_rows" if it["fid"] == "measure.volume.change_pct" else "")
            ser_ = by_slug.get(slug_)
            if ser_ is None:
                continue
            named = [x for x in ((tt.get("composition_steps") or {}).get("named") or [])]
            st_ = tt.get("step") or {}
            if named:
                top_ = named[0]
                ser_.step = {"month": top_["month"], "size": top_["size"], "kind": "composition",
                             "why": "; ".join("'%s' %s" % (lv[:40], verb) for lv, verb in top_["levels"]),
                             "fact": top_["fact"], "claim": it["fid"],
                             # every named step, for a forecast that must fit across them
                             "steps": [{"month": x["month"], "size": x["size"]} for x in named]}
            elif st_.get("explains") and st_.get("month") is not None:
                ser_.step = {"month": _ml(int(st_["month"])), "size": float(st_["size"]), "kind": "step",
                             "why": "", "fact": "", "claim": it["fid"]}

        # -- dimensions -----------------------------------------------------------
        for c in roles.dimensions:
            col, s = qi(at.col(c)), at.slug(c)
            top = con.execute("SELECT %s, COUNT(*) FROM %s WHERE %s AND %s IS NOT NULL GROUP BY %s "
                              "ORDER BY 2 DESC, 1 LIMIT %d" % (col, t, in_span, col, col, TOP_N)).fetchall()
            for rank, (val, _n) in enumerate(top, start=1):
                add("measure.%s.share.%d" % (s, rank),
                    "Share of rows where %s is '%s' (rank %d by rows), %s to %s"
                    % (c, str(val)[:60], rank, _ml(w.start), _ml(w.end)),
                    "SELECT 100.0 * SUM(CASE WHEN %s = %s THEN 1 ELSE 0 END) / COUNT(*) FROM %s WHERE %s"
                    % (col, ql(val), t, in_span), "pct", rows_scanned=at.n_rows)
    finally:
        con.close()
    return res


# --------------------------------------------------------------------------- review v2 helpers
# Additive measures (review v2, 24 Sep 2026): the engine analysed row counts and per-row averages
# and never a total, so "rent collected" and "revenue" were absent. A measure whose name's head
# word is money or a count of things adds up across rows; its monthly TOTAL is a claim of its own.
_MONEY_WORDS = frozenset(("amount", "amounts", "revenue", "revenues", "sales", "sale", "cost", "costs",
                          "fee", "fees", "spend", "spending", "expense", "expenses", "income",
                          "payment", "payments", "gmv", "rent", "rents", "paid", "charge", "charges",
                          "refund", "refunds", "profit", "profits", "total", "totals", "subtotal",
                          "invoiced", "billed", "turnover", "takings", "wage", "wages", "salary",
                          "salaries", "payroll"))
_UNIT_COUNT_WORDS = frozenset(("units", "qty", "quantity", "quantities", "count", "counts", "items",
                               "pieces", "visits", "violations", "orders", "tickets", "calls",
                               "sessions", "bookings", "admissions", "shipments", "deliveries"))
_NOT_ADDITIVE = frozenset(("avg", "average", "mean", "median", "per", "rate", "pct", "percent",
                           "percentage", "ratio", "share", "price", "prices", "score", "rating",
                           "index", "balance", "level", "min", "max", "margin", "age"))


def additive_kind(name: Any) -> str:
    """'money', 'units' or '' (not additive) for a measure, from its name's head word."""
    toks = _name_tokens(name)
    if not toks or set(toks) & _NOT_ADDITIVE:
        return ""
    head = _head_tokens(toks)[-1]
    if head in _MONEY_WORDS:
        return "money"
    if head in _UNIT_COUNT_WORDS:
        return "units"
    return ""


#: A level of a category "starts" (or "stops") inside the modelled months when it has no row
#: before (after) that month, holds at least COMPOSITION_MIN_SHARE of the modelled rows, and is
#: present in at least COMPOSITION_PRESENCE of the months from its first to its last row (a
#: seasonal category that comes and goes is not a start or a stop).
COMPOSITION_MIN_SHARE = 0.02
COMPOSITION_PRESENCE = 0.75


def _composition(con: sqlite3.Connection, t: str, at: AnalysisTable, start: int,
                 end: int) -> Optional[Dict[str, Any]]:
    """
    A change in what the file covers inside the modelled months [start, end]: the levels of one
    category that start or stop there (review v2, 24 Sep 2026: two buildings bought mid-way were
    reported as 'drift'). Of the categories where this happens, the one with the fewest levels
    (the coarsest description, 'Property' before 'Unit') is chosen. Returns None when no category
    changed, or when no level is present across the whole span to compare like with like.
    """
    best: Optional[Dict[str, Any]] = None
    for d in at.roles.dimensions:
        col = qi(at.col(d))
        # levels compared case- and space-blind: 'PARKDALE WALK-UP' is Parkdale Walk-Up
        key = "LOWER(TRIM(%s))" % col
        rows = con.execute("SELECT %s, _month, COUNT(*) FROM %s WHERE %s IS NOT NULL AND _month IS NOT "
                           "NULL AND _month <= %s GROUP BY 1, 2" % (key, t, col, ql(_ml(end)))).fetchall()
        spell = {}
        for k, v, n in con.execute("SELECT %s, %s, COUNT(*) FROM %s WHERE %s IS NOT NULL GROUP BY 1, 2 "
                                   "ORDER BY 3 DESC, 2" % (key, col, t, col)).fetchall():
            spell.setdefault(str(k), str(v))
        per: Dict[str, Dict[int, int]] = {}
        for lv, m, n in rows:
            per.setdefault(str(lv), {})[_mi(m)] = int(n)
        if len(per) < 2 or len(per) > MAX_DIM_LEVELS:
            continue
        in_span = {lv: sum(n for m, n in ms.items() if start <= m <= end) for lv, ms in per.items()}
        total = float(sum(in_span.values())) or 1.0
        entered: List[Tuple[str, int]] = []
        left: List[Tuple[str, int]] = []
        for lv, ms in per.items():
            first, last_m = min(ms), max(ms)
            presence = len(ms) / float(last_m - first + 1)
            share = in_span[lv] / total
            if share < COMPOSITION_MIN_SHARE or presence < COMPOSITION_PRESENCE:
                continue
            if start + 3 <= first <= end - 2:
                entered.append((lv, first))
            elif start <= last_m <= end - 3 and last_m - first + 1 >= 3:
                left.append((lv, last_m))
        if not entered and not left:
            continue
        moved = {lv for lv, _ in entered} | {lv for lv, _ in left}
        stable = sorted(lv for lv, ms in per.items()
                        if lv not in moved and min(ms) <= start and max(ms) >= end - 2)
        if not stable:
            continue
        cand = {"column": d, "levels": len(per), "key": key,
                "entered": sorted(((spell.get(lv, lv), m) for lv, m in entered), key=lambda x: (x[1], x[0])),
                "left": sorted(((spell.get(lv, lv), m) for lv, m in left), key=lambda x: (x[1], x[0])),
                "stable": stable, "moved": sorted(moved),
                "moved_share": sum(in_span[lv] for lv in moved) / total}
        if best is None or (cand["levels"], -cand["moved_share"]) < (best["levels"], -best["moved_share"]):
            best = cand
    return best


def _in_list(col: str, values: Sequence[str]) -> str:
    return "%s IN (%s)" % (col, ", ".join(ql(v) for v in values))


def composition_words(comp: Dict[str, Any]) -> str:
    """'East York Low-Rise' first appears in 2025-03; 'Junction Six-Plex' in 2024-07 ..."""
    parts = []
    for i, (lv, m) in enumerate(comp["entered"][:4]):
        parts.append("'%s' first appears in %s" % (lv[:40], _ml(m)))
    for lv, m in comp["left"][:4]:
        parts.append("'%s' has no rows after %s" % (lv[:40], _ml(m)))
    more = len(comp["entered"]) + len(comp["left"]) - len(parts)
    if more > 0:
        parts.append("and %d more" % more)
    return "; ".join(parts)


#: A measure whose values fall into two kinds (review v2: rent near 2,050 and repairs near 300 in
#: one 'Amount' column) is split by the category level that separates them: a level holding at
#: least KIND_MIN_SHARE of the rows whose median is at least KIND_RATIO times the rest's (or at
#: most 1/KIND_RATIO), with the two groups' middle halves not overlapping.
KIND_MIN_SHARE = 0.15
KIND_RATIO = 4.0
KIND_MAX_LEVELS = 12

#: Size alone is not a different kind of money (fixer round, 24 Sep 2026: a coffee shop's cheap
#: 'Drinks' lines, median 38.7 against 381.9, split net sales in two and total sales appeared in
#: no claim). The split also needs evidence that the two groups sit on different sides of the
#: ledger: medians of opposite sign, or level names that read as money coming in (rent, sales,
#: fees) against money going out (repairs, utilities, wages), or the reverse.
_LEDGER_IN = frozenset((
    "rent", "rents", "rental", "rentals", "lease", "leases", "sale", "sales", "revenue", "revenues",
    "income", "incomes", "receipt", "receipts", "deposit", "deposits", "credit", "credits", "inflow",
    "inflows", "tuition", "dues", "donation", "donations", "subscription", "subscriptions",
    "royalty", "royalties", "interest", "dividend", "dividends",
    "grant", "grants", "earnings", "takings", "collected", "collection", "collections"))
_LEDGER_OUT = frozenset((
    "repair", "repairs", "maintenance", "plumbing", "electrical", "electric", "heating", "cooling",
    "hvac", "cleaning", "janitorial", "landscaping", "snow", "removal", "pest", "control",
    "appliance", "appliances", "utility", "utilities", "hydro", "gas", "water", "power", "insurance",
    "tax", "taxes", "property_tax", "payroll", "wage", "wages", "salary", "salaries", "expense",
    "expenses", "cost", "costs", "supplies", "supply", "materials", "contractor", "contractors",
    "debit", "debits", "outflow", "outflows", "withdrawal", "withdrawals", "refund", "refunds",
    "commission", "commissions", "advertising", "marketing", "mortgage", "loan",
    "loans", "purchase", "purchases", "vendor", "vendors", "bill", "bills", "freight", "shipping",
    "postage", "rent_expense", "renovation", "renovations", "capex", "legal", "accounting",
    "security", "roofing", "painting", "flooring", "elevator", "garbage", "waste", "internet",
    "phone", "software", "travel", "meals", "fuel", "parking"))


def ledger_side(name: Any) -> str:
    """'in' for a level named like money coming in, 'out' for money going out, '' otherwise."""
    toks = set(re.findall(r"[a-z]+", str(name or "").lower()))
    i, o = bool(toks & _LEDGER_IN), bool(toks & _LEDGER_OUT)
    return "in" if (i and not o) else "out" if (o and not i) else ""


def _kind_split(con: sqlite3.Connection, t: str, at: AnalysisTable, c: str,
                where: str) -> Optional[Dict[str, Any]]:
    """The category level that splits measure c into two kinds of value, or None."""
    col = qi(at.col(c))
    best: Optional[Dict[str, Any]] = None
    for d in at.roles.dimensions:
        dcol = qi(at.col(d))
        rows = con.execute("SELECT %s, %s FROM %s WHERE %s IS NOT NULL AND %s IS NOT NULL AND %s"
                           % (dcol, col, t, col, dcol, where)).fetchall()
        if len(rows) < 50:
            continue
        levels: Dict[str, List[float]] = {}
        for lv, v in rows:
            levels.setdefault(str(lv), []).append(float(v))
        if not (2 <= len(levels) <= KIND_MAX_LEVELS):
            continue
        n = float(len(rows))
        for lv, vals in levels.items():
            if len(vals) < KIND_MIN_SHARE * n or len(vals) > (1.0 - KIND_MIN_SHARE) * n:
                continue
            rest = np.array([v for k, vs in levels.items() if k != lv for v in vs], dtype=float)
            a = np.abs(np.array(vals, dtype=float))
            b = np.abs(rest)
            ma, mb = float(np.median(a)), float(np.median(b))
            if min(ma, mb) <= 0:
                continue
            ratio = max(ma, mb) / min(ma, mb)
            hi_g, lo_g = (a, b) if ma > mb else (b, a)
            if ratio < KIND_RATIO or float(np.percentile(hi_g, 25)) <= float(np.percentile(lo_g, 75)):
                continue
            # a different kind of money, not size alone (see _LEDGER_IN)
            med_l, med_r = float(np.median(vals)), float(np.median(rest))
            side_l = ledger_side(lv)
            rest_sides: Dict[str, int] = {}
            for k, vs in levels.items():
                if k != lv:
                    sd = ledger_side(k)
                    rest_sides[sd] = rest_sides.get(sd, 0) + len(vs)
            side_r = max(rest_sides, key=lambda x: (rest_sides[x], x)) if rest_sides else ""
            if med_l * med_r < 0:
                evidence = "sign"
            elif side_l and side_r and side_l != side_r:
                evidence = "names"
            else:
                continue
            cand = {"column": d, "level": lv, "ratio": ratio, "median_level": med_l,
                    "median_rest": med_r, "rows_level": len(vals),
                    "rows_rest": int(len(rest)), "evidence": evidence,
                    "side_level": side_l, "side_rest": side_r}
            if best is None or ratio > best["ratio"]:
                best = cand
    return best


#: Screens that run before any money is added up (fixer round, 24 Sep 2026: a subscription export
#: summed 16,338 USD and 5,130 CAD invoices, refunded and failed ones included, into one
#: "+5.5%"). A currency column with two or more currencies splits every money total by currency
#: (never added across); a status column whose values include refunds, failures or voids takes
#: those rows out of every money total. Both are said in the story.
_ISO_CURRENCIES = frozenset((
    "usd", "cad", "eur", "gbp", "aud", "nzd", "jpy", "cny", "rmb", "inr", "bdt", "chf", "sek", "nok",
    "dkk", "pln", "czk", "huf", "mxn", "brl", "ars", "clp", "cop", "pen", "zar", "ngn", "kes", "egp",
    "aed", "sar", "qar", "ils", "try", "rub", "uah", "krw", "twd", "hkd", "sgd", "myr", "thb", "idr",
    "php", "vnd", "pkr", "lkr", "npr"))
_CURRENCY_NAME = frozenset(("currency", "currencies", "ccy", "curr", "iso_currency", "currency_code"))
CURRENCY_MIN_SHARE = 0.01
_NOT_REVENUE_STATUS = frozenset((
    "refunded", "refund", "refunds", "failed", "failure", "void", "voided", "cancelled", "canceled",
    "cancellation", "declined", "chargeback", "charged back", "charged_back", "reversed", "reversal",
    "returned", "rejected", "uncollectible", "written off", "written_off", "write-off", "write off",
    "bounced", "disputed", "unpaid", "past due", "past_due", "overdue"))
STATUS_MAX_LEVELS = 20


def _currency_split(con: sqlite3.Connection, t: str, at: AnalysisTable, where: str) -> Optional[Dict[str, Any]]:
    """The column that says which currency each row is in, when it holds two or more currencies
    (each on at least CURRENCY_MIN_SHARE of the rows): {"column", "levels": [(code, rows), ...]}."""
    for d in at.roles.dimensions:
        dcol = qi(at.col(d))
        rows = con.execute("SELECT UPPER(TRIM(%s)), COUNT(*) FROM %s WHERE %s IS NOT NULL AND %s GROUP BY 1 "
                           "ORDER BY 2 DESC, 1" % (dcol, t, dcol, where)).fetchall()
        n = float(sum(int(k) for _v, k in rows)) or 1.0
        named = bool(set(_name_tokens(d)) & _CURRENCY_NAME) or "currency" in str(d).lower()
        iso = sum(int(k) for v, k in rows if str(v).lower() in _ISO_CURRENCIES) / n
        if not (named or iso >= 0.95):
            continue
        levels = [(str(v), int(k)) for v, k in rows if int(k) >= CURRENCY_MIN_SHARE * n]
        if len(levels) >= 2 and iso >= 0.5:
            return {"column": d, "levels": levels}
    return None


def _status_exclusion(con: sqlite3.Connection, t: str, at: AnalysisTable, where: str) -> Optional[Dict[str, Any]]:
    """The column whose values mark rows that are not money received (refunded, failed, void...):
    {"column", "values": [...], "counts": [(value, rows)], "rows": total}; None when there is none."""
    for d in at.roles.dimensions:
        dcol = qi(at.col(d))
        rows = con.execute("SELECT LOWER(TRIM(%s)), COUNT(*) FROM %s WHERE %s IS NOT NULL AND %s GROUP BY 1 "
                           "ORDER BY 2 DESC, 1" % (dcol, t, dcol, where)).fetchall()
        if not (2 <= len(rows) <= STATUS_MAX_LEVELS):
            continue
        bad = [(str(v), int(k)) for v, k in rows if str(v) in _NOT_REVENUE_STATUS]
        if not bad or sum(k for _v, k in bad) >= sum(int(k) for _v, k in rows):
            continue
        return {"column": d, "values": [v for v, _k in bad], "counts": bad,
                "rows": sum(k for _v, k in bad)}
    return None


def _peak_fact(add: Any, con: sqlite3.Connection, t: str, top: Dict[str, Any], start: int, end: int,
               bar: float, rows24: int) -> None:
    """The fall since the primary total's peak (see PEAK_MIN_AGE): three descriptive facts, only
    when the turn is clear."""
    col, cond = top["col"], top["cond"]
    inner = cond.replace(col, "x." + col, 1)
    vals = [float(v or 0.0) for v in _column(con, "%s SELECT (SELECT SUM(%s) FROM %s x WHERE x._month = "
                                                  "m._month AND %s) FROM m ORDER BY m._month"
                                             % (_months_cte(start, end), "x." + col, t, inner))]
    if len(vals) < 12:
        return
    roll = [sum(vals[i - 2:i + 1]) / 3.0 for i in range(2, len(vals))]
    k = max(range(len(roll)), key=lambda i: (roll[i], -i))
    peak_end = start + k + 2
    latest = roll[-1]
    if roll[k] <= 0 or end - peak_end < PEAK_MIN_AGE or latest / roll[k] - 1.0 > -float(bar):
        return
    three = ("WITH m AS (SELECT %%s AS _month UNION ALL SELECT %%s UNION ALL SELECT %%s) SELECT "
             "SUM(COALESCE((SELECT SUM(%s) FROM %s x WHERE x._month = m._month AND %s), 0)) / 3.0 FROM m"
             % ("x." + col, t, inner))
    p_sql = three % tuple(ql(_ml(peak_end - j)) for j in (2, 1, 0))
    l_sql = three % tuple(ql(_ml(end - j)) for j in (2, 1, 0))
    base = top["base"]
    add(base + ".peak3", "Highest 3-month average of the monthly total of %s, the 3 months to %s"
        % (top["what"], _ml(peak_end)), p_sql, top["unit"], rows_scanned=rows24)
    add(base + ".latest3", "Average monthly total of %s in the latest 3 months, to %s" % (top["what"], _ml(end)),
        l_sql, top["unit"], rows_scanned=rows24)
    add(base + ".from_peak", "Change in the monthly total of %s from its highest 3-month average (the 3 "
        "months to %s) to the latest 3 months (to %s); a description found by looking, not a tested "
        "change" % (top["what"], _ml(peak_end), _ml(end)),
        "SELECT 100.0 * (%s) / (%s) - 100.0" % (l_sql, p_sql), "pct", rows_scanned=rows24)


def status_words(st: Dict[str, Any]) -> str:
    """'337 refunded and 281 failed' (largest first)."""
    parts = ["%s %s" % (format(k, ","), v) for v, k in st["counts"]]
    return parts[0] if len(parts) == 1 else ", ".join(parts[:-1]) + " and " + parts[-1]


#: A turn inside the compared window (fixer round, 24 Sep 2026: subscription revenue peaked in
#: mid-2025 and fell every month since, while the 12-against-12 comparison read +5.5%). When the
#: primary total's highest 3-month average ends at least PEAK_MIN_AGE months before the end and
#: the latest 3 months sit at least the materiality bar below it, the fall since the peak is
#: stated beside the 12-versus-12 figure, as a description (it is found by looking, so it is
#: never tested or graded).
PEAK_MIN_AGE = 6
_CUSTOMER_WORDS = frozenset(("customer", "customers", "client", "clients", "member", "members",
                             "subscriber", "subscribers", "account", "accounts", "patient", "patients",
                             "user", "users", "donor", "donors", "tenant", "tenants"))


#: A value more than EXTREME_MADS robust standard deviations (1.4826 x MAD) from the median is
#: extreme; the screen reports it when such values are rare (at most EXTREME_MAX_SHARE of rows).
EXTREME_MADS = 10.0
EXTREME_MAX_SHARE = 0.01


def _extremes(con: sqlite3.Connection, t: str, col: str, where: str) -> Optional[Dict[str, Any]]:
    """A measure's extreme rows (review v2: six rows of Units = 9,999 drove '-68.2%')."""
    vals = np.array([r[0] for r in con.execute("SELECT %s FROM %s WHERE %s IS NOT NULL AND %s"
                                               % (col, t, col, where)).fetchall()], dtype=float)
    if len(vals) < 50:
        return None
    med = float(np.median(vals))
    mad = 1.4826 * float(np.median(np.abs(vals - med)))
    if mad > 0:
        lo, hi = med - EXTREME_MADS * mad, med + EXTREME_MADS * mad
    elif med != 0:
        lo, hi = med - 100.0 * abs(med), med + 100.0 * abs(med)
    else:
        return None
    bad = (vals < lo) | (vals > hi)
    k = int(bad.sum())
    if not k or k > EXTREME_MAX_SHARE * len(vals):
        return None
    ex = sorted(set(float(v) for v in vals[bad]), key=lambda v: -abs(v - med))[:3]
    return {"lo": float(lo), "hi": float(hi), "k": k, "n": int(len(vals)), "median": med,
            "examples": ex}


#: A month holding under this share of the median month's rows (for one measure) is a gap in
#: that measure's change: headline and test alike (review of R1, 23 Sep 2026).
MONTH_ROWS_FLOOR = 0.05


def _month_row_floor(con: sqlite3.Connection, t: str, col: str, start: int,
                     end: int) -> Tuple[int, List[Tuple[str, int]]]:
    """(the least rows a month needs, the months under it) for one measure over the model's months."""
    rows = con.execute("SELECT _month, COUNT(%s) FROM %s WHERE %s IS NOT NULL AND %s GROUP BY _month "
                       "ORDER BY _month" % (col, t, col, _between(start, end))).fetchall()
    if not rows:
        return 0, []
    med = float(np.median([int(n) for _, n in rows]))
    need = int(math.ceil(MONTH_ROWS_FLOOR * med - 1e-9))
    if need < 2:
        return 0, []
    return need, [(str(m), int(n)) for m, n in rows if int(n) < need]


def _fmt(v: float) -> str:
    """A threshold as a claim prints it (no more digits than it needs)."""
    v = float(v)
    if abs(v) >= 100:
        return format(int(round(v)), ",")
    return "%.3g" % v


def _plural_months(n: int) -> str:
    return "1 month" if n == 1 else "%d months" % n


def _rows_word(n: int) -> str:
    return "1 row" if n == 1 else "%s rows" % format(int(n), ",")


def _thresholds(q: float, n_claims: int) -> List[float]:
    """
    The decision thresholds a claim's p could meet: q alone (a primary claim) and the
    Benjamini-Hochberg steps q*j/m of a family of up to n_claims (M3). Kept for callers; since
    the R1 review the change test is extended only against the line that decides the claim
    (measure_facts' provisional family pass), not against every step here.
    """
    m = max(1, int(n_claims))
    return sorted({round(float(q) * j / m, 12) for j in range(1, m + 1)} | {float(q)})


def _claim_seed(fid: str) -> int:
    """A claim's bootstrap seed: fixed by the engine seed and the claim's id alone."""
    import zlib
    return int(zlib.crc32(("%s|%d" % (fid, SEED)).encode("utf-8")))


def _pct_text(fraction: float) -> str:
    v = 100.0 * float(fraction)
    return ("%d%%" % int(round(v))) if abs(v - round(v)) < 1e-9 else ("%.1f%%" % v)


def column_claim_health(health: Any) -> Dict[str, float]:
    """
    Health of each column for the claims that read it (design M9): the minimum of its
    completeness (100 - null-like share) and validity (see _claim_validity), with the
    table's uniqueness. A claim
    takes the minimum over its columns, so a claim on a 45%-empty column scores 55 however
    clean the rest of the table is.
    """
    out: Dict[str, float] = {}
    if health is None:
        return out
    dims = getattr(health, "dimensions", None) or {}
    uniq = dims.get("uniqueness")
    for ch in getattr(health, "columns", None) or []:
        parts = [100.0 - float(getattr(ch, "pct_null_like", 0.0) or 0.0)]
        v = _claim_validity(ch)
        if v is not None:
            parts.append(100.0 * v)
        if uniq is not None:
            parts.append(float(uniq))
        out[str(ch.name)] = round(max(0.0, min(parts)), 1)
    return out


def _claim_validity(ch: Any) -> Optional[float]:
    """
    Validity as a claim meets it: the share of the column's non-empty values that read as
    the column's own type (a number in a numeric column, a date in a date column). The
    profile's validity also halves a numeric column whose numbers were LANDED as text
    (SQLite storage class), which every CSV is: cleaning casts those before any claim reads
    them, so that penalty describes the landing, not the values, and is left out here.
    """
    counts = getattr(ch, "class_counts", None) or {}
    nn = int(getattr(ch, "n_non_null", 0) or 0)
    if not counts or nn <= 0:
        v = getattr(ch, "validity", None)
        return None if v is None else float(v)
    return max(0.0, min(1.0, max(int(x) for x in counts.values()) / float(nn)))


def _claim_health(health: Optional[Dict[str, float]], cols: Sequence[str]) -> Optional[float]:
    if not health:
        return None
    vals = [health[c] for c in cols if c and c in health]
    return min(vals) if vals else None


def _test_summary(res: Dict[str, Any], start: str, end: str) -> Dict[str, Any]:
    """The change test's numbers the gate and the report read (the payload holds the rest)."""
    keep = ("ran", "not_run", "method", "bar", "direction", "delta_hat", "se", "sigma_hat", "effect_model",
            "phi_hat", "phi_hat_2d", "noise_share_hat", "phi_cap", "phi_boot", "phi_restricted",
            "n", "params", "df", "seasonal_terms", "seasonal_rule", "older_term",
            "p_min_effect", "p_nonzero", "b", "mc_interval", "mc_level", "mc_straddles",
            "ci_level", "ci_low", "ci_high", "ci_method", "ci_b", "ci_table", "fcr_bounds",
            "drift_screen", "months_observed", "months_gap", "months_in_model", "months_usable",
            "never_observed_months", "nonpositive_months", "nonpositive_gaps", "headline",
            "estimand_mismatch", "estimand_z", "unit_root", "trend", "mean_month",
            "seasonal", "seasonal_p", "screen_kind", "step", "ci_test_agree", "composition_step")
    out = {k: res[k] for k in keep if k in res}
    out["model_months"] = [start, end]
    return out


def _amount_cv(con: sqlite3.Connection, t: str, col: str, where: str) -> Optional[float]:
    """The CV of the row values a total adds up (SD over mean, population form): with the rows a
    month it sets the total's counting noise, (1 + CV^2) / rows (ship round, 24 Sep 2026)."""
    r = con.execute("SELECT AVG(%s), AVG(%s * %s), COUNT(%s) FROM %s WHERE %s"
                    % (col, col, col, col, t, where)).fetchone()
    if not r or r[0] is None or not r[2] or float(r[0]) == 0.0:
        return None
    var = max(float(r[1]) - float(r[0]) ** 2, 0.0)
    return math.sqrt(var) / abs(float(r[0]))


def _held(monthly: Sequence[float], baseline: float, change: float) -> int:
    """Months of the latest window that sit on the side of the baseline the change points to."""
    if change > 0:
        return int(sum(1 for v in monthly if v is not None and v > baseline))
    if change < 0:
        return int(sum(1 for v in monthly if v is not None and v < baseline))
    return 0
